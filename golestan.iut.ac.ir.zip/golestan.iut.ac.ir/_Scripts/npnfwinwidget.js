var $openedwin, $iswinopen = !1,
    $openedwinAut = [],
    $openedwinACT = "",
    $openedwinInXML = null,
    $opener_openedwin, $opener_openedwinAut = {},
    $opener_iswinopen = !1;

function npnfopenwin(a, b, c, d, e) {
    $openedwin = $("<DIV></DIV>").addClass("ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix").draggable({
        containment: "parent",
        cursorAt: {
            top: 5
        }
    }).css({
        "background-repeat": "repeat",
        "background-position-y": "52px"
    }).appendTo($("body")).faciinwin({
        w: a,
        url: b,
        opid: c,
        inxml: e,
        act: d,
        opener: $openedwin
            /*,
            		openeraut : $openedwinAut*/
            ,
        openerisopen: $iswinopen
    }).css({
        display: "none",
        position: "absolute",
        "z-index": 1E7,
        width: "100%",
        height: "100%"
    })
    $openedwinAut.push({});
    $openedwin.faciinwin("option", "openeraut", $openedwinAut);
}

function npnfclosewin(a) {
    var b = $openedwin;
    b.faciinwin("close", a);
    setTimeout(function() {
        $(b).remove();
    }, 0)
}

function npnfwinopenerid() {
    return $openedwin.faciinwin("option", "opid")
}

function currframeid() {
    return $openedwin.faciinwin("frameid")
}

function npnfwinscale(a, b) {
    $openedwin.faciinwin("scale", a, b)
}

$.widget("np.faciinwin", {
    options: {
        w: null,
        url: "",
        opid: "",
        inxml: null,
        act: "",
        opener: null,
        openeraut: null,
        openeract: null,
        openerisopen: null
    },
    ifr: null,
    overlay: null,
    _create: function() {
        var a = this,
            b = a.options,
            c = a.element;
        if (t.ready < 0)
            return alert("\u0627\u0645\u06a9\u0627\u0646 \u0628\u0627\u0632 \u06a9\u0631\u062f\u0646 \u0635\u0641\u062d\u0647 \u062c\u062f\u064a\u062f \u062f\u0631 \u062d\u0627\u0644 \u062d\u0627\u0636\u0631 \u0648\u062c\u0648\u062f \u0646\u062f\u0627\u0631\u062f."), -1;
        t.ready--;
        a.overlay = $('<div class="ui-widget-overlay"></div>').css({
            "z-index": 1E7
        }).insertBefore($(c));
        a.closeButt = $('<a href="#"></a>').addClass("ui-dialog-titlebar-close ui-corner-all").attr("role", "button").hover(function() {
            a.closeButt.addClass("ui-state-hover")
        }, function() {
            a.closeButt.removeClass("ui-state-hover")
        }).focus(function() {
            a.closeButt.addClass("ui-state-focus")
        }).blur(function() {
            a.closeButt.removeClass("ui-state-focus")
        }).click(function(b) {
            if (window.ActiveXObject)
                a.ifr[0].contentWindow.document.frames.Commander.IM90_gomenu.click();
            else
                a.ifr[0].contentWindow.frames.Commander.IM90_gomenu.click();
            b.preventDefault();
            return !1
        }).text("").appendTo(c);
        $("<span></span>").addClass("ui-icon ui-icon-closethick").text("").appendTo(a.closeButt);
        a.ifr = $("<IFRAME></IFRAME>").css({
            width: "100%",
            height: "100%"
        }).appendTo(c);
        setTimeout(function() {
            a.ifr.attr("src", b.url)
        }, 10);
        setTimeout(function() {
            c.show()
        }, 100);
        $iswinopen = !0;
        $openedwinInXML = b.inxml;
        $openedwinACT = b.act
    },
    scale: function(a, b) {
        var c = this.element;
        $(c).css({
            width: a,
            height: b
        });
        $(this.ifr).css({
            width: a - 3,
            height: b - 17,
            position: "absolute",
            top: 15
        });
        c.position({
            my: "center center",
            at: "center center",
            of: $(window)
        })
    },
    frameid: function() {
        return this.ifr.attr("uniqueID")
    },
    close: function(a) {
        var b = this.options;
        $openedwin = b.opener;
        $iswinopen = b.openerisopen;
        //$openedwinAut[$openedwinAut.length-1] = b.openeraut[b.openeraut.length-1];
        $openedwinAut.pop();
        $openedwinACT = "";
        $openedwinInXML = null;
        b.w.onclose(a)
    },
    _destroy: function() {
        $(this.closeButt).remove();
        $(this.ifr).remove();
        $(this.overlay).remove()
    }
});