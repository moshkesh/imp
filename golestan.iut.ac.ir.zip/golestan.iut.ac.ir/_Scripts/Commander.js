var Curr_Page = 1;
var ValidChars = {};
ValidChars["ALan1F"] = ' ~~~~~~گ~~~~و~~~~~~~~~~~~~~ك~~~~~شذژيثبلآهتنمءدخحضقس،عؤصطغظجپچ~~ژشذزيثبلاهتنمئدخحضقسفعرصطغظ~~~ّ';
ValidChars["ALan2F"] = ' !~~~~~~~~*+,-.~~~~~~~~~~~~~~~~~@ABCDEFGHIJKLMNOPQRSTUVWXYZ[~]~_~abcdefghijklmnopqrstuvwxyz{|}~';
ValidChars["ALan1F2"] = ' !~~~%،گ)(~~و-./0123456789~ك،~~؟~شذژيثبلآهتنمءدخحضقس،عؤصطغظجپچ~~ژشذزيثبلاهتنمئدخحضقسفعرصطغظ~~~~ّ';
ValidChars["ALan2F2"] = ' !~~~%~~()~~,-./0123456789~~~~~~~ABCDEFGHIJKLMNOPQRSTUVWXYZ~~~~~~abcdefghijklmnopqrstuvwxyz~~~~';
ValidChars["ALan1"] = ' !~#$%،گ)(×+و-./0123456789:ك،=.؟@شذژيثبلآهتنمءدخحضقس،عؤصطغظجپچ^_ژشذزيثبلاهتنمئدخحضقسفعرصطغظ<|>ّ';
ValidChars["ALan12N"] = ' !~~~%~~~~*+,-.~~~~~~~~~~~~~~~~~@ABCDEFGHIJKLMNOPQRSTUVWXYZ[~]~_~abcdefghijklmnopqrstuvwxyz{|}~';
ValidChars["ALan12N2"] = ' !~~~%~~()~~,-./0123456789~~~~~~~ABCDEFGHIJKLMNOPQRSTUVWXYZ~~~~~~abcdefghijklmnopqrstuvwxyz~~~~';
var ver = 3;
var FD, NextAct, fmod = '';
var Stat_Flag = 0;
/*  Indicate the status of the form
              1:After control
              0:Remaining statuses
              */
var checkmodi_r = false;
var LastActNo = null;
// Start of functions and plugins for MB project
var $ = $ ? $ : top.$;
if (!window.ActiveXObject) {
    var ml = new Array();
    ml[0] = new Array(31, 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 30);
    ml[1] = new Array(31, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    var stdlen = top.LengthOfStudentNo;
    var valid;
    var FocusCounter = 0;

    MBPrepare = function(Field) {
        if (!window)
            debugger;
        var $element = Field ? $(Field) : $(this);
        var element = Field ? Field : this[0];
        if ($element.attr("id")) element.id = $element.attr("id");
        if ($element.attr("nul")) element.Nul = $element.attr("nul");
        if ($element.attr("Min")) element.Min = $element.attr("Min");
        if ($element.attr("Max")) element.Max = $element.attr("Max");
        if ($element.attr("Cap")) element.Cap = $element.attr("Cap");
        if ($element.attr("Pic")) element.Pic = $element.attr("Pic");
        if ($element.attr("Typ")) element.Typ = $element.attr("Typ");
        if ($element.attr("Fro")) element.Fro = $element.attr("Fro");
        if ($element.attr("To")) element.To = $element.attr("To");
        if ($element.attr("Nex")) element.Nex = $element.attr("Nex");
        if ($element.attr("Dec")) element.Dec = $element.attr("Dec");
        if ($element.attr("Def")) element.Def = $element.attr("Def");
        if ($element.attr("Num")) element.Num = $element.attr("Num");
        if ($element.prop("HFld")) element.HFld = $element.prop("HFld");
        if ($element.attr("RFld")) element.RFld = $element.attr("RFld");
        if ($element.attr("CFld")) element.CFld = $element.attr("CFld");
        if ($element.attr("HELP")) element.HELP = $element.attr("HELP");
        if ($element.attr("RDiv")) element.RDiv = $element.attr("RDiv");
        if ($element.attr("chk")) element.chk = $element.attr("chk");
        if ($element.attr("lan")) element.chk = $element.attr("lan");
        if ($element.attr("Mat")) element.chk = $element.attr("Mat");
        if ($element.attr("onchange2")) element.onchange2 = $element.attr("onchange2");
        if ($element.attr("onkeyup2")) element.onkeyup2 = $element.attr("onkeyup2");
        if ($element.attr("onclick2")) element.onclick2 = $element.attr("onclick2");

        if (element.id == "F00061") {
            element.fireEvent = function() {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent("change", false, true);
                element.dispatchEvent(evt);
            }
        }
        //if(!$element.hasClass("Comm")){
        element.disable_Butt = function() {
            //$(this).disable_Butt();
            var element = this;
            var bh = CommanderButt(element);
            element.disabled = true;
            element.style.backgroundPositionY = -element.by - bh * 3 + "px";
        }
        element.enable_Butt = function() {
            //$(this).enable_Butt();
            var element = this;
            var bh = CommanderButt(element);
            element.disabled = false;
            element.style.backgroundPositionY = -element.by + "px";
        }
        //}   
        element.valid = true;
        //element.oldValue='';
        if (element.tagName == "SELECT") {
            element.onmousedown = function(event) {
                if (event.button == 2) {
                    var id = element.id;
                    timeInt = setTimeout(id + ".style.width=" + id + ".offsetWidth+10;", 700);
                    mup(element, event);
                    return false;
                }
            }

            function mup(element, event) {
                clearTimeout(timeInt);
                if (event.button == 2) {
                    try {
                        eval("window.parent.Master.Form_Body.document.all." + element.id.substr(1) + ".value='';");
                        element.selectedIndex = -1;
                        eval("window.parent.Master.Form_Body.document.all." + element.id.substr(1) + ".change();");
                    } catch (e) {}
                }
            }
            /*element.mout=function(){
               clearTimeout(timeInt);
            }*/
            /*
            function keypress(){
               var key;
               var e=window.event;
               key=e.keyCode;
               if (key==13 || key==9 || key==16){
                  eval(element.id.substr(1)+".FocusNext();");
               }
               
            }*/


            return;
        }

        element.UpdateSndData = function(NoFixNumber) {
            var element = this;
            var XmlSnd = window.parent.Master.Form_Body.XmlSnd;
            //XmlSnd.documentElement.setAttribute(element.id).value = element.value;//element.FixNumber();
            if (NoFixNumber)
                XmlSnd.documentElement.setAttribute(element.id, element.value);
            else
                XmlSnd.documentElement.setAttribute(element.id, element.FixNumber());
            var s = new XMLSerializer();
            var d = XmlSnd.documentElement;
            window.parent.Master.Form_Body.XmlSnd.xml = s.serializeToString(d);
            element.RefreshRadio();
            element.RefreshCbox();
        }
        /*element.onpaste = function(event){
           var _this = this;
           setTimeout( function() {
                 var text = $(_this).val();
                 _this.value = ConvertPersianNumberToLatin(text);
           }, 100);
        };*/

        element.RefreshRadio = function() {
            var element = this;
            try {
                if (element.RFld) {
                    for (var i = 0; i < element.RFld.length; i++) {
                        if (element.RFld[i].name + element.value == element.RFld[i].id) {
                            element.RFld[i].checked = true;
                        } else {
                            element.RFld[i].checked = false;
                        }
                    }
                }
            } catch (e) {}
        }
        element.RefreshCbox = function() {
            var element = this;
            try {
                var noy = 0;
                try {
                    noy = $(element).attr("noy")
                } catch (e) {}
                if (element.CFld) {
                    element.CFld.checked = (element.value == ((noy == 1) ? 2 : 1)) ? true : false;
                }
            } catch (e) {}
        }

        function CommanderButt(element) {
            element.by = $(element).attr("by");
            element.bh = $(element).attr("bh");
            var bh;
            element.style.backgroundPositionY = -element.by + "px";
            element.style.backgroundPositionX = "0px";
            bh = element.bh;
            if (!bh) bh = 21
            element.bh = bh;
            return bh;
        }

        function ConvertPersianNumberToLatin(text) {
            /*if(window.ActiveXObject)
               return text;*/
            //return text;   
            var map = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            if (/\>(.*?)\</.test(text) == false) {
                var k = 0;
                return text.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(w) {
                    if (w == "۰")
                        k = 0;
                    if (w == "۱")
                        k = 1;
                    if (w == "۲")
                        k = 2;
                    if (w == "۳")
                        k = 3;
                    if (w == "۴")
                        k = 4;
                    if (w == "۵")
                        k = 5;
                    if (w == "۶")
                        k = 6;
                    if (w == "۷")
                        k = 7;
                    if (w == "۸")
                        k = 8;
                    if (w == "۹")
                        k = 9;
                    return map[+k];
                });
            } else {
                return text.replace(/\>(.*?)\</g, function(w) {
                    return w.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(v) {
                        return v.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(w) {
                            if (w == "۰")
                                k = 0;
                            if (w == "۱")
                                k = 1;
                            if (w == "۲")
                                k = 2;
                            if (w == "۳")
                                k = 3;
                            if (w == "۴")
                                k = 4;
                            if (w == "۵")
                                k = 5;
                            if (w == "۶")
                                k = 6;
                            if (w == "۷")
                                k = 7;
                            if (w == "۸")
                                k = 8;
                            if (w == "۹")
                                k = 9;
                            return map[+k]
                        });
                    });
                });
            }
        }
        element.ComboChange = function() {
            //$(this).ComboChange();
            var element = this;
            Helement = parent.Master.Form_Body.document.all.item("H" + element.id)
            element.value = Helement.value;
            try {
                if (ver == 3) element.UpdateSndData();
            } catch (e) {}
            element.change();
        }
        element.Disable = function(Yes) {
            var bool;
            if (typeof(Yes) == 'undefined')
                bool = true;
            else
                bool = Yes;
            elementID = element.id;
            element.disabled = bool;
            Helement = window.parent.Master.Form_Body.document.all.item('H' + elementID); //window.document.all.item('H'+elementID);
            if (Helement) Helement.disabled = bool;

            try {
                element.HFld.disabled = bool;
            } catch (e) {}
            try {
                element.CFld.disabled = bool;
            } catch (e) {}

            try {
                elementHelp2 = window.parent.Master.Form_Body.document.all.item('H' + element.HELP); //window.document.all.item('H'+element.HELP);
                if (bool)
                    elementHelp2.disable_Butt();
                else
                    elementHelp2.enable_Butt();
            } catch (e) {}
            if (element.RDiv) {
                element.RDiv.disabled = bool;
                $("input", element.RDiv).each(function(i, v) {
                    $(v).attr("disabled", bool);
                })
            }
            CheckDisableLinks();
        }
        element.onfocus = function(e) {
            var element = this;
            if (element.valid)
                element.oldValue = element.value;
        }
        element.onblur = function(e) {
            var element = this;
            if ($(element).data("npchange") == "1")
                element.change(e)

        }
        /*if(element.onkeyup2){
           element.onkeyup2=function(NoBrother,e){  
              element.onkeyup();
           }
        }
        if(element.onchange2){
           element.onchange2=function(NoBrother,e){  
              element.onchange();
           }
        }*/
        element.change = element.onchange = function(NoBrother, e) {
            var element = this;
            $(element).data("npchange", "0");
            if (typeof(ver) != 'undefined' && ver == 3) return element.change3(e || NoBrother);
            if (element.oldValue == element.value) return;
            Helement = window.parent.Master.Form_Body.document.all.item("H" + element.id);
            if (NoBrother);
            else
            if (Helement) {
                if (typeof(element.SelIndex) != 'undefined' && element.SelIndex != -2) { //SelIndex is a custom property for text box. if "element combo" has been filled before "brother combo", this property of "brother element" set to selectedIndex of "element combo"
                    //then when "brother element" change event fire, first of all this property must be checked and the appropriate item was selected.
                    Helement.selectedIndex = element.SelIndex;
                    element.value = Helement.value;
                    element.SelIndex = -2;
                } else Helement.value = element.value;
                for (var i = 1; i < 6; i++) {
                    ID_elementBr_i = eval("element.Brother" + i); //id of element's ith Brother 
                    if (!ID_elementBr_i) break;
                    else {
                        elementBr_i = window.parent.Master.Form_Body.document.all.item(ID_elementBr_i); //element's ith Brother 
                        HelementBr_i = window.parent.Master.Form_Body.document.all.item('H' + ID_elementBr_i);
                        HelementBr_i.selectedIndex = Helement.selectedIndex;
                        if (HelementBr_i.selectedIndex != Helement.selectedIndex)
                            elementBr_i.SelIndex = Helement.selectedIndex;
                        if (Helement.length > 0) {
                            elementBr_i.value = HelementBr_i.value;
                        } else
                            elementBr_i.value = '';
                        ClearValue(elementBr_i.id, 1);
                    }
                }
            }
            ClearValue(element.id, 1);
            if (element.value == '') {
                if (element.onchange2) {
                    try {
                        eval("window.parent.Master.Form_Body." + element.onchange2 + "");
                    } catch (e) {}
                }
                return;
            }
            if (element.CheckVal() < 0) {
                element.valid = false;
                e.returnValue = false;
            } else {
                element.valid = true;
                if (element.onchange2) {
                    try {
                        eval("window.parent.Master.Form_Body." + element.onchange2 + "");
                    } catch (e) {}
                }
                if ((typeof(element.Pic) != "undefined") && (element.Pic == "C")) {
                    element.value = element.value.replace(/,/g, '');
                    var l, s = element.value,
                        s2 = '';
                    while (s != '') {
                        l = s.length;
                        if (l < 3) {
                            s2 = ',' + s + s2;
                            break;
                        } else {
                            s2 = ',' + s.slice(l - 3) + s2;
                            s = s.slice(0, l - 3);
                        }
                    }
                    element.value = s2.slice(1);
                }
            }
        }
        element.change3 = function(e) {
            var element = this;
            var event = e;
            if (element.id == 'F00111') {
                //var c=parent.parent.Commander;
                if (fmod != element.value) {
                    fmod = element.value;
                    setShowBtn();
                    setnexact('00', 0);
                    InitFrm();
                }
            }

            if (element.HFld) {
                var e = element.HFld;
                e.value = element.value;
                if (e.value == '') {
                    e.selectedIndex = -1;
                }
            }
            if (element.oldValue == element.value) {
                element.valid = true;
                return;
            }
            element.UpdateSndData();
            ClearValue(element.id, 1);
            if (element.value == '') {
                if (element.onchange2) {
                    try {
                        eval("window.parent.Master.Form_Body." + element.onchange2 + "");
                    } catch (e) {}
                }
            } else {
                if (element.CheckVal() < 0) {
                    element.valid = false;
                    e.returnValue = false;

                    return;
                } else {
                    element.valid = true;
                    if (element.onchange2) {
                        try {

                            eval("window.parent.Master.Form_Body." + element.onchange2 + "");
                        } catch (e) {
                            console.log(e);
                            console.log("window.parent.Master.Form_Body." + element.onchange2 + "");
                        }
                    }

                    if ((typeof(element.Pic) != "undefined") && (element.Pic == "C")) {
                        element.value = element.value.replace(/,/g, '');
                        var l, s = element.value,
                            s2 = '';
                        while (s != '') {
                            l = s.length;
                            if (l < 3) {
                                s2 = ',' + s + s2;
                                break;
                            } else {
                                s2 = ',' + s.slice(l - 3) + s2;
                                s = s.slice(0, l - 3);
                            }
                        }
                        element.value = s2.slice(1);
                    }
                }
            }
            element.oldValue = element.value;
            element.UpdateSndData();
        }
        element.SetFocus = function(NoErr) {
            element = this;
            var e;
            if ((element.style.display == "none")) {
                if (!element.HFld) return -1;
                e = element.HFld;
            } else {
                e = element
            }

            z = e.style;
            if (!NoErr)
                z.backgroundColor = "#FF0000";
            else
                z.backgroundColor = "#0000FF";

            setTimeout(function() {
                try {
                    var el = element;
                    if (el.HFld)
                        el.HFld.style.backgroundColor = ''
                    // else
                    el.style.backgroundColor = ''
                    el.focus();
                    el.select();
                } catch (e) {}
            }, 50);
            if (e.disabled) {
                element.FocusNext(true);
            } else {
                try {
                    e.focus();
                    e.select();
                } catch (e) {}
            }

            return 1;
        }
        element.FocusNext = function(NoAct) {
            var element = this;
            var TD = element;
            while (TD.tagName != 'TD') {
                if (TD.tagName == 'BODY') break;
                TD = TD.parentElement;
            }
            if (TD.tagName == 'TD') {
                var TR = TD;
                while (TR.tagName != 'TR') TR = TR.parentElement;
                var Table = TR;
                while (Table.tagName != 'TABLE') Table = Table.parentElement;

                TD = Table.rows[0].cells[TD.cellIndex];
                try {
                    /*if(TD.NextCol!=''){
                       TR.cells[parseInt(TD.NextCol)].childNodes[0].focus();
                       TR.cells[parseInt(TD.NextCol)].childNodes[0].select();
                    }*/
                    if ($(TD).attr("nextcol") != '') {
                        TR.cells[parseInt($(TD).attr("nextcol"))].childNodes[0].focus();
                        TR.cells[parseInt($(TD).attr("nextcol"))].childNodes[0].select();
                    }
                    return;
                } catch (e) {}
            }
            //-----------------------------------------------------
            var Nex;
            if (element.tagName == 'SELECT') {
                var o = window.document.all.item(element.id.substring(1));
                if (window.parent.Master.Form_Body.FrameStdHlp && window.parent.Master.Form_Body.FrameStdHlp.contentDocument.all[$(element).attr("id")])
                    Nex = window.parent.Master.Form_Body.FrameStdHlp.contentDocument.all[o.Nex];
                else if (!Nex)
                    Nex = window.document.all.item(o.Nex);
                Temp = Nex;
            }
            if (element.tagName == 'INPUT' || element.tagName == 'TEXTAREA' || element.tagName == 'IMG' || element.tagName == 'npobj_cal' || element.tagName == 'npobj_bdo') {
                if (window.parent.Master.Form_Body.FrameStdHlp && window.parent.Master.Form_Body.FrameStdHlp.contentDocument.all[$(element).attr("id")] && $(element).closest("div#d").length != 0)
                    Nex = window.parent.Master.Form_Body.FrameStdHlp.contentDocument.all[$(element).attr("nex")];
                else if (!Nex)
                    Nex = window.parent.Master.Form_Body.document.all[$(element).prop("Nex")]; //window.parent.Master.Form_Body.document.all[$(element).attr("nex")];
                if (!msie() && !Nex && $("input[r_id='" + $(element).attr("nex") + "']", window.parent.Master.Form_Body.document).length == 1) {
                    Nex = $("input[r_id='" + $(element).attr("nex") + "']", window.parent.Master.Form_Body.document);
                }
            }
            /*if(!Nex && window.parent.Master.Form_Body.document.getElementById(""+$(element).attr("nex")+"").length==1)
               window.parent.Master.Form_Body.document.getElementById(""+$(element).attr("nex")+"").focus();
            */
            while (typeof(Nex) != "undefined" && Nex != null && Nex.id != '') {
                FocusCounter++;
                if (FocusCounter > 100) {
                    FocusCounter = 0;
                    return;
                }
                try {
                    if (Nex.tagName == 'FONT' || Nex.tagName == 'LABEL' || Nex.tagName == 'SPAN') {
                        try {
                            if (Nex.Nex == Nex.id) return;
                            Nex = window.document.all.item(Nex.Nex);
                        } catch (e) {
                            return;
                        }
                    } else {
                        /*if(Nex.focus()<0)throw('1097');*/
                        Nex.focus();
                        if (Nex.HFld)
                            throw ('1097');


                        if (Nex.disabled) {
                            Nex = window.document.all.item(Nex.Nex);
                            return;
                        }
                        var c = 0,
                            AllNex = [],
                            IsLoop = false;
                        while (!isVisible(Nex) && !IsLoop) {

                            for (var i = 0; i < AllNex.length; i++) {
                                if (AllNex[i] == Nex.id) {
                                    IsLoop = true;
                                    return;
                                }

                            }
                            AllNex[c] = Nex.id;
                            var ne = window.parent.Master.Form_Body.document.all[Nex.Nex]
                            //var ne = window.document.all.item(Nex.Nex);
                            if (!ne) ne = eval(Nex.Nex);
                            Nex = ne;
                            c++;

                        }
                        if (IsLoop)
                            return;
                        if (Nex && Nex.disabled)
                            break;


                        switch (Nex.tagName) {
                            case 'IMG':
                                {
                                    try {
                                        Nex.click();
                                    } catch (e) {}
                                    break;
                                }
                            case 'INPUT':
                                {
                                    if (Nex.type == 'image') {
                                        Nex.click();
                                    } else {
                                        Nex.select();
                                    }
                                    break;
                                }
                            case 'npobj_cal':
                            case 'npobj_bdo':
                                {
                                    //Nex.select();
                                    Nex.focus();
                                    break;
                                }
                        }
                        return;
                    }
                } catch (e) {
                    //   alert("error 1")
                    try {
                        if (ver == 3) {
                            if ($("input[r_id='" + Nex.Nex + "']", window.parent.Master.Form_Body.document).length == 1) {
                                $("input[r_id='" + Nex.Nex + "']", window.parent.Master.Form_Body.document).focus();
                                return;
                            }
                            if (Nex.RFld) {
                                Nex.RFld[0].focus();
                            } else {
                                z = Nex.HFld;
                                z.focus();
                                z.style.backgroundColor = "#0000FF";
                                setTimeout('try{window.parent.Master.Form_Body.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                            }
                        } else {
                            d = window.document.all;
                            d.item('H' + Nex.id).focus();
                            z = d.item('H' + Nex.id).style;
                            z.backgroundColor = "#0000FF";
                            setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                        }
                        return;
                    } catch (e) {
                        try {
                            if (!Nex.Nex || Nex.Nex == Nex.id) break;
                            var ne = window.parent.Master.Form_Body.document.all[Nex.Nex];
                            //var ne = window.document.all.item(Nex.Nex);
                            if (!ne) ne = eval(Nex.Nex);
                            Nex = ne;
                        } catch (e) {
                            return;
                        }
                    }
                }
            }
            if (NoAct) return;
            var NextAct = window.NextAct;
            if (NextAct == '01') {
                if (window.document.body.LastEnterAct) {
                    NextAct = window.document.body.LastEnterAct;
                }
            }
            window.act_data_frm(NextAct);
        }

        function isVisible(obj) {
            if (obj.tagName == "npobj_bdo" || obj.tagName == "npobj_cal")
                obj = obj.d;

            if (obj.tagName == "BODY") return true

            if (!obj) return false
            if (!obj.parentElement) return false
            if (obj.style) {
                if (obj.style.display == 'none') return false
                if (obj.style.visibility == 'hidden') return false
            }
            return isVisible(obj.parentElement)
        }

        element.CheckVal = function() {
            var element = this;
            var v_max = element.Max,
                v_min = element.Min;
            if (typeof(v_max) == 'undefined') v_max = element.max;
            if (typeof(v_min) == 'undefined') v_min = element.min;
            if (typeof(v_max) == 'undefined' || v_max == '') v_max = 0;
            if (typeof(v_min) == 'undefined' || v_min == '') v_min = 0;
            var FieldValue = element.FixNumber();
            try {
                element.UpdateSndData();
            } catch (e) {}
            if (isNaN(FieldValue) && !CheckValidChars(FieldValue, element)) {
                alert(element.Cap + " " + "دارای کاراکتر غیر مجاز است ");
                element.SetFocus();
                return -1;
            }
            if (FieldValue == "") {
                if (element.Nul && element.Nul == "0") {
                    if (window.event) {
                        alert(element.Cap + " " + "نمي تواند خالي باشد");
                        if (window.event.srcElement != element) {
                            element.SetFocus();
                        }
                    } else {
                        alert(element.Cap + " " + "نمي تواند خالي باشد");
                        element.SetFocus();
                    }
                    return -1;
                }
            } else {

                if (v_min > 0)
                    if (FieldValue.length < parseFloat(v_min)) {
                        alert('طول"' + element.Cap + '" نمي تواند کمتر از  ' + v_min + ' کاراکتر باشد');
                        element.SetFocus();
                        return -1;
                    }

                var p = element.Pic;
                switch (p) {
                    case "M":
                        {
                            var s = element.value.replace(/(\/)/g, '')
                            if (!mell(s)) {
                                alert(element.Cap + " نامعتبر است");
                                element.SetFocus();
                                return -1;
                            }
                            break;
                        }
                    case "E":
                        {
                            var s = element.value.replace(/(\/)/g, '')
                            s = s.toLowerCase();
                            element.value = s;
                            if (!emailCheck(s)) {
                                alert(element.Cap + " نامعتبر است");
                                element.SetFocus();
                                return -1;
                            }
                            break;
                        }
                    case "S":
                        {
                            if (element.value.length > stdlen) {
                                alert(element.Cap + " نامعتبر است");
                                element.SetFocus();
                                return -1;
                            }
                            break;
                        }
                }
                //date-------------------------------
                if ((element.Typ == "C" || element.Typ == "D") && p && (p == "D" || p == 'G')) {
                    if (element.Typ == "C" && top.SupportOldGolestan && p == "D") {

                        var d = FieldValue;
                        var s = FieldValue.substr(0, 4),
                            m = FieldValue.substr(4, 2),
                            r = FieldValue.substr(6, 2);
                        if (r > 31) {
                            alert("تاریخ وارد شده صحیح نمی باشد - روز نمی تواند از 31 بیشتر باشد")
                            element.SetFocus();
                        } else if (m > 12) {
                            alert("تاریخ وارد شده صحیح نمی باشد - ماه نمی تواند از 12 بیشتر باشد")
                            element.SetFocus();
                        } else if (FieldValue.length != 8) {
                            alert("تاریخ وارد شده صحیح نمی باشد")
                            element.SetFocus();
                        }


                    } else {
                        var x = element.value;
                        var s = element.value.replace(/(\/)/g, '');
                        if (top.SupportOldGolestan && s != element.value) {
                            if (element.value.indexOf("/") == 2) {
                                s = s.substr(4, 4) + '.' + s.substr(2, 2) + '.' + s.substr(0, 2);
                                element.value = s;
                            } else
                                s = s.substr(0, 4) + '.' + s.substr(4, 2) + '.' + s.substr(6, 2);
                        } else if (s != element.value) {
                            s = s.substr(4, 4) + '.' + s.substr(2, 2) + '.' + s.substr(0, 2);
                            element.value = s;
                        }


                        if (s.substr(4, 1) != '.' || s.substr(7, 1) != '.') {
                            alert(element.Cap + " نامعتبر است");
                            if (top.SupportOldGolestan) element.value = x;
                            element.SetFocus();
                            return -1;
                        }
                        var s = s.replace(/\./g, '');
                        var y = parseFloat(s.substr(0, 4)),
                            m = parseFloat(s.substr(4, 2)),
                            da = parseFloat(s.substr(6, 2));
                        if (m < 0 || m > 12) {
                            if (top.SupportOldGolestan) element.value = x;
                            alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
                            element.SetFocus();
                            return -1;
                        }
                        var mi = (p == 'D') ? 0 : 1;
                        if (da < 0 || da > ml[mi][m]) {
                            if (top.SupportOldGolestan) element.value = x;
                            alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
                            element.SetFocus();
                            return -1;
                        }

                        if (parseFloat(s) < parseFloat(element.Fro)) {
                            dateStr = element.Fro.substr(0, 4) + '/' + element.Fro.substr(4, 2) + '/' + element.Fro.substr(6, 2);
                            if (top.SupportOldGolestan) element.value = x;
                            alert(element.Cap + " بايد بزرگتر از  " + dateStr + " باشد");
                            element.SetFocus();
                            return -1;
                        }
                        if (s > parseFloat(element.To)) {
                            dateStr = element.To.substr(0, 4) + '/' + element.To.substr(4, 2) + '/' + element.To.substr(6, 2);
                            if (top.SupportOldGolestan) element.value = x;
                            alert(element.Cap + " بايد کوچکتر از  " + dateStr + " باشد");
                            element.SetFocus();
                            return -1;
                        }

                    }
                }
                //time-------------------------------
                if ((element.Typ == "C" || element.Typ == "T") && p && p == "T") {
                    if (element.value.substr(2, 1) != ':' || element.value.length < 5 || !element.value.substr(3, 2).match(/^\d+$/) || !element.value.substr(0, 2).match(/^\d+$/)) {
                        alert(element.Cap + " نامعتبر است");
                        element.SetFocus();
                        return -1;
                    }
                    if (parseFloat(element.value.substr(3, 2)) > 59) {
                        alert('دقيقه نمي تواند مقدار بيش از 59 داشته باشد');
                        element.SetFocus();
                        return -1;
                    }
                    if (parseFloat(element.value.substr(0, 2)) > 24) {
                        alert('ساعت نمي تواند مقدار بيش از 24 داشته باشد');
                        element.SetFocus();
                        return -1;
                    }
                    if (parseFloat(element.value.substr(3, 2)) > 0 && parseFloat(element.value.substr(0, 2)) == 24) {
                        alert('مقدار ورودي صحيح نيست');
                        element.SetFocus();
                        return -1;
                    }
                    timeStr = element.value.substr(0, 2) + element.value.substr(3, 2);
                    if (parseInt(timeStr) < parseInt(element.Fro)) {
                        timeStr = element.Fro.substr(0, 2) + ':' + element.Fro.substr(3, 2);
                        alert(element.Cap + " بايد بزرگتر از  " + timeStr + " باشد");
                        element.SetFocus();
                        return -1;
                    }
                    if (parseInt(timeStr) > parseInt(element.To)) {
                        timeStr = element.To.substr(0, 2) + ':' + element.To.substr(3, 2);
                        alert(element.Cap + " بايد کوچکتر از  " + timeStr + " باشد");
                        element.SetFocus();
                        return -1;
                    }
                }
                //-----------------------------
                if (element.Typ == "N") {
                    if (isNaN(FieldValue)) {
                        alert(element.Cap + " " + "نمي تواند غير عددي باشد");
                        element.SetFocus();
                        return -1;
                    }
                    if ((typeof(element.Dec) != "undefined") && (element.Dec != "")) {
                        if (((FieldValue.length - FieldValue.indexOf(".") - 1) > parseInt(element.Dec)) && (FieldValue.indexOf(".") >= 1)) {
                            alert(element.Cap + '" نمي تواند بيش از ' + element.Dec + ' رقم اعشار داشته باشد"');
                            element.SetFocus();
                            return -1;
                        }
                    }
                    if ((typeof(element.Fro) != "undefined") && (element.Fro != ""))
                        if (FieldValue < parseFloat(element.Fro)) {
                            alert(element.Cap + '" نمي تواند کوچکتر از  ' + element.Fro + ' باشد"');
                            element.SetFocus();
                            return -1;
                        }
                    if ((typeof(element.To) != "undefined") && (element.To != ""))
                        if (FieldValue > parseFloat(element.To)) {
                            alert(element.Cap + '" نمي تواند بزرگتر از ' + element.To + ' باشد"');
                            element.SetFocus();
                            return -1;
                        }
                }
                if (element.Typ == "C") {
                    if (element.Num == "1") {
                        if (isNaN(element.value)) {
                            alert(element.Cap + " " + "نمي تواند غير عددي باشد");
                            element.SetFocus();
                            return -1;
                        }
                        if ((typeof(element.Fro) != undefined) && (element.Fro != ""))
                            if (FieldValue < parseFloat(element.Fro)) {
                                alert(element.Cap + '" نمي تواند کوچکتر از  ' + element.Fro + ' باشد"');
                                element.SetFocus();
                                return -1;
                            }
                        if ((typeof(element.To) != undefined) && (element.To != ""))
                            if (FieldValue > parseFloat(element.To)) {
                                alert(element.Cap + '" نمي تواند بزرگتر از ' + element.To + ' باشد"');
                                element.SetFocus();
                                return -1;
                            }
                    }

                }
            }
            return 1;
        }
        element.GetPos = function() {
            var element = this;
            var curleft = curtop = 0;
            var obj = element;
            if (obj.offsetParent) {
                curleft = obj.offsetLeft
                curtop = obj.offsetTop
                while (obj = obj.offsetParent) {
                    curleft += obj.offsetLeft
                    curtop += obj.offsetTop
                }
            }
            return [curleft, curtop];
        }
        element.Trim = function() {
            var element = this;
            element.value = element.value.replace(/(^\s*)|(\s*$)/g, "");
            return element.value;
        }

        function mell(v) {
            if (v.length == 0)
                return true;
            else if (v.length == 10) {
                if (v == '1111111111' || v == '0000000000' || v == '2222222222' || v == '3333333333' || v == '4444444444' || v == '5555555555' || v == '7777777777' || v == '8888888888' || v == '9999999999')
                    return false;
                else if (v.charAt(0) == '0' && v.charAt(1) == '0' && v.charAt(2) == '0' && v.charAt(3) == '0' && v.charAt(4) == '0' && v.charAt(5) == '0' && v.charAt(6) == '0')
                    return false;
                else {
                    c = parseInt(v.charAt(9));
                    n = parseInt(v.charAt(0)) * 10 + parseInt(v.charAt(1)) * 9 + parseInt(v.charAt(2)) * 8 + parseInt(v.charAt(3)) * 7 + parseInt(v.charAt(4)) * 6 + parseInt(v.charAt(5)) * 5 + parseInt(v.charAt(6)) * 4 + parseInt(v.charAt(7)) * 3 + parseInt(v.charAt(8)) * 2;
                    r = n - parseInt(n / 11) * 11;
                    if ((r == 0 && r == c) || (r == 1 && c == 1) || (r > 1 && c == 11 - r))
                        return true;
                    else
                        return false;
                }
            } else
                return false;
        }

        function emailCheck(emailStr) {
            var checkTLD = 1;

            var knownDomsPat = /^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;

            var emailPat = /^(.+)@(.+)$/;

            var specialChars = "\\(\\)><@,&;:\\\\\\\"\\.\\[\\]";

            var validChars = "\[^\\s" + specialChars + "\]";

            var quotedUser = "(\"[^\"]*\")";

            var ipDomainPat = /^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

            var atom = validChars + '+';

            var word = "(" + atom + "|" + quotedUser + ")";

            var userPat = new RegExp("^" + word + "(\\." + word + ")*$");

            var domainPat = new RegExp("^" + atom + "(\\." + atom + ")*$");

            var matchArray = emailStr.match(emailPat);

            if (matchArray == null) {

                return false;
            }
            var user = matchArray[1];
            var domain = matchArray[2];

            for (i = 0; i < user.length; i++) {
                if (user.charCodeAt(i) > 127) {
                    return false;
                }
            }
            for (i = 0; i < domain.length; i++) {
                if (domain.charCodeAt(i) > 127) {
                    return false;
                }
            }

            if (user.match(userPat) == null) {
                return false;
            }

            var IPArray = domain.match(ipDomainPat);
            if (IPArray != null) {

                for (var i = 1; i <= 4; i++) {
                    if (IPArray[i] > 255) {
                        return false;
                    }
                }
                return true;
            }


            var atomPat = new RegExp("^" + atom + "$");
            var domArr = domain.split(".");
            var len = domArr.length;
            for (i = 0; i < len; i++) {
                if (domArr[i].search(atomPat) == -1) {
                    return false;
                }
            }

            if (checkTLD && domArr[domArr.length - 1].length != 2 &&
                domArr[domArr.length - 1].search(knownDomsPat) == -1) {
                return false;
            }


            if (len < 2) {
                return false;
            }

            return true;
        }
        element.FixNumber = function() {
            var element = this;
            try {
                element.value = ConvertPersianNumberToLatin(element.value);
                element.value = element.value.replace(/٫/g, '.');
            } catch (e) {

            }

            if (typeof(element.Pic) != "undefined") {
                switch (element.Pic) {
                    case "D":
                    case "G":
                        {
                            if (top.SupportOldGolestan)
                                element.value = element.value.replace(/\./g, '/');
                            if (element.value.indexOf("/") >= 0 && !top.SupportOldGolestan) {
                                return (element.value.substr(6, 4) + element.value.substr(3, 2) + element.value.substr(0, 2));
                            }
                            if (element.value.indexOf("/") >= 0 && top.SupportOldGolestan) {
                                if (element.Pic == "G") {
                                    if (element.value.indexOf("/") == 2)
                                        return (element.value.substr(6, 4) + element.value.substr(3, 2) + element.value.substr(0, 2));
                                    else
                                        return (element.value.substr(0, 4) + element.value.substr(5, 2) + element.value.substr(8, 2));
                                } else
                                    return (element.value.substr(0, 4) + element.value.substr(5, 2) + element.value.substr(8, 2));

                            }
                            if (element.value.indexOf("/") == -1 && element.value != "" && top.SupportOldGolestan) // fix bug in new system - grid fill date text boxs
                                element.value = element.value.substr(0, 4) + "/" + element.value.substr(4, 2) + "/" + element.value.substr(6, 2)

                            return (element.value.replace(/\./g, ''));

                        }
                    case "T":
                        {
                            if (element.value.indexOf(":") < 0) return (element.value);
                            return (element.value.substr(0, 2) + element.value.substr(3, 2));
                        }
                    case "A":
                        {
                            if (element.value.indexOf(".") < 0) return (element.value);
                            return (element.value.substr(0, 2) + element.value.substr(3));
                        }
                    case "C":
                        {
                            return (element.value.replace(/,/g, ''));
                        }
                }
            }

            if (!element.Fil || element.Fil == "") return element.value;
            var n = element.value;
            if (n == '') return n;

            var v_max = element.Max;
            if (typeof(v_max) == 'undefined') v_max = element.max;
            if (typeof(v_max) == 'undefined' || v_max == '') v_max = 0;

            var len = (v_max > 0) ? parseFloat(v_max) : 0;
            var fillChar = element.Fil;
            var align = element.Jus;
            if (n.length > len) return n;
            var s = '';
            for (var i = 0; i < (len - n.length); i++) {
                s = s + fillChar;
            }

            if (align == 'R') /*align right*/ return (s + n);
            if (align == 'L') /*align left*/ return (n + s);
            return (s + n);
        }
    }

    top.$.fn.MBPrepare = $.fn.MBPrepare = MBPrepare;
    $.fn.GetVal = top.$.fn.GetVal = $.fn.GetVal = function(s) {
        var element = $(this)[0];
        element.Pic = $(element).attr("pic");
        element.Fil = $(element).attr("Fil");
        element.Jus = $(element).attr("Jus");

        //s=s.s;  
        if (typeof(element.Pic) == "undefined" || s == "") return s;
        switch (element.Pic) {
            case "D":
            case "G":
                {
                    if (s.indexOf("/") != -1)
                        return (s.substr(0, 4) + '.' + s.substr(5, 2) + '.' + s.substr(8, 2));
                    else if (s.indexOf(".") != -1)
                        return (s.substr(0, 4) + '.' + s.substr(5, 2) + '.' + s.substr(8, 2));
                    else
                        return (s.substr(0, 4) + '.' + s.substr(4, 2) + '.' + s.substr(6, 2));
                }
            case "T":
                {
                    s = s.replace(/:/g, '');
                    return (s.substr(0, 2) + ':' + s.substr(2, 2));
                }
            case "C":
                {
                    var l, s2 = '';
                    while (s != '') {
                        l = s.length;
                        if (l < 3) {
                            s2 = ',' + s + s2;
                            break;
                        } else {
                            s2 = ',' + s.slice(l - 3) + s2;
                            s = s.slice(0, l - 3);
                        }
                    }
                    return (s2.slice(1));
                    break;
                }
            case "A":
                {
                    return (s.slice(0, 2) + "." + s.slice(2));
                    break;
                }
            case "L":
                {;
                    //alert(s.replace(/./g,'\u202A'));
                    //return(s.replace(/./g,'\u202A'));
                }
            default:
                {
                    if (!element.Fil || element.Fil == "") return s;
                    var fillChar = element.Fil;
                    var align = element.Jus;

                    var l = s.length;
                    if (align == 'R') {
                        for (var i = 0; i < l; i++) {
                            if (s.charAt(i) != fillChar) break;
                        }
                        return (s.substr(i));
                    }
                    if (align == 'L') {
                        for (var i = l - 1; i >= 0; i--) {
                            if (s.charAt(i) != fillChar) break;
                        }
                        return (s.substring(0, i + 1));
                    }
                    return s;
                }
        }
    }
} // End of functions and plugins for MB project 

function GetContInd() {
    var ContInd = parent.ContInd;
    if (!ContInd) {
        arr = window.parent.Data.location.search.split('&')
        for (var i = 0; i < arr.length; i++) {
            var arri = arr[i].split('=');
            if (arri[0] == 'TabId') {
                ContInd = arri[1];
            }
        }
        /*if(!ContInd)
           ContInd=0;*/
        parent.ContInd = ContInd;
    }
    return ContInd;
}

function ClearValue(field, level) {
    var i, l;
    var b = window.parent.Master.Form_Body;
    if (b.Fathers)
        for (i = 0; i < b.Fathers.length; i++) {
            curr_fieldFather = b.Fathers[i];
            if (curr_fieldFather == field)
                ClearValue(b.Sons[i], level + 1);
        }
    if (level > 1) {
        try {
            if (window.parent.Master.Form_Body.document.all.item(field).tagName == 'IFRAME') {
                window.parent.Commander.frame_set(field, 'i&x', '');
                //window.parent.parent.Commander.frame_set(field,'i&x','');
                return;
            }
        } catch (e) {
            alert(e.message);
        }
        try {
            if (window.parent.Master.Form_Body.document.all.item('H' + field).length > 0) {
                window.parent.Master.Form_Body.document.all.item('H' + field).length = 0;
                window.parent.Master.Form_Body.document.all.item(field).style.display = "";
                window.parent.Master.Form_Body.document.all.item('H' + field).style.display = "none";
            }
        } catch (e) {}
        window.parent.Master.Form_Body.document.all.item(field).value = '';
        try {
            if (ver == 3) {
                window.parent.Master.Form_Body.document.all.item(field).UpdateSndData();
            }
        } catch (e) {}
    }
}


function ComboTextbox(IMG_obj) {
    var b = window.parent.Master.Form_Body.document.all,
        n = IMG_obj.id.substr(1);
    if (b.item().style.display == "") {
        IMG_obj.src = "/_Images/ComboBox.gif";
        b.item(n).style.display = "none";
        b.item("H" + n).style.display = "";
        b.item("H" + n).value = b.item(n).value;
        b.item(n).value = b.item("H" + n).value;
    } else {
        IMG_obj.src = "/_Images/TextBox.gif";
        b.item(n).style.display = "";
        b.item("H" + n).style.display = "none";
    }
}

function Put_Data(act_no) {
    var b = parent.Master.Form_Body;
    if (b.Put_Data)
        if (b.Put_Data(act_no) < 0) return -1;
    var FD = window.parent.Data.DataModi;
    try {
        FD.TxtMiddle.value = b.XmlSnd.xml;
    } catch (e) {
        FD.TxtMiddle.value = '<r/>';
    }
    try {
        FD.Frm_Type.value = window.parent.Master.Form_Title.SubFrmSeq.value;
    } catch (e) {}
    FD.TicketTextBox.value = top.tck_sign(FD.TicketTextBox.value);
    return 1;
}

function ShowStatus(s) {
    var t = window.parent.Master.Form_Title;
    t.stat = s;
    switch (s.toUpperCase()) {
        case 'OK':
            {
                t.Form_Status.src = "/_Images/Status_OK.gif";
                break;
            }
        case 'ERROR':
            {
                t.Form_Status.src = "/_Images/Status_NOK.gif";
                break;
            }
    }
}

//Enable The Action Input Fields And Disable Other Fields
function InitFrm() {
    var b = window.parent.Master.Form_Body;
    var curr_fieldID, curr_field, Hcurr_field, curr_field_Help, curr_field_Help2 = null;


    var FrmFieldsCount;
    try {
        FrmFieldsCount = b.FrmFields.length
    } catch (e) {
        return -1;
    }
    for (var i = 0; i < FrmFieldsCount; i++) {

        curr_field = b.FrmFields[i];
        if (curr_field.id == 'F00061') continue;
        curr_field = RealObj(curr_field);
        if (curr_field.tagName == 'IFRAME') {
            frame_set(curr_field.name, 'c', 0);
        } else {
            try {
                curr_field.Disable();
            } catch (e) {}
            try {
                curr_field.className = 'txt';
                try {
                    curr_field.HFld.className = 'sel';
                } catch (e) {}
            } catch (e) {}
        }
    }
    try {
        eval("NextActInput=b.ACT" + NextAct + fmod + ";");
    } catch (e) {
        NextActInput = null;
    }
    if (NextActInput != null) {
        for (var i = 0; i < NextActInput.length; i++) {
            curr_field = NextActInput[i];
            curr_field = RealObj(curr_field);
            if (curr_field.tagName == 'IFRAME') {
                frame_set(curr_field.name, 'c', 1);
            } else {
                try {
                    curr_field.Disable(false);
                } catch (e) {}
                var dis = curr_field.disabled;
                if (!dis) {
                    try {
                        dis = curr_field.HFld.disabled;
                    } catch (e) {}
                }
                /*if(curr_field.Nul==0 && !curr_field.disabled){
                   try{curr_field.className='txtreq';try{curr_field.HFld.className='selreq';}catch(e){}}catch(e){}
                }*/
            }
        }
    }
    if (!window.ActiveXObject) {
        $(IM06_Search).MBPrepare()
        $(IM08_Control).MBPrepare();
        $(IM01_Create).MBPrepare();
        $(IM02_Delete).MBPrepare();
        $(IM03_Modify).MBPrepare();
        $(IM13_Do).MBPrepare();
    }
    switch (NextAct) {
        case "01":
            {
                // try{
                IM06_Search.disable_Butt();
                IM08_Control.enable_Butt();
                IM01_Create.enable_Butt();
                IM02_Delete.enable_Butt();
                IM03_Modify.enable_Butt();
                IM13_Do.enable_Butt();
                // }catch(e){}
                break;
            }
        case "02":
        case "03":
        case "04":
            {
                //  try{
                IM06_Search.disable_Butt();
                IM08_Control.disable_Butt();
                IM01_Create.enable_Butt();
                IM02_Delete.enable_Butt();
                IM03_Modify.enable_Butt();
                IM13_Do.enable_Butt();
                //  }catch(e){}
                break;
            }
        case "08":
            {
                // try{
                IM06_Search.enable_Butt();
                IM08_Control.disable_Butt();
                IM01_Create.disable_Butt();
                IM02_Delete.disable_Butt();
                IM03_Modify.disable_Butt();
                IM13_Do.disable_Butt();
                //  }catch(e){}
                break;
            }
        case "09":
            {
                // try{
                IM06_Search.disable_Butt();
                IM08_Control.enable_Butt();
                IM01_Create.enable_Butt();
                IM02_Delete.enable_Butt();
                IM03_Modify.enable_Butt();
                IM13_Do.enable_Butt();
                // }catch(e){}
                break;
            }
    }
}

function setnexact(lact, ErLen) {
    FrmTyp = window.parent.Master.Form_Title.FrmTyp;
    switch (lact) {
        case "00":
            {
                switch (FrmTyp) {
                    case 'I':
                        {
                            NextAct = "01";
                            break;
                        }
                    case 'D', 'U':
                        {
                            NextAct = "08";
                            break;
                        }
                    default:
                        {
                            if (CI(0) == 1) { //کليد جستجو وجود دارد
                                NextAct = "08";
                            } else
                            if (CI(1) == 1) { //کليد بررسي وجود دارد
                                NextAct = "01";
                            } else {
                                NextAct = "09";
                            }
                        }
                }
                break;
            }
        case "01":
            {
                if (ErLen > 0) {
                    NextAct = "01";
                    ShowStatus('Error');
                } else {
                    ShowStatus('OK');
                    switch (FrmTyp) {
                        case "I":
                            {
                                NextAct = "02";
                                break;
                            }
                        case "D":
                            {
                                NextAct = "03";
                                break;
                            }
                        case "U":
                            {
                                NextAct = "04";
                                break;
                            }
                        default:
                            {
                                NextAct = "09";
                                break;
                            }
                    }
                }
                break;
            }
        case "02":
            {
                if (ErLen > 0) NextAct = "02";
                else NextAct = "01";
                break;
            }
        case "03":
            {
                if (ErLen > 0) NextAct = "03";
                else NextAct = "08";
                break;
            }
        case "04":
            {
                if (ErLen > 0) NextAct = "04";
                else NextAct = "08";
                break;
            }
        case "08":
            {
                if (ErLen > 0) {
                    NextAct = "08";
                    ShowStatus('Error');
                } else {
                    ShowStatus('Ok');
                    switch (FrmTyp) {
                        case "D":
                            {
                                if (CI(6) == '1') //کليد اعمال فعال است
                                    NextAct = "09";
                                else
                                    NextAct = "03";
                                break;
                            }
                        case "U":
                            {
                                if (CI(6) == '1') //کليد اعمال فعال است
                                    NextAct = "09";
                                else
                                    NextAct = "01";
                                break;
                            }
                        default:
                            {
                                if (CI(1) == '1') //کليد بررسي وجود دارد
                                    NextAct = "01";
                                else {
                                    //if(b.CommImage[6]=='1')//کليد  يااعمال وجود دارد
                                    NextAct = "09";
                                }
                                break;
                            }
                    }
                }
                break;
            }
        case "09":
            {
                switch (FrmTyp) {
                    case "U":
                        {
                            if (ErLen > 0) NextAct = "09";
                            else NextAct = "08";
                            break;
                        }
                    case "D":
                        {
                            if (ErLen > 0) NextAct = "09";
                            else NextAct = "08";
                            break;
                        }
                    case "I":
                        {
                            if (ErLen > 0) NextAct = "09";
                            else NextAct = "01";
                            break;
                        }
                    default:
                        {
                            if (ErLen > 0) {
                                if (CI(1) == 1) { //کليد بررسي وجود دارد
                                    NextAct = "01";
                                    IM08_Control.enable_Butt();
                                }
                            } else {
                                if (CI(1) == 1) { //کليد بررسي وجود دارد
                                    NextAct = "01";
                                    IM08_Control.enable_Butt();
                                } else {
                                    NextAct = "09";
                                    IM13_Do.enable_Butt();
                                    IM01_Create.enable_Butt();
                                    IM02_Delete.enable_Butt();
                                    IM03_Modify.enable_Butt();
                                }
                            }
                        }
                }
                break;
            }
    }
}

function transformTypedChar(charStr) {
    return /[a-g]/.test(charStr) ? charStr.toUpperCase() : charStr;
}

function msie() {
    if (window.ActiveXObject)
        return true;
    else
        return false;
}

function IsEdge() {
    var ua = window.navigator.userAgent;
    var edge = ua.indexOf('Edge/');
    var version = parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    if (edge > 0 && version >= 12)
        return true;
    else
        return false;
}

function KeyEvents(Field) {
    Field.onkeypress = function(e) {
        var element = this;
        if ($(element).attr("lan"))
            element.Lan = $(element).attr("lan")

        frmchg = true;
        var key;
        //var e=window.event;
        key = e.charCode || e.keyCode;
        //key=typeof e.which == "number" ? e.which : e.keyCode;
        shift = e.shiftKey;
        //if(key=="46" || key=="8") return; // bug in firefox
        if ( /*key=="46" ||*/ key == "8" || e.which == 0) return; // bug in firefox
        if (e.ctrlKey) { // for opera and firefox
            return;
        }
        if (key == 13 && element.tagName == 'TEXTAREA') return;
        if (key == 13 || key == 9 || key == 16) {
            if (element.tagName == 'SELECT') {
                try {
                    if (window.document.all.item(element.id.substring(1)).CheckVal() > 0)
                        if (!shift) {
                            element.change(null, e);
                            element.FocusNext();
                        }
                } catch (er) {}
                e.preventDefault();
                e.cancelBubble = true;
                e.returnValue = false;
                return;
            }
            if (element.CheckVal() > 0) {
                if (!shift) {
                    element.change(null, e);
                    element.FocusNext();
                }
            }
            e.preventDefault();
            e.cancelBubble = true;
            e.returnValue = false;
            return;
        }
        if (element.maxLength > 0 && element.value.length > element.maxLength) {
            e.preventDefault();
            e.cancelBubble = true;
            e.returnValue = false;
            return;
        }
        var p = element.Pic;
        if (p && (p == "D" || p == "G" || p == "L") && key == 47) {
            e.keyCode = 46;
            return;
        }
        if ((p && (p == "D" || p == "G" || p == "T")) || (element.Typ == "N") || ((element.Typ == "C") && (element.Num == "1"))) {
            if (top.SupportOldGolestan && element.Typ == "C" && p == "D") {
                element.LastValue = element.value;
                var SelStart = 0,
                    SelEnd = 0,
                    SelVal = "";
                var Val = element.value;
                if (Val.length == 1) {
                    if (key == 47) {
                        element.value = Val = '/' + Val;
                        e.returnValue = false;
                    } else if ((key < 48 || key > 57)) {
                        e.returnValue = false;
                    } else {
                        SelStart = SelEnd = 1;
                        Val = Val.substring(0, SelStart) + String.fromCharCode(key) + Val.substring(SelEnd, Val.length);

                        if (Val.length > 1) {
                            element.value = Val = '/' + Val;
                            e.returnValue = false;
                            element.selectionStart = 0;
                            element.selectionEnd = 0;
                        }
                    }
                } else if (Val.length == 2) {
                    if (key == 47) {
                        element.value = Val = Val + '/';
                        e.returnValue = false;
                        element.selectionStart = 0;
                        element.selectionEnd = 0;
                    } else if (SelVal == '') {
                        e.returnValue = false;
                    } else if ((key < 48 || key > 57)) {
                        e.returnValue = false;
                    }
                } else if (Val.length == 3) {
                    if (SelStart == 0 && SelEnd == 0) {
                        if ((key < 48 || key > 57)) {
                            e.returnValue = false;
                        }
                    } else {
                        e.returnValue = false;
                    }
                } else if (Val.length == 4) {
                    if (key == 47) {
                        element.value = '/' + Val;
                        e.returnValue = false;
                        element.selectionStart = 0;
                        element.selectionEnd = 0;
                    } else if ((key < 48 || key > 57)) {
                        e.returnValue = false;
                    } else {

                        element.value = '/' + Val.substr(0, 1) + String.fromCharCode(key) + Val.substr(1);
                        e.returnValue = false;
                        element.selectionStart = 0;
                        element.selectionEnd = 0;
                    }
                }

            } else {
                if (key < 48 || key > 57) {
                    if (key == 45) return;
                    if ((element.Dec != undefined) && (element.Dec != ""))
                        if (parseInt(element.Dec, 10) > 0)
                            if (key == 46) return;
                    if ((p == "D" || p == "G") && key == 46) return;
                    e.preventDefault();
                    e.cancelBubble = true;
                    e.returnValue = false;
                }
            }
            $(element).data("npchange", "1");
            return;
        }
        if (key > 1547) {
            alert("لطفا حالت صفحه کليد خود را به انگليسي تغيير دهيد.");
            e.preventDefault();
            e.cancelBubble = true;
            e.returnValue = false;
            return;
        }
        var PreventSpecialChar = (element.Lan == "3") ? 1 : 0;
        if (!element.ALan || element.ALan == "") {
            if (element.Lan == "2") {
                element.ALan = "2";
            } else {
                element.ALan = "1";
                if (!element.Lan) element.Lan = "0";
            }
        }
        var fs = '';
        if (element.ALan == "1") //Farsi
            if (key > 31 && key < 128) {
                if (!shift && key < 91 && key > 64) key = key + 32;
                if (shift && key < 123 && key > 96) key = key - 32;
            }
        if (element.ALan == "1" && element.Pic == 'F') // farsi faghat harf dar halate farsi-latin ya faghat farsi
            fs = ValidChars["ALan1F"]
        else if (element.ALan == "2" && element.Pic == 'F') // latin faghat harf dar halate farsi-latin
            fs = ValidChars["ALan2F"]
        else if (element.Pic == 'N') // latin faghat harf
            fs = ValidChars["ALan12N"]
        else if (element.Pic == 'N2') // latin ba charactere khas
            fs = ValidChars["ALan12N2"]
        else if (element.ALan == "1" && element.Pic == "F2") //farsi ba charactere khas dar halate farsi-latin ya faghat farsi
            fs = ValidChars["ALan1F2"];
        else if (element.ALan == "2" && element.Pic == "F2") // latin ba charactere khas dar halate farsi-latin
            fs = ValidChars["ALan2F2"]
        else if (element.ALan == "1") //farsi dar halate farsi-latin
            fs = ValidChars["ALan1"];
        if (fs != '') {
            var val = this.value;
            var k = fs.charCodeAt(key - 32);
            if (String.fromCharCode(k) == '~') return false;
            //e.keyCode=k;
            var mappedChar = String.fromCharCode(k); //transformTypedChar(String.fromCharCode(k));
            var start = this.selectionStart;
            var end = this.selectionEnd;
            this.value = val.slice(0, start) + mappedChar + val.slice(end);
            this.selectionStart = this.selectionEnd = start + 1;
            $(element).data("npchange", "1");
            //this.focus();
            //this.select();
            e.preventDefault();
        }

    };

    Field.onkeyup = function(e) {

        var element = this;
        //this.UpdateSndData(1);           
        var v_max = element.Max,
            v_min = element.Min;
        if (typeof(v_max) == 'undefined') v_max = element.max;
        if (typeof(v_min) == 'undefined') v_min = element.min;
        if (typeof(v_max) == 'undefined' || v_max == '') v_max = 0;
        if (typeof(v_min) == 'undefined' || v_min == '') v_min = 0;

        var key;
        //var e=window.event;
        key = e.keyCode;
        if (element.onkeyup2 != undefined) {
            try {
                element.KeyUpEvent = e;
                var KeyUpEvent = element.KeyUpEvent;
                eval("window.parent.Master.Form_Body." + element.onkeyup2 + "");
                // eval(element.onkeyup2);
            } catch (e) {}
        }
        if (key == 27) {
            element.value = element.oldValue;
            element.valid = true;
            return;
        }
        if (key == 17) { //Ctrl has pressed
            if (!element.Lan) {
                element.ALan = '1';
            } else {
                if (element.Lan == '0') {
                    switch (element.ALan) {
                        case '2':
                            {
                                element.ALan = '1';
                                break;
                            }
                        case '1':
                            {
                                element.ALan = '2';
                                break;
                            }
                    }
                }
            }
            e.preventDefault();
            e.cancelBubble = true;
            e.returnValue = false;
            return;
        }

        if (key == 8 || (key >= 33 && key <= 39) || key == 45 || key == 46)
            return;
        if (key == 13 || key == 9 || key == 16) {
            e.preventDefault();
            e.cancelBubble = true;
            e.returnValue = false;
            return;
        }
        //return;
        var d = window.document.all;

        //شماره نامه
        if (element.Pic && element.Pic == "A") {
            if (element.value.length == 2) {
                element.value = element.value + '.';
                return;
            }
            element.value = element.value.slice(0, 8);
            if (element.value.length >= 8) {
                element.change(null, e); //change(null,e);
                //ClearValue(element.id,1);
                element.FocusNext();
            }
            return;
        }

        //شماره دانشجوئي
        if (element.Pic && element.Pic == "S") {
            if (element.value.length >= stdlen) {
                element.value = element.value.slice(0, stdlen);
                element.change(null, e); //change(null,e);
                //ClearValue(element.id,1);
                element.FocusNext();
            }
            return;
        }
        //date -------------------------------------
        var p = element.Pic;
        if ((element.Typ == "C" || element.Typ == "D") && p && (p == "D" || p == "G")) {
            var ValTemp = element.value.replace(/(\/)/g, '');
            if (element.value.length > 10 && top.SupportOldGolestan && (p == "D" || p == "G")) {
                element.value = element.LastValue;
                e.preventDefault();
                e.cancelBubble = true;
                e.returnValue = false;
                return;
            }
            if (key == 8 || (element.Typ == "C" && top.SupportOldGolestan && p == "D")) {
                e.preventDefault();
                e.cancelBubble = true;
                e.returnValue = false;
                return;
            }
            var s = element.value;
            var m = (s.substr(3, 2) == '') ? 0 : parseFloat(s.substr(3, 2)),
                da = parseFloat(s.substr(0, 2));
            try {
                if (s.length > 7 && s.indexOf("\.") >= 0) {
                    var ta = s.split("\.");
                    if (ta[2].length < 2) da = 1;
                    else da = parseFloat(ta[2]);
                    if (ta[1].length < 2) m = 1;
                    else m = parseFloat(ta[1]);
                }
                if (s.length > 4 && (m < 1 || m > 12)) {
                    alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
                    e.preventDefault();
                    e.cancelBubble = true;
                    e.returnValue = false;
                    return;
                }
                var mi = (p == 'D') ? 0 : 1;
                if (s.length > 1 && (da < 1 || da > ml[mi][m])) {
                    alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
                    element.SetFocus();
                    return -1;
                }
                if (s.length == 2 || s.length == 5) {
                    element.value = s + '/';
                    return;
                }
                if (v_max > 0) {
                    if ((element.value.length) >= parseInt(v_max) + 2) {
                        element.value = element.value.slice(0, parseInt(v_max) + 2);
                        //element.change(null,e);
                        //if (element.valid)  element.FocusNext();
                        //$(element).blur();
                        if (element.valid)
                            element.FocusNext();
                        else {
                            if (!$(element).is(':focus'))
                                element.change(null, e);
                        }

                    }
                }
            } catch (e) {}
            return;
        }
        //------------------------------------------
        //time -------------------------------------
        if ((element.Typ == "C" || element.Typ == "T") && p && p == "T") {
            if (key == 8) {
                e.preventDefault();
                e.cancelBubble = true;
                e.returnValue = false;
                return;
            }
            if (element.value.length == 2) {
                if (parseFloat(element.value) < 0 || parseFloat(element.value) > 59) {
                    alert('دقيقه نمي تواند بيش از مقدار 59 داشته باشد');
                    e.preventDefault();
                    e.cancelBubble = true;
                    e.returnValue = false;
                    return;
                } else {
                    element.value = element.value + ':';
                    return;
                }
            }
            if (v_max > 0) {
                if ((element.value.length) >= parseInt(v_max) + 1) {
                    element.value = element.value.slice(0, parseInt(v_max) + 1);
                    //element.change(null,e);
                    //if (element.valid)  element.FocusNext();
                    //  $(element).blur();
                    if (element.valid)
                        element.FocusNext();
                    else {
                        if (!$(element).is(':focus'))
                            element.change(null, e);
                    }

                }
            }
            return;
        }
        //------------------------------------------

        if (v_max > 0) {
            if ((element.value.length) >= parseInt(v_max)) {
                element.value = element.value.slice(0, parseInt(v_max));
                //element.change(null,e);
                //if (element.valid)  element.FocusNext();
                // $(element).blur();
                if (element.valid)
                    element.FocusNext();
                else {
                    if (!$(element).is(':focus'))
                        element.change(null, e);
                }

            }
        }

    };
}

function Get_Data() {
    b = parent.Master.Form_Body;
    var FrmObjList;
    try {
        FrmObjList = b.FrmFields;
    } catch (r) {
        return;
    }
    try {
        b.MaxHlp.value = '';
        b.MaxHlp.UpdateSndData();
    } catch (e) {}
    b.frmchg = false;
    FD = window.parent.Data.DataModi;
    Fr_Data = window.parent.Data;
    act = FD.Fm_Action.value;
    if (act == "00" && !msie()) {
        for (var i = 0; i < FrmObjList.length; i++) {
            if (FrmObjList[i].tagName == "INPUT" || FrmObjList[i].tagName == "TEXTAREA") {

                KeyEvents(FrmObjList[i]);

            }
        }
    }
    var ErLen = 0;
    try {
        if (!Fr_Data.ErrorArr) {
            ErLen = Fr_Data.ErrorDSC.length;
        } else {
            ErLen = Fr_Data.ErrorDSC.length + Fr_Data.ErrorArr.length;
        }
    } catch (e) {
        ErLen = 1;
    }
    setnexact(act, ErLen);
    switch (act) {
        case "95":
        case "96":
        case "97":
            {
                return;
            }
        case "00":
            {
                if (msie()) {
                    IM01_Create.disable_Butt();
                    IM02_Delete.disable_Butt();
                    IM03_Modify.disable_Butt();
                }
                break;
            }
        case "08":
            {
                if (ErLen == 0) {
                    if (FD.PhotoAddr &&
                        b.document.all.item("PhotoPer")) {
                        if (FD.PhotoAddr.value != null) {
                            b.document.all.item("PhotoPer").style.display = "";
                            b.document.all.item("PhotoPer").src = FD.PhotoAddr.value + b.document.all.item("F38001").value + '.gif';
                        }
                    }
                }
                FocusFirstObj();
                break;
            }
        default:
            {
                try {
                    if (ErLen > 0) ShowStatus('Error');
                    else ShowStatus('Ok');
                } catch (e) {
                    return -1
                };
            }
    }
    try {
        b.Dsbl_Key(true);
    } catch (e) {
        if (InitFrm() < 0) return;
    }
    parent.Message.HideMsg();
    if (window.ActiveXObject) {
        var XmlRcv = new ActiveXObject("Microsoft.XMLDOM"),
            A = null;
        XmlRcv.loadXML(FD.TxtMiddle.value);
    } else {
        var parser = new DOMParser(),
            XmlRcv = parser.parseFromString(FD.TxtMiddle.value, "text/xml");
    }
    try {
        var x, t;
        if (top.$iswinopen) {
            x = top.$openedwinInXML.documentElement.attributes;
            A = top.$openedwinACT;
        } else {
            var f = parent.parent.t.FaciArr[GetContInd()];
            if (!top.SupportOldGolestan) {
                t = f.par;
                //t.faci.auth.GetFromCookie();
                x = t.faci.auth.XmlSnd.documentElement.attributes;
                A = t.faci.auth.Act;
                t.faci.auth.Act = null;
            } else {
                A = f.Params.NF_Act;
                f.Params.NF_Act = null;
                x = f.Params.NF_XmlSnd.documentElement.attributes;
            }
        }
        for (var i = 0; i < x.length; i++) {
            if (msie())
                var n = XmlRcv.documentElement.selectSingleNode('\/\/' + x[i].name);
            else {
                var n = XmlRcv.evaluate('\/\/' + x[i].name, XmlRcv, null, 9, null);
                n = n.singleNodeValue;
            }
            if (!n) {
                if (msie()) {
                    var Nod = XmlRcv.createNode(1, x[i].name, "");
                } else {
                    var Nod = XmlRcv.createElement(x[i].name);

                }
                Nod.setAttribute("val", x[i].value);
                XmlRcv.childNodes[0].appendChild(Nod);
            } else {
                n.setAttribute("val", x[i].value);
            }
        }
        if (top.$iswinopen) {
            top.$openedwinInXML = null;
        } else {
            if (!top.SupportOldGolestan) {
                if (msie()) {
                    t.faci.auth.XmlSnd.loadXML('<r/>');
                } else {
                    t.faci.auth.XmlSnd = new DOMParser().parseFromString("<r/>", "text/xml");
                    t.faci.auth.XmlSnd.xml = new XMLSerializer().serializeToString(t.faci.auth.XmlSnd);

                }
            } else {
                f.Params.NF_XmlSnd.loadXML('<r/>');
            }
        }
    } catch (e) {}
    for (var i = 0; i < (FrmObjList.length); i++) {
        try {

            curr_field = FrmObjList[i];

            curr_field = RealObj(curr_field);

            if ($ && !window.ActiveXObject) {
                /*curr_field.id=$(curr_field).id();
                curr_field.tagName=$(curr_field).tagName();*/
            }

            try {
                Icurr_field = b.document.images["I" + curr_field.id];
            } catch (e) {}
            ide = curr_field.Mat || $(curr_field).attr("Mat");
            if (typeof(ide) == "undefined" || ide == "") {
                if (curr_field.id)
                    ide = curr_field.id;
                else if ($)
                    ide = $(curr_field).attr("id");
                if (ide == '') {
                    ide = curr_field.name;
                }
            }
            if (msie()) {
                var FSelf = XmlRcv.documentElement.selectNodes('\/\/' + curr_field.id);
                var F = XmlRcv.documentElement.selectNodes('\/\/' + ide);
                var CSelf = FSelf.nextNode();
            } else {
                var FSelf = XmlRcv.getElementsByTagName(curr_field.id);
                var F = XmlRcv.getElementsByTagName(ide);
                var CSelf = FSelf[0] //&&FSelf[0].nextSibling; 
            }
            if (CSelf) {
                var v = CSelf.attributes.getNamedItem("val").value;
                switch (curr_field.tagName) {
                    case 'LABEL':
                    case 'A':
                    case 'FONT':
                    case 'SPAN':
                        {
                            curr_field.innerHTML = StandardHtml(v);
                            break;
                        }
                    case 'IFRAME':
                        {
                            frame_set(curr_field.name, 'i&x', v);
                            /*var b=window.parent.Master.Form_Body, x=b.frames[curr_field.name].frames['F'];
                            x.document.body.innerHTML=v;
                            b.XmlSnd.documentElement.setAttribute(curr_field.name)=v;*/
                            break;
                        }
                    default:
                        {
                            curr_field.value = v;
                            try {
                                if (window.ActiveXObject)
                                    curr_field.value = curr_field.GetVal(v);
                                else {
                                    try {
                                        curr_field.value = curr_field.GetVal(v);

                                    } catch (e) {
                                        curr_field.value = $(curr_field).GetVal(v);
                                    }
                                }
                                curr_field.UpdateSndData();
                            } catch (e) {}
                            curr_field.oldValue = v;
                        }
                }
            }
            var visible = false
            try {
                if (curr_field.clientWidth > 0) {
                    visible = true;
                } else if (curr_field.HFld.clientWidth > 0) {
                    visible = true;
                }
            } catch (e) {}

            if (F.length > 0 /*&& visible*/ ) {
                if (msie())
                    var C = F.nextNode();
                else
                    var C = F[0]; //F[0].nextSibling;   
                if (C && C.childNodes.length == 0) {
                    try {
                        curr_field.HFld.value = curr_field.value;
                        curr_field.style.display = "none";
                        curr_field.HFld.style.display = "";
                        Icurr_field.src = "/_Images/ComboBox.gif";
                        Icurr_field.style.display = "";
                    } catch (e) {}
                } else {
                    try {

                        curr_field.HFld.style.display = "";
                        curr_field.style.display = "none";
                        curr_field.HFld.length = C.childNodes.length;
                        for (var j = 0; j < C.childNodes.length; j++) {
                            curr_field.HFld.item(j).innerText = C.childNodes[j].attributes.getNamedItem("dsc").value;
                            curr_field.HFld.item(j).value = C.childNodes[j].attributes.getNamedItem("val").value;
                        }
                        curr_field.HFld.value = curr_field.value;
                        Icurr_field.style.display = "";
                        Icurr_field.src = "/_Images/ComboBox.gif";
                        try {
                            curr_field.change();
                        } catch (e) {
                            npLog(curr_field.id + '::' + e.name + '::' + e.message, true);
                        }
                    } catch (e) {
                        curr_field.style.display = "";
                        if (C)
                            curr_field.value = C.childNodes[0].attributes.getNamedItem("val").value;
                        try {
                            try {
                                curr_field.UpdateSndData()
                            } catch (e) {
                                $(curr_field).UpdateSndData()
                            }
                            //curr_field.UpdateSndData();
                        } catch (e) {
                            npLog(curr_field.id + '::' + e.name + '::' + e.message, true);
                        }
                        curr_field.oldValue = curr_field.value;
                    }
                }
            }
            try {
                if (curr_field.HFld.length == 0) {
                    curr_field.HFld.style.display = 'none';
                    Icurr_field.style.display = 'none';
                    curr_field.style.display = '';
                }
            } catch (e) {}
            if (curr_field.id == 'F00111') {
                curr_field.change();
            }
            try {
                if (curr_field.id == 'F00061') {
                    switch (curr_field.value) {
                        case '2':
                            {
                                b.ins.checked = true;
                                break;
                            }
                        case '3':
                            {
                                b.del.checked = true;
                                break;
                            }
                        case '4':
                            {
                                b.upd.checked = true
                                break;
                            }
                    }
                    b.Dsbl_Key(true);
                }
            } catch (e) {}
        } catch (e) {}
    }
    if (act == '00') {
        ClearContent('00');
        FocusFirstObj();
    }
    if (b.Get_Data)
        b.Get_Data();

    if (A && act == '00') {
        act_data_frm(A);
    }
    CheckDisableLinks();

}



function FocusFirstObj() {
    try {
        eval("ACT=window.parent.Master.Form_Body.ACT" + NextAct + fmod);
        ACT[0].SetFocus(true);
        if (!window.ActiveXObject) {
            setTimeout(function() {
                if (ACT[0].valid)
                    ACT[0].oldValue = ACT[0].value;
            }, 0)
        }
    } catch (e) {}

}


//Check Validation Of Active Fields
function CheckVal(act_no) {
    var FieldValue, CheckValFlds;
    try {
        d = window.parent.Master.Form_Body.document.all;
        eval("CheckValFlds=window.parent.Master.Form_Body.ACT" + act_no + fmod + ";");
        if (top.SupportOldGolestan) {
            $.each(window.parent.Master.Form_Body.FrmFields, function(i, v) {
                if ((v.Pic == "D" || v.Pic == "G") && v.value != "")
                    CheckValFlds.push(v);
            })
        }

    } catch (e) {
        return 1;
    }
    if (typeof(CheckValFlds) == 'undefined' || !CheckValFlds) return 1;
    for (var i = 0; i < CheckValFlds.length; i++) {
        curr_field = CheckValFlds[i];
        /*if(!msie()){
          curr_field=$(curr_field); 
        }*/
        if (typeof(curr_field.CheckVal) != "undefined") {
            if (curr_field.CheckVal() < 0) return -1;
        }
        /*else if($ && typeof($(curr_field).CheckVal)!="undefined"){
                 if ($(curr_field).CheckVal()<0) return -1;
              }*/
    }
    return 1;
}

//Activate Data Frame
function act_data_frm(act_no, nocheckval) {
    if (window.parent.Message.document.readyState != "complete") {
        window.setTimeout("act_data_frm('" + act_no + "');", 10);
        return;
    }
    if (window.parent.Data.document.readyState != "complete") {
        if (act_no == "00") {
            window.setTimeout("act_data_frm('" + act_no + "');", 10);
            return;
        }
        return -1;
    }
    if (parent.Message.ShowPleaseWait() < 0) return -1;
    if (!nocheckval && CheckVal(act_no) < 0) {
        parent.Message.HideMsg();
        return -1;
    }
    window.parent.Data.DataModi.Fm_Action.value = act_no;
    if (act_no != "96" && act_no != "97" && act_no != "95" && act_no != "94")
        if (Put_Data(act_no) < 0) {
            parent.Message.HideMsg();
            return -1;
        }
    //}
    if (typeof(window.parent.Data.DataModi) != "object") alert("DataModi Not an object.");
    if (act_no == "94") {
        try {
            window.parent.Data.DataModi.Frm_Type.value = window.parent.Master.Form_Title.Frm_Type.value;
        } catch (e) {
            window.parent.Data.DataModi.Frm_Type.value = window.parent.Master.Form_Title.SubFrmSeq.value;
        }
        try {
            window.parent.Data.DataModi.F_ID.value = window.parent.Master.Form_Title.F_ID.value;
        } catch (e) {}
        LastActNo = "94";
    }
    if (top.SupportOldGolestan && LastActNo == "94") {
        LastActNo = act_no;
        //window.parent.FixSimpleGrids();
        //window.parent.FixHiddenInputs();
    }
    if (top.$iswinopen) {
        var a = top.$openedwinAut[top.$openedwinAut.length - 1];
        RetAut(a);
        setTimeout("parent.Data.DataModi.submit()", 1);
    } else {
        var fac, t, a;
        if (!top.SupportOldGolestan) {
            fac = parent.parent.t.FaciArr[GetContInd()];
            t = fac.par;
            a = fac.auth;
        } else {
            t = top.FaciObj;
            a = t.FaciArr[GetContInd()].auth;
        }
        setTimeout(function() {
            if (t.ready < 0) {
                window.setTimeout(function() {
                    parent.Message.HideMsg();
                    act_data_frm(act_no);
                }, 10);
                return;
            }
            RetAut(a);
            parent.Data.DataModi.submit();
        }, 1);
    }
}

function IM13_Do_onclick() {
    if (IM13_Do.disabled) return;
    IM13_Do.disable_Butt();
    if (parent.Master.Form_Body.ChangeDo)
        if (parent.Master.Form_Body.ChangeDo() < 0) {
            IM13_Do.enable_Butt();
            return -1
        };
    if (act_data_frm("09") < 0) IM13_Do.enable_Butt();
}

function IM08_Control_onclick() {
    if (IM08_Control.disabled) return;
    var FieldValue;
    IM08_Control.disable_Butt();
    if (act_data_frm("01") < 0) IM08_Control.enable_Butt();
}

function IM01_Create_onclick() {
    if (IM01_Create.disabled) return;
    IM01_Create.disable_Butt();
    switch (window.parent.Master.Form_Title.FrmTyp) {
        case 'I':
            {
                if (act_data_frm("02") < 0)
                    IM01_Create.enable_Butt();
                break;
            }
        default:
            if (act_data_frm("09") < 0)
                IM01_Create.enable_Butt();
    }
}

function IM02_Delete_onclick() {
    if (IM02_Delete.disabled) return;
    IM02_Delete.disable_Butt();
    switch (window.parent.Master.Form_Title.FrmTyp) {
        case 'D':
            {
                if (act_data_frm("03") < 0)
                    IM02_Delete.enable_Butt();
                break;
            }
        default:
            if (act_data_frm("09") < 0)
                IM02_Delete.enable_Butt();
    }
}

function IM03_Modify_onclick() {
    if (IM03_Modify.disabled) return;
    IM03_Modify.disable_Butt();
    switch (window.parent.Master.Form_Title.FrmTyp) {
        case 'U':
            {
                if (act_data_frm("04") < 0)
                    IM03_Modify.enable_Butt();
                break;
            }
        default:
            if (act_data_frm("09") < 0)
                IM03_Modify.enable_Butt();
    }
}

function IM06_Search_onclick() {
    if (IM06_Search.disabled) return;
    IM06_Search.disable_Butt();
    var p = window.parent.Master.Form_Body.document.all.item("PhotoPer");
    if (window.parent.Data.DataModi.PhotoAddr && p) {
        p.style.display = "none";
    }
    if (act_data_frm("08") < 0) IM06_Search.enable_Butt();
}

function window_onload() {
    if (parent.NewsPage.document.readyState != 'complete') {
        setTimeout("window_onload()", 200);
        return;
    }
    try {
        var dum = parent.Message.tbl_Msg.rows[0].cells[0].innerText;
    } catch (e) {
        setTimeout("window_onload()", 200);
        return;
    }
    try {
        if (typeof(window.parent.Master) != "object") {
            window.setTimeout("window_onload();", 200);
            return;
        } else {
            if (parent.Master.Form_Title.document.readyState != 'complete') {
                setTimeout("window_onload()", 200);
                return;
            }
            if (parent.Master.Form_Body.document.readyState != 'complete') {
                setTimeout("window_onload()", 200);
                return;
            }
            if (parent.Data.src == null) {
                /*if(!window.ActiveXObject){
                   IM01_Create=$(IM01_Create);
                   IM02_Delete=$(IM02_Delete);
                   IM03_Modify=$(IM03_Modify);
                   IM04_PreviousPage=$(IM04_PreviousPage);
                   IM05_NextPage=$(IM05_NextPage);
                   IM06_Search=$(IM06_Search);
                   IM08_Control=$(IM08_Control);   
                }*/
                IM01_Create.disable_Butt();
                IM02_Delete.disable_Butt();
                IM03_Modify.disable_Butt();
                IM04_PreviousPage.disable_Butt();
                IM05_NextPage.disable_Butt();
                IM06_Search.disable_Butt();
                IM08_Control.disable_Butt();

                return;
            }
            if (typeof(window.parent.Master.Form_Body) != "object") {
                setTimeout("window_onload();", 10);
                return;
            } else {
                if (typeof(window.parent.Master.Form_Body.NOPage) != "object") {
                    setTimeout("window_onload();", 10);
                    return;
                }
            }
        }

        IM01_Create.disable_Butt();
        IM02_Delete.disable_Butt();
        IM03_Modify.disable_Butt();
        IM04_PreviousPage.disable_Butt();
        if (window.parent.Master.Form_Body.NOPage.value <= 1)
            IM05_NextPage.disable_Butt();
        //page change code
        BoPage.value = "of " + window.parent.Master.Form_Body.NOPage.value
    } catch (e) {}

    var u, u_ = parent.document.URL;
    u = u_.replace('Dat.htm', 'Dat.aspx');
    if (u != u_) {
        var q = u.split('&');
        for (var i = 0; i < q.length; i++) {
            var qi = q[i].split('=');
            //if(qi[0]=='mi'){
            //parent.pagetitle.max_idl=qi[1];
            //}
            if (qi[0] == 'ltck') {
                parent.Data.document.cookie = 'lt=' + escape(qi[1]);
            }
        }
        if (parent.Data.location != u) {
            setTimeout("parent.Data.location='" + u + "'", 100);
        }
    } else {
        var uu = parent.Data.location.toString();
        if (uu.search(/blank.htm/i) > 0) {
            parent.Data.location = '/forms/f0240_process_authnav/nav.aspx' + parent.document.location.search;
        }
    }
}

function fqs(key) { //FindInQueryString
    var kv, qs = window.parent.location.search.substr(1).split(/\&/);
    for (var i = 0; i < qs.length; i++) {
        kv = qs[i].split(/\=/);
        if (kv[0] == key) {
            return kv[1];
        }
    }
    return null;
}

function SetOpenerTck(tck) {
    //var ttop=top.opener;
    if (top.SupportOldGolestan) {
        top.FaciObj.SetOpenerTck(tck, GetContInd());
        return;
    }
    if (top.$iswinopen) {
        if (msie())
            var ifr = top.document.frames(top.npnfwinopenerid()),
                d = ifr.Data.DataModi;
        else {
            var ifr = top.window.frames[top.npnfwinopenerid()];
            if (!ifr)
                ifr = top.window.frames[top.window.frames.length - 2];
            d = ifr.Data.DataModi;


        }



        d.TicketTextBox.value = tck;
        try {

            top.t.FaciArr[ifr.ContInd].auth.tck = tck;
        } catch (e) {}
        return;
    }
    var f, op;
    try {
        f = parent.parent.t.FaciArr[GetContInd()];
        op = f.Opener;
        if (op && (op.doc.frames || op.doc[op.f.id] || op.doc.defaultView[op.f.id])) {
            var d = op.doc.frames ? op.doc.frames(op.f.id).Data.DataModi : (op.doc[op.f.id] ? op.doc[op.f.id].Data.DataModi : op.doc.defaultView[op.f.id].Data.DataModi); // ie - chrome - firefox
            d.TicketTextBox.value = tck;
            op.auth.tck = tck;
        }
    } catch (e) {
        alert(e.message);
    }
}

function TabReady(tf) {
    //var f=parent.parent.t.FaciArr[parent.ContInd],tab=f.par;
    var tab = top.t;
    tab.ready++;
    if (tab.ready > 0) tab.ready = 0;
    if (top.SupportOldGolestan) {
        top.FaciObj.TabReady(GetContInd());
        return;
    }

}

function SetTime(y, m, d, wd, ho, mi) {
    if (top.SupportOldGolestan) {
        top.SetTimeFromOldGolestan(y, m, d, wd, ho, mi);
        return;
    }
    if (y < 1388) return;
    if (!parent.ContObj) {
        setTimeout('SetTime(' + y + ',' + m + ',' + d + ',' + wd + ',' + ho + ',' + mi + ')', 100);
        return;
    }
    parent.ContObj.par.maintitle.tim.SetTime(y, m, d, wd, ho, mi);
}

function SetBrNam(h3) {
    if (top.SupportOldGolestan) {
        $("html", parent.Master.document).attr("dir", "rtl");
        top.FaciObj.SetBrNam(GetContInd(), h3);
        return;
    }
    if (top.$iswinopen) return;
    var f = parent.parent.t.FaciArr[parent.ContInd],
        butt = f.butt;
    butt.SetBrNam(h3);
    butt.par.maintitle.SetGTit(null, null, h3);
}

function mex() {
    try {
        if ($('input#ex', parent.Data.DataModi).length == 0)
            $(parent.Data.DataModi).append('<input type="text" name="ex" id="ex">');

    } catch (e) {
        alert(e.message);
    }
}

function SavAut(u, su, ft, fid, ltck, tck, seq, nam, cchg, ut, actsign) {
    var cook = document.cookie.split(";");
    var sess = '';
    for (var i = 0; i < cook.length; i++) {
        var n = cook[i].split("=");
        //if(trim(n[0])=='ASP.NET_SessionId'){ sess  = trim(n[1]) ;}
    }
    if (top.SupportOldGolestan) {
        //TODO:
        var arr, ContInd = GetContInd();
        top.FaciObj.SetAut(ContInd, {
            u: u,
            su: su,
            ft: ft,
            f: fid,
            ltck: ltck,
            lt: ltck,
            tck: tck,
            seq: seq,
            sess: '',
            //sid:'',
            actsign: actsign,
            ut: ut
        })
        if (top.SupportOldGolestan && $("link[href='/_Scripts/o2n/o2nStyles.css']", window.parent.Master.Form_Body.document.all[1]).length == 0) {
            $(window.parent.Master.Form_Body.document.all[1]).append('<link rel="stylesheet" type="text/css" href="/_Scripts/o2n/o2nStyles.css" />')
            $(window.parent.Master.Form_Body.document.all[1]).append('<link rel="stylesheet" type="text/css" href="/_Styles/jqui/themes/np/ui.css" />')
        } else {

        }

        top.FaciObj.SetNam(ContInd, nam, cchg, ut);
        return;
    }
    if (top.Data && top.Master) {
        alert("top.Data");
        return;
    }
    if (ltck == '' || tck == '')
        return;
    if (top.$iswinopen) {
        top.$openedwinAut[top.$openedwinAut.length - 1] = {
            u: u,
            su: su,
            ft: ft,
            f: fid,
            ltck: ltck,
            tck: tck,
            seq: seq,
            sess: ''
        };
        RetAut();
        return;
    }


    var tab = parent.parent.t,
        fac = tab.FaciArr[parent.ContInd],
        a = fac.auth;
    a.SetVal(u, su, ft, fid, ltck, tck, seq, sess, actsign);
    if (nam) {
        fac.butt.SetNam(nam, cchg, ut);
        tab.VisButts(true);
    }
    if (fac.Clop) {
        fac.Clop = false;
        tab.Close(fac.Opener, null, true);
        fac.Opener = null;
    }
}

function CheckValidChars(text, element) {
    return true;
    var CharsList = "";
    element.Lan = element.Lan || $(element).attr("lan");
    if (element.Lan == "1" && element.Pic == 'F')
        CharsList = ValidChars["ALan1F"]
    else if (element.Lan == "1" && element.Pic == 'F2')
        CharsList = ValidChars["ALan1F2"]
    else if (element.Lan == "2" && element.Pic == 'F')
        CharsList = ValidChars["ALan2F"]
    else if (element.Lan == "2" && element.Pic == "F2")
        CharsList = ValidChars["ALan2F2"]
    else if (element.Pic == 'N')
        CharsList = ValidChars["ALan12N"]
    else if (element.Pic == 'N2')
        CharsList = ValidChars["ALan12N2"]
    else if (element.Lan == "0" && element.Pic == 'F')
        CharsList = ValidChars["ALan1F"].concat(ValidChars["ALan2F"]);
    else if (element.Lan == "0" && element.Pic == 'F2')
        CharsList = ValidChars["ALan1F2"].concat(ValidChars["ALan2F2"]);
    /*else if(element.Lan=="0")
       CharsList = ValidChars["ALan1"].concat(ValidChars["ALan2F"]); */
    if (CharsList == "")
        return true;
    CharsList = "[^(" + CharsList.replace(/~/g, "").replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1") + ")]";
    if (text.match(new RegExp(CharsList, "g")))
        return false;
    return true;
}

function RetAut(a) {
    var d = parent.Data.document;
    if (top.$iswinopen) {
        var a = top.$openedwinAut[top.$openedwinAut.length - 1];
        d.cookie = 'u=' + a.u + "; path=/";
        d.cookie = 'lt=' + a.ltck + "; path=/";
        d.cookie = 'su=' + a.su + "; path=/";
        d.cookie = 'ft=' + a.ft + "; path=/";
        d.cookie = 'f=' + a.f + "; path=/";
        d.cookie = 'seq=' + a.seq + "; path=/";
        $("#ex", f).val(a.ft + '|' + a.f + '|' + a.seq + '|' + a.su)
        return;
    }
    if (!a) {
        if (!top.SupportOldGolestan) {
            var f = parent.parent.t.FaciArr[parent.ContInd];
            a = f.auth;
        } else {
            var ContInd = GetContInd();
            if (!ContInd) {
                alert('ContInd is not found in RetAut');
                return;
            }
            a = top.FaciObj.FaciArr[ContInd].auth;
        }
    }

    d.cookie = 'u=' + a.u + "; path=/";
    d.cookie = 'lt=' + a.ltck + "; path=/";
    d.cookie = 'su=' + a.su + "; path=/";
    d.cookie = 'ft=' + a.ft + "; path=/";
    d.cookie = 'f=' + a.f + "; path=/";
    d.cookie = 'seq=' + a.seq + "; path=/";
    $("#ex", f).val(a.ft + '|' + a.f + '|' + a.seq + '|' + a.su)
}

function NF_init(ft, fid, act, t, l, w, h) {
    NF_ft = ft;
    NF_fid = fid;
    NF_act = act;
    NF_fidvar = null;
    NF_t = t;
    NF_l = l;
    NF_w = w;
    NF_h = h;
    NF_HR = false;
    NF_modal = false;
    NF_after = false;
    NF_clop = false;
    NF_HFld = null;
    if (window.ActiveXObject) {
        NF_X = new ActiveXObject("Microsoft.XMLDOM");
        NF_X.loadXML('<r/>');
    } else {
        NF_X = new DOMParser().parseFromString("<r/>", "text/xml");
    }
    NF_DisPos = null;
    NF_BRN = '';
    NF_LMT = '';
    NF_sub = null;
}

function NF_SetHR(tf) {
    NF_HR = tf;
    if (tf) {
        NF_after = tf;
        NF_clop = false;
    }
}

function NF_SetModal(tf) {
    NF_modal = tf;
    if (tf) {
        NF_HR = tf;
        NF_after = tf;
    }
}

function NF_CloseOpener(tf) {
    NF_clop = tf;
    NF_SetHR(false);
    NF_SetModal(false);
}

function NF_SetHFld(HFld) {
    NF_HFld = HFld;
}

function NF_SetBRN(brn, lmt) {
    NF_BRN = brn;
    NF_LMT = lmt;
}

function NF_SetFidVar(v) {
    NF_fidvar = v;
}

function NF_SetSub(v) {
    NF_sub = v;
}

function NF_Call() {
    if (parent.Message.WebBusy) {
        return -1;
    }
    var f = parent.parent.t.FaciArr[GetContInd()],
        t = f.par,
        pt = this.NF_t,
        pl = this.NF_l,
        pw = this.NF_w,
        ph = this.NF_h;
    if (top.SupportOldGolestan) {
        t = top.t;
    }
    if (true) { //(!top.SupportOldGolestan){
        if (t.ready < 0) {
            alert('امکان باز کردن صفحه جديد در حال حاضر وجود ندارد.');
            return -1;
        }
        t.ready--;
    }
    for (var i = 0; i < arguments.length; i += 2) {
        NF_X.documentElement.setAttribute(arguments[i], arguments[i + 1]);
    }
    RetAut();
    var tck = 0,
        ltck = 0,
        cook = document.cookie.split(";");
    if (true) { //(!top.SupportOldGolestan){
        tck = parent.Data.DataModi.TicketTextBox.value;
    } else {
        tck = top.FaciObj.FaciArr[GetContInd()].auth.tck;
    }
    for (var i = 0; i < cook.length; i++) {
        var n = cook[i].split("=");
        if (trim(n[0]) == 'lt') {
            ltck = trim(n[1]);
        }
    }
    switch (NF_DisPos) {
        case 'TabCenter':
            {
                pt = (t.tHeight - NF_h) / 2;
                pl = (t.tWidth - NF_w) / 2;
                pw = NF_w;
                ph = NF_h;
                break;
            }
    }
    if (top.SupportOldGolestan) {
        var TabId = GetContInd(),
            Params = {},
            ThisFaciArr = top.FaciObj.FaciArr[GetContInd()],
            SelfOfMenu = ThisFaciArr.Params.OpenerSelf; //ThisFaciArr.SelfOfMenu||
        Params.OldGolestanOpenerTabId = TabId;
        Params.OldGolestan = true;
        Params.OpenFromNewGolestan = false;
        Params.ParentAut = top.FaciObj.FaciArr[TabId].auth;

        Params.CmpType = NF_ft;
        Params.CmpId = NF_fid;
        Params.NF_fidvar = NF_fidvar;
        Params.NF_sub = NF_sub;
        Params.NF_BRN = NF_BRN;
        Params.NF_LMT = NF_LMT;
        //Params.ParentDataModi=parent.Data.DataModi;//remove this line after commit form.js (use Openerframset instead)
        Params.NF_XmlSnd = NF_X;
        Params.NF_Act = NF_act;
        Params.OpenerLi = top.FaciObj.FaciArr[TabId].Params.NewLi;
        Params.Openerframset = parent;
        //TODO:
        //if(NF_HFld)t.faci.ParF=NF_HFld;
        //NF_HR
        //t.faci.RelPar=f;
        //NF_modal,,Opener,NF_clop
        Params.After = NF_after;
        SelfOfMenu.AfterGetForm(Params);
        /*Params.AfterClose=function(myEvent,p){
           var ThisFaciArr=top.FaciObj.FaciArr[TabId];
           var au=ThisFaciArr.auth;
           Params.Openerframset.Master.Form_Body.AfterCloseChild(au.ft,au.f,p);
        }
        var outpar={} 
        for(var i=0;i<arguments.length;i+=2){
           outpar[arguments[i]]=arguments[i+1].toString();
        }
        Params.inxml = {doact : {act:NF_act}};
        Params.inxml.outpar=outpar;
        SelfOfMenu.OpenNewForm(NF_ft,NF_fid,NF_sub,NF_BRN,NF_LMT,Params);
        */
        return;
    }
    if (!top.SupportOldGolestan) {
        var v = (NF_fidvar) ? '&fv=' + NF_fidvar : '';
        var nam = '',
            url = "/forms/f0240_process_authnav/nav.htm?r=" + Math.random() + "&fid=" + NF_ft + ";" + NF_fid + v + ((NF_sub) ? "&sub=" + NF_sub : "") + "&b=" + NF_BRN + "&l=" + NF_LMT + "&tck=" + tck;
        var Opener = null;
        Opener = f;
        t.maintitle.ShowGTit();
        if (!pt) {
            t.AddNew(nam, url, NF_modal, NF_after, Opener, NF_clop);
        } else {
            t.AddNew(nam, url, NF_modal, NF_after, Opener, NF_clop, pt, pl, pw, ph);
        }
        t.Activate();
        t.faci.auth.XmlSnd = NF_X;
        t.faci.auth.Act = NF_act;
        if (NF_HFld) t.faci.ParF = NF_HFld;

        if (NF_HR) {
            t.faci.RelPar = f;
            if (!f.RelChi) {
                t.faci.FirstChild = true;
                f.RelChi = t.faci;
            } else {
                var lf = f.RelChi;
                while (lf.RelBro) {
                    lf = lf.RelBro;
                }
                lf.RelBro = t.faci;
                t.faci.RelBroRev = lf;
            }
        } else {
            t.faci.RelPar = null;
        }
        return;
    }
}

function go(ft, f, clop) {
    if (top.Login_header_logo)
        top.Hide_Login_header_logo();
    NF_init(ft, f);
    NF_CloseOpener(clop);
    NF_Call();
}


function trim(s) {
    try {
        return s.replace(/^\s+|\s+$/g, "");
    } catch (e) {
        return ''
    };
}

function RetPar(a) {
    var f = parent.parent.t.FaciArr[GetContInd()];
    if (top.SupportOldGolestan) {
        alert('Retpar');
    }
    f.RetPar(a);
}

function IM10_Default_onclick() {
    FrmObjList = window.parent.Master.Form_Body.FrmFields;
    for (var i = 0; i < (FrmObjList.length); i++) {

        curr_field = FrmObjList[i];
        if (curr_field.tagName == "INPUT") {
            if (curr_field.Def != '$') { //$=مقدار پيش فرض در فيلد ريخته نشود
                curr_field.value = curr_field.Def;
                curr_field.UpdateSndData();
                try {
                    curr_field.HFld.value = curr_field.value;
                } catch (e) {}
            }
        }
    }
    if (parent.Master.Form_Body.SetDefaultValue)
        parent.Master.Form_Body.SetDefaultValue();
}

function RealObj(c) {
    try {
        if (typeof(c.tagName) == 'undefined') {
            var x = c.name;
            if (!window.ActiveXObject && c.ZoomEd) {
                if (x != "") {
                    c.Tname = x;
                } else {
                    c.name = c.Tname;
                    x = c.Tname;
                }
            }
            if (!x) {
                return c;
            }
            return eval('parent.Master.Form_Body.document.all.' + x);
            //parent.Master.Form_Body.document.all[x];
        } else {
            return c;
        }

    } catch (e) {
        // bug in TextArea on Edge browser
        if (!window.ActiveXObject)
            return $("iframe[lan][cap][max][onactivate]", parent.Master.Form_Body.document)[0];
    }

}

function ClearContent(act, unload) {
    b = window.parent.Master.Form_Body;
    try {
        b.T01.CancelFill();
    } catch (e) {} //Form 1.5 
    if (!unload && savechg(true) < 0) return -1;
    b.frmchg = false;
    FrmObjList = b.FrmFields;
    var FrmObjList_length = 0;
    try {
        FrmObjList_length = FrmObjList.length;
    } catch (e) {}
    for (var i = 0; i < (FrmObjList_length); i++) {
        curr_field = FrmObjList[i];
        curr_field = RealObj(curr_field);
        if (top.SupportOldGolestan)
            curr_field.Def = $(curr_field).attr("Def");
        if (curr_field.tagName == 'IFRAME') {
            frame_set(curr_field.name, 'i&x', '');
            continue;
        }
        if (!msie())
            curr_field.Def = $(curr_field).attr("Def") || $(curr_field).attr("def");
        if (typeof(curr_field.Def) != "undefined") {
            try {
                if (curr_field.Def != '$')
                    try {
                        if (curr_field.tagName == 'INPUT' || curr_field.tagName.substr(0, 5) == 'npobj' || (!window.ActiveXObject && curr_field.tagName == 'TEXTAREA')) {
                            if (act != '00' || curr_field.value == '') {
                                if (curr_field.tagName.substr(0, 5) == 'npobj') {
                                    if (curr_field.tagName == "npobj_editor" && !window.ActiveXObject)
                                        curr_field.ta.value = curr_field.value;
                                    curr_field.SetVal(curr_field.Def);
                                } else {
                                    curr_field.value = curr_field.Def;
                                }
                                curr_field.UpdateSndData();
                            }
                        } else {
                            if (act != '00' || curr_field.innerText == '')
                                curr_field.innerText = curr_field.Def;
                        }
                    }
                catch (e) {}
            } catch (e) {}

            curr_field.oldValue = curr_field.value;

        } else
        if (act != '00') {
            if (window.ActiveXObject)
                curr_field.innerText = "";
            else {
                $(curr_field).text("");
                $(curr_field).val("");
                if (curr_field.r && curr_field.m && curr_field.s) {
                    curr_field.value = "";
                    /*curr_field.UpdateSndData();*/
                    curr_field.s.value = "";
                    curr_field.m.value = "";
                    curr_field.r.value = "";
                }

            }
        }
        try {
            curr_field.HFld.value = curr_field.value;
        } catch (e) {}
        try {
            curr_field.RefreshRadio();
        } catch (e) {}
        if (curr_field.id == 'F00111') curr_field.change();
    }
    if (CI(0) == 1) NextAct = '08'; //کليد جستجو وجود دارد
    else
    if (CI(1) == 1) NextAct = '01'; //کليد بررسي وجود دارد
    else
    if (CI(3) == 1) NextAct = '02'; //کليد ايجاد وجود دارد
    else
    if (CI(4) == 1) NextAct = '03'; //کليد حذف وجود دارد
    else
    if (CI(5) == 1) NextAct = '04'; //کليد اصلاح وجود دارد
    else
    if (CI(6) == 1) NextAct = '09'; //کليد اعمال وجود دارد

    InitFrm();
    FocusFirstObj();
    if (b.ClearContent) b.ClearContent(act, unload);
    parent.Message.HideMsg();

    if (window.parent.Data.DataModi.PhotoAddr &&
        b.document.all.item("PhotoPer")) {
        b.document.all.item("PhotoPer").style.display = "none";
    }
    CheckDisableLinks();
}

function CheckDisableLinks() {
    if (!msie()) {
        $("a", parent.Master.Form_Body.document).each(function(i, v) {
            if (v.disabled) {
                $(v).addClass("DisabledLink");
            } else {
                $(v).removeClass("DisabledLink");
            }
        })
    }
}
var FullScr = false;

function IM14_FullScreen_onclick() {
    return;
    if (window.parent.document.body.rows == '0,0,100%,30,30') {
        FullScr = false;
        window.parent.document.body.rows = '0,80,100%,30,30';
        if (parent.Master.Form_Body.OnFullScreen) window.parent.Master.Form_Body.OnFullScreen(false);
    } else {
        FullScr = true;
        window.parent.document.body.rows = '0,0,100%,30,30';
        if (parent.Master.Form_Body.OnFullScreen) window.parent.Master.Form_Body.OnFullScreen(true);
    }

}

function IM16_ViewRep_onclick() {
    var DoArc = false;
    if (typeof(window.parent.Master.Form_Body.DoArc) != "undefined")
        DoArc = window.parent.Master.Form_Body.DoArc;
    if (!DoArc && (parent.Data.DataModi.usrlvl & 0xb400000) > 0)
        $("#view_arc", window.parent.frames["Master"].frames["Form_Body"].document).show();
    else
        window.parent.Master.Form_Body.SendXmlForSP_with_pleasewait((DoArc ? 2 : null));

}

function savechg(tomenu) {
    var s1 = 'لطفا درخواست خروج از سيستم را تاييد نماييد',
        s2 = ' اطلاعات وارد شده ذخيره نشده است. در صورت تاييد، این اطلاعات از دست می رود.';
    var b = window.parent.Master.Form_Body,
        fc;
    try {
        fc = (!b.sensechg) ? false : b.frmchg;
    } catch (e) {
        return 0;
    }
    if (!fc) {
        if (!tomenu)
            if (!confirm(s1)) return -1;
    } else {
        if (!confirm(s2)) return -1;
    }
    return 0;
}

function ReturnMenu() {
    try {
        if (!window.parent.Master.Form_Body.ReturnMenu())
            return -1;
    } catch (e) {

    }
    if (ClearContent('', true) < 0) return;
    parent.Message.HideMsg();
    if (top.SupportOldGolestan) { //also for top.$iswinopen this code is true to close dialog in new system
        top.FaciObj.ReturnOpener(GetContInd());
        return;
    }
    if (top.$iswinopen) {
        var au = top.$openedwinAut[top.$openedwinAut.length - 1];
        top.ex(au.ltck, au.tck, au.u, au.seq, au.ft, au.f, au.sess);
        top.$openedwin.hide();
        top.npnfclosewin(window.parent.Master.Form_Body.paramforopener);
        RetAut(top.$iswinopen ? top.$openedwinAut[top.$openedwinAut.length - 1] : parent.parent.t.FaciArr[parent.parent.t.FaciArr.length - 1].auth);

        //$(top.$openedwin).faciinwin('close');
        /*   top.$openedwin.parentNode.removeChild(top.$openedwin);
        top.$openedwin=null;*/
        return;
    }
    var t = parent.parent.t,
        f = t.FaciArr[parent.ContInd],
        a = f.auth;
    if (t.FaciArr.length > 1) {
        var o = f.Opener;
        o = o ? o : t.FaciArr[0];
        if (t.Close(f) == -1) return;
        t.Activate(o);
    } else {
        setTimeout('go(0,11130,true);', 10);
    }
}

function LogOff() {
    if (top.SupportOldGolestan) return;
    parent.parent.closeall();
}

function exitUser() {
    if (savechg(false) < 0) return;
    try {
        if (window.parent.Master.Form_Body.exitUser() < 0) return;
    } catch (e) {}
    if (act_data_frm("97") < 0) {
        enabledBtn();
    }
}

function enabledBtn() {
    try {
        IM90_gomenu.parentElement.style.display = 'inline';
        IM91_exit.parentElement.style.display = 'inline';
        login.parentElement.style.display = 'inline';
        try {
            IM90_gomenu.enable_Butt();
            IM91_exit.enable_Butt();
            login.enable_Butt();
        } catch (e) {

        }
    } catch (e) {
        setTimeout("enabledBtn()", 10);
    }
}

function disabledBtn() {
    try {
        IM16_ViewRep.disable_Butt();
        IM90_gomenu.disable_Butt();
        IM91_exit.disable_Butt();
        login.disable_Butt();
    } catch (e) {
        setTimeout("disabledBtn()", 10);
    }
}
//-----------------------------------------
function setShowBtn() {
    for (var i = 0; i < document.all.ImgTbl.rows[0].cells.length; ++i) {
        var c = document.all.ImgTbl.rows[0].cells[i];
        if (CI(i) == "1") {
            c.style.display = "inline-block";
            if (c.width == "70px") c.width = "50px"; // be khatere inline-block shodan width ziyad shode ast
            //if(i<7)c.childNodes(0).disable_Butt();
            if (i < 7) try {
                c.disable_Butt()
            } catch (e) {};
        } else {
            c.style.display = "none";
        }
    }
    enabledBtn();
}

function Hi() {
    this.bgColor = '#B5D6BE';
    this.style.border = '1px solid black';
}

function Lo() {
    this.bgColor = '';
    this.style.border = '1px solid white';
}
//------------------------------------------
function FormGuideClick() {
    var fid = 0,
        SubFrmSeq = 0;
    try {
        fid = parent.Master.Form_Title.F_ID.value;
    } catch (e) {}
    try {
        SubFrmSeq = window.parent.Master.Form_Title.SubFrmSeq.value;
    } catch (e) {}
    //window.open('/Forms/F0224_PROCESS_FACIHELP/F0224_PROCESS_FORMGUIDE.aspx?tck='+parent.Data.DataModi.TicketTextBox.value+'&fi='+fid+'&ft=0&sseq='+SubFrmSeq,'','help:no;resizable:yes;status:no;center:yes;dialogwidth=600px');
    //window.open('/Forms/F0224_PROCESS_FACIHELP/F0224_PROCESS_FORMGUIDE.aspx?tck=' + parent.Data.DataModi.TicketTextBox.value + '&fi=' + fid + '&ft=0&sseq=' + SubFrmSeq, '', 'resizable=yes,toolbar=yes,menubar=yes,scrollbars=no,top=0,left=0,width=' + window.document.body.offsetWidth/2 + 'px,height=450px');
    window.open('/Forms/F0224_PROCESS_FACIHELP/F0224_PROCESS_FORMGUIDE.aspx?tck=' + parent.Data.DataModi.TicketTextBox.value + '&fi=' + fid + '&ft=0&sseq=' + SubFrmSeq, '', 'resizable=yes,toolbar=no,menubar=yes,scrollbars=no,top=0,left=0,width=800px,height=600px');
}

function Form_BodyLoad() {
    try {
        parent.Master.Form_Title.ImageHelp.onclick = FormGuideClick;
    } catch (e) {
        setTimeout('Form_BodyLoad()', 500);
        return;
    }
    if (!window.ActiveXObject) {
        $(".txt,select", window.parent.Master.Form_Body.document).each(function(i, v) {
            if (v.tagName == "INPUT" && $(v).attr("dir") != "ltr")
                $(v).css("font-family", "BTahoma")
            else if ($(v).attr("dir") == "ltr")
                $(v).css("font-family", "tahoma")
            $(v).attr("autocomplete", "off").MBPrepare();

        })

        var Img = $("img.Comm", window.parent.Master.Form_Body.document);
        for (var k = 0; k < Img.length; k++) {
            var v = Img[k];
            if ($(v).attr("src")) {
                $(v).attr("src2", $(v).attr("src"))
                $(v).attr("onclick_t", $(v).attr("onclick"));
            }

            v.disable_Butt = function() {
                var element = this;
                element.src = $(this).attr("src");
                //element.src2=$(this).attr("src2");
                element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
                if (!element.src) return;
                var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
                var comext = element.src.substr(element.src.length - 3);
                Disable = new Image();
                Disable.src = OrgSrc + '_disable.' + comext;
                element.disabled = true;
                element.src = Disable.src;
                $(element).attr("onclick", "return false;")
            }
            v.__proto__.disable_Butt = v.disable_Butt;
            v.enable_Butt = function() {
                var element = this;
                element.src = $(this).attr("src");
                //element.src2=$(this).attr("src2");
                element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
                if (!element.src) return;
                var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
                var comext = element.src.substr(element.src.length - 3);
                Enable = new Image();
                Enable.src = OrgSrc + '.' + comext;
                element.disabled = false;
                element.src = Enable.src;
                $(element).attr("onclick", $(element).attr("onclick_t"));
            }
            v.__proto__.enable_Butt = v.enable_Butt;
            v.init = function() {

            }
            v.__proto__.init = v.init;
        }

        /*$("img.Comm",window.parent.Master.Form_Body.document).each(function(i,v){
           if($(v).attr("src")){
             $(v).attr("src2",$(v).attr("src"))
             $(v).attr("onclick2",$(v).attr("onclick"));
           }
                 
           v.disable_Butt=function(){
              var element = this;
              element.src=$(this).attr("src");
              element.src2=$(this).attr("src2");
              if(!element.src) return;
              var OrgSrc=element.src2.substring(0,element.src2.length-4);
              var comext=element.src2.substr(element.src2.length-3);
              Disable = new Image();  Disable.src = OrgSrc+'_disable.'+comext;
              element.disabled = true;
              element.src = Disable.src;
              $(element).attr("onclick","return false;")
            }
            v.enable_Butt=function(){
               var element = this;
               element.src=$(this).attr("src");
               element.src2=$(this).attr("src2");
               if(!element.src) return;
               var OrgSrc=element.src2.substring(0,element.src2.length-4);
               var comext=element.src2.substr(element.src2.length-3);
               Enable = new Image();   Enable.src = OrgSrc+'.'+comext;
               element.disabled = false;
               element.src = Enable.src;
               $(element).attr("onclick",$(element).attr("onclick2"));
           }
        })
        */
        $("img.Comm", window.parent.Master.Form_Body.document).live("mouseover", function(e) {
            var element = $(this)[0];
            element.src = $(this).attr("src");
            element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
            var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
            var comext = element.src.substr(element.src.length - 3);

            Focus = new Image();
            Focus.src = OrgSrc + '_focus.' + comext;
            if (!element.disabled)
                element.src = Focus.src;

        })
        $("img.Comm", window.parent.Master.Form_Body.document).live("mouseout", function(e) {
            var element = $(this)[0];
            element.src = $(this).attr("src");
            //element.src2=$(this).attr("src2");
            element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
            var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
            var comext = element.src.substr(element.src.length - 3);
            Enable = new Image();
            Enable.src = OrgSrc + '.' + comext;
            if (!element.disabled)
                element.src = Enable.src;

        })
        $("img.Comm", window.parent.Master.Form_Body.document).live("mousedown", function(e) {
            var element = $(this)[0];
            element.src = $(this).attr("src");
            //element.src2=$(this).attr("src2");
            element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
            var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
            var comext = element.src.substr(element.src.length - 3);
            Clicked = new Image();
            Clicked.src = OrgSrc + '_clicked.' + comext;
            if (!element.disabled)
                element.src = Clicked.src;

        })
        $("img.Comm", window.parent.Master.Form_Body.document).live("mouseup", function(e) {
            var element = $(this)[0];
            element.src2 = element.src.split("_disable").length > 1 ? element.src.split("_disable")[0] : (element.src.split("_click").length > 1 ? element.src.split("_click")[0] : (element.src.split("_focus").length > 1 ? element.src.split("_focus")[0] : element.src.substring(0, element.src.length - 4)));
            var OrgSrc = element.src2; //element.src.substring(0,element.src.length-4);
            var comext = element.src.substr(element.src.length - 3);
            Focus = new Image();
            Focus.src = OrgSrc + '_focus.' + comext;
            if (!element.disabled)
                element.src = Focus.src;

        })
        var Img = $(".c1", [window.parent.Commander.document, window.parent.Master.Form_Body.document]);
        for (var k = 0; k < Img.length; k++) {
            var v = Img[k];
            v.disable_Butt = function() {
                //$(this).disable_Butt();
                var element = this;
                element.by = $(element).attr("by");
                element.bh = $(element).attr("bh");
                var bh;
                element.style.backgroundPositionY = -element.by;
                element.style.backgroundPositionX = 0;
                bh = element.bh;
                if (!bh) bh = 21
                element.bh = bh;
                element.disabled = true;
                try {
                    if (!window.ActiveXObject && element.tagName == "DIV")
                        $(element).css("pointer-events", "none");
                } catch (e) {

                }
                element.style.backgroundPositionY = -element.by - bh * 3 + "px";
            }
            v.__proto__.disable_Butt = v.disable_Butt;
            v.enable_Butt = function() {
                //$(this).enable_Butt();
                var element = this;
                element.by = $(element).attr("by");
                element.bh = $(element).attr("bh");
                var bh;
                element.style.backgroundPositionY = -element.by;
                element.style.backgroundPositionX = 0;
                bh = element.bh;
                if (!bh) bh = 21
                element.bh = bh;
                element.disabled = false;
                try {
                    if (!window.ActiveXObject && element.tagName == "DIV")
                        $(element).css("pointer-events", "auto");
                } catch (e) {

                }

                element.style.backgroundPositionY = -element.by + "px";
            }
            v.__proto__.enable_Butt = v.enable_Butt;
        }
        $("img.c1", window.parent.Master.Form_Body.document).each(function(i, v) {
            v.disable_Butt = function() {
                //$(this).disable_Butt();
                var element = this;
                element.by = $(element).attr("by");
                element.bh = $(element).attr("bh");
                var bh;
                element.style.backgroundPositionY = -element.by;
                element.style.backgroundPositionX = 0;
                bh = element.bh;
                if (!bh) bh = 21
                element.bh = bh;
                element.disabled = true;
                try {
                    if (!window.ActiveXObject && element.tagName == "DIV")
                        $(element).css("pointer-events", "none");
                } catch (e) {

                }
                element.style.backgroundPositionY = -element.by - bh * 3 + "px";
            }
            v.enable_Butt = function() {
                //$(this).enable_Butt();
                var element = this;
                element.by = $(element).attr("by");
                element.bh = $(element).attr("bh");
                var bh;
                element.style.backgroundPositionY = -element.by;
                element.style.backgroundPositionX = 0;
                bh = element.bh;
                if (!bh) bh = 21
                element.bh = bh;
                element.disabled = false;
                try {
                    if (!window.ActiveXObject && element.tagName == "DIV")
                        $(element).css("pointer-events", "auto");
                } catch (e) {

                }
                element.style.backgroundPositionY = -element.by + "px";
            }
        })
        $("img.c1", window.parent.Master.Form_Body.document).live("mouseover", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            bh = $(element).attr("bh");
            if (!bh) bh = 21;
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh + "px";

        })
        $("img.c1", window.parent.Master.Form_Body.document).live("mouseout", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") + "px";

        })
        $("img.c1", window.parent.Master.Form_Body.document).live("mousedown", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh * 2 + "px";

        })
        $("img.c1", window.parent.Master.Form_Body.document).live("mouseup", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh + "px";

        })

        //$("td.c1",document.all.ImgTbl)
        $(".c1", document).live("mouseover", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            bh = $(element).attr("bh");
            if (!bh) bh = 21;
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh + "px";

        })
        $(".c1", document).live("mouseout", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            //element.bh=(!element.bh)?21:element.bh;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") + "px";

        })
        $(".c1", document).live("mousedown", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            //element.bh=(!element.bh)?21:element.bh;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh * 2 + "px";

        })
        $(".c1", document).live("mouseup", function(e) {
            var element = $(this)[0];
            if (element.disabled) return;
            element.style.backgroundPositionY = -$(element).attr("by");
            element.style.backgroundPositionX = 0;
            //element.bh=(!element.bh)?21:element.bh;
            bh = $(element).attr("bh");
            if (!bh) bh = 21
            $(element).attr("bh", bh);
            element.style.backgroundPositionY = -$(element).attr("by") - bh + "px";

        })
        FixHiddenInputs();


    }
    FixSimpleGrids(window.ActiveXObject);
    if (checkmodi() < 0) {
        checkmodi_r = true;
        return;
    }
    if (checkmodi_r) {
        parent.Master.Form_Title.location.reload(true);
        checkmodi_r = false;
        return;
    }
    try {
        window.dialogArguments.title = window.parent.Master.Form_Title.document.all.tags('TABLE').item(0).rows[0].cells[2].innerText;
    } catch (e) {}


    act_data_frm("00");
    setShowBtn();
    setTimeout('try{parent.Master.Form_Body.F00111.change();}catch(e){}', 500);
    Curr_Page = 1;
    if (top.SupportOldGolestan) {
        LoadJQAndUi(1);
        FixHiddenInputs();
        FixSimpleGrids();
    }

}

function DivBestHeight(DivObj) {
    var top = 0,
        a = DivObj;
    while (a.tagName != 'BODY') {
        top += a.offsetTop; //-a.scrollTop;
        a = a.offsetParent;
    }
    var h = 0,
        x = DivObj;
    while (x != null && x.tagName != 'BODY') {
        if (x != DivObj) {
            if (x.offsetHeight != undefined) {
                if (x.style.position != 'absolute')
                    h += x.offsetHeight;
            }
        }
        while (x.tagName != 'BODY' && x.nextSibling == null) {
            x = x.parentNode;
        }
        x = x.nextSibling;
    }
    if (DivObj.scrollHeight < (a.clientHeight - top - h)) {
        return (DivObj.scrollHeight);
    } else {
        return (a.clientHeight - top - h - 4);
    }
}

function ShowDiv(DivObj, ParentObj) {
    var left = 0,
        top = 0,
        a = ParentObj;
    while (a.tagName != 'BODY') {
        left += a.offsetLeft;
        top += a.offsetTop - a.scrollTop;
        a = a.offsetParent;
    }
    DivObj.style.display = '';
    var DivWidth = DivObj.offsetWidth;
    var BodyWidth = document.body.clientWidth;
    if (left + 0.5 * DivWidth > BodyWidth)
        left = BodyWidth - DivWidth - 5;
    else {
        left = left - 0.5 * DivWidth;
        if (left < 0) left = 10;
    }
    DivObj.style.left = left;
    DivObj.style.top = top + 15;
}

function checkmodi() {
    var q = window.parent.Data.location.search;
    var l = q.substr(q.search(/lastm=/) + 6, 14)
    var clm = new Date(Date.parse(parent.Master.Form_Body.document.lastModified));
    clm = new Date(clm.toUTCString());
    var slm = new Date(Date.UTC(l.substr(0, 4), (l.substr(4, 2) - 1), l.substr(6, 2), l.substr(8, 2), l.substr(10, 2), l.substr(12, 2)));
    if (slm - clm > 3660000) {
        try {
            parent.Data.deffrm = parent.Master.Form_Title.SubFrmSeq.value;
        } catch (e) {}
        var b = parent.Master.Form_Body.document;
        var ifr = b.createElement('IFRAME'),
            st = ifr.style;
        ifr.name = 'reffr';
        st.position = 'absolute';
        st.right = 2;
        st.top = 2;
        st.width = 280;
        st.height = 73;
        ifr.src = "/_Templates/FormReload.htm";
        b.body.appendChild(ifr);
        return -1;
    }
    return 1;
}

function msg(t, s) { //string,type
    var o = new Object();
    o.t = t;
    o.s = s
    if (msie())
        window.showModalDialog('/_Templates/msg.htm', o, 'help:no;status:no;center:yes;dialogwidth:10;dialogheight:10');
    else
        window.open('/_Templates/msg.htm', o, 'help:no;status:no;center:yes;dialogwidth:10;dialogheight:10');

}

function frame_set(n, att, val) {
    try {
        var b = window.parent.Master.Form_Body,
            x = b.frames[n].frames['F'];
        if (!x)
            return;
        if (x.document)
            var bb = x.document.body;
        else
            var bb = x.contentDocument.body;
        if (att == 'c') {
            if (window.ActiveXObject) {
                bb.ce = val;
            } else {
                $(bb).attr("ce", val);
            }
        }
        if (att == 'i') {
            bb.innerHTML = val;
        }
        if (att == 'i&x') {
            bb.innerHTML = StandardHtml(val);
            b.XmlSnd.documentElement.setAttribute(n, val);
        }
    } catch (e) {

        alert(e.message);
        setTimeout('frame_set(\'' + n + '\',\'' + att + '\',\'' + val + '\')', 100);
    }
}

function CI(ind) {
    try {
        return eval('window.parent.Master.Form_Body.CommImage' + fmod + '[' + ind + ']')
    } catch (e) {
        return -1
    }
}

function HiHlpFld() {
    var b = parent.Master.Form_Body;
    for (var i = 0; i < b.HlpIn.length; i++) {
        var hf = b.HlpIn[i];
        try {
            b.bor = hf.currentStyle.borderColor;
        } catch (e) {
            b.bor = hf.style.borderColor;
        }
        //var bc=hf.className;
        //hf.className='txtHi';

        hf.style.borderColor = '#C7545F';
        try {
            b.hbor = hf.HFld.currentStyle.backgroundColor;
            hf.HFld.style.backgroundColor = '#C7545F';
        } catch (e) {
            try {
                b.hbor = hf.HFld.style.backgroundColor;
                hf.HFld.style.backgroundColor = '#C7545F';
            } catch (e) {

            }
        }
        //setTimeout("parent.Master.Form_Body."+hf.id+".className='"+bc+"';",500);
        //setTimeout(function(){parent.Master.Form_Body.HlpIn[i].className='TXT';},500);
    }
}

function NormHlpFld() {
    var b = parent.Master.Form_Body;
    for (var i = 0; i < b.HlpIn.length; i++) {
        var hf = b.HlpIn[i];
        //hf.className='txt';
        hf.style.borderColor = b.bor;
        try {
            hf.HFld.style.backgroundColor = b.hbor;
        } catch (e) {}
    }
}

function TDAbsIndex(TD) {
    var TR = TD;
    while (TR.tagName != 'TR') {
        if (TR.tagName == 'BODY') return 0;
        TR = TR.parentElement;
    }
    for (var i = 0; i < TR.cells.length; i++) {
        if (TR.cells[i] == TD) return i;
    }
    return 0;
}

function dashopr() {
    var b = parent.Master.Form_Body;
    if (b.F77771.value != '') {
        this.fromdash = true;
        var v = b.F77771.value.split('@@');
        b.F77771.value = v[0];
        b.F77771.UpdateSndData();
        if (v[1]) {
            this.fromdashact = v[1];
            try {
                b.F00111.value = v[1];
                b.F00111.UpdateSndData();
                b.F00111.change();
            } catch (e) {

            }
        }
    } else {
        this.fromdash = false;
    }
}

function npLog(msg, iserror) {
    try {
        if (console) {
            if (iserror)
                console.error(msg);
            else
                console.log(msg);
        }
    } catch (e) {}
    return;
};

function FixHiddenInputs() {
    $("input", parent.Master.Form_Body.document.all[0]).each(function(i, v) {
        //if ($(v).width() == 0 && $(v).closest("table").is(":visible"))
        if (v.style.width == "0px" || v.style.width == "0")
            $(v).css({
                "padding": "0px",
                "border": "0px"
            })

    })
}

function LoadJQAndUi(First) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '/_Scripts/jq.js';
    if (!parent.Master.Form_Body.jQuery && First) {
        parent.Master.Form_Body.document.all[1].appendChild(script);
    }
    if (parent.Master.Form_Body.jQuery) {
        parent.Master.Form_Body.jQuery.ajax({
            url: '/_Scripts/jqui.js',
            dataType: "script",
            success: function(xhr, msg) {
                parent.Master.Form_Body.jQuery.ajax({
                    url: '/_Scripts/jqui.date.js',
                    dataType: "script",
                    success: function(xhr, msg) {
                        parent.Master.Form_Body.jQuery.ajax({
                            url: '/_Scripts/jqui.date.calender.js',
                            dataType: "script",
                            success: function(xhr, msg) {
                                parent.Master.Form_Body.jQuery.ajax({
                                    url: '/_Scripts/jqui.date-fa.js',
                                    dataType: "script",
                                    success: function(xhr, msg) {
                                        parent.Master.Form_Body.DatePickerLoaded = true;
                                    }
                                })
                            }
                        })
                    }
                })
            }
        })
        return;
    } else {
        setTimeout(function() {
            LoadJQAndUi(0);
        }, 100)
    }
    /*if(First){
       var link = document.createElement('link');
       link.rel = 'stylesheet';
       link.href = '/_Scripts/o2n/Forms2.css';
       link.type= 'text/css';
       parent.Master.Form_Body.document.all[1].appendChild(link);
    }*/
}

function FixSimpleGrids(IE) {
    var SimpleGridSW = 0,
        SimpleGrid = $('table.simplegrid', parent.Master.Form_Body.document.all[0]);
    for (var k = 0; k < SimpleGrid.length; k++) {
        SimpleGrid = $(SimpleGrid[k]);

        //SimpleGrid.css({"width":"100%","max-width":"1px"});
        $("tr.Title2", SimpleGrid).css("display", "table-row");
        var Width = [];
        var SumWidth = 0;
        $("tr.title2 td:visible", SimpleGrid).each(function(i, v) {
            var W = $(v).attr("width");
            $(v).css("min-width", W + "px").css("max-width", W + "px");
            Width[i] = W;
            SumWidth += parseInt(W);

        })
        var j = 0;
        var Title = $('table tr:eq(0)', SimpleGrid.parent().siblings("div#T01Tit"))[0];
        var clientWidth = parent.Master.Form_Body.document.body.clientWidth;
        if (SumWidth > clientWidth && ($(SimpleGrid.parent().siblings("div#T01Tit"))[0].style.width == "" || $(SimpleGrid.parent().siblings("div#T01Tit"))[0].style.width == "100%")) {
            $(SimpleGrid.parent().siblings("div#T01Tit")).css({
                "width": clientWidth - 17 + "px",
                "overflow": "hidden"
            });
            // $("div#T01Div",SimpleGrid.parent()).css({"width":clientWidth+"px"});
        }
        if (IE)
            return;
        if (Title && Title.style.display == "none") {
            Title.style.display = "";
            Title.style.visibility = "hidden";
        }
        $('table tr:eq(0) td', SimpleGrid.parent().siblings("div#T01Tit")).each(function(i, v) {
            if ($(v).hasClass("hide"))
                return;
            if ($(v).attr("colspan")) {
                var W2 = 0;
                for (var m = 0; m < parseInt($(v).attr("colspan")); m++)
                    W2 += parseInt(Width[j + m]);
                $(v).css("min-width", W2 + "px").css("max-width", W2 + "px");
                j = j + parseInt($(v).attr("colspan"));
            } else {
                $(v).css("min-width", Width[j] + "px").css("max-width", Width[j] + "px");
                j++;
            }
        })
        /*if(SimpleGrid.parent().siblings("div#T01Tit")[0])
           SimpleGrid.parent().siblings("div#T01Tit")[0].onscroll=function(){
              return;
           }*/
    }
    /*var W2=[];
    var Count2=0;
    var Count=0;
    var MasterBody=parent.Master.Form_Body.document.all[0];
    var Header = $("#T01Tit", MasterBody).length==1 ? "T01Tit" : "T01DivTit";
    $('#'+Header+' tr:eq(0)', MasterBody).css("display","table-row");
    $('#'+Header+' tr.title:eq(0) td:visible', MasterBody).each(function(i,v){
       var Col = $(v).prop("colSpan");
       var W=0;    
       for(var j=0;j<Col; j++)
          W += parseInt(Width[Count+j])      
       Count+=Col;              
       $(v).css("width",W+"px"); 
      
    })*/
}

function StandardHtml(Str) {
    return Str; // bug in 16200
    var Result = {
        "flag": '',
        "Str": ''
    };
    var regex = /(<[^>]*\son\w*=[^>]*>)|(<[^>]*\w*=\W\s*javascript\s*:[^>]*>)|(<\s*\/?\s*(script|source|embed|body|head|html|iframe|audio|object|frameset|meta)\s*.*?>)/gi
    var found = Str.match(regex);
    if (found == null) {
        Result.Str = Str;
        Result.flag = true;
    } else {
        Result.flag = false;
        Result.Str = $('<A>' + Str + '</A>').text()
    }
    return Result.Str;
}
/*if(msie() == -1){

   IM06_Search.disable_Butt=function(){};
   IM08_Control.disable_Butt=function(){};
   IM01_Create.disable_Butt=function(){};
   IM02_Delete.disable_Butt=function(){};
   IM03_Modify.disable_Butt=function(){};
   IM13_Do.disable_Butt=function(){};
}*/