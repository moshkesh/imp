//file .js for help
var XMLDataHelp;
var XMLStruHelp;
var move = 0;
var currentNodeHelp;
//چندمين سطر ايکس ام ال تا کنون رسم شده است
var currentRow = 0;
var $ = $ ? $ : top.$;
var DIVwidthhelp = 0;
var xslString;
var clicked = 0;
var clickLeft;
var clickTop;
//آيا امکان ادامه ساخت جدول وجود دارد
var ContinueFillTag;
//آيا ساختن جدول در حال انجام است.
var InProc;
var objSortTest;
var MaxW, MaxH;
//-----------------------------------------------------------------------------------
var rowh = 20;

function declareXMLHelp() {
    FB = window.parent.Master.Form_Body;
    d = FB.document.all;
    try {
        f = FB.document.frames["FrameHelp"].document.all;
    } catch (e) {
        f = FB.window.frames["FrameHelp"].document.all;
    }

    var cHeight = top.SupportOldGolestan ? FB.innerHeight : FB.document.body.clientHeight;
    availrow = (cHeight - f.DIVhelpTit.offsetHeight - f.DIVhelpHeader.offsetHeight - 20) / rowh;
    if (window.ActiveXObject) {
        XMLDataHelp = new ActiveXObject("Msxml2.DOMDocument");
        XMLDataHelp.async = false;
        //   for DataFrame
        //   testXMLLode=XMLDataHelp.load("datahelp.xml"); 
        XMLDataHelp.loadXML(parent.Data.XMLForDat);
        XMLStruHelp = new ActiveXObject("Msxml2.DOMDocument");
        XMLStruHelp.async = false;
        //   for DataFrame
        //   XMLStruHelp.load("structhelp.xml"); 
        XMLStruHelp.loadXML(parent.Data.XMLForStr);
    } else {
        XMLDataHelp = new DOMParser().parseFromString(parent.Data.XMLForDat, "text/xml");
        XMLStruHelp = new DOMParser().parseFromString(parent.Data.XMLForStr, "text/xml");

    }


    ;
    rowno = XMLDataHelp.documentElement.childNodes.length;
}
//-----------------------------------------------------------------------------------
function createIFrame() {
    var cWidth = top.SupportOldGolestan ? FB.innerWidth : FB.document.body.clientWidth;
    var cHeight = top.SupportOldGolestan ? FB.innerHeight : FB.document.body.clientHeight;
    MaxW = cWidth - 20;
    MaxH = cHeight - 20;
    FB.DIVFrameHelp.style.height = "";
    FB.DIVFrameHelp.style.width = "";
    f.DIVhelpBody.style.width = "";
    f.DIVhelpHeader.style.width = "";
    d.FrameHelp.style.width = "";

    Fix = 'table-layout:fixed;';
    var bo = 'border="1"';
    if (window.ActiveXObject)
        var strHTML = '<table onclick="return window.parent.parent.parent.Commander.outputHelp(event)"  id="TablehelpBody" cellpadding="0" cellspacing="0" style="border-collapse: collapse;' + Fix + 'padding-right:5px"  ' + bo + ' onmouseover="return window.parent.parent.parent.Commander.mouseoverTR(event)" onmouseout="return window.parent.parent.parent.Commander.mouseoutTR(event)">';
    else
        var strHTML = '<table onclick="return window.parent.parent.parent.Commander.outputHelp(event)"  id="TablehelpBody" cellpadding="0" cellspacing="0" style="height:100%;border-collapse: collapse;' + Fix + 'padding-right:5px"  ' + bo + ' onmouseover="return window.parent.parent.parent.Commander.mouseoverTR(event)" onmouseout="return window.parent.parent.parent.Commander.mouseoutTR(event)">';
    window.parent.Master.Form_Body.FrameHelp.DIVhelpBody.innerHTML = strHTML + '</Table>';
    //يک متغير عمومي که گره جاري در ايکس ام ال داده ها نشان مي دهد
    currentNodeHelp = XMLDataHelp.documentElement.childNodes[0];
    createTHHelp();
    initialIFrame();
    if (rowno > 0 || top.SupportOldGolestan) DrawHelp();
    //createTBHelp();
}
//-----------------------------------------------------------------------------------
function help_onclick() {
    ContinueFillTag = true;
    InProc = false;
    window.parent.Master.Form_Body.FrameHelp.DataDirty.style.display = "none";
    currentRow = 0;

    var idwith = 0;
    declareXMLHelp();
    for (i = 1; i <= XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDNUMBERCOL").value; i++) {
        eval('idwith=idwith+parseInt(XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDWIDTH' + i + '").value);');
    }
    createIFrame();
}
//-----------------------------------------------------------------------------------
function Centr() {
    var l = parseInt(FB.DIVFrameHelp.style.left);
    var w = parseInt(FB.DIVFrameHelp.style.width);
    var t = parseInt(FB.DIVFrameHelp.style.top);
    var h = parseInt(FB.DIVFrameHelp.style.height);

    var cWidth = top.SupportOldGolestan ? FB.innerWidth : FB.document.body.clientWidth;
    var cHeight = top.SupportOldGolestan ? FB.innerHeight : FB.document.body.clientHeight;

    if (w > cWidth) l = 0;
    else l = (cWidth - w) / 2;
    if (h > cHeight) t = 0;
    else t = (cHeight - h) / 2;

    FB.DIVFrameHelp.style.left = l;
    FB.DIVFrameHelp.style.top = t + window.parent.Master.Form_Body.document.body.scrollTop;
}

function initialIFrame() {
    var cWidth = top.SupportOldGolestan ? FB.innerWidth : FB.document.body.clientWidth;
    var cHeight = top.SupportOldGolestan ? FB.innerHeight : FB.document.body.clientHeight;
    availrow = parseInt((cHeight - f.DIVhelpTit.offsetHeight - f.DIVhelpHeader.offsetHeight) / rowh) - 1;
    if (availrow <= 0) {
        try {
            FB.FrameHelp.dabov.style.height = parseInt(cHeight / 2) + "px";
        } catch (e) {
            return;
        }
        initialIFrame();
        return;
    }
    var cl = 'TableHeaderClass';
    try {
        if (Fix == '') cl = 'TableHeaderClassNoLine';
    } catch (e) {}
    f.TblHlpHeader.className = cl;
    if (!window.ActiveXObject) {
        for (var i = 0; i < f.TblHlpHeader.rows[0].cells.length; i++)
            f.TblHlpHeader.rows[0].cells[i].style.borderLeftColor = "#fff";
    }
    f.TblHlpTit.className = "TableTit";
    f.TablehelpBody.className = "TableBodyClass";
    if (window.ActiveXObject)
        f.DIVhelpBody.className = "DivBodyClass";
    var DIVwidthhelp2;
    vov = false;
    hov = false;
    if (rowno > availrow) {
        var c = $("td:visible", f.TblHlpHeader.rows[0]) /*f.TblHlpHeader.rows[0].cells*/ ;
        var scw = c[c.length - 1].width;
        scw = (scw == '') ? 0 : scw;
        c[c.length - 1].width = parseInt(scw) + 18;
        DIVwidthhelp += 18;
        vov = true;
    }
    if (DIVwidthhelp > MaxW) DIVwidthhelp2 = MaxW;
    else DIVwidthhelp2 = DIVwidthhelp;

    FB.DIVFrameHelp.style.visibility = "visible";

    if (f.TblHlpHeader.scrollWidth > DIVwidthhelp2 + 5) hov = true;
    f.DIVhelpBody.style.overflow = (rowno > availrow || hov) ? "auto" : "hidden";
    f.DIVexit.style.left = DIVwidthhelp2 - 15;

    f.DIVhelpBody.style.height = (rowno == 0) ? 0 : ((rowno > availrow) ? availrow : rowno) * rowh + 7 + (hov ? 20 : 0);

    f.DIVhelpBody.style.width = DIVwidthhelp2 + 4;
    f.DIVhelpHeader.style.width = DIVwidthhelp2 + 4; //-((hov)?18:0);
    d.FrameHelp.style.width = DIVwidthhelp2 + 4;
    FB.DIVFrameHelp.style.width = DIVwidthhelp2 + 8;
    var hh;
    if (top.SupportOldGolestan && rowno <= availrow) {
        hh = 20;
    } else {
        try {
            hh = FB.document.frames["FrameHelp"].document.body.scrollHeight;
        } catch (e) {
            hh = FB.FrameHelp.DIVhelp.offsetHeight; //FB.window.frames["FrameHelp"].document.body.scrollHeight;
        }
    }
    d.FrameHelp.style.height = hh;
    FB.DIVFrameHelp.style.height = parseInt(d.FrameHelp.style.height) + 6;
    Centr();
    FB.DIVFrameHelp.style.visibility = "visible";
    //------------------------

    FB.FrameHelp.DataDirty.style.left = 3;
    FB.FrameHelp.DataDirty.style.top = 0;
}
//-----------------------------------------------------------------------------------
function createTHHelp(ev) {
    var FD = parent.Data.DataModi;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    if (window.ActiveXObject) {
        var XmlRcv = new ActiveXObject("Microsoft.XMLDOM");
        XmlRcv.loadXML(FD.TxtMiddle.value);
        if (XmlRcv.parseError != 0) XmlRcv.loadXML('<r/>');
        var mt = XmlRcv.documentElement.selectSingleNode('\/\/UpTit'),
            mb = XmlRcv.documentElement.selectSingleNode('\/\/UpDat'),
            RMax = XmlRcv.documentElement.selectSingleNode('\/\/MaxRow');
    } else {
        var XmlRcv = new DOMParser().parseFromString(FD.TxtMiddle.value, "text/xml");
        var mt = XmlRcv.evaluate('\/\/UpTit', XmlRcv, null, 9, null),
            mb = XmlRcv.evaluate('\/\/UpDat', XmlRcv, null, 9, null),
            RMax = XmlRcv.evaluate('\/\/MaxRow', XmlRcv, null, 9, null);
        mt = mt.singleNodeValue;
        mb = mb.singleNodeValue;
        RMax = RMax.singleNodeValue;

    }
    var strHTML = '',
        tit, U, b = false,
        RMaxV = 32000;
    var idwidth, tit = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDTITLE").value;
    hlpstayonscreen = 0;
    try {
        hlpstayonscreen = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("STAY").value;
    } catch (e) {}
    try {
        RMaxV = RMax.attributes.getNamedItem("val").value;
    } catch (e) {}
    try {
        //tit=mt.attributes.getNamedItem("val").value;
        U = mb.attributes.getNamedItem("val").value;
        U = U.replace(/&amp;nbsp;/g, "&nbsp;");
        b = true;
    } catch (e) {}
    if (b) {
        strHTML += '<div style="width:100%;" class="TableTit" align=center>' + tit + '</div><DIV ALIGN="CENTER"><div id="dabov" align="right" style="margin-buttom:10px;overflow:auto;BACKGROUND-COLOR: #e7edee;WIDTH:99.5%">' +
            ((rowno >= RMaxV) ?
                '<TABLE><TR><TD><TABLE style="clea_r:none;float:right"><TR><TD>' +
                'حداکثر سطر قابل نمايش: ' +
                '</TD><TD>' +
                '<input id="MaxRow" value="' + ((RMaxV < 0) ? '' : RMaxV) + '" onchange="this.value=parseInt(this.value);if(isNaN(this.value))this.value=\'\';parent.MaxHlp.value=this.value;parent.MaxHlp.UpdateSndData();parent.PrH.click();" onkeypress="if(ev.keyCode==13){this.blur()}" style="border : #879EAC 1px solid;   font-size: 8pt;   font-family: Golestan System;height: 16px;line-height: 110%;background-color: WHITE;width:40px">' +
                '</TD><TD>' +
                '<input type="image" src="/_Images/Refresh.gif" onclick="parent.PrH.click();">' +
                '</TD></TR></TABLE>' +
                '  براي دريافت اطلاعات مفيدتر، مي توانيد در محل هايي که با کادر رنگي مشخص مي شود، به صورت زير عمل نماييد: <BR>-ورود ابتداي کلمه خاص، براي پيدا کردن عباراتي که با اين کلمه شروع مي شود.<BR>-استفاده از علامت % در ابتداي کلمه خاص، براي پيدا کردن عباراتي که اين کلمه در هرجاي آن قرار گرفته باشد.' +
                '</TD></TR></TABLE>' :
                '') +
            U +
            '</div></DIV>';
        tit = '';
    }
    DIVwidthhelp = 0;
    strHTML += '<table width="100%" id="TblHlpTit" cellpadding="0" cellspacing="0" style="border-collapse: collapse;TABLE-LAYOUT: fixed;left:0"  ><TR>';
    IDNUMBERCOL = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDNUMBERCOL").value;
    strHTML = strHTML + '<TD UNSELECTABLE="on" align="center" colspan="' + IDNUMBERCOL + '">' + tit + '</TD></TR></TABLE>';
    FB.FrameHelp.DIVhelpTit.innerHTML = strHTML;
    var bo = 'border="1"';
    try {
        if (Fix == '') bo = "";
    } catch (e) {}
    strHTML = '<TABLE   id="TblHlpHeader" cellpadding="0" cellspacing="0" style="border-collapse: collapse;TABLE-LAYOUT: fixed;" ' + bo + '><TR onmouseover="return window.parent.parent.parent.Commander.mouseoverTD(event)" onmouseout="return window.parent.parent.parent.Commander.mouseoutTD(event)">';
    for (i = 1; i < IDNUMBERCOL; i++) {
        eval('idwidth=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDWIDTH' + i + '").value;');
        DIVwidthhelp = DIVwidthhelp + parseInt(idwidth);
        eval('idcolumn=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDCOLUMN' + i + '").value;');
        var col_type = '';
        try {
            col_type = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem('COLTYPE' + i).value;
        } catch (e) {}
        var cl = 'TDHeader';
        try {
            if (Fix == '') cl = 'TDHeaderNoLine';
        } catch (e) {}
        // if(window.ActiveXObject)
        strHTML = strHTML + '<TD class=' + cl + '  col_type="' + col_type + '" sortField="C' + i + '" UNSELECTABLE="on" ' + ((idwidth == 0) ? 'style="display:none" ' : 'width="' + idwidth + '" ') + ' align="center" onclick="return window.parent.parent.parent.Commander.sorthelp()" >' + idcolumn + '</TD>';
        /*  else
         strHTML=strHTML+'<TD class='+cl+' col_type="'+col_type+'" sortField="C'+i+'" UNSELECTABLE="on" '+((idwidth==0 || idwidth==1)?'style="display:none" ':'width="'+idwidth+'" ')+' align="center" onclick="return window.parent.parent.parent.Commander.sorthelp()" >'+idcolumn+'</TD></TR></table>';
*/
    }
    eval('idwidth=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDWIDTH' + i + '").value;');
    //if(XMLDataHelp.documentElement.childNodes.length>availrow)//(f.TablehelpBody.clientHeight>300)
    /*if(rowno>availrow)
       idwidth=parseInt(idwidth)+18;*/

    DIVwidthhelp = DIVwidthhelp + parseInt(idwidth);
    eval('idcolumn=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDCOLUMN' + i + '").value;');
    var col_type = '';
    try {
        col_type = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem('COLTYPE' + i).value;
    } catch (e) {}
    var cl = 'TDHeader';
    try {
        if (Fix == '') cl = 'TDHeaderNoLine';
    } catch (e) {}
    //strHTML=strHTML+'<TD class='+cl+' col_type="'+col_type+'" sortField="C'+i+'" UNSELECTABLE="on" width="'+idwidth+'" align="center" onclick="return window.parent.parent.parent.Commander.sorthelp()" >'+idcolumn+'</TD></TR></table>';
    // if(window.ActiveXObject)
    strHTML = strHTML + '<TD class=' + cl + ' col_type="' + col_type + '" sortField="C' + i + '" UNSELECTABLE="on" ' + ((idwidth == 0) ? 'style="display:none" ' : 'width="' + idwidth + '" ') + ' align="center" onclick="return window.parent.parent.parent.Commander.sorthelp()" >' + idcolumn + '</TD></TR></table>';
    /* else
      strHTML=strHTML+'<TD class='+cl+' col_type="'+col_type+'" sortField="C'+i+'" UNSELECTABLE="on" '+((idwidth==0 || idwidth==1)?'style="display:none" ':'width="'+idwidth+'" ')+' align="center" onclick="return window.parent.parent.parent.Commander.sorthelp()" >'+idcolumn+'</TD></TR></table>';
*/
    FB.FrameHelp.DIVhelpHeader.innerHTML = strHTML;
}

function createTBHelp() {
    InProc = true;
    var f = window.parent.Master.Form_Body.FrameHelp;
    f.DataDirty.style.display = "";
    var iddata, celli, NoCol;

    var i, idwidth
    var TablehelpBody = f.TablehelpBody;
    if (currentNodeHelp) {
        var TD, TR = TablehelpBody.insertRow();
        NoCol = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDNUMBERCOL").value;
        for (i = 1; i <= NoCol; i++) {
            eval('idwidth=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDWIDTH' + i + '").value;');
            eval('iddirection=XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDDIRECTION' + i + '") ? XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDDIRECTION' + i + '").value : "";');

            calign = "right";
            try {
                calign = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem('ALIGN' + i).value;
            } catch (e) {}
            TD = TR.insertCell();
            //if(idwidth==0){
            //   TD.style.display='none';
            //}
            //else{
            TD.style.width = idwidth;
            // For Use In New System
            TD.style.direction = iddirection;
            var ClassName = 'D';
            if (idwidth == 0)
                ClassName = 'DH'
            //}
            TD.align = calign = calign.toLowerCase();
            TD.vAlign = 'top';
            if (!window.ActiveXObject && (TD.style.width == "1px" || TD.style.width == "0px")) {
                //TD.style.width="0px";
                TD.style.display = "none";
            }
            if (!window.ActiveXObject)
                TD.style.borderLeftColor = "#fff";
            if (calign == 'left') {
                TD.dir = 'LTR';
                TD.style.fontFamily = "tahoma"
            }
            try {
                iddata = currentNodeHelp.attributes.getNamedItem('C' + i).value;
            } catch (e) {
                iddata = '';
            }
            try {
                celli = TR.cells[i - 1];
                var ml = 0;
                try {
                    ml = XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("MULTILINE").value;
                } catch (e) {}
                if (ml == '1') {
                    if (calign == 'left') celli.className = 'LData';
                    else celli.className = 'Data';
                    celli.innerHTML = '<div style="white-space:pre-line">' + iddata + '</div>';
                    //celli.innerHTML='<pre style="font-family:Golestan System,tahoma;margin:0px;white-space:pre-wrap">'+iddata+'</pre>';
                    /*celli.style.whiteSpace="pre-line";*/
                    // celli.innerText=iddata;
                } else {
                    celli.className = ClassName;
                    celli.height = 20;
                    celli.innerHTML = '<nobr>' + iddata + '</nobr>';
                    //celli.innerText='<nobr>'+iddata+'</nobr>';
                }
                celli.title = celli.innerText;
            } catch (e) {
                alert('window.parent.Master.Form_Body.document.frames["FrameHelp"].document.all.TablehelpBody.rows[' + TR.rowIndex + '].cells[' + (i - 1) + '].innerText=' + iddata);
                return false;
            }
        }
        if (!vov) {
            if (TR.clientHeight > rowh) {
                var realH = TR.scrollHeight - rowh + f.DIVhelpBody.scrollHeight; //+parseInt(f.DIVhelpBody.style.height);
                if (realH > MaxH) {
                    vov = true;
                    f.DIVhelpBody.style.overflow = "auto";
                    var c = f.TblHlpHeader.rows[0].cells;
                    var scw = c[c.length - 1].width;
                    try {
                        c[c.length - 1].width = parseInt(scw) + 18;
                    } catch (e) {
                        c[c.length - 1].width = 18;
                    }
                } else {
                    f.DIVhelpBody.style.height = f.DIVhelpBody.scrollHeight + f.DIVhelpBody.offsetHeight - f.DIVhelpBody.clientHeight;
                }
            }
        }
        currentNodeHelp = currentNodeHelp.nextSibling;
        currentRow++;
        return false;
    }
    objSortTest = null;
    InProc = false;
    window.parent.Master.Form_Body.FrameHelp.DataDirty.style.display = "none";
    //initialIFrame();
    return true;

}
//-----------------------------------------------------------------------------------
function DrawHelp() {
    if (ContinueFillTag) {
        if (createTBHelp()) {
            if (f.DIVhelpBody.scrollHeight > f.DIVhelpBody.clientHeight) {
                var cHeight = top.SupportOldGolestan ? FB.innerHeight : FB.document.body.clientHeight;
                var avail = cHeight - f.DIVhelpBody.offsetTop - 10;
                if (f.DIVhelpBody.scrollHeight > avail) {
                    f.DIVhelpBody.style.height = avail;
                    f.DIVhelpBody.style.overflow = "auto";
                } else {
                    f.DIVhelpBody.style.height = f.DIVhelpBody.scrollHeight + (hov ? 25 : 0);
                }
            }

            try {
                d.FrameHelp.style.height = FB.document.frames["FrameHelp"].document.body.scrollHeight;
            } catch (e) {
                d.FrameHelp.style.height = FB.window.frames["FrameHelp"].document.body.scrollHeight;
            }
            FB.DIVFrameHelp.style.height = parseInt(d.FrameHelp.style.height) + 6;
            Centr();
            return;
        }
        if (currentRow > 20 && currentRow % 5 == 0)
            setTimeout("DrawHelp();", 70);
        else {
            DrawHelp();
        }
    }
}

function fillTBHelp() {
    currentNodeHelp = XMLDataHelp.documentElement.childNodes[0];
    var j = 0;
    var TablehelpBody, FrameHelp, rowj, celli, NoCol;
    try {
        TablehelpBody = window.parent.Master.Form_Body.document.frames["FrameHelp"].document.all.TablehelpBody;
    } catch (e) {
        TablehelpBody = window.parent.Master.Form_Body.frames["FrameHelp"].document.all.TablehelpBody;
    }
    FrameHelp = window.parent.Master.Form_Body.FrameHelp;
    NoCol = XMLStruHelp.documentElement.firstChild.attributes.getNamedItem("IDNUMBERCOL").value;
    while (currentNodeHelp) {
        rowj = TablehelpBody.rows[j];
        for (i = 1; i <= NoCol; i++) {
            try {
                iddata = currentNodeHelp.attributes.getNamedItem('C' + i).value;
            } catch (e) {
                iddata = '';
            }
            celli = rowj.cells[i - 1];
            celli.innerHTML = iddata;
            celli.title = celli.innerText;
        }
        j++;
        currentNodeHelp = currentNodeHelp.nextSibling;
    }
    FrameHelp.document.all.DIVhelp.style.cursor = "hand";
    FrameHelp.DataDirty.style.display = "none";
    FrameHelp.DataDirty.src = "/_images/hourglass.gif";
}
//-----------------------------------------------------------------------------------
function createXSLStrHelp(Cvalue, Corder, col_type) {
    col_type = col_type.toLowerCase();
    if (col_type == '' || (col_type != 'text' && col_type != 'number')) col_type = 'text';
    xslString = '<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"><xsl:output method="xml" encoding="UTF-8" omit-xml-declaration="yes"/><xsl:template match="/">   <xsl:apply-templates select="Root">   </xsl:apply-templates></xsl:template>   <xsl:template match="Root">   <xsl:copy>   <xsl:for-each select="row">';
    xslString = xslString + '<xsl:sort select="@' + Cvalue + '" lang="fa" data-type="' + col_type + '" order="' + Corder + '"></xsl:sort>';
    xslString = xslString + '<xsl:copy-of select="."></xsl:copy-of>   </xsl:for-each>   </xsl:copy></xsl:template></xsl:stylesheet>'
}
//-----------------------------------------------------------------------------------
function sorthelp(ev) {
    if (InProc) return;
    ContinueFillTag = false;
    //alert(window.parent.Master.Form_Body.FrameHelp.document.all.DIVhelp.style.cursor);
    window.parent.Master.Form_Body.FrameHelp.document.all.DIVhelp.style.cursor = "wait";
    window.parent.Master.Form_Body.FrameHelp.DataDirty.style.display = "";
    window.parent.Master.Form_Body.FrameHelp.DataDirty.src = "/_images/hourglassfix.gif";
    var objSort;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    objSort = ev.srcElement || ev.target;
    while (objSort.tagName != "TD") {
        objSort = objSort.parentNode;
    }
    if (objSort != objSortTest) {
        strorder = "";
        if (objSortTest != null) {
            objSortTest.style.backgroundImage = "";
        }
    }
    if (strorder != "ascending") {
        objSort.style.backgroundImage = "url(/_Images/sort_Up.gif)";
        objSort.style.backgroundRepeat = "no-repeat";
        objSort.style.backgroundPositionY = "5px";
        objSort.style.backgroundPositionX = "5px";
        strorder = "ascending";
    } else {
        objSort.style.backgroundImage = "url(/_Images/Sort_Down.gif)";
        objSort.style.backgroundRepeat = "no-repeat";
        objSort.style.backgroundPositionY = "5px";
        objSort.style.backgroundPositionX = "5px";
        strorder = "descending";
    }
    objSortTest = objSort;
    var sortField = (top.SupportOldGolestan || !window.ActiveXObject) ? $(objSort).attr('sortField') : objSort.sortField;
    var col_type = (top.SupportOldGolestan || !window.ActiveXObject) ? $(objSort).attr('col_type') : objSort.col_type;
    createXSLStrHelp(sortField, strorder, col_type);
    sort(xslString, XMLDataHelp);
    setTimeout("fillTBHelp();", 5);
}
//-----------------------------------------------------------------------------------
function sort(xslObject, xmlObject) {
    if (InProc) return;
    ContinueFillTag = false;
    if (window.ActiveXObject) {
        var XSLT = new ActiveXObject("Msxml2.XSLTemplate");
        var XSLDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument");
        XSLDoc.async = false;
        XSLDoc.loadXML(xslObject);
        XSLT.stylesheet = XSLDoc;
        var xslProc = XSLT.createProcessor();
        xslProc.input = xmlObject;
        xslProc.transform();
        var strxml = xslProc.output;
        xmlObject.loadXML(strxml);
    } else {
        var xmlDoc;
        var xslDoc;
        var xslTemplate;
        var xslProcessor;
        var xslFragment;

        xmlDoc = xmlObject; //new DOMParser().parseFromString(xmlObject, "text/xml");

        xslDoc = new DOMParser().parseFromString(xslObject, "text/xml");

        xslProcessor = new XSLTProcessor();
        xslProcessor.importStylesheet(xslDoc);
        /*xslFragment = xslProcessor.transformToFragment(xmlDoc, document);
        var strxml=document.createElement('DIV');
        strxml.appendChild(xslFragment);                     
        xmlObject = new DOMParser().parseFromString(strxml.innerHTML, "text/xml");
        XMLDataHelp = xmlObject;*/
        xslFragment = xslProcessor.transformToDocument(xmlDoc); //xslProcessor.transformToFragment(xmlDoc, document);
        XMLDataHelp = xslFragment;
    }
}
//-----------------------------------------------------------------------------------
function outputHelp(ev) {
    if (window.parent.Master.Form_Body.ver == 3) return outputHelp3(ev);
    var HFL;
    if (window.parent.Master.Form_Body.HlpFldList)
        HFL = window.parent.Master.Form_Body.HlpFldList;
    else
        HFL = null;
    ContinueFillTag = false;
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TR") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    var strtest = new String();
    j = 0;
    for (h = 0; h < XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("IDNUMBERCOL").value; h++) {
        k = 0;
        strtest = trim(obj.childNodes[h].innerText);
        for (i = 0; i < strtest.length; i++) {
            if (strtest.charAt(i) == ",") {
                j++;
                try {
                    if (!HFL)
                        eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + j + '").value;');
                    else
                        text = HFL[j - 1];
                    if (typeof(eval('window.parent.Master.Form_Body.' + text + '.value')) != 'undefined') {
                        eval('window.parent.Master.Form_Body.' + text + '.value=strtest.substr(k,i-k);');
                        eval('window.parent.Master.Form_Body.H' + text + '.value=strtest.substr(k,i-k);');
                    } else
                        eval('window.parent.Master.Form_Body.' + text + '.innerText=strtest.substr(k,i-k);');
                } catch (e) {}
                k = i + 1;
            }
        }
        j++;
        try {
            if (!HFL)
                eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + j + '").value;');
            else
                text = HFL[j - 1];
            if (typeof(eval('window.parent.Master.Form_Body.' + text + '.value')) != 'undefined') {
                eval('window.parent.Master.Form_Body.' + text + '.value=strtest.substr(k,i-k);');
                eval('window.parent.Master.Form_Body.H' + text + '.value=strtest.substr(k,i-k);');
            } else
                eval('window.parent.Master.Form_Body.' + text + '.innerText=strtest.substr(k,i-k);');
        } catch (e) {}
    }
    DIVexit_onclick();

    var listFieldID = '';
    if (!HFL)
        for (h = 1; h <= XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("T").value; h++) {
            try {
                eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + h + '").value;');
                listFieldID = listFieldID + text + ',';
            } catch (e) {}
        }
    else
        for (h = 0; h < HFL.length; h++) {
            text = HFL[h];
            if (text != '')
                listFieldID = listFieldID + text + ',';
        }
    try {
        window.parent.Master.Form_Body.document.all.item(listFieldID.substr(0, 6)).focus();
    } catch (e) {}

    if (window.parent.Master.Form_Body.AfterClickedHelp)
        window.parent.Master.Form_Body.AfterClickedHelp(listFieldID);
}

function outputHelp3(ev) {
    var HFL;
    if (window.parent.Master.Form_Body.HlpFldList)
        HFL = window.parent.Master.Form_Body.HlpFldList;
    else
        HFL = null;
    ContinueFillTag = false;
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TR") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    var comma, strtest = new String();
    j = 0;
    for (h = 0; h < XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("IDNUMBERCOL").value; h++) {
        k = 0;
        if (window.ActiveXObject)
            strtest = obj.childNodes[h] ? obj.childNodes[h].innerText : "";
        else
            strtest = $(obj.childNodes[h]).text().trim();
        var isnum = isNumeric(strtest.replace(/,/g, ''));
        for (i = 0; i < strtest.length; i++) {
            try {
                comma = XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("COMMA" + h).value;
            } catch (e) {
                comma = 1
            }
            if (strtest.charAt(i) == "," && comma == 1 && isnum) {
                j++;
                try {
                    if (!HFL)
                        eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + j + '").value;');
                    else
                        text = HFL[j - 1];
                    if (typeof(text) == 'undefined') x = y;
                    if (window.ActiveXObject) {
                        var cur = parent.Master.Form_Body.document.all.tags('INPUT').item(text);
                        var Hcur = parent.Master.Form_Body.document.all.tags('SELECT').item('H' + text);
                    } else {
                        var cur = parent.Master.Form_Body.document.childNodes[0].getElementsByTagName("INPUT")[text];
                        var Hcur = parent.Master.Form_Body.document.childNodes[0].getElementsByTagName("SELECT")['H' + text];
                    }
                    try {
                        cur.value = strtest.substr(k, i - k);
                        cur.oldValue = cur.value;
                        cur.UpdateSndData();
                        if (cur.onchange2) eval("parent.Master.Form_Body." + cur.onchange2);
                        if (Hcur) Hcur.value = cur.value;
                    } catch (e) {
                        cur.innerText = strtest.substr(k, i - k);
                    }
                } catch (e) {}
                k = i + 1;
            }
        }
        j++;
        try {
            if (!HFL)
                eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + j + '").value;');
            else
                text = HFL[j - 1];
            var cur = eval("parent.Master.Form_Body." + text + ";");
            var Hcur = null;
            try {
                Hcur = eval("parent.Master.Form_Body.H" + text + ";");
            } catch (e) {}
            try {
                if (window.ActiveXObject)
                    cur.value = cur.GetVal(strtest.substr(k, i - k));
                else
                    cur.value = $(cur).GetVal(strtest.substr(k, i - k));
                cur.oldValue = cur.value;

                cur.UpdateSndData();
                if (cur.onchange2) eval("parent.Master.Form_Body." + cur.onchange2);
                if (Hcur) Hcur.value = cur.value;
            } catch (e) {

                cur.innerText = strtest.substr(k, i - k);
                try {
                    if (!window.ActiveXObject) {
                        if (cur.f && cur.f.contentDocument && cur.f.contentDocument.body)
                            cur.f.contentDocument.body.innerHTML = cur.innerText;
                    } else {
                        if (cur.F && cur.F.document && cur.F.document.body)
                            cur.F.document.body.innerHTML = cur.innerText;
                    }
                } catch (e) {

                }

            }
        } catch (e) {}
    }
    if (hlpstayonscreen != 1) DIVexit_onclick();

    var listFieldID = '';
    if (!HFL) {
        for (h = 1; h <= XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("T").value; h++) {
            try {
                eval('text=XMLStruHelp.documentElement.childNodes[0].attributes.getNamedItem("F' + h + '").value;');
                listFieldID = listFieldID + text + ',';
            } catch (e) {}
        }
    } else
        for (h = 0; h < HFL.length; h++) {
            text = HFL[h];
            if (text != '')
                listFieldID = listFieldID + text + ',';
        }
    try {
        window.parent.Master.Form_Body.document.all.item(listFieldID.substr(0, 6)).focus();
    } catch (e) {}

    if (window.parent.Master.Form_Body.AfterClickedHelp)
        window.parent.Master.Form_Body.AfterClickedHelp(listFieldID, obj, ev);

}
//-----------------------------------------------------------------------------------
function DIVexit_onclick() {
    ContinueFillTag = false;
    window.parent.Master.Form_Body.DIVFrameHelp.style.visibility = "hidden";
    window.parent.Master.Form_Body.FrameHelp.DIVhelpHeader.innerHTML = "";
    window.parent.Master.Form_Body.FrameHelp.DIVhelpBody.innerHTML = "";
}
//-----------------------------------------------------------------------------------
function mouseoverTR(ev) {
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TR") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    obj.className = "HighlightTRClass";
}
//-----------------------------------------------------------------------------------
function mouseoutTR(ev) {
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TR") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    obj.className = "";
}
//-----------------------------------------------------------------------------------
function mouseoverTD(ev) {
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TD") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    obj.className = "HighlightTDClass";
}
//-----------------------------------------------------------------------------------
function mouseoutTD(ev) {
    var obj;
    var ev = window.parent.Master.Form_Body.FrameHelp.event || ev;
    obj = ev.srcElement || ev.target;
    while (obj.tagName != "TD") {
        if (obj.tagName == "TABLE")
            return;
        obj = obj.parentNode;
    }
    var cl = 'TDHeader';
    try {
        if (Fix == '') cl = 'TDHeaderNoLine';
    } catch (e) {}
    obj.className = cl;
}
//-----------------------------------------------------------------------------------
function isNumeric(x) {
    var RegExp = /^(-)?(\d*)(\.?)(\d*)$/;
    var result = x.match(RegExp);
    if (result == null) result = false;
    return result;
}