var $ = top.$ ? top.$ : $;
var WebBusy = false;
var d = document.all;
var ErrTyp = new Array();
var STATUS = ''; //STATUS='Suc':Success, STATUS='Err':Error
var min = 0,
    sec = 0,
    msec = 0;
var mbox = null,
    errcntvar = '';
var params = [];

function trim(s) {
    return s.replace(/(^\s*)|(\s*$)/g, "");
}

function AutoLogOff() {
    if (typeof(de) == 'undefined') de = 0;
    else de++;
    if (de > 10) {
        window.parent.Commander.LogOff();
        de = 0;
    } else {
        setTimeout("errtxt.innerText+='.';AutoLogOff();", 300);
    }
}

function ShowCap() {
    try {
        var b = parent.Master.Form_Body,
            i = b.imgCaptcha;
        b.CapRow.style.display = '';
        i.style.display = 'none';
        i.src = i.src + '?' + Math.random();
        i.onreadystatechange = function() {
            if (this.readyState == "complete") {
                this.style.display = '';
            }
        }
        if (!window.ActiveXObject) {
            setTimeout(function() {
                i.style.display = '';
            }, 2000)
        }
    } catch (e) {}
}

function ShowMessage(msg, Status) { //Status='Suc':Success, Status='Err':Error
    if (Status == 'Err') {
        STATUS = 'Err';
        d.tbl_Msg.className = "ErrActive";
        try {
            parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/Status_NOK.gif";
        } catch (e) {}
    } else {
        STATUS = 'Suc';
        d.tbl_Msg.className = "SuccActive";
        try {
            parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/Status_OK.gif";
        } catch (e) {}
    }
    errcnt.innerText = '';
    var _m = msg.split('::');
    errtxt.innerHTML = _m[0];
    errtxt.title = _m[0];
    eval(_m[1]);
    d.Previous.style.display = "none";
    d.imgNext.style.display = "none";
}

function tick() {
    msec += 1;
    if (msec > 9) {
        msec = 0;
        sec += 1;
        if (sec > 59) {
            sec = 0;
            min += 1;
        }
    }
    divtime.innerText = ((min < 10) ? '0' + min : min) + ':' + ((sec < 10) ? '0' + sec : sec) + '.' + msec;
}

function ShowPleaseWait() {
    d.tbl_Msg.style.display = "";
    if (WebBusy) return -1;
    min = sec = 0;
    divtime.style.display = '';
    try {
        clearInterval(t);
    } catch (e) {}
    d.tbl_Msg.className = 'PleaseWait';
    errcnt.innerText = '';
    errnumber.innerText = '';
    errtxt.innerText = 'لطفا صبر کنيد.';
    errtxt.title = errtxt.innerText;
    d.Previous.style.display = "none";
    d.imgNext.style.display = "none";
    WebBusy = true;
    try {
        parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/WebBusy.gif";
    } catch (e) {}
    return 1;
}

function HideMsg() {
    WebBusy = false;
    min = sec = 0;
    divtime.style.display = 'none';
    try {
        clearInterval(t);
    } catch (e) {}
    tbl_Msg.className = "inActive";
    try {
        parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/Status_OK.gif";
    } catch (e) {}
}
var MArr = new Array();

function OpenFaci(event) {
    var Translate = {
        "15450": {
            "Stdno": "F41251",
            "Balance": "F34101",
            "BalText": "F51802",
            "PayAmount": "F34102"
        }
    }
    var NF_Param = [];
    var prm = $.parseJSON($(event.srcElement).attr("np-prm"))[0];
    var Fid = prm.Fid,
        Ftype = prm.Ftype,
        Act = prm.Act;
    if (Translate[Fid])
        $.each(Translate[Fid], function(key, value) {
            if (prm[key]) {
                NF_Param.push(value);
                NF_Param.push(prm[key]);
            }
        })
    if (!top.$iswinopen) {
        var c = window.parent.Commander;
        c.NF_init(Ftype, Fid, Act);
        if (NF_Param.length > 1)
            c.NF_Call.apply(null, NF_Param);
        else
            c.NF_Call();
    } else {
        var nfw = new window.parent.Master.Form_Body.npnfwin(Ftype, Fid, null, Act, null);
        if (NF_Param.length > 1) {
            nfw.call.apply(nfw, NF_Param);
            nfw.setscale("95%", "95%");
        } else
            nfw.call();
    }
}

function Get_Message() {
    MArr.length = 0;

    if (document.readyState != "complete") {
        setTimeout("Get_Message();", 10);
        return;
    }
    var i, Fr_Data = window.parent.Data;

    var TM = new Array(),
        er = false,
        wa = false,
        ms = false,
        suclen = 0,
        erlen = 0;
    try {
        if (Fr_Data.SuccArr) {
            TM = Fr_Data.SuccArr;
        }
        if (Fr_Data.ErrorArr) {
            suclen = TM.length;
            erlen = Fr_Data.ErrorArr.length;
            for (var j = 0; j < erlen; j++) {
                Fr_Data.ErrorArr[j] = ReplaceTags(Fr_Data.ErrorArr[j]);
                TM[suclen + j] = Fr_Data.ErrorArr[j];
            }
        }
        ErrTyp = Fr_Data.ErrorTyp;
        var l = TM.length;
        for (i = 0; i < Fr_Data.ErrorDSC.length; i++) {
            Fr_Data.ErrorDSC.item(i).innerHTML = ReplaceTags(Fr_Data.ErrorDSC.item(i).value);
            TM[i + l] = Fr_Data.ErrorDSC.item(i).innerHTML;
            ErrTyp[i + l] = 2;
        }
        var l = TM.length;
        for (i = 0; i < Fr_Data.SuccDSC.length; i++) {
            Fr_Data.SuccDSC.item(i).innerHTML = ReplaceTags(Fr_Data.SuccDSC.item(i).value);
            TM[i + l] = Fr_Data.SuccDSC.item(i).innerHTML;
            ErrTyp[i + l] = 0;
        }
    } catch (e) {
        setTimeout("Get_Message();", 10);
        return;
    }
    var erc = 0,
        wac = 0,
        msc = 0,
        Mi;
    for (var i = 0; i < TM.length; i++) {
        Mi = (i < suclen) ? i + erlen : i - suclen;
        MArr[Mi] = new Array();
        MArr[Mi][0] = TM[i];
        MArr[Mi][1] = ErrTyp[i];
        if (ErrTyp[i] == 0) {
            ms = true;
            msc++;
        }
        if (ErrTyp[i] == 1) {
            wa = true;
            wac++;
        }
        if (ErrTyp[i] == 2) {
            er = true;
            erc++;
        }
    }
    d.TB01_Index.value = 0;
    try {
        parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/Status_OK.gif";
        parent.Master.Form_Title.document.all.tags('TABLE').item(0).rows[0].cells[0].style.display = 'none';
    } catch (e) {}
    if (er || wa) {
        var _s = '';
        STATUS = 'Err';
        _s = '';
        if (er) _s = _s + ' و ' + erc + ' خطا ';
        if (ms) _s = _s + ' و ' + msc + ' پيغام ';
        if (wa) _s = _s + ' و ' + wac + '  هشدار ';
        _s = trim(trim(_s).substr(1));
        errcntvar = _s
        try {
            parent.Master.Form_Title.document.all.Form_Status.src = "/_Images/Status_NOK.gif";
        } catch (e) {}
    } else {
        if (MArr.length > 0) {
            STATUS = 'Suc';
            errcntvar = MArr.length + ' پيغام ';
        } else {
            STATUS = '';
            d.imgNext.style.display = "none";
            d.Previous.style.display = "none";
            errtxt.innerText = "";
            errtxt.title = "";
            errnumber.innerText = "";
            d.tbl_Msg.className = '';
        }
    }

    errtxt.innerText = '';
    errtxt.title = '';
    if (STATUS != '') {
        d.TB01_Index.value = 0;
        if (TM.length > 1) {
            d.Previous.style.display = "";
            d.imgNext.style.display = "";
            if (parseInt(d.TB01_Index.value) == 0) {
                d.Previous.style.display = "none";
            }
            if (parseInt(d.TB01_Index.value) == MArr.length - 1) {
                d.imgNext.style.display = "none";
            }
        } else {
            d.imgNext.style.display = "none";
            d.Previous.style.display = "none";
        }
        Get_Mess();
    }
}

function ReplaceTags(msg) {
    var res = msg.replace("</np-openfaci>", "</span>").replace("<np-openfaci", "<span class='Link-OpenFaci' onclick='OpenFaci(event)'");
    return res;
}

function Get_Mess() {
    errcnt.innerText = errcntvar;
    var s = 'ErrActive',
        seq = parseInt(d.TB01_Index.value);
    switch (MArr[seq][1]) {
        case 0:
        case '0':
            {
                s = 'SuccActive';
                break;
            }
        case 1:
        case '1':
            {
                s = 'Warning';
                break;
            }
    }
    d.tbl_Msg.className = s;
    d.tbl_Msg.style.display = "";
    var _m = MArr[seq][0].split('::');
    //errtxt.innerHTML = _m[0];
    //if(ErrTyp[seq]=="3"){
    if (_m[0].indexOf(":dialog:") != -1) {
        //لازم است سيستم مورد استفاده مشخص شود:dialog:
        _m[0] = _m[0].replace(":dialog:", "");
        d.tbl_Msg.style.display = "none";
        var Icon = "CloseAll.gif";
        if (ErrTyp[seq] == "0")
            Icon = "Status_OK.gif";
        if (ErrTyp[seq] == "1")
            Icon = "Status_WAR.gif";

        var DialogError = document.getElementById("DialogError") ? $(document.getElementById("DialogError")) : $("#DialogError");
        DialogError.html("<img src='../../_images/" + Icon + "' />&nbsp;&nbsp;" + _m[0]).dialog({
            modal: true,
            width: 550,
            open: function() {
                $(this.parentElement).css("z-index", 10000001);
            },
            close: function() {
                DialogError.html("");
                DialogError.dialog("destroy");
            }
        });
    } else {
        $(errtxt).html(_m[0]);
        errtxt.title = errtxt.innerText;
    }
    d.Previous.style.display = "";
    d.imgNext.style.display = "";
    if (MArr.length > 1)
        errnumber.innerText = (parseInt(d.TB01_Index.value) + 1) + "-";
    if (parseInt(d.TB01_Index.value) == 0) {
        d.Previous.style.display = "none";
    }
    if (parseInt(d.TB01_Index.value) == MArr.length - 1) {
        d.imgNext.style.display = "none";
    }
    eval(_m[1]);
}


function Previous_onmouseout() {
    Previous.src = "/_Images/PreviousMSG.gif"
}

function Previous_onmouseover() {
    Previous.src = "/_Images/PreviousMSG_Focus.gif"
}

function Previous_onmousedown() {
    Previous.src = "/_Images/PreviousMSG_Clicked.gif"
    if (parseInt(d.TB01_Index.value) > 0) {
        d.TB01_Index.value = parseInt(d.TB01_Index.value) - 1;
        Get_Mess();
    }
}

function Previous_onmouseup() {
    if (Previous.style.display == "")
        Previous.src = "/_Images/PreviousMSG_Focus.gif";
    else
        Previous.src = "/_Images/PreviousMSG.gif";
}


function Next_onmousedown() {
    imgNext.src = "/_Images/NextMSG_Clicked.gif"
    if (parseInt(d.TB01_Index.value) < (MArr.length)) {
        d.TB01_Index.value = parseInt(d.TB01_Index.value) + 1;
        Get_Mess();
    }
}

function Next_onmouseout() {
    imgNext.src = "/_Images/NextMSG.gif"
}

function Next_onmouseover() {
    imgNext.src = "/_Images/NextMSG_Focus.gif"
}

function Next_onmouseup() {
    if (imgNext.style.display == "")
        imgNext.src = "/_Images/NextMSG_Focus.gif";
    else
        imgNext.src = "/_Images/NextMSG.gif";
}