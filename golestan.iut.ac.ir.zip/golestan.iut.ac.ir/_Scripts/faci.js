function trim(s) {
    try {
        return s.replace(/^\s+|\s+$/g, "");
    } catch (e) {
        return ''
    };
}

function setpos(o, t, b, l, r, w, h) {
    if (t) o.top = t;
    if (b) o.bottom = b;
    if (l) o.left = l;
    if (r) o.right = r;
    if (w) o.width = w;
    if (h) o.height = h;
}
// Faci Object
function Faci(doc, url, NamInd, FaciInd, t, l, w, h, facfit) {
    if (facfit) this.facfit = true;
    else this.facfit = false;
    var iid = 'Faci' + NamInd;
    this.ind = FaciInd;
    this.iid = iid;
    this.zIndex = NamInd + 1;
    this.doc = doc;
    this.t = t;
    this.l = l;
    this.w = w;
    this.h = h;
    this.url = url;
    var d = doc.createElement('DIV');
    d.par = this;
    d.style.overflow = 'auto';
    d.style.position = 'absolute';
    d.style.zIndex = this.zIndex;
    var f = doc.createElement('IFRAME');
    f.src = url;
    f.style.zIndex = this.zIndex;
    f.frameborder = 0;
    f.id = iid;
    f.name = iid;
    f.par = this;
    f.doc = doc;
    d.onclick = function() {
        var tt = this;
        setTimeout(function() {
            tt.par.BrToFront();
        }, 100);
    }
    this.d = d;
    this.f = f;
    this.auth = new Auth(this);
    this.Opener = null;
    this.Clop = false;
    this.RelPar = null;
    this.RelChi = null;
    this.RelBro = null;
    this.RelBroRev = null; //Brother Reverse
    this.FirstChild = null;
    this.ParF = new Array();
    this.Area = doc;
}

Faci.prototype.setzIndex = function(z) {
    this.zIndex = z;
    this.d.style.zIndex = z;
    this.f.style.zIndex = z;
}

Faci.prototype.BrToFront = function() {
    var fac, dz, max = 0,
        maxfac, a = this.par.FaciArr;
    for (var i = 0; i < a.length; i++) {
        fac = a[i];
        dz = fac.zIndex;
        if (max < dz) {
            max = dz;
            maxfac = fac;
        }
    }
    if (i == 0 || this.zIndex == max) return;
    maxfac.setzIndex(this.zIndex);
    this.setzIndex(max);
}
Faci.prototype.Init = function() {
    if (this.par) this.Area = this.par.FacArea;
    this.Area.appendChild(this.d);
    this.d.appendChild(this.f);
    this.SetInd(this.ind);
}
Faci.prototype.SetInd = function(i) {
    this.ind = i;
    /*  if(window.ActiveXObject)
         var x=this.doc.frames(this.iid);
      else
         var x=this.doc[this.iid];
      x.ContInd = i;
      x.ContObj = this;*/
    try {
        var x = this.doc.frames(this.iid);
        x.ContInd = i;
        x.ContObj = this;
    } catch (e) {
        var x = window.frames[this.iid];
        x.ContInd = i;
        x.ContObj = this;
    }
}
Faci.prototype.SetPos = function() {
    var t, l, w, h, d = this.d,
        f = this.f,
        p = this.par;
    t = this.t;
    l = this.l;
    w = this.w;
    h = this.h;
    if (this.facfit) {
        t = 0;
        l = 0;
        w = p.tWidth;
        h = p.tHeight;
    }
    this.t = t;
    this.l = l;
    this.w = w;
    this.h = h;
    setpos(d.style, t, null, l, null, w, h);
    f.width = w;
    f.height = h;
}
Faci.prototype.Show = function(vis) {
    /*if(this.RelPar){
       this.RelPar.Show(true);
       this.RelPar.BrToFront();
    }*/
    if (this.RelPar) {
        if (window.ActiveXObject) {
            this.RelPar.Show(true);
            this.RelPar.BrToFront();
        }
    }
    this.SetPos();
    this.f.style.display = '';
    this.d.style.display = '';
    this.butt.Show(vis);
}
Faci.prototype.Hide = function() {
    this.f.style.display = 'none';
    this.d.style.display = 'none';
}
Faci.prototype.Activate = function() {
    this.Show(true);
    this.BrToFront();
    try {
        if (window.ActiveXObject)
            document.frames(this.iid).Master.Form_Body.OnFullScreen();
        else
            window.frames[this.iid].Master.Form_Body.OnFullScreen();

    } catch (e) {}
    try {
        this.auth.SetToCookie();
    } catch (e) {}
}
Faci.prototype.Deactivate = function() {
    this.Hide();
}
Faci.prototype.Maxi = function() {
    this.BrToFront();
}
Faci.prototype.Close = function(silent) {
    var d = this.Area;
    try {
        if (window.ActiveXObject)
            var _t = this.doc.frames[this.f.id];
        else
            var _t = this.doc[this.f.id];
        _t.Commander.ClearContent('', true);

    } catch (e) {}
    this.f.src = "/blank.htm";
    this.d.onclick = null;
    d.removeChild(this.d);
    this.d.removeChild(this.f);
    var p = this.RelPar;
    if (p) {
        if (this.FirstChild) {
            p.RelChi = this.RelBro;
        } else {
            this.RelBroRev.RelBro = this.RelBro;
        }
    }
    var au = this.auth;
    if (!silent && this.Opener) {
        try {
            if (window.ActiveXObject)
                document.frames[this.Opener.iid].Master.Form_Body.AfterCloseChild(au.ft, au.f);
            else
                window.frames[this.Opener.iid].Master.Form_Body.AfterCloseChild(au.ft, au.f);
        } catch (e) {}
    }
    if (!(au.ft == 0 && au.f == 1))
        ex(au.ltck, au.tck, au.u, au.seq, au.ft, au.f, au.sess);
}
Faci.prototype.RetPar = function(a) {
    for (var i = 0; i < a.length && i < this.ParF.length; i++) {
        this.ParF[i].value = a[i];
        this.ParF[i].UpdateSndData();
    }
    this.par.Close();
}
//////Auth Object
function Auth(f) {
    this.faci = f;
    this.u = '';
    this.su = '';
    this.ft = '';
    this.f = '';
    this.ltck = '';
    this.tck = '';
    this.seq = '';
    this.sess = '';
    this.actsign = '';
}
Auth.prototype.SetVal = function(u, su, ft, f, ltck, tck, seq, sess, actsign) {
    this.u = u;
    this.su = su;
    this.ft = ft;
    this.f = f;
    this.ltck = ltck;
    this.tck = tck;
    this.seq = seq;
    this.sess = sess;
    this.actsign = actsign;

}
Auth.prototype.GetFromCookie = function() {
    return;
    var u = '',
        su = '',
        ft = '',
        f = '',
        ltck = '',
        tck = '',
        seq = '',
        sess = '';
    var cook = document.cookie.split(";");
    for (var i = 0; i < cook.length; i++) {
        var n = cook[i].split("=");
        if (trim(n[0]) == 'u') u = trim(n[1]);
        else if (trim(n[0]) == 'su') su = trim(n[1]);
        else if (trim(n[0]) == 'ft') ft = trim(n[1]);
        else if (trim(n[0]) == 'f') f = trim(n[1]);
        else if (trim(n[0]) == 'lt') ltck = trim(n[1]);
        else if (trim(n[0]) == 'seq') seq = trim(n[1]);
    }
    this.SetVal(u, su, ft, f, ltck, tck, seq, sess);
}

Auth.prototype.SetToCookie = function() {
    if (window.ActiveXObject)
        var d = this.faci.doc.frames(this.faci.f.id).Data.document;
    else
        var d = this.faci.doc[this.faci.f.id].Data.document;
    d.cookie = 'u=' + this.u + "; path=/";
    d.cookie = 'su=' + this.su + "; path=/";
    d.cookie = 'ft=' + this.ft + "; path=/";
    d.cookie = 'f=' + this.f + "; path=/";
    d.cookie = 'lt=' + this.ltck + "; path=/";
    d.cookie = 'seq=' + this.seq + "; path=/";
}

//////Tab Object
function Tab(doc, t, l, w, h, so) {
    this.ready = 0;
    this.FaciArr = new Array();
    this.doc = doc;
    this.Top = t;
    this.Left = l;
    this.Width = w;
    this.Height = h;
    var ButtArea = doc.createElement('DIV');
    doc.body.appendChild(ButtArea);
    ButtArea.id = 'ButtArea';
    ButtArea.style.position = 'absolute';
    ButtArea.style.overflow = 'Hidden';
    this.ButtArea = ButtArea;
    var FacArea = doc.createElement('DIV');
    if (!window.ActiveXObject)
        FacArea.style.top = "48px";
    doc.body.appendChild(FacArea);
    FacArea.style.position = 'absolute';
    FacArea.style.overflow = 'Hidden';
    FacArea.id = 'FacArea';
    this.FacArea = FacArea;
    var ExArea = doc.createElement('DIV');
    doc.body.appendChild(ExArea);
    ExArea.id = 'ExArea';
    ExArea.style.position = 'absolute';
    ExArea.style.overflow = 'Hidden';
    ExArea.style.visibility = 'Hidden';

    var i1 = doc.createElement('img');
    ExArea.appendChild(i1);
    i1.by = 3300;
    i1.bh = 18;
    i1.className = 'c1';
    i1.style.width = '18px';
    i1.style.height = '18px';
    i1.style.backgroundPosition = '0 -3300';

    i1.title = "تمام صفحه"
    i1.src = "/_Images/nophoto.gif";
    i1.unselectable = 'on';

    i1.par = this;
    i1.onclick = function() {
        var t = this.par,
            mt = t.maintitle;
        if (mt.ch == mt.mh) {
            mt.Hide();
            this.by = 3380;
            this.style.backgroundPosition = '0 -3380';
        } else {
            mt.Maxi();
            this.by = 3300;
            this.style.backgroundPosition = '0 -3300';
        }
        t.VisButts();
        try {

            if (window.ActiveXObject)
                document.frames(t.faci.iid).Master.Form_Body.OnFullScreen();
            else
                window.frames[t.faci.iid].Master.Form_Body.OnFullScreen();

        } catch (e) {}
    }
    this.ExArea = ExArea;
    var BSR = doc.createElement('DIV');
    var BSL = doc.createElement('DIV');
    doc.body.appendChild(BSR);
    doc.body.appendChild(BSL);
    var IL = doc.createElement('INPUT');
    var IR = doc.createElement('INPUT');
    IL.src = "/_Images/sm/scrleft.gif";
    IR.src = "/_Images/sm/scrright.gif";
    IL.type = "image";
    IR.type = "image";
    BSL.appendChild(IL);
    BSR.appendChild(IR);

    BSR.par = this;
    BSL.par = this;
    var Timeout = 10;
    try {
        var ua = window.navigator.userAgent;
        var edge = ua.indexOf('Edge/');
        var version = parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        if (edge > 0 && version >= 12)
            Timeout = 100;

    } catch (e) {

    }
    BSL.onmouseover = function() {
        BSL.TI = setInterval(function() {
            if (BSL.par.ButtArea.doScroll)
                BSL.par.ButtArea.doScroll('left');
            else
                BSL.par.ButtArea.scrollLeft = BSL.par.ButtArea.scrollLeft - 10;
        }, Timeout);
    }
    BSL.onmouseout = function() {
        clearInterval(this.TI);
    }
    BSR.onmouseover = function() {
        BSR.TI = setInterval(function() {
            if (BSR.par.ButtArea.doScroll)
                BSR.par.ButtArea.doScroll('right');
            else
                BSR.par.ButtArea.scrollLeft = BSR.par.ButtArea.scrollLeft + 10;
        }, Timeout);
    }
    BSR.onmouseout = function() {
        clearInterval(this.TI);
    }
    this.BScrlR = BSR;
    this.BScrlL = BSL;
    BSR.style.position = 'absolute';
    BSL.style.position = 'absolute';
    BSR.style.display = 'none';
    BSL.style.display = 'none';
    this.lastnamind = 0;
    this.exalert = true;
    this.usrcertreq = false;
    this.signObj = so;
}
Tab.prototype.SetDim = function(t, l, w, h) {
    this.Top = t;
    this.Left = l;
    this.Width = w;
    this.Height = h;
}
Tab.prototype.SetPos = function(ShowButts) {
    var t = this.Top,
        l = this.Left,
        w = this.Width,
        h = this.Height,
        mt_ch = 0,
        mt_mh = 0,
        mt_top = 0;
    var BH = (ShowButts) ? 23 : 0,
        BSWidth = (ButtArea.scrollWidth > ButtArea.clientWidth && ButtArea.clientWidth > 0) ? 8 : 0;
    this.BScrlR.style.display = (BSWidth == 0) ? 'none' : '';
    this.BScrlL.style.display = (BSWidth == 0) ? 'none' : '';
    try {
        var mt = this.maintitle;
        mt_ch = mt.ch;
        mt_mh = mt.mh;
        mt_top = mt.top;
    } catch (e) {
        alert(e.message)
    }
    t = mt_top + mt_ch;
    h = h - (t + BH - this.Top);
    this.tTop = t + BH;
    this.tLeft = l;
    this.tWidth = w;
    this.tHeight = h;
    this.tBott = this.doc.body.clientHeight - (this.tTop + this.tHeight);
    this.tRight = this.doc.body.clientWidth - (this.tLeft + this.tWidth);

    this.bTop = t;
    this.bLeft = l + 82 + BSWidth;
    this.bWidth = w - 82 - 20 - 2 * BSWidth;
    this.bHeight = BH;
    this.bBott = this.tBott - this.bHeight;
    this.bRight = this.tRight + 20 + BSWidth;
    setpos(this.FacArea.style, this.tTop, null, this.tLeft, null, this.tWidth, this.tHeight);
    setpos(this.ButtArea.style, this.bTop + 1, null, null, this.bRight, this.bWidth, this.bHeight + 5);
    setpos(this.ExArea.style, this.bTop + 5, null, null, this.tRight, this.bRight, BH);

    setpos(this.BScrlR.style, this.bTop + 1, null, null, this.bRight - BSWidth, 8, BH);
    setpos(this.BScrlL.style, this.bTop + 1, null, this.bLeft - BSWidth, null, 8, BH);
}
Tab.prototype.AddNew = function(nam, url, modal, after, Opener, Clop, t, l, w, h, brnam) {
    var facfit = false;
    d = this.doc, no = this.FaciArr.length;
    if (!t) {
        t = 0;
        l = 0;
        w = this.tWidth;
        h = this.tHeight;
        facfit = true;
    }
    var bu = new TabButt(this);

    var j = no;
    if (after && no > 1) {
        j = this.faci.ind + 1;
        for (var i = no; i > j; i--) {
            this.FaciArr[i] = this.FaciArr[i - 1];
            var fi = this.FaciArr[i];
            fi.SetInd(fi.ind + 1);
        }
    }
    this.lastnamind++;
    var faci = new Faci(d, url, this.lastnamind, j, t, l, w, h, facfit);
    bu.faci = faci;
    faci.par = this;
    faci.butt = bu;
    faci.Clop = Clop;
    faci.Opener = Opener;
    faci.modal = modal;
    this.FaciArr[j] = faci;
    faci.Init();
    this.jafaci = faci;
    this.jaind = faci.ind;

    bu.SetNam(nam);
    bu.SetBrNam(brnam);
    if (modal) Opener.butt.invis = true;
    this.VisButts();
}
Tab.prototype.Activate = function(f) {
    if (f == null) {

        f = this.jafaci;
    }
    try {
        this.faci.Deactivate();
        this.faci.butt.Unsel();
    } catch (e) {}

    f.Activate();

    f.butt.Sel();
    this.faci = f;
    this.ind = f.ind;
}
Tab.prototype.VisButts = function() {
    var a = this.FaciArr,
        visible = (a.length > 1) ? true : false;
    if (!visible) {
        this.butt_vis = false;
        ExArea.style.visibility = 'Hidden';
    } else {
        this.butt_vis = true;
        ExArea.style.visibility = 'visible';
    }
    this.SetPos(visible);
    for (var i = 0; i < a.length; i++) {
        a[i].butt.Show(visible);
    }
    if (this.faci) {
        this.faci.Show(visible);
        this.faci.BrToFront();
    }
}
Tab.prototype.Close = function(f, CloseBro, force, silent) {
    var a = this.FaciArr,
        ind, CurAct = false;
    if (!f) f = this.faci;
    try {
        if (window.ActiveXObject) {
            if (document.frames(f.iid).Commander.savechg(true) < 0) return -1;
        } else {
            if (window.frames[f.iid].Commander.savechg) {
                if (window.frames[f.iid].Commander.savechg(true) < 0) return -1;

            } else {
                if (window.frames[f.Opener.iid].Commander.savechg(true) < 0) return -1;
            }
        }

    } catch (eee) {}
    if (f.ind == this.ind) CurAct = true;
    var rp = f.RelPar;
    if (rp) rp.butt.invis = false;
    if (f.RelChi) this.Close(f.RelChi, true, false, true);
    if (CloseBro)
        if (f.RelBro) this.Close(f.RelBro, true, false, true);
    var l = a.length,
        ind = f.ind,
        b = f.butt;
    if (ind == 0 && !force) {
        return;
    }
    var nam = b.nam,
        cnt = b.cnt;
    if (ind == l - 1) {
        i = ind;
        ind--;
        if (CurAct && l >= 2) this.Activate(a[l - 2]);
    } else {
        if (CurAct) this.Activate(a[ind + 1]);
        for (var i = ind; i < l - 1; i++) {
            a[i] = a[i + 1];
            a[i].SetInd(a[i].ind - 1);
        }
        this.ind = this.faci.ind;
    }
    f.Close(silent);
    b.Close();
    if (CurAct && ind < 0) this.faci = null;
    a[l - 1] = null;
    a.length--;
    l = a.length;
    for (var i = 0; i < l; i++) {
        var v = a[i].butt;
        if (v.nam == nam && v.cnt > cnt) v.DecCnt();
    }
    this.VisButts();
    if (rp) this.Activate(rp);
}
/*Tab.prototype.LogOff = function(){
/*    var l= this.FaciArr.length-1;
   while(l>=0){
       this.Close(this.FaciArr[l],false,true);
       l= this.FaciArr.length-1;
   } * /
   t.exalert=false;
   top.location="/";
}*/
function TabButt(tab) {
    this.par = tab;
    this.invis = false;
    var d = tab.doc,
        r = tab.bRight,
        t = tab.bTop;
    var div0 = d.createElement('DIV');
    var div1 = d.createElement('DIV');
    var div2 = d.createElement('DIV');
    tab.ButtArea.appendChild(div0);
    tab.ButtArea.appendChild(div1);
    tab.ButtArea.appendChild(div2);
    this.div0 = div0;
    this.div1 = div1;
    this.div2 = div2;
    this.nam = null;
    this.brnam = null;
    this.cnt = null;
    div1.id = "TabButtNam";

    var c = d.createElement('img');
    c.by = 2250;
    c.bh = 13;
    c.className = 'c1';
    c.style.width = '10px';
    c.style.height = '13px';
    c.style.backgroundPosition = '0 -2250';

    c.title = "close"
    c.src = "/_Images/nophoto.gif";
    c.unselectable = 'on';

    div0.appendChild(c);
    c.par = this;
    this.c = c;
    c.onclick = function() {
        var p = this.par,
            tab = p.par,
            f = p.faci,
            a = f.auth;
        tab.Close(f);
    }
    div1.onmouseover = function() {
        this.par.Hi();
    }
    div1.onmouseout = function() {
        this.par.Norm();
    }

    div0.className = 'tabbutt r0';
    div1.className = 'tabbutt m0';
    div2.className = 'tabbutt l0';

    div0.style.position = 'absolute';
    div1.style.position = 'absolute';
    div2.style.position = 'absolute';

    div0.style.overflow = 'hidden';
    div1.style.overflow = 'hidden';
    div2.style.width = '4px';
    div0.par = this;
    div1.par = this;

    div1.onclick = function() {
        this.par.par.Activate(this.par.faci);
    }
}
TabButt.prototype.SetNam = function(nam, cchg, ut) {
    var t = this.par;
    var ii = 1;
    t.FaciArr.length;
    for (var i = 0; i < t.FaciArr.length; i++) {
        if (t.FaciArr[i].butt.nam == nam) {
            if (this.faci.ind == i) return;
            ii++;
        }
    }
    this.nam = nam;
    this.cnt = ii;
    this.div1.id = "TabButtNam";
    var utn = ''
    if (cchg == 'true') {
        if (ut == '1') utn = ' - نوع کاربر: استاد';
        if (ut == '2') utn = ' - نوع کاربر: مدير';
    }

    this.SetLabel(this.nam + utn);
}
TabButt.prototype.SetBrNam = function(brnam) {
    this.brnam = brnam;
}
TabButt.prototype.SetLabel = function(tit) {
    this.div1.innerHTML = '<nobr>' + this.nam + ((this.cnt > 1) ? '[' + this.cnt + ']' : '') + '</nobr>';
    this.div1.title = tit;
    this.w0 = this.div0.offsetWidth;
    this.w1 = this.div1.offsetWidth;
    this.w2 = this.div2.offsetWidth;
    this.div1.innerHTML = '<div style="width:' + this.w1 + 'px">' + this.nam + ((this.cnt > 1) ? '[' + this.cnt + ']' : '') + '</div>';
}
TabButt.prototype.DecCnt = function() {
    this.cnt--;
    this.SetLabel();
}
TabButt.prototype.width = function() {
    if (this.invis) return 0;
    return this.div0.offsetWidth + this.div1.offsetWidth + this.div2.offsetWidth;
}
TabButt.prototype.awidth = function() {
    if (this.invis) return 0;
    return this.w0 + this.w1 + this.w2;
}
TabButt.prototype.SetWidth = function(w) {
    if (!w) return;
    this.div1.style.width = w;
}
TabButt.prototype.Hi = function() {
    if (!this.selected) {
        this.div0.className = 'tabbutt r1';
        this.div1.className = 'tabbutt m1';
        this.div2.className = 'tabbutt l1';
    }
}
TabButt.prototype.Norm = function() {
    if (!this.selected) {
        this.div0.className = 'tabbutt r0';
        this.div1.className = 'tabbutt m0';
        this.div2.className = 'tabbutt l0';
    }
}
TabButt.prototype.Sel = function() {
    this.Show(true);
    this.selected = true;
    this.div0.className = 'tabbutt r2';
    this.div1.className = 'tabbutt m2';
    this.div2.className = 'tabbutt l2';
    this.par.maintitle.SetGTit(null, null, this.brnam);
}
TabButt.prototype.Unsel = function() {
    this.selected = false;
    this.Norm();
}
TabButt.prototype.Show = function(tf) {
    var s, div0 = this.div0,
        div1 = this.div1,
        div2 = this.div2;
    if (!tf || this.invis) s = 'hidden';
    else s = 'visible';
    div0.style.visibility = s;
    div1.style.visibility = s;
    div2.style.visibility = s;
    var tb = this.par,
        r = 0,
        t = 0,
        a = tb.FaciArr,
        w = 1,
        aw = 0,
        ind = a.length;
    try {
        ind = this.faci.ind;
    } catch (e) {
        alert(e.message)
    }
    for (var i = 0; i < ind; i++) {
        w += a[i].butt.width();
        aw += a[i].butt.awidth();
    }
    setpos(div0.style, t, null, null, r + w, null, null);
    setpos(div1.style, t, null, null, r + w + div0.offsetWidth, null, null);
    setpos(div2.style, t, null, null, r + w + div0.offsetWidth + div1.offsetWidth, null, null);
    div2.scrollIntoView();
    var h = this.par.maintitle.h2 + ' - ' + this.par.maintitle.h1 + ' ';
    top.document.title = (h == ' -  ') ? 'سيستم جامع دانشگاهي گلستان' : h + ' - ' + this.nam;

}
TabButt.prototype.Close = function() {
    this.c.onclick = null;
    this.div1.onmouseover = null;
    this.div1.onmouseout = null;
    this.div1.onclick = null;
    this.par.ButtArea.removeChild(this.div0);
    this.par.ButtArea.removeChild(this.div1);
    this.par.ButtArea.removeChild(this.div2);
    this.par = null;
    this.div0.par = null;
    this.div1.par = null;
    this.div0 = null;
    this.div1 = null;
    this.div2 = null;
}
//Main Title Object
function Hide_Login_header_logo() {
    $("#_mt_Login_header_logo", this.d).hide();
    top.t.maintitle.ch = 48;
    top.t.maintitle.mh = 48;
    top.Login_header_logo = null;
}

function MainTit(doc, hei) {
    var ds, d = new Array(),
        b = doc.body;
    this.doc = doc;
    this.ch = hei;
    this.mh = hei;
    this.top = 0;
    this.left = 0;
    this.h1 = '';
    this.h2 = '';
    this.h3 = '';

    for (var i = 0; i < 8; i++) {
        d[i] = doc.createElement('DIV');
        d[i].par = this;
        ds = d[i].style;
        ds.position = 'absolute';
        ds.visibility = 'hidden';
        ds.zIndex = 1000;
        ds.fontSize = '9px';

        switch (i) {
            case 0:
                {
                    d[i].id = '_mt_bou';
                    this.bou = d[i];
                    break;
                }
            case 1:
                {
                    d[i].id = '_mt_god';
                    d[i].innerText = 'به نام خدا';
                    d[i].align = 'center';
                    this.god = d[i];
                    break;
                }
            case 2:
                {
                    d[i].id = '_mt_gt';
                    ds.fontSize = '12px';
                    ds.color = /*'#9b5818';*/ '#411b18';
                    this.gt = d[i];
                    break;
                }
            case 3:
                {
                    d[i].id = '_mt_arm';
                    d[i].innerHTML = '<IMG src="/_templates/unvarm/unvarm.aspx?typ=1">';
                    this.arm = d[i];
                    break;
                }
            case 4:
                {
                    d[i].id = '_mt_usr';
                    this.usr = d[i];
                    break;
                }
            case 5:
                {
                    d[i].id = '_mt_tim';
                    this.tim = Time.Create(doc, d[0], 1, 1, 1, 1, 1, 1, 1);
                    this.tim.owner = this;
                    break;
                }
            case 6:
                {

                    if (typeof Login_header_logo != "undefined") {
                        this.mh = 108;
                        this.ch = 108;
                        d[i].id = '_mt_Login_header_logo';
                        d[i].innerHTML = '<img src="' + Login_header_logo + '" ></img>';
                        d[i].align = 'center';
                        this.Login_header_logo = d[i];
                    }
                    break;
                }
        }
        if (i < 1) b.appendChild(d[i]);
        else if (i < 7) d[0].appendChild(d[i]);
    }
}
MainTit.prototype.SetPos = function() {
    var b = this.bou.style,
        g = this.god.style,
        q = (typeof Login_header_logo != "undefined") && this.Login_header_logo.style,
        a = this.arm.style,
        t = this.tim,
        u = this.usr.style,
        gt = this.gt.style,
        top = this.top,
        left = this.left;
    b.top = top;
    b.left = left;
    b.width = this.doc.body.clientWidth;
    b.height = this.ch;
    g.top = top;
    g.right = '0px';
    g.width = b.width;
    q.top = top + this.god.offsetHeight + 3;
    q.right = '0px';
    q.width = b.width;
    a.top = top;
    a.left = left;
    var _w;
    if (this.arm.readyState != 'complete') _w = 80;
    else _w = this.arm.clientWidth;
    t.SetPos(_w, null, null, 0);
    u.right = "6px";
    u.bottom = "0px";
    gt.top = top + this.god.offsetHeight + ((typeof Login_header_logo != "undefined") && this.Login_header_logo.offsetHeight) + 3;
    gt.left = left;
    gt.width = b.width;
    this.gt.align = "center";
}
MainTit.prototype.Mini = function() {
    this.typ = 'min';
    var bo = this.bou.style,
        u = this.usr.style,
        t = this.tim.style,
        uc = this.usr.offsetHeight,
        tc = this.tim.offsetHeight;
    this.ch = ((tc > uc) ? tc : uc) + 5;
    this.bou.style.visibility = 'visible';
    this.god.style.visibility = 'hidden';
    if (typeof Login_header_logo != "undefined") this.Login_header_logo.style.visibility = 'hidden';
    this.arm.style.visibility = 'hidden';
    this.gt.style.visibility = 'hidden';
    this.tim.Show();
    this.usr.style.visibility = 'visible';
    this.SetPos();
}
MainTit.prototype.Maxi = function() {
    this.typ = 'max';
    this.ch = this.mh;
    this.bou.style.visibility = 'visible';
    this.god.style.visibility = 'visible';
    if (typeof Login_header_logo != "undefined") this.Login_header_logo.style.visibility = 'visible';
    this.arm.style.visibility = 'visible';
    this.gt.style.visibility = 'visible';
    this.tim.Show();
    this.usr.style.visibility = 'visible';
    this.SetPos();
}
MainTit.prototype.Hide = function() {
    this.typ = 'hid';
    this.ch = 0;
    this.bou.style.visibility = 'hidden';
    this.god.style.visibility = 'hidden';
    if (typeof Login_header_logo != "undefined") this.Login_header_logo.style.visibility = 'hidden';
    this.arm.style.visibility = 'hidden';
    this.gt.style.visibility = 'hidden';
    this.tim.Hide();
    this.usr.style.visibility = 'hidden';
    this.SetPos();
}
MainTit.prototype.SetUsr = function(n, f) {
    if (trim(n + f) == '') return;
    this.usr.innerHTML = 'کاربر : ' + n + ' ' + f + '&nbsp;&nbsp;&nbsp;<span style="cursor:hand;color:blue" onclick="closeall();">خروج</span>';
}
MainTit.prototype.RemUsr = function() {
    this.usr.innerHTML = '';
}
MainTit.prototype.SetGTit = function(h1, h2, h3) {
    if (h1 != null) this.h1 = h1;
    if (h2 != null) this.h2 = h2;
    if (h3 != null) this.h3 = h3;
    this.gt.innerHTML = this.h2 + '&nbsp;&nbsp;&nbsp;' + this.h1 + '<br><SPAN STYLE="COLOR:#aa0000">' + this.h3 + '</SPAN>';
}
MainTit.prototype.ShowGTit = function() {
    if (this.typ == 'max') this.gt.style.visibility = 'visible';
}
MainTit.prototype.HideGTit = function() {
    this.gt.style.visibility = 'hidden';
}
// Time Object
var Time = {
    weekdays: ['شنبه', 'يكشنبه', 'دوشنبه', 'سه شنبه', 'چهارشنبه', 'پنج شنبه', 'جمعه'],
    months: ['فروردين', 'ارديبهشت', 'خرداد', 'تير', 'مرداد', 'شهريور', 'مهر', 'آبان', 'آذر', 'دي', 'بهمن', 'اسفند'],
    cont: null,
    hasset: false,
    Create: function(doc, parDiv, y, m, d, wd, ho, mi, se) {
        this.y = y;
        this.m = m;
        this.d = d;
        this.wd = wd;
        this.ho = ho;
        this.mi = mi;
        this.se = se;
        this.l = 0;
        this.t = 0;

        var d = doc.createElement('DIV');
        d.style.visibility = 'hidden';
        d.par = this;
        d.style.position = 'absolute';
        this.cont = d;
        parDiv.appendChild(d);
        var tt = this;
        setInterval(function() {
            tt.IncSec();
            tt.Repaint();
        }, 1000);
        return this;
    },
    Requery: function() {
        return;
    },
    Repaint: function() {
        var ho = this.ho,
            mi = this.mi,
            se = this.se;
        this.cont.innerHTML = ('0' + ho).substr((ho > 9) ? 1 : 0) + ':' + ('0' + mi).substr((mi > 9) ? 1 : 0) + ':' + ('0' + se).substr((se > 9) ? 1 : 0) + '&nbsp;' + this.weekdays[this.wd - 1] + '&nbsp;' + this.d + '&nbsp;' + this.months[this.m - 1] + '&nbsp;' + this.y + '&nbsp;';
    },
    Show: function() {
        if (!this.hasset) return;
        this.Repaint();
        this.cont.style.visibility = 'visible';
    },
    Hide: function() {
        this.cont.style.visibility = 'hidden';
    },
    SetPos: function(l, t, r, b) {
        this.l = l;
        this.t = t;
        this.r = r;
        this.b = b;
        if (!l) {
            this.cont.style.right = r;
        } else {
            this.cont.style.left = l;
        }
        if (!t) {
            this.cont.style.bottom = b;
        } else {
            this.cont.style.top = t;
        }
    },
    IncSec: function() {
        var se = this.se;
        se = (se < 59) ? se + 1 : 0;
        if (se == 0) this.IncMin();
        this.se = se;
    },
    IncMin: function() {
        var mi = this.mi;
        mi = (mi < 59) ? mi + 1 : 0;
        if (mi == 0) this.IncHou();
        this.mi = mi;
    },
    IncHou: function() {
        var ho = this.ho;
        ho = (ho < 23) ? ho + 1 : 0;
        if (ho == 0) this.IncDay();
        this.ho = ho;
    },
    IncDay: function() {
        var max, d = this.d,
            wd = this.wd;
        wd = (wd < 7) ? wd + 1 : 1;
        if (this.m > 6) max = 30;
        else max = 31;
        if (this.m == 12) max = 29;
        d = (d < max) ? d + 1 : 1;
        if (d == 1) this.IncMon();
        this.d = d;
        this.wd = wd;
    },
    IncMon: function() {
        var m = this.m;
        m = (m < 12) ? m + 1 : 1;
        this.m = m;
        if (m == 1) this.y++;
    },
    SetTime: function(y, m, d, wd, ho, mi, se) {
        var now = new Date();
        this.y = y;
        this.m = m;
        this.d = d;
        this.wd = wd;
        this.ho = ho;
        this.mi = mi;
        this.se = (!se) ? now.getSeconds() : se;
        this.hasset = true;
        this.Show();
        this.owner.SetPos();
    }
};
// General Repository 
var G = {
    LLogin: '',
    ToDeactDay: ''
};

function UpObj(doc, fnam, fid, flen) { //fid:file id
    this.doc = doc;
    this.n = fnam;
    this.id = fid;
    this.hhr = false;
    this.haserror = false;
    this.AfterUpload = function() {};
    var f = doc.createElement('IFRAME');
    this.f = f;
    f.par = this;
    f.doc = doc;
    f.fid = fid;
    f.fuq = null;
    f.flen = flen;
    f.src = "/GolestanUpload/GolestanUpload.aspx";
    f.style.display = 'none';
    f.style.right = '0 px';
    f.style.top = '0 px';
    f.style.position = 'absolute';
    f.allowTransparency = "true";

    doc.body.appendChild(f);
};
UpObj.prototype.setfuqto = function(o) {
    this.f.fuq = o;
};
UpObj.prototype.setftckto = function(o) {
    this.f.ftck = o;
};
UpObj.prototype.go = function(tck, ext, fmod) {
    if (window.ActiveXObject) {
        this.doc.parentWindow.parent.parent.Commander.RetAut();
        var d = this.doc.frames(this.f.uniqueID).document;
        this.f.style.width = this.doc.body.clientWidth - 20;
        this.f.style.height = '350 px';
        if (d.readyState != 'complete') {
            alert('لطفا صبر کنيد');
            return;
        }
        var u = d.getElementById("Ufrm");
        u.UpFile.click();
        var v = u.UpFile.value;
        if (v == '') return;
        this.f.style.display = '';
        if (this.n.tagName == 'INPUT')
            this.n.value = v;
        else
            this.n.innerText = v;
        //u.TicketTextBox.value=tck;
        u.TicketTextBox.value = top.tck_sign(tck);
        u.FMODE.value = (fmod ? fmod : "");
        u.HasHeaderRow.value = this.hhr ? 1 : 0;
        if (ext && ext.toString().charAt(0) == '<') u.ext.value = ext;

        this.f.onreadystatechange = function() {
            if (this.readyState == 'complete') {
                this.doc.parentWindow.parent.parent.Message.WebBusy = false;
                var d = this.contentWindow.document;
                if (parseInt(d.getElementById('stat').value) < 0) {
                    this.par.haserror = true;
                    var m = d.getElementById('mess').innerText;
                    if (window.ActiveXObject)
                        this.doc.parentWindow.parent.parent.Message.ShowMessage(m, 'Err');
                    else
                        this.doc.defaultView.parent.parent.Message.ShowMessage(m, 'Err');


                } else {
                    if (window.ActiveXObject)
                        this.doc.parentWindow.parent.parent.Message.ShowMessage('ارسال فايل با موفقيت صورت پذيرفت', 'Suc');
                    else
                        this.doc.defaultView.parent.parent.Message.ShowMessage('ارسال فايل با موفقيت صورت پذيرفت', 'Suc');
                    try {
                        this.fid.value = d.getElementById('FileID').value;
                        this.fid.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.fuq.value = d.getElementById('FP').value;
                        this.fuq.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.ftck.value = d.getElementById('FTCK').value;
                        this.ftck.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.flen.value = d.getElementById('LineNo').value;
                        this.flen.UpdateSndData();
                    } catch (ee) {}
                }
                this.style.display = 'none';

                this.par.AfterUpload(this.par.haserror);
            }
        }
        this.doc.parentWindow.parent.parent.Message.HideMsg();
        this.doc.parentWindow.parent.parent.Message.WebBusy = true;
        this.haserror = false;
        u.bsubmit.click();

    } else {
        var that = this;
        this.doc.defaultView.parent.parent.Commander.RetAut();
        var d = this.f.contentDocument;
        this.f.style.width = this.doc.body.clientWidth - 20;
        this.f.style.height = '350 px';
        if (d.readyState != 'complete') {
            alert('لطفا صبر کنيد');
            return;
        }
        var u = d.getElementById("Ufrm");
        u.UpFile.onchange = function() {
            var v = u.UpFile.value;
            if (v == '') return;
            that.f.style.display = '';
            if (that.n.tagName == 'INPUT')
                that.n.value = v;
            else
                that.n.innerText = v;
            //u.TicketTextBox.value=tck;
            u.TicketTextBox.value = top.tck_sign(tck);
            u.FMODE.value = (fmod ? fmod : "");
            u.HasHeaderRow.value = that.hhr ? 1 : 0;
            if (ext && ext.toString().charAt(0) == '<') u.ext.value = ext;
            that.f.onload = function() {
                //that.f.onreadystatechange = function() {
                //   if (this.readyState == 'complete') {
                this.doc.defaultView.parent.parent.Message.WebBusy = false;
                var x = that;
                var d = this.contentWindow.document;
                if (parseInt(d.getElementById('stat').value) < 0) {
                    this.par.haserror = true;
                    var m = d.getElementById('mess').innerText;
                    if (window.ActiveXObject)
                        this.doc.parentWindow.parent.parent.Message.ShowMessage(m, 'Err');
                    else
                        this.doc.defaultView.parent.parent.Message.ShowMessage(m, 'Err');


                } else {
                    if (window.ActiveXObject)
                        this.doc.parentWindow.parent.parent.Message.ShowMessage('ارسال فايل با موفقيت صورت پذيرفت', 'Suc');
                    else
                        this.doc.defaultView.parent.parent.Message.ShowMessage('ارسال فايل با موفقيت صورت پذيرفت', 'Suc');
                    try {
                        this.fid.value = d.getElementById('FileId').value;
                        this.fid.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.fuq.value = d.getElementById('FP').value;
                        this.fuq.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.ftck.value = d.getElementById('FTCK').value;
                        this.ftck.UpdateSndData();
                    } catch (ee) {}
                    try {
                        this.flen.value = d.getElementById('LineNo').value;
                        this.flen.UpdateSndData();
                    } catch (ee) {}
                }
                this.style.display = 'none';


                this.par.AfterUpload(this.par.haserror);
                // }
            }
            that.doc.defaultView.parent.parent.Message.HideMsg();
            that.doc.defaultView.parent.parent.Message.WebBusy = true;
            that.haserror = false;
            u.bsubmit.click();

        }
        u.UpFile.click();

    }
}
UpObj.prototype.close = function() {
    this.doc.body.removeChild(this.f);
    this.f.onreadystatechange = null;
    this.doc = null;
    this.f = null;
    this.n = null;
    this.AfterUpload = null;
}
/*****************/
function DownObj(doc) {
    this.doc = doc;
    var defv = window.ActiveXObject ? this.doc.parentWindow : this.doc.defaultView;

    this.DownVer = 0;
    if (typeof Use_NPDownload != "undefined" && Use_NPDownload == "1") {
        var au, _fid;
        try {
            (top.$iswinopen) ? au = top.$openedwinAut[top.$openedwinAut.length - 1]: au = parent.parent.t.FaciArr[defv.parent.parent.Commander.GetContInd()].auth;
            _fid = au.f;
        } catch (e) {}
        if (_fid == 14080)
            this.DownVer = 1;
    }
    if (this.DownVer == 0) {
        var f = doc.createElement('IFRAME');
        this.f = f;
        f.doc = doc;
        f.id = "FrDown";
        f.src = "/golestandownload/down.aspx";

        f.style.display = 'none';
        f.style.right = '0 px';
        f.style.top = '0 px';
        f.style.position = 'absolute';

        f.allowTransparency = true;

        f.frameBorder = 0;
        doc.body.appendChild(f);
    } else {
        var ff;
        if (window.ActiveXObject)
            ff = doc.createElement('<iframe name="BlankFrame"/>');
        else {
            ff = doc.createElement('IFRAME');
            ff.name = "BlankFrame";
        }
        ff.src = "/blank.htm";
        ff.style.display = 'none';
        doc.body.appendChild(ff);
        var f = doc.createElement('form');
        this.action = "/npdownload/dwn.ashx";
        //this.action="/golestandownload/down.aspx";
        f.action = this.action;
        f.method = "POST"
        f.target = "BlankFrame";
        f.style.display = 'none'
        this.f = f;
        var input = doc.createElement('input')
        input.name = "TicketTextBox";
        f.appendChild(input)
        for (var i = 1; i < 26; i++) {
            var input = doc.createElement('input');
            input.name = "p" + i + "";
            f.appendChild(input)
        }
        doc.body.appendChild(f);
    }

}
var MBSetTimeout;

function DownCallBack(thisDownObj) {
    thisDownObj.MBSetTimeout = setTimeout(function() {
        if (this.DownVer != 0) {
            if (thisDownObj.doc.cookie.indexOf("mbdown=1") != -1) {
                var defv = window.ActiveXObject ? thisDownObj.doc.parentWindow : thisDownObj.doc.defaultView;
                var defvStr = window.ActiveXObject ? 'thisDownObj.doc.parentWindow' : 'thisDownObj.doc.defaultView';
                defv.parent.parent.Message.HideMsg();
                thisDownObj.doc.cookie = "mbdown=;expires=Wed; 01 Jan 1970; path=/";
                clearTimeout(thisDownObj.MBSetTimeout);
                //thisDownObj.doc.body.removeChild(thisDownObj.f);
            } else
                DownCallBack(thisDownObj);
        } else {
            if (thisDownObj.f.doc.cookie.indexOf("mbdown=1") != -1) {
                var defv = window.ActiveXObject ? thisDownObj.doc.parentWindow : thisDownObj.doc.defaultView;
                var defvStr = window.ActiveXObject ? 'thisDownObj.doc.parentWindow' : 'thisDownObj.doc.defaultView';

                defv.parent.parent.Message.HideMsg();
                var Err = thisDownObj.f.doc.getElementById("err");
                if (Err != null && Err.innerText != "") {
                    var arr = Err.innerText.split(";");
                    for (var i = 0; i < arr.length - 1; i++) {
                        if (i < 4 && arr[i].length > 0) {
                            eval(defvStr + ".parent." + arr[i]);
                        } else if (i > 3 && arr[i].length > 0) {
                            eval(defvStr + ".parent.parent.Data." + arr[i]);
                        }

                    } // for
                    eval("try{" + defvStr + ".parent.parent.Commander.Get_Data();" + defvStr + ".window.parent.parent.Message.Get_Message();}catch(e){" + defvStr + ".window.parent.parent.Message.Get_Message();}");
                    /*if(window.ActiveXObject)
                    eval("try{thisDownObj.doc.parentWindow.parent.parent.Commander.Get_Data();thisDownObj.doc.parentWindow.window.parent.parent.Message.Get_Message();}catch(e){thisDownObj.doc.parentWindow.window.parent.parent.Message.Get_Message();}");
                    else
                    eval("try{thisDownObj.doc.defaultView.parent.parent.Commander.Get_Data();thisDownObj.doc.parentWindow.window.parent.parent.Message.Get_Message();}catch(e){thisDownObj.doc.parentWindow.window.parent.parent.Message.Get_Message();}");
                    */

                }
                thisDownObj.f.doc.cookie = "mbdown=;expires=Wed; 01 Jan 1970; path=/";

                clearTimeout(thisDownObj.MBSetTimeout);
            } else
                DownCallBack(thisDownObj);
        }
    }, 300)
}
DownObj.prototype.go = function(tck, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25) {
    var defv = window.ActiveXObject ? this.doc.parentWindow : this.doc.defaultView;
    if (this.DownVer != 0) {
        defv.parent.parent.Commander.RetAut();
        var u = this.f;
        $.each(u.childNodes, function(i, v) {
            if (i == 0)
                v.value = top.tck_sign(tck);
            else {
                try {
                    v.value = eval("p" + i);
                } catch (e) {

                }
            }
        })
        defv.parent.parent.Message.HideMsg();
        u.submit();
        DownCallBack(this);
    } else {
        var d = window.ActiveXObject ? this.doc.frames(this.f.uniqueID).document : this.f.contentDocument;
        var defv = window.ActiveXObject ? this.doc.parentWindow : this.doc.defaultView;
        if (d.readyState == 'loading') {
            alert('لطفا صبر کنيد');
            return;
        }
        defv.parent.parent.Commander.RetAut();

        //this.f.style.width = this.doc.body.clientWidth-20;
        //this.f.style.height='350 px';
        var u = d.getElementById("Dfrm");
        //this.f.style.display='';
        u.TicketTextBox.value = top.tck_sign(tck);
        u.p1.value = p1;
        u.p2.value = p2;
        u.p3.value = p3;
        u.p4.value = p4;
        u.p5.value = p5;
        u.p6.value = p6;
        u.p7.value = p7;
        u.p8.value = p8;
        u.p9.value = p9;
        u.p10.value = p10;
        u.p11.value = p11;
        u.p12.value = p12;
        u.p13.value = p13;
        u.p14.value = p14;
        u.p15.value = p15;
        u.p16.value = p16;
        u.p17.value = p17;
        u.p18.value = p18;
        u.p19.value = p19;
        u.p20.value = p20;
        u.p21.value = p21;
        u.p22.value = p22;
        u.p23.value = p23;
        u.p24.value = p24;
        u.p25.value = p25;


        u.bsubmit.click();
        DownCallBack(this);
    }
}
DownObj.prototype.close = function() {
    this.doc.body.removeChild(this.f);
    this.f.onreadystatechange = null;
    this.doc = null;

}

/****************/
//*****************/
function tck_sign(tck) {
    try {
        var tab = top.t;
        if (tab.usrcertreq && tck != '') {
            try {

                if (tab.signObj == null) {
                    tab.signObj = new SignData(document);
                }
                switch (tab.signObj.CheckToken()) {
                    case 0:
                        {
                            if (tab.signObj.SelectedCertificate != null) {
                                var signstr = tab.signObj.Sign(tck);
                                tck += signstr;
                            }
                            break;
                        }
                }
            } catch (e) {} finally {
                signObj = null;
            }
        }
    } catch (e) {}
    return tck;
}

/***********/

function SignData(doc) {
    this.CAPICOM_STORE_OPEN_READ_ONLY = 0;
    this.CAPICOM_CURRENT_USER_STORE = 2;
    this.CAPICOM_LOCAL_MACHINE_STORE = 1;
    this.CAPICOM_CERTIFICATE_INCLUDE_OPTION = 2;
    this.CAPICOM_CERTIFICATE_FIND_SHA1_HASH = 0;
    this.CAPICOM_CERTIFICATE_FIND_EXTENDED_PROPERTY = 6;
    this.CAPICOM_CERTIFICATE_FIND_TIME_VALID = 9;
    this.CAPICOM_CERTIFICATE_FIND_KEY_USAGE = 12;
    this.CAPICOM_CERTIFICATE_FIND_ISSUER_NAME = 2;
    this.CAPICOM_CERTIFICATE_FIND_SUBJECT_NAME = 1;
    this.CAPICOM_DIGITAL_SIGNATURE_KEY_USAGE = 0x00000080;
    this.CAPICOM_AUTHENTICATED_ATTRIBUTE_SIGNING_TIME = 0;
    this.CAPICOM_INFO_SUBJECT_SIMPLE_NAME = 0;
    this.CAPICOM_ENCODE_BASE64 = 0;
    this.CAPICOM_E_CANCELLED = -2138568446;
    this.CAPICOM_LOGIN_CANCELLED = -2146434962;
    this.CAPICOM_TOKEN_NOTEXIST = -2146893802;
    this.CERT_KEY_SPEC_PROP_ID = 6;
    this.SelectedCertificate;
    this.doc = doc;
    try {

        var capiObject = new ActiveXObject("CAPICOM.Store");
        capiObject.Open(this.CAPICOM_CURRENT_USER_STORE, "My", this.CAPICOM_STORE_OPEN_READ_ONLY);
        capiObject = null;
    } catch (e) {
        if (e.number == this.CAPICOM_E_CANCELLED)
            alert("براي استفاده از گواهينامه ديجيتال بايد کليد YES را کليک نماييد");
        else
            this.Install_Capicom();
    }

}

SignData.prototype.Install_Capicom = function() {
    var objElement = this.doc.createElement("div");
    this.doc.body.appendChild(objElement);
    objElement.innerHTML = "<OBJECT id='oCAPICOM' codeBase='/home/golestan-downloads/capicom.cab#version=2,0,0,3' classid='clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679' VIEWASTEXT>";
    alert("لطفاً پس از اتمام نصب CAPICOM کليد Ok را کليک کنيد ...");

}
SignData.prototype.CheckToken = function() {
    if (this.SelectedCertificate != null)
        return 0;
    return this.SelectCertificate();

}

SignData.prototype.FilterCertificates = function() {
    try {
        var MyStore = new ActiveXObject("CAPICOM.Store");
        var FilteredCertificates = new ActiveXObject("CAPICOM.Certificates");
        MyStore.Open(this.CAPICOM_CURRENT_USER_STORE, "My", this.CAPICOM_STORE_OPEN_READ_ONLY);
    } catch (e) {
        if (e.number == this.CAPICOM_E_CANCELLED)
            alert("براي استفاده از گواهينامه ديجيتال بايد کليد YES را کليک نماييد");
        else
            alert("خطا هنگام خواندن گواهينامه ديجيتال \n Error message: " + e.message);
        MyStore = null;
        FilteredCertificates = null;
        return null;
    }
    var FilteredCertificates = MyStore.Certificates.Find(this.CAPICOM_CERTIFICATE_FIND_ISSUER_NAME, "NoPardaz");
    MyStore = null;
    return FilteredCertificates;
}

SignData.prototype.SelectCertificate = function() {
    var FilteredCertificates = this.FilterCertificates();
    if (FilteredCertificates == null) {
        return 3;
    }
    var userSelectedCertificate;
    var retVal = 0;
    if (FilteredCertificates.Count == 1) {
        this.SelectedCertificate = FilteredCertificates.Item(1);
    } else if (FilteredCertificates.Count > 1) {
        try {
            userSelectedCertificate = FilteredCertificates.Select();
            this.SelectedCertificate = userSelectedCertificate.Item(1);
        } catch (e) {
            retVal = 1;
        }
    } else {
        retVal = 2;
    }
    userSelectedCertificate = null;
    FilteredCertificates = null;
    return retVal;
}


SignData.prototype.SignedData = function(strToSign) {
    if (this.SelectedCertificate != null) {
        var SignedData = new ActiveXObject("CAPICOM.SignedData");
        var Signer = new ActiveXObject("CAPICOM.Signer");
        var TimeAttribute = new ActiveXObject("CAPICOM.Attribute");
        var retVal;
        Signer.Options = this.CAPICOM_CERTIFICATE_INCLUDE_OPTION;
        SignedData.Content = strToSign;
        try {
            Signer.Certificate = this.SelectedCertificate;
            var Today = new Date();
            TimeAttribute.Name = this.CAPICOM_AUTHENTICATED_ATTRIBUTE_SIGNING_TIME;
            TimeAttribute.Value = Today.getVarDate();
            Today = null;
            Signer.AuthenticatedAttributes.Add(TimeAttribute);
            retVal = SignedData.Sign(Signer, true, this.CAPICOM_ENCODE_BASE64);
        } catch (e) {
            if (e.number == this.CAPICOM_E_CANCELLED)
                alert("براي استفاده از گواهينامه ديجيتال بايد کليد YES را کليک نماييد");
            else if (e.number == this.CAPICOM_LOGIN_CANCELLED)
                alert("براي استفاده از گواهينامه ديجيتال بايد رمز عبور را وارد نماييد");
            else if (e.number == this.CAPICOM_TOKEN_NOTEXIST)
                alert("براي استفاده از گواهينامه ديجيتال بايد شناسه سخت افزاری را متصل نماييد");
            else
                alert("خطا در هنگام امضا داده:\n " + e.description + "\n" + e.number);
            retVal = "";
        }
        SignedData = null;
        Signer = null;
        TimeAttribute = null;
        return retVal;
    }
}

SignData.prototype.Sign = function() {
    var strToSign = "";
    for (i = 0; i < arguments.length; i++)
        strToSign += arguments[i];
    if (strToSign == "")
        return "";
    if (this.SelectedCertificate != null)
        return this.SignedData(strToSign);
    else {
        alert(" دسترسی به گواهینامه دیجیتال امکان پذیر نیست");
        return "";
    }

}