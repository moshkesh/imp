$.fn.pasteHtmlAtCaret = function(html, windo) {
    windo = windo || window;
    var sel, range;
    if (windo.getSelection) {
        // IE9 and non-IE
        sel = windo.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            range = sel.getRangeAt(0);
            range.deleteContents();
            // Range.createContextualFragment() would be useful here but is
            // non-standard and not supported in all browsers (IE9, for one)
            var el = windo.document.createElement("div");
            el.innerHTML = html;
            var frag = windo.document.createDocumentFragment(),
                node, lastNode;

            while ((node = el.firstChild)) {
                lastNode = frag.appendChild(node);
            }
            range.insertNode(frag);
            // Preserve the selection
            if (lastNode) {
                range = range.cloneRange();
                range.setStartAfter(lastNode);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
            /*
          if(range.endOffset != 1 && range.commonAncestorContainer.webkitdropzone==""){
             //  $(range.commonAncestorContainer).unwrap();
             //  $(range.commonAncestorContainer).parent().html($(range.commonAncestorContainer).parent().text())
              var TempTextContent = range.commonAncestorContainer.textContent;
              range.commonAncestorContainer.textContent = TempTextContent;
             //$(range.commonAncestorContainer).html($(range.commonAncestorContainer).html());
         }
         */
        }
    } else {
        if (windo.document.selection && windo.document.selection.type != "Control") {
            // IE < 9
            windo.document.selection.createRange().pasteHTML(html);
        }
    }
    //  $($('iframe').get(0).contentWindow.document.body)
};

function ConvertPersianNumberToLatin(text) {
    /*if(window.ActiveXObject)
       return text;*/
    //return text;   
    var map = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    if (/\>(.*?)\</.test(text) == false) {
        var k = 0;
        return text.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(w) {
            if (w == "۰")
                k = 0;
            if (w == "۱")
                k = 1;
            if (w == "۲")
                k = 2;
            if (w == "۳")
                k = 3;
            if (w == "۴")
                k = 4;
            if (w == "۵")
                k = 5;
            if (w == "۶")
                k = 6;
            if (w == "۷")
                k = 7;
            if (w == "۸")
                k = 8;
            if (w == "۹")
                k = 9;
            return map[+k];
        });
    } else {
        return text.replace(/\>(.*?)\</g, function(w) {
            return w.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(v) {
                return v.replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function(w) {
                    if (w == "۰")
                        k = 0;
                    if (w == "۱")
                        k = 1;
                    if (w == "۲")
                        k = 2;
                    if (w == "۳")
                        k = 3;
                    if (w == "۴")
                        k = 4;
                    if (w == "۵")
                        k = 5;
                    if (w == "۶")
                        k = 6;
                    if (w == "۷")
                        k = 7;
                    if (w == "۸")
                        k = 8;
                    if (w == "۹")
                        k = 9;
                    return map[+k]
                });
            });
        });
    }
}

function np_valid(doc, obj, nextobj) {
    this.doc = doc;
    if (doc.parentWindow)
        this.mess = doc.parentWindow.parent.parent.Message;
    else
        this.mess = window.parent.parent.Message
    //this.XmlSnd = XmlSnd;
    this.par = obj;
    this.Nex = nextobj;
}

function isVisible(obj) {
    if (obj.tagName == "npobj_bdo" || obj.tagName == "npobj_cal") {
        obj = obj.d;
    }

    if (obj.tagName == "BODY") return true

    if (!obj) return false
    if (!obj.parentElement) return false
    if (obj.style) {
        if (obj.style.display == 'none') return false
        if (obj.style.visibility == 'hidden') return false
    }
    return isVisible(obj.parentElement)
}
np_valid.prototype.CheckVal = function(event) {
    this.par.UpdateSndData();
    fv = this.par.value;
    var event = event || window.event;
    if (fv == "") {
        if (this.par.Nul && this.par.Nul == "0") {
            if (event) {
                alert(this.par.Cap + " " + "نمي تواند خالي باشد");
                this.SetFocus();
            } else {
                alert(this.par.Cap + " " + "نمي تواند خالي باشد");
                this.SetFocus();
            }
            return -1;
        }
    } else {

        if ((typeof(this.par.Min) != "undefined") && (this.par.Min != ""))
            if (fv.length < parseFloat(this.par.Min)) {
                alert('طول"' + this.par.Cap + '" نمي تواند کمتر از  ' + this.par.Min + ' کاراکتر باشد');
                this.SetFocus();
                return -1;
            }

        var p = this.par.Pic;
        /*if (p && p == "M") {
        var s = fv.replace(/(\/)/g, '')
        if (!mell(s)) {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        }
        if (p && p == "E") {
        var s = fv.replace(/(\/)/g, '')
        s = s.toLowerCase();
        this.par.value = s;
        this.par.SetVal(s);
        if (!emailCheck(s)) {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        }
        //date-------------------------------
        if ((this.par.Typ == "C" || this.par.Typ == "D") && p && (p == "D" || p == 'G')) {
        var s = fv.replace(/(\/)/g, '');
        if (s != fv)
        s = s.substr(4, 4) + '.' + s.substr(2, 2) + '.' + s.substr(0, 2);
        this.par.value = s;
        this.par.SetVal(s);
        if (s.substr(4, 1) != '.' || s.substr(7, 1) != '.') {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        var s = s.replace(/\./g, '');
        var y = parseFloat(s.substr(0, 4)), m = parseFloat(s.substr(4, 2)), da = parseFloat(s.substr(6, 2));
        if (m < 0 || m > 12) {
        alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
        this.par.SetFocus();
        return -1;
        }
        var mi = (p == 'D') ? 0 : 1;
        if (da < 0 || da > ml[mi][m]) {
        alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(s) < parseFloat(this.par.Fro)) {
        dateStr = this.par.Fro.substr(0, 4) + '/' + element.Fro.substr(4, 2) + '/' + this.par.Fro.substr(6, 2);
        alert(this.par.Cap + " بايد بزرگتر از  " + dateStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        if (s > parseFloat(this.par.To)) {
        dateStr = this.par.To.substr(0, 4) + '/' + this.par.To.substr(4, 2) + '/' + this.par.To.substr(6, 2);
        alert(this.par.Cap + " بايد کوچکتر از  " + dateStr + " باشد");
        this.par.SetFocus();
        return -1;
        }

        }
        //time-------------------------------
        if ((this.par.Typ == "C" || this.par.Typ == "T") && p && p == "T") {
        if (fv.substr(2, 1) != ':') {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(3, 2)) > 59) {
        alert('دقيقه نمي تواند مقدار بيش از 59 داشته باشد');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(0, 2)) > 24) {
        alert('ساعت نمي تواند مقدار بيش از 24 داشته باشد');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(3, 2)) > 0 && parseFloat(fv.substr(0, 2)) == 24) {
        alert('مقدار ورودي صحيح نيست');
        this.par.SetFocus();
        return -1;
        }
        timeStr = fv.substr(0, 2) + fv.substr(3, 2);
        if (parseInt(timeStr) < parseInt(this.par.Fro)) {
        timeStr = this.par.Fro.substr(0, 2) + ':' + this.par.Fro.substr(3, 2);
        alert(this.par.Cap + " بايد بزرگتر از  " + timeStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        if (parseInt(timeStr) > parseInt(this.par.To)) {
        timeStr = this.par.To.substr(0, 2) + ':' + this.par.To.substr(3, 2);
        alert(this.par.Cap + " بايد کوچکتر از  " + timeStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        }*/
        //-----------------------------
        if (this.par.Typ == "N") {
            if (isNaN(fv)) {
                alert(this.par.Cap + " " + "نمي تواند غير عددي باشد");
                this.SetFocus();
                return -1;
            }
            if ((typeof(this.par.Dec) != "undefined") && (this.par.Dec != "")) {
                if (((fv.length - fv.indexOf(".") - 1) > parseInt(this.par.Dec)) && (fv.indexOf(".") >= 1)) {
                    alert(this.par.Cap + '" نمي تواند بيش از ' + this.par.Dec + ' رقم اعشار داشته باشد"');
                    this.SetFocus();
                    return -1;
                }
            }
            if ((typeof(this.par.Fro) != "undefined") && (this.par.Fro != ""))
                if (fv < parseFloat(this.par.Fro)) {
                    alert(this.par.Cap + '" نمي تواند کوچکتر از  ' + this.par.Fro + ' باشد"');
                    this.SetFocus();
                    return -1;
                }
            if ((typeof(this.par.To) != "undefined") && (this.par.To != ""))
                if (fv > parseFloat(this.par.To)) {
                    alert(this.par.Cap + '" نمي تواند بزرگتر از ' + this.par.To + ' باشد"');
                    this.SetFocus();
                    return -1;
                }
        }
        if (this.par.Typ == "C") {
            if (this.par.Num == "1") {
                if (isNaN(fv)) {
                    alert(this.par.Cap + " " + "نمي تواند غير عددي باشد");
                    this.SetFocus();
                    return -1;
                }

                if ((typeof(this.par.Fro) != "undefined") && (this.par.Fro != ""))
                    if (fv < parseFloat(this.par.Fro)) {
                        alert(this.par.Cap + '" نمي تواند کوچکتر از  ' + this.par.Fro + ' باشد"');
                        this.SetFocus();
                        return -1;
                    }
                if ((typeof(this.par.To) != "undefined") && (this.par.To != ""))
                    if (fv > parseFloat(this.par.To)) {
                        alert(this.par.Cap + '" نمي تواند بزرگتر از ' + this.par.To + ' باشد"');
                        this.SetFocus();
                        return -1;
                    }
            }

        }
    }
    return 1;
}
np_valid.prototype.change = function(event) {
    //this.par.UpdateSndData();
    //ClearValue(element.id, 1);
    /*    if (element.value == '') {
    if (element.onchange2) {
    eval(element.onchange2);
    }
    }
    else {*/
    var event = event || window.event;
    if (this.CheckVal() < 0) {
        this.isvalid = false;
        event.returnValue = false;
        return;
    } else {
        this.isvalid = true;
        /*if (element.onchange2) {
        eval(element.onchange2);
        }
        if ((typeof (element.Pic) != "undefined") && (element.Pic == "C")) {
        element.value = element.value.replace(/,/g, '');
        var l, s = element.value, s2 = '';
        while (s != '') {
        l = s.length;
        if (l < 3) {
        s2 = ',' + s + s2;
        break;
        }
        else {
        s2 = ',' + s.slice(l - 3) + s2;
        s = s.slice(0, l - 3);
        }
        }
        element.value = s2.slice(1);
        }*/
    }
    //}
    //element.oldValue = element.value;
    //element.UpdateSndData();
}
np_valid.prototype.onkeypress = function(event) {
    frmchg = true;
    var key;
    var e = event || window.event;
    key = e.keyCode;
    shift = e.shiftKey;
    //if (key == 13 && element.tagName == 'TEXTAREA') return;
    if (key == 13 || key == 9 || key == 16) {
        /* if (element.tagName == 'SELECT') {
        try {
        if (window.document.all.item(element.id.substring(1))CheckVal() > 0)
        if (!shift) { change(); FocusNext(); }
        }
        catch (er) { }
        e.cancelBubble = true;
        e.returnValue = false;
        return;
        }*/

        if (this.CheckVal() > 0) {
            this.isvalid = true;
            if (!shift) {
                this.FocusNext();
            }
        }

        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }
    /*var p = element.Pic;
    if (p && (p == "D" || p == "G" || p == "L") && key == 47) { window.event.keyCode = 46; return; }
    if ((p && (p == "D" || p == "G" || p == "T")) || (element.Typ == "N") || ((element.Typ == "C") && (element.Num == "1"))) {
    if (key < 48 || key > 57) {
    if (key == 45) return;
    if ((element.Dec != undefined) && (element.Dec != ""))
    if (parseInt(element.Dec, 10) > 0)
    if (key == 46) return;
    if ((p == "D" || p == "G") && key == 46) return;
    e.cancelBubble = true;
    e.returnValue = false;
    }
    return;
    }*/
    if (this.par.Typ == 'N') {
        if (key < 48 || key > 57) {
            e.cancelBubble = true;
            e.returnValue = false;
        }
        return;
    }
    if (key > 1547) {
        alert("لطفا حالت صفحه کليد خود را به انگليسي تغيير دهيد.");
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }
    if (!this.par.ALan || this.par.ALan == "") {
        if (this.par.Lan == "2") {
            this.par.ALan = "2";
        } else {
            this.par.ALan = "1";
            if (!this.par.Lan) this.par.Lan = "0";
        }
    }
    var fs = '';
    if (this.par.ALan == "1") //Farsi
        if (key > 31 && key < 128) {
            if (!shift && key < 91 && key > 64) key = key + 32;
            if (shift && key < 123 && key > 96) key = key - 32;
            //fs = ' !"#$%،گ)(×+و-./0123456789:ك،=.؟@شذزيثبلآهتنمءدخحضقسفعرصطغظجژچ^_پشذزيثبلاهتنمئدخحضقسفعرصطغظ<|>ّ';
            fs = ' !~#$%،گ)(×+و-./0123456789:ك،=.؟@شذژيثبلآهتنمءدخحضقس،عرصطغظجپچ^_ژشذزيثبلاهتنمئدخحضقسفعرصطغظ<|>ّ';
        }
    if (this.par.Pic == 'F') {
        //fs = ' ~~~~~~گ~~~~و~~~~~~~~~~~~~~ك~~~~~شذزيثبلآهتنمءدخحضقسفعرصطغظجژچ~~پشذزيثبلاهتنمئدخحضقسفعرصطغظ~~~ّ'
        fs = ' ~~~~~~گ~~~~و~~~~~~~~~~~~~~ك~~~~~شذژيثبلآهتنمءدخحضقس،عرصطغظجپچ~~ژشذزيثبلاهتنمئدخحضقسفعرصطغظ~~~ّ'
    }
    if (fs != '') {
        var k = fs.charCodeAt(key - 32);
        if (String.fromCharCode(k) == '~') k = null;
        e.keyCode = k;
    }
}
np_valid.prototype.onkeyup = function(event) {
    var key;
    var e = event || window.event;
    key = e.keyCode;
    if (key == 27) {
        //this.par.value = this.par.oldValue;
        this.par.isvalid = true;
        return;
    }
    if (key == 17) { //Ctrl has pressed
        if (!this.par.Lan) {
            this.par.ALan = '1';
        } else {
            if (this.par.Lan == '0') {
                switch (this.par.ALan) {
                    case '2':
                        {
                            this.par.ALan = '1';
                            break;
                        }
                    case '1':
                        {
                            this.par.ALan = '2';
                            break;
                        }
                }
            }
        }
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }

    if (key == 8 || (key >= 33 && key <= 39) || key == 45 || key == 46)
        return;
    if (key == 13 || key == 9 || key == 16) {
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }
    var p = this.par;
    if ((p.Max != undefined) && (p.Max != "")) {
        if ((p.value.length) >= parseInt(p.Max)) {
            p.value = p.value.slice(0, parseInt(p.Max));
            this.change(event);
            if (this.isvalid) {
                this.FocusNext();
            }
        }
    }
}
np_valid.prototype.onblur = function(event) {
    this.change(event);
}
np_valid.prototype.FocusNext = function(NoAct) {
    var Nex = this.Nex;
    while (typeof(Nex) == 'object' || typeof(eval(Nex)) == 'object') {
        var Nex = (typeof(Nex) == 'object') ? Nex : eval(Nex);
        try {
            if (Nex.tagName == 'FONT' || Nex.tagName == 'LABEL' || Nex.tagName == 'SPAN') {
                try {
                    if (Nex.Nex == Nex.id) return;
                    Nex = window.document.all.item(Nex.Nex);
                } catch (e) {
                    return;
                }
            } else {
                if (Nex.focus() < 0) throw ('1097');
                switch (Nex.tagName) {
                    case 'IMG':
                        {
                            try {
                                Nex.click();
                            } catch (e) {}
                            break;
                        }
                    case 'INPUT':
                        {
                            if (Nex.type == 'image')
                                Nex.click();
                            else
                                Nex.select();

                            break;
                        }
                    case 'npobj_cal':
                    case 'npobj_bdo':
                        {
                            Nex.select();
                            break;
                        }
                }
                return;
            }
        } catch (e) {
            try {
                if (ver == 3) {
                    if (Nex.RFld) {
                        Nex.RFld[0].focus();
                    } else {
                        z = Nex.HFld;
                        z.focus();
                        z.style.backgroundColor = "#0000FF";
                        setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                    }
                } else {
                    d = window.document.all;
                    d.item('H' + Nex.id).focus();
                    z = d.item('H' + Nex.id).style;
                    z.backgroundColor = "#0000FF";
                    setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                }
                return;
            } catch (e) {
                try {
                    if (!Nex.Nex || Nex.Nex == Nex.id) break;
                    var ne = window.document.all.item(Nex.Nex);
                    if (!ne) ne = eval(Nex.Nex);
                    Nex = ne;
                } catch (e) {
                    return;
                }
            }
        }
    }
    if (NoAct) return;
    var NextAct = parent.parent.Commander.NextAct;
    if (NextAct == '01') {
        if (window.document.body.LastEnterAct) {
            NextAct = window.document.body.LastEnterAct;
        }
    }
    parent.parent.Commander.act_data_frm(NextAct);
}
np_valid.prototype.SetFocus = function(NoErr) {
    var e = this.par;
    if (e.style.display == "none") {
        return -1;
    }

    if (e.disabled) {
        e.FocusNext(true);
    } else {
        try {
            e.focus();
            e.select();
        } catch (e) {}
    }
    return 1;
}
np_valid.prototype.UpdateSndData = function() {
    if (window.ActiveXObject) {
        XmlSnd.documentElement.setAttribute(this.par.id) = this.par.value;
    } else {
        XmlSnd.documentElement.setAttribute(this.par.id, this.par.value);
        XmlSnd.xml = new XMLSerializer().serializeToString(XmlSnd.documentElement);

    }
}

function np_valid_forbdo(doc) {
    this.doc = doc;
    if (doc.parentWindow)
        this.mess = doc.parentWindow.parent.parent.Message;
    else
        this.mess = window.parent.parent.Message;

    //this.XmlSnd = XmlSnd;

}

np_valid_forbdo.prototype.CheckVal = function(event) {
    //var fv = element.FixNumber();
    this.par.value = this.par.b.innerHTML;
    this.par.UpdateSndData();
    fv = this.par.value;
    event = event || window.event;


    if (fv == "") {
        if (this.par.Nul && this.par.Nul == "0") {
            if (event) {
                alert(this.par.Cap + " " + "نمي تواند خالي باشد");
                var srcElement = event.srcElement || event.target;
                if (srcElement != this.par.b) {
                    this.par.SetFocus();
                }
            } else {
                alert(this.par.Cap + " " + "نمي تواند خالي باشد");
                this.par.SetFocus();
            }
            return -1;
        }
    } else {

        if ((typeof(this.par.Min) != undefined) && (this.par.Min != ""))
            if (fv.length < parseFloat(this.par.Min)) {
                alert('طول"' + this.par.Cap + '" نمي تواند کمتر از  ' + this.par.Min + ' کاراکتر باشد');
                this.par.SetFocus();
                return -1;
            }
        /*if(fv!=this.par.oldVal &&  !parent.parent.Commander.CheckValidChars(fv,this.par))
        {   var Cap = this.par.Cap||this.par.cap;
            alert(Cap + " " + "دارای کاراکتر غیر مجاز است ");
            this.par.SetFocus();
            return -1;
        }*/

        var p = this.par.Pic;
        /*if (p && p == "M") {
        var s = fv.replace(/(\/)/g, '')
        if (!mell(s)) {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        }
        if (p && p == "E") {
        var s = fv.replace(/(\/)/g, '')
        s = s.toLowerCase();
        this.par.value = s;
        this.par.SetVal(s);
        if (!emailCheck(s)) {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        }
        //date-------------------------------
        if ((this.par.Typ == "C" || this.par.Typ == "D") && p && (p == "D" || p == 'G')) {
        var s = fv.replace(/(\/)/g, '');
        if (s != fv)
        s = s.substr(4, 4) + '.' + s.substr(2, 2) + '.' + s.substr(0, 2);
        this.par.value = s;
        this.par.SetVal(s);
        if (s.substr(4, 1) != '.' || s.substr(7, 1) != '.') {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        var s = s.replace(/\./g, '');
        var y = parseFloat(s.substr(0, 4)), m = parseFloat(s.substr(4, 2)), da = parseFloat(s.substr(6, 2));
        if (m < 0 || m > 12) {
        alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
        this.par.SetFocus();
        return -1;
        }
        var mi = (p == 'D') ? 0 : 1;
        if (da < 0 || da > ml[mi][m]) {
        alert('.تاريخ وارد شده صحيح نمي باشد، تاريخ بايد بصورت روز، ماه، سال وارد گردد\n.همچـنين  روز  و  ماه  و  سـال  بايد  در  محدوده  معني دار قرار داشته باشد\n\n.مثلا  تـاريخ 1380/1/2  بـايد به صورت  02 سپـس 01 و بعد 1380  وارد شـود');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(s) < parseFloat(this.par.Fro)) {
        dateStr = this.par.Fro.substr(0, 4) + '/' + element.Fro.substr(4, 2) + '/' + this.par.Fro.substr(6, 2);
        alert(this.par.Cap + " بايد بزرگتر از  " + dateStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        if (s > parseFloat(this.par.To)) {
        dateStr = this.par.To.substr(0, 4) + '/' + this.par.To.substr(4, 2) + '/' + this.par.To.substr(6, 2);
        alert(this.par.Cap + " بايد کوچکتر از  " + dateStr + " باشد");
        this.par.SetFocus();
        return -1;
        }

        }
        //time-------------------------------
        if ((this.par.Typ == "C" || this.par.Typ == "T") && p && p == "T") {
        if (fv.substr(2, 1) != ':') {
        alert(this.par.Cap + " نامعتبر است");
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(3, 2)) > 59) {
        alert('دقيقه نمي تواند مقدار بيش از 59 داشته باشد');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(0, 2)) > 24) {
        alert('ساعت نمي تواند مقدار بيش از 24 داشته باشد');
        this.par.SetFocus();
        return -1;
        }
        if (parseFloat(fv.substr(3, 2)) > 0 && parseFloat(fv.substr(0, 2)) == 24) {
        alert('مقدار ورودي صحيح نيست');
        this.par.SetFocus();
        return -1;
        }
        timeStr = fv.substr(0, 2) + fv.substr(3, 2);
        if (parseInt(timeStr) < parseInt(this.par.Fro)) {
        timeStr = this.par.Fro.substr(0, 2) + ':' + this.par.Fro.substr(3, 2);
        alert(this.par.Cap + " بايد بزرگتر از  " + timeStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        if (parseInt(timeStr) > parseInt(this.par.To)) {
        timeStr = this.par.To.substr(0, 2) + ':' + this.par.To.substr(3, 2);
        alert(this.par.Cap + " بايد کوچکتر از  " + timeStr + " باشد");
        this.par.SetFocus();
        return -1;
        }
        }*/
        //-----------------------------
        if (this.par.Typ == "N") {
            if (isNaN(fv)) {
                alert(this.par.Cap + " " + "نمي تواند غير عددي باشد");
                this.par.SetFocus();
                return -1;
            }
            if ((typeof(this.par.Dec) != "undefined") && (this.par.Dec != "")) {
                if (((fv.length - fv.indexOf(".") - 1) > parseInt(this.par.Dec)) && (fv.indexOf(".") >= 1)) {
                    alert(this.par.Cap + '" نمي تواند بيش از ' + this.par.Dec + ' رقم اعشار داشته باشد"');
                    this.par.SetFocus();
                    return -1;
                }
            }
            if ((typeof(this.par.Fro) != "undefined") && (this.par.Fro != ""))
                if (fv < parseFloat(this.par.Fro)) {
                    alert(this.par.Cap + '" نمي تواند کوچکتر از  ' + this.par.Fro + ' باشد"');
                    this.par.SetFocus();
                    return -1;
                }
            if ((typeof(this.par.To) != "undefined") && (this.par.To != ""))
                if (fv > parseFloat(this.par.To)) {
                    alert(this.par.Cap + '" نمي تواند بزرگتر از ' + this.par.To + ' باشد"');
                    this.par.SetFocus();
                    return -1;
                }
        }
        if (this.par.Typ == "C") {
            if (this.par.Num == "1") {
                if (isNaN(fv)) {
                    alert(this.par.Cap + " " + "نمي تواند غير عددي باشد");
                    this.par.SetFocus();
                    return -1;
                }
                if ((typeof(this.par.Fro) != undefined) && (this.par.Fro != ""))
                    if (fv < parseFloat(this.par.Fro)) {
                        alert(this.par.Cap + '" نمي تواند کوچکتر از  ' + this.par.Fro + ' باشد"');
                        this.par.SetFocus();
                        return -1;
                    }
                if ((typeof(this.par.To) != undefined) && (this.par.To != ""))
                    if (fv > parseFloat(this.par.To)) {
                        alert(this.par.Cap + '" نمي تواند بزرگتر از ' + this.par.To + ' باشد"');
                        this.par.SetFocus();
                        return -1;
                    }
            }

        }
    }
    return 1;
}
np_valid_forbdo.prototype.change = function(event) {
    this.par.value = this.par.b.innerHTML;
    this.par.UpdateSndData();
    //ClearValue(element.id, 1);
    /*    if (element.value == '') {
    if (element.onchange2) {
    eval(element.onchange2);
    }
    }
    else {*/

    if (this.CheckVal() < 0) {
        this.par.oldVal = this.par.value;
        this.isvalid = false;
        var event = event || window.event;
        event.returnValue = false;
        return;
    } else {
        this.par.oldVal = this.par.value;
        this.isvalid = true;
        /*if (element.onchange2) {
        eval(element.onchange2);
        }
        if ((typeof (element.Pic) != "undefined") && (element.Pic == "C")) {
        element.value = element.value.replace(/,/g, '');
        var l, s = element.value, s2 = '';
        while (s != '') {
        l = s.length;
        if (l < 3) {
        s2 = ',' + s + s2;
        break;
        }
        else {
        s2 = ',' + s.slice(l - 3) + s2;
        s = s.slice(0, l - 3);
        }
        }
        element.value = s2.slice(1);
        }*/
    }
    //}
    //element.oldValue = element.value;
    //element.UpdateSndData();
}
np_valid_forbdo.prototype.onkeypress = function(event, window) {
    frmchg = true;
    var key;
    var e = event || window.event;
    key = e.keyCode;
    shift = e.shiftKey;
    //if (key == 13 && element.tagName == 'TEXTAREA') return;
    if (key == 13 || key == 9 || key == 16) {
        /* if (element.tagName == 'SELECT') {
        try {
        if (window.document.all.item(element.id.substring(1))CheckVal() > 0)
        if (!shift) { change(); FocusNext(); }
        }
        catch (er) { }
        e.cancelBubble = true;
        e.returnValue = false;
        return;
        }*/
        e.cancelBubble = true;
        e.returnValue = false;
        if (this.CheckVal() > 0) {
            if (!shift) {
                this.change(event);
                this.FocusNext();
            }
        }
        return;
    }
    /*var p = element.Pic;
    if (p && (p == "D" || p == "G" || p == "L") && key == 47) { window.event.keyCode = 46; return; }
    if ((p && (p == "D" || p == "G" || p == "T")) || (element.Typ == "N") || ((element.Typ == "C") && (element.Num == "1"))) {
    if (key < 48 || key > 57) {
    if (key == 45) return;
    if ((element.Dec != undefined) && (element.Dec != ""))
    if (parseInt(element.Dec, 10) > 0)
    if (key == 46) return;
    if ((p == "D" || p == "G") && key == 46) return;
    e.cancelBubble = true;
    e.returnValue = false;
    }
    return;
    }*/
    if (key > 1547) {
        alert("لطفا حالت صفحه کليد خود را به انگليسي تغيير دهيد.");
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }
    if (!this.par.ALan || this.par.ALan == "") {
        if (this.par.Lan == "2") {
            this.par.ALan = "2";
        } else {
            this.par.ALan = "1";
            if (!this.par.Lan) this.par.Lan = "0";
        }
    }
    if (this.par.ALan == "1") //Farsi
        if (key > 31 && key < 128) {
            if (!shift && key < 91 && key > 64) key = key + 32;
            if (shift && key < 123 && key > 96) key = key - 32;
            var fs;
            fs = ' !~#$%،گ)(×+و-./0123456789:ك،=.؟@شذزيثبلآهتنمءدخحضقسفعرصطغظجژچ^_پشذزيثبلاهتنمئدخحضقسفعرصطغظ<|>ّ';
            if (this.par.Pic == 'F') {
                fs = ' ~~~~~~گ~~~~و~~~~~~~~~~~~~~ك~~~~~شذزيثبلآهتنمءدخحضقسفعرصطغظجژچ~~پشذزيثبلاهتنمئدخحضقسفعرصطغظ~~~ّ'
            }
            var k = fs.charCodeAt(key - 32);
            if (String.fromCharCode(k) == '~') k = null;
            e.keyCode = k;
            if (!window.ActiveXObject) {
                $("bdo", this.par.d).pasteHtmlAtCaret(String.fromCharCode(k), window)
                e.preventDefault();

            }
        }
}
np_valid_forbdo.prototype.onkeyup = function(event) {
    var key;
    var e = event || window.event;
    key = e.keyCode;
    if (key == 27) {
        //this.par.value = this.par.oldValue;
        this.par.isvalid = true;
        return;
    }
    if (key == 17) { //Ctrl has pressed
        if (!this.par.Lan) {
            this.par.ALan = '1';
        } else {
            if (this.par.Lan == '0') {
                switch (this.par.ALan) {
                    case '2':
                        {
                            this.par.ALan = '1';
                            break;
                        }
                    case '1':
                        {
                            this.par.ALan = '2';
                            break;
                        }
                }
            }
        }
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }

    if (key == 8 || (key >= 33 && key <= 39) || key == 45 || key == 46)
        return;
    if (key == 13 || key == 9 || key == 16) {
        e.cancelBubble = true;
        e.returnValue = false;
        return;
    }
    var p = this.par;
    p.Max = p.Max || p.max;
    if ((p.Max != undefined) && (p.Max != "")) {
        if ((p.b.innerText.length) >= parseInt(p.Max)) {
            p.SetVal(p.b.innerText.slice(0, parseInt(p.Max)));
            this.change(event);
            if (this.isvalid) this.FocusNext();
        }
    }
    p.value = p.b.innerHTML;
}
np_valid_forbdo.prototype.onblur = function(event) {
    this.change(event);
}
np_valid_forbdo.prototype.onpaste = function(event) {
    var target = window.event.srcElement;
    setTimeout(function() {
        var text = ConvertPersianNumberToLatin(target.innerText);
        target.innerText = trim(text)
    }, 0)

}
np_valid_forbdo.prototype.FocusNext = function(NoAct) {
    var Nex = this.par.Nex;
    if (!window.ActiveXObject)
        var Nex = $(this.par).attr("nex")
    while (typeof(Nex) == 'object' || typeof(eval(Nex)) == 'object') {
        var Nex = (typeof(Nex) == 'object') ? Nex : eval(Nex);
        try {
            if (Nex.tagName == 'FONT' || Nex.tagName == 'LABEL' || Nex.tagName == 'SPAN') {
                try {
                    if (Nex.Nex == Nex.id) return;
                    Nex = window.document.all.item(Nex.Nex);
                } catch (e) {
                    return;
                }
            } else {
                if (Nex.focus() < 0) throw ('1097');
                if (Nex.disabled) {
                    Nex = window.document.all.item(Nex.Nex);
                    return;
                }
                var c = 0,
                    AllNex = [],
                    IsLoop = false;
                while (!isVisible(Nex) && !IsLoop) {

                    for (var i = 0; i < AllNex.length; i++) {
                        if (AllNex[i] == Nex.id) {
                            IsLoop = true;
                            return;
                        }

                    }
                    AllNex[c] = Nex.id;
                    var ne = window.document.all.item(Nex.Nex);
                    if (!ne) ne = eval(Nex.Nex);
                    Nex = ne;
                    c++;

                }
                if (IsLoop)
                    return;
                switch (Nex.tagName) {
                    case 'IMG':
                        {
                            try {
                                Nex.click();
                            } catch (e) {}
                            break;
                        }
                    case 'INPUT':
                        {
                            if (Nex.type == 'image')
                                Nex.click();
                            else
                                Nex.select();

                            break;
                        }
                    case 'npobj_cal':
                    case 'npobj_bdo':
                        {
                            //Nex.select();
                            Nex.focus();
                            break;
                        }
                }
                return;
            }
        } catch (e) {
            try {
                if (ver == 3) {
                    if (Nex.RFld) {
                        Nex.RFld[0].focus();
                    } else {
                        z = Nex.HFld;
                        z.focus();
                        z.style.backgroundColor = "#0000FF";
                        setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                    }
                } else {
                    d = window.document.all;
                    d.item('H' + Nex.id).focus();
                    z = d.item('H' + Nex.id).style;
                    z.backgroundColor = "#0000FF";
                    setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                }
                return;
            } catch (e) {
                try {
                    if (!Nex.Nex || Nex.Nex == Nex.id) break;
                    var ne = window.document.all.item(Nex.Nex);
                    if (!ne) ne = eval(Nex.Nex);
                    Nex = ne;
                } catch (e) {
                    return;
                }
            }
        }
    }
    if (NoAct) return;
    var NextAct = parent.parent.Commander.NextAct;
    if (NextAct == '01') {
        if (window.document.body.LastEnterAct) {
            NextAct = window.document.body.LastEnterAct;
        }
    }
    parent.parent.Commander.act_data_frm(NextAct);
}
np_valid_forbdo.prototype.UpdateSndData = function() {
    if (window.ActiveXObject)
        XmlSnd.documentElement.setAttribute(this.par.id) = this.par.value;
    else {
        XmlSnd.documentElement.setAttribute(this.par.id, (this.par.value != undefined ? this.par.value : ""));
        XmlSnd.xml = new XMLSerializer().serializeToString(XmlSnd.documentElement);
    }

}

function np_bdo(doc, replace_obj_id) {
    var rid = replace_obj_id;
    this.rid = rid;
    //this.id = rid.id;
    this.doc = doc;
    this.valid = new np_valid_forbdo(doc);
    for (var i = 0; i < rid.attributes.length; i++) {
        var n = rid.attributes[i].name,
            v = rid.attributes[i].value;
        if (n == 'class') n = '_' + n;
        if (n == 'id') v = v.replace('bdo_', '');
        if (n.search(/-/g) < 0) eval('this.' + n + '=\'' + v + '\'');
    }
    this.tagName = 'npobj_bdo';

    var d = doc.createElement('DIV');
    var b = doc.createElement('BDO');
    try {
        d.tabIndex = this.tabIndex
    } catch (e) {};
    try {
        d.id = this.id;
        $(d).attr("nex", this.nex)
    } catch (e) {};
    b.par = this;
    this.d = d;
    this.b = b;
    this.valid.par = this;

    b.contentEditable = true;
    b.style.width = "100%";
    b.dir = "LTR";
    if (!window.ActiveXObject)
        b.style.height = "14px";
    b.innerHTML = '&nbsp;';
    b.onblur = function(event) {
        this.par.valid.onblur(event);
    }
    /*b.onpaste = function() {
        this.par.valid.onpaste(event);
    }*/
    b.onkeypress = function(event) {
        this.par.valid.onkeypress(event, window);
    }
    b.onkeyup = function(event) {
        this.par.valid.onkeyup(event);
    }

    copyStyle2(rid, d);

    b.style.marginTop = '-5px';
    b.style.paddingRight = '2px';

    d.onfocus = function() {
        b.focus()
    };
    d.onclick = function() {
        b.focus()
    };
    d.appendChild(b);

    var p = rid.parentNode,
        w = p.offsetWidth;
    if (rid.replaceNode)
        rid.replaceNode(d);
    else
        rid.parentNode.replaceChild(d, rid)
    if (w > 0)
        p.style.width = w;
}
np_bdo.prototype.SetVal = function(v) {
    this.value = v;
    this.b.innerHTML = v;
}
np_bdo.prototype.GetVal = function(v) {
    return v;
}
np_bdo.prototype.Disable = function(bool) {
    var tf = true;
    if (typeof(bool) != 'undefined')
        tf = bool;
    this.b.contentEditable = !tf;
    this.disabled = tf;
    this.b.style.color = tf ? '#777777' : '';
    setTimeout('window.focus();', 1);
}
np_bdo.prototype.UpdateSndData = function() {
    this.b.innerHTML = this.value != undefined ? this.value : "";
    this.valid.UpdateSndData();
}
np_bdo.prototype.SetFocus = function() {
    if (this.disabled) return -1;
    try {
        this.b.focus();
    } catch (e) {
        return -1;
    }
    this.doc.execCommand('SelectAll');
    return 1;
    //this.d.select();
}
np_bdo.prototype.focus = function() {
    return this.SetFocus();
}
np_bdo.prototype.select = function() {
    this.doc.execCommand('SelectAll');
}
np_bdo.prototype.FocusNext = function() {
    this.valid.FocusNext();
}

function np_cal(doc, replace_obj_id) {
    var that = this;
    this.that = this;
    /*var xlog=doc.createElement('DIV');
    xlog.style.left=0;
    xlog.style.top=0;
    xlog.style.position='absolute';
    xlog.innerHTML='';
    doc.body.appendChild(xlog);
    this.log=xlog;*/
    var $ = $ ? $ : top.$;
    if (!top.SupportOldGolestan) {
        var rid = replace_obj_id;
        this.rid = rid;
        this.doc = doc;
        //$($(rid)).datepicker();
        for (var i = 0; i < rid.attributes.length; i++) {
            var n = rid.attributes[i].name,
                v = rid.attributes[i].value;
            if (n == 'class') n = '_' + n;
            if (n == 'id') v = v.replace('cal_', '');
            if (n.search(/-/g) < 0)
                eval('this.' + n + '=\'' + v + '\'');
            //this[n]=v;
        }
        if (top.SupportOldGolestan || !window.ActiveXObject) {
            this.value = rid.value;
        }
        this.tagName = 'npobj_cal';

        var d = doc.createElement('DIV');
        var r = doc.createElement('INPUT');
        var m = doc.createElement('INPUT');
        var s = doc.createElement('INPUT');
        var p1 = doc.createElement('span');
        var p2 = doc.createElement('span');
        try {
            d.tabIndex = this.tabIndex;
            r.tabIndex = d.tabIndex;
            m.tabIndex = d.tabIndex;
            s.tabIndex = d.tabIndex;
        } catch (e) {};
        r.par = this;
        m.par = this;
        s.par = this;
        if (window.ActiveXObject)
            d.className = 'cal_d';
        else {
            d.className = 'cal_d cal_d_MB';
            /*d.style.border="1px solid #879eac";
            d.style.display="inline-block";
            d.style.verticalAlign="middle";*/
        }
        r.className = "cal_r";
        m.className = "cal_m";
        s.className = "cal_s";
        p1.innerText = '/';
        p2.innerText = '/';
        p1.className = "cal_p";
        p2.className = "cal_p";
        $(r).attr("R_ID", this.id);
        if (rid.style.width > d.style.width) rid.style.width = d.style.width;
        /*r.Nul = this.Nul;
        m.Nul = this.Nul;
        s.Nul = this.Nul;*/
        this.fro = this.fro || this.Fro;
        this.to = this.to || this.To;
        var S_Fro = this.fro ? this.fro.substring(0, 4) : 1300;
        /*,
                M_Fro = this.fro ?  this.fro.substring(4,6) : 1,
                R_Fro = this.fro ? this.fro.substring(6,8) : 1;*/
        var S_To = this.to ? this.to.substring(0, 4) : 1450
        /*,
                M_To =  this.to ? this.to.substring(4,6) : 31,
                R_To =  this.to ? this.to.substring(6,8) : 12;*/
        this.d = d;
        this.r = r;
        this.m = m;
        this.s = s;
        this.p1 = p1;
        this.p2 = p2;
        r.Fro = 1;
        m.Fro = 1;
        s.Fro = S_Fro;
        r.To = 31;
        m.To = 12;
        s.To = S_To;
        r.Max = 2;
        m.Max = 2;
        s.Max = 4;
        r.Typ = 'N';
        m.Typ = 'N';
        s.Typ = 'N';
        r.Cap = 'روز';
        m.Cap = 'ماه';
        s.Cap = 'سال';
        r.disabled = true;
        m.disabled = true;
        s.disabled = true;
        r.valid = new np_valid(doc, r, m);
        m.valid = new np_valid(doc, m, s);
        if (window.ActiveXObject)
            s.valid = new np_valid(doc, s, this.Nex);
        else
            s.valid = new np_valid(doc, s, $(this).attr("nex"));

        r.valid.par = r;
        m.valid.par = m;
        s.valid.par = s;

        r.onblur = function() {
            //this.valid.onblur();
        };
        r.onkeypress = function() { /*this.par.log.innerHTML+='r key press<br>';*/
            if (this.par.disabled) return false;
            this.valid.onkeypress(event);
        };
        r.onkeyup = function() { /*this.par.log.innerHTML+='r key up<br>';*/
            this.valid.onkeyup(event);
        };

        m.onblur = function() { /*this.valid.onblur();*/ };
        m.onkeypress = function() {
            if (this.par.disabled) return false;
            this.valid.onkeypress(event);
        };
        m.onkeyup = function() {
            this.valid.onkeyup(event);
        };

        s.onblur = function() { /*this.valid.onblur();*/ };
        s.onkeypress = function() {
            if (this.par.disabled) return false;
            this.valid.onkeypress(event);
        };
        s.onkeyup = function() {
            this.valid.onkeyup(event);
        };

        r.UpdateSndData = function() { /*this.par.log.innerHTML+='<b>r update snd data</b><br>';*/
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };
        m.UpdateSndData = function() {
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };
        s.UpdateSndData = function() {
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };

        r.onchange = function() { /*this.par.log.innerHTML+='<b>r on change</b><br>';*/
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };
        m.onchange = function() {
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };
        s.onchange = function() {
            var p = this.par;
            p.Syncsmr2par();
            p.UpdateSndData();
            p.showDatePicker(false);
        };

        copyStyle(rid, d);

        d.onfocus = function() {
            try {
                r.focus();
            } catch (e) {}
        };
        d.onclick = function() {
            try {
                r.focus();
            } catch (e) {}
        };

        r.onclick = function(event) { /*this.par.log.innerHTML+='r click<br>';*/
            if (this.valid.isvalid || typeof(this.valid.isvalid) == 'undefined') this.par.displayDatePicker();
            var e = event || window.event;
            e.cancelBubble = true;
            e.returnValue = false;
        };
        m.onclick = function(event) {
            if (this.valid.isvalid || typeof(this.valid.isvalid) == 'undefined') this.par.displayDatePicker();
            var e = event || window.event;
            e.cancelBubble = true;
            e.returnValue = false;
        };
        s.onclick = function(event) {
            if (this.valid.isvalid || typeof(this.valid.isvalid) == 'undefined') this.par.displayDatePicker();
            var e = event || window.event;
            e.cancelBubble = true;
            e.returnValue = false;
        };

        d.appendChild(r);
        d.appendChild(p1);
        d.appendChild(m);
        d.appendChild(p2);
        d.appendChild(s);

        //var p = rid.parentNode, w = d.offsetWidth;
        if (rid.replaceNode)
            rid.replaceNode(d);
        else
            rid.parentNode.replaceChild(d, rid);
        //p.style.width = w;
        //d.style.width=parseInt(d.style.width,10)+50
        /////////////////////////////////////////////////////////////////////////////////
        this.dayArrayShort = new Array('ش', 'ي', 'د', 'س', 'چ', 'پ', 'ج');
        this.dayArrayMed = new Array('&#1588;&#1606;&#1576;&#1607;', '&#1740;&#1705;&#1588;&#1606;&#1576;&#1607;', '&#1583;&#1608;&#1588;&#1606;&#1576;&#1607;', '&#1587;&#1607;&#32;&#1588;&#1606;&#1576;&#1607;', '&#1670;&#1607;&#1575;&#1585;&#1588;&#1606;&#1576;&#1607;', '&#1662;&#1606;&#1580;&#1588;&#1606;&#1576;&#1607;', '&#1580;&#1605;&#1593;&#1607;');
        this.dayArrayLong = this.dayArrayMed;
        this.monthArrayShort = new Array('&#1601;&#1585;&#1608;&#1585;&#1583;&#1740;&#1606;', '&#1575;&#1585;&#1583;&#1740;&#1576;&#1607;&#1588;&#1578;', '&#1582;&#1585;&#1583;&#1575;&#1583;', '&#1578;&#1740;&#1585;', '&#1605;&#1585;&#1583;&#1575;&#1583;', '&#1588;&#1607;&#1585;&#1740;&#1608;&#1585;', '&#1605;&#1607;&#1585;', '&#1570;&#1576;&#1575;&#1606;', '&#1570;&#1584;&#1585;', '&#1583;&#1740;', '&#1576;&#1607;&#1605;&#1606;', '&#1575;&#1587;&#1601;&#1606;&#1583;');
        this.monthArrayMed = this.monthArrayShort;
        this.monthArrayLong = this.monthArrayShort;

        this.defaultDateFormat = "ymd";
        this.dateFormat = this.defaultDateFormat;

        var cd = document.createElement("div");
        cd.par = this;
        cd.className = "calDiv";
        cd.style.display = "none";
        cd.style.border = "2px solid #aaaaaa";
        document.body.appendChild(cd);
        cd.style.height = "180px";
        if (!window.ActiveXObject)
            cd.style.background = "#fff";

        this.calDiv = cd;
        var ifr = document.createElement("iFrame");
        ifr.src = '/blank.htm';
        ifr.style.display = "none";
        document.body.appendChild(ifr);
        this.ifr = ifr;
        /////////////////////////////////////////////////////////////////////////////////
    } else {
        var r = replace_obj_id;
        r.setAttribute("dir", "ltr");
        r.id = r.id.replace(/cal_/g, '');
        r.style.width = "81px";
        //r.className = "cal_r";
        setDatePicker(r, 0);
        this.r = r;
        return r;
    }
}

function setDatePicker(r, Count) {
    /* if(Count==10 && !parent.Form_Body.jQuery)
       LoadJQAndUi(1);
    */
    var $ = $ ? $ : top.$;
    if (parent.Form_Body.jQuery && typeof parent.Form_Body.jQuery.ui != 'undefined' && parent.Form_Body.DatePickerLoaded) {
        $(r).datepicker({
            dateFormat: 'yy/mm/dd'
        });
    } else {
        setTimeout(function() {
            Count++;
            setDatePicker(r, Count);
        }, 100)
    }
}
np_cal.prototype.SetVal = function(v) {
    if (top.SupportOldGolestan) {
        //this.r.value = v;
        return;
    }
    if (typeof(v) == 'undefined') {
        this.value = this.value.replace(/\./g, '');
        v = this.value;
    } else {
        v = v.replace(/\./g, '');
        this.value = v;
    }
    var r = this.r,
        m = this.m,
        s = this.s,
        vr = trim(v.substr(6, 2)),
        vm = trim(v.substr(4, 2)),
        vs = trim(v.substr(0, 4));
    if (r.value != vr) {
        if (vr == '00') vr = '';
        r.value = vr;
    }
    if (m.value != vm) {
        if (vm == '00') vm = '';
        m.value = vm;
    }
    if (s.value != vs) {
        if (vs == '0000') vs = '';
        s.value = vs;
    }
    if (trim(this.value) == '0000') this.value = '';
    /*this.log.innerHTML+=' cal SetVal:<br>';
    this.log.innerHTML+=' &nbsp;&nbsp;this.value:' + this.value;
    this.log.innerHTML+=' <br>&nbsp;&nbsp;v:'+v;
    */
    //setTimeout(function() { if (r.value != vr) r.value = vr; if (m.value != vm) m.value = vm; if (s.value != vs) s.value = vs; }, 100);
}
np_cal.prototype.GetVal = function(v) {
    return (v.replace(/\./g, '').replace(/\//g, ''));
}
np_cal.prototype.Syncsmr2par = function() {
    //alert(this.value);
    this.value = lpad(this.s.value, ' ', 4) + lpad(this.m.value, '0', 2) + lpad(this.r.value, '0', 2);
    if (this.value == '    0000') this.value = '';
}
np_cal.prototype.FixNumber = function() {
    this.Syncsmr2par();
    return (this.value);
}
np_cal.prototype.Disable = function(bool) {
    var tf = true;
    if (typeof(bool) != 'undefined')
        tf = bool;
    this.disabled = tf;
    this.r.disabled = tf;
    this.m.disabled = tf;
    this.s.disabled = tf;
    this.p1.style.color = (tf) ? 'gray' : 'black';
    this.p2.style.color = (tf) ? 'gray' : 'black';
    try {
        elementHelp2 = this.doc.getElementById('H' + this.HELP);
        if (tf)
            elementHelp2.disable_Butt();
        else
            elementHelp2.enable_Butt();
    } catch (e) {}
}
np_cal.prototype.UpdateSndData = function(v) {

    this.SetVal(v);
    XmlSnd.documentElement.setAttribute(this.id, trim(this.value));
    if (!window.ActiveXObject)
        XmlSnd.xml = new XMLSerializer().serializeToString(XmlSnd.documentElement);

    /*this.log.innerHTML+=' cal UpdateSndData:<br>';
    this.log.innerHTML+=' &nbsp;&nbsp;&nbsp;this.id:'+this.id+'<br>';
    this.log.innerHTML+=' &nbsp;&nbsp;&nbsp;this.value:'+this.value+'<br>';
    */
}
np_cal.prototype.SetFocus = function() {
    try {
        this.r.focus();
    } catch (e) {
        return -1
    }
    return 1;
}
np_cal.prototype.focus = function() {
    return this.SetFocus();
}
np_cal.prototype.CheckVal = function() {
    var $ = $ ? $ : top.$;
    this.UpdateSndData();
    var v = trim(this.value);
    if (!window.ActiveXObject) {
        this.Nul = $(this).attr("nul");
        this.Cap = $(this).attr("cap");
    }
    if (this.Nul == '0' && (v == '0000' || v.length == 0)) {
        alert(this.Cap + ' نمي تواند خالي باشد ');
        this.SetFocus();
        return -1;
    }
    if (v.length == 0) return 1;
    if (v != '0000') {
        this.r.value = trim(this.value.substr(6, 2));
        this.m.value = trim(this.value.substr(4, 2));
        this.s.value = trim(this.value.substr(0, 4));
    }
    if (this.r.valid.CheckVal() < 0 || this.m.valid.CheckVal() < 0 || this.s.valid.CheckVal() < 0) {
        return -1;
    }
    if (v != '0000' && v.length < 8) {
        alert('تاريخ وارد شده در "' + this.Cap + '" صحيح نمي باشد ');
        this.SetFocus();
        return -1;
    }
    if (parseInt(this.m.value, 10) > 6 && parseInt(this.r.value, 10) > 30) {
        alert('تاريخ وارد شده در "' + this.Cap + '" صحيح نمي باشد ');
        this.SetFocus();
        return -1;
    }
    return 1;
}
np_cal.prototype.change = function(event) {
    //this.UpdateSndData();
    var event = event || window.event;
    if (this.CheckVal() < 0) {
        this.isvalid = false;
        event.returnValue = false;
        return;
    } else {
        this.isvalid = true;
    }
}
np_cal.prototype.FocusNext = function(NoAct) {
    this.showDatePicker(false);
    this.valid.s.FocusNext(NoAct);
}
np_cal.prototype.select = function() {
    this.r.select();
}
np_cal.prototype.F_ocusNext = function(NoAct) {
    var Nex = window.document.all.item(this.Nex);
    while (typeof(Nex) != "undefined" && Nex != null && Nex.id != '') {
        try {
            if (Nex.tagName == 'FONT' || Nex.tagName == 'LABEL' || Nex.tagName == 'SPAN') {
                try {
                    if (Nex.Nex == Nex.id) return;
                    Nex = window.document.all.item(Nex.Nex);
                } catch (e) {
                    return;
                }
            } else {
                if (Nex.disabled) {
                    Nex = window.document.all.item(Nex.Nex);
                    return;
                }
                var c = 0,
                    AllNex = [],
                    IsLoop = false;
                while (!isVisible(Nex) && !IsLoop) {

                    for (var i = 0; i < AllNex.length; i++) {
                        if (AllNex[i] == Nex.id) {
                            IsLoop = true;
                            return;
                        }
                    }
                    AllNex[c] = Nex.id;
                    var ne = window.document.all.item(Nex.Nex);
                    if (!ne) ne = eval(Nex.Nex);
                    Nex = ne;
                    c++;

                }
                if (IsLoop)
                    return;
                Nex.focus();
                if (Nex.tagName == 'IMG') {
                    try {
                        Nex.click();
                    } catch (e) {}
                }
                if (Nex.tagName == 'INPUT') {
                    if (Nex.type == 'image')
                        Nex.click();
                    else
                        Nex.select();
                }
                return;
            }
        } catch (e) {
            try {
                if (ver == 3) {
                    if (Nex.RFld) {
                        Nex.RFld[0].focus();
                    } else {
                        z = Nex.HFld;
                        z.focus();
                        z.style.backgroundColor = "#0000FF";
                        setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                    }
                } else {
                    d = window.document.all;
                    d.item('H' + Nex.id).focus();
                    z = d.item('H' + Nex.id).style;
                    z.backgroundColor = "#0000FF";
                    setTimeout('try{window.document.all.item("H' + Nex.id + '").style.backgroundColor="";}catch(e){}', 800);
                }
                return;
            } catch (e) {
                try {
                    if (Nex.Nex == Nex.id) break;
                    Nex = window.document.all.item(Nex.Nex);
                } catch (e) {
                    return;
                }
            }
        }
    }
    if (NoAct) return;
    var NextAct = parent.parent.Commander.NextAct;
    if (NextAct == '01') {
        if (window.document.body.LastEnterAct) {
            NextAct = window.document.body.LastEnterAct;
        }
    }
    parent.parent.Commander.act_data_frm(NextAct);
}
np_cal.prototype.displayDatePicker = function(dateFieldName, displayBelowThisObject) {
    if (this.disabled)
        return;
    var x = this.d.offsetLeft;
    var y = this.d.offsetTop + this.d.offsetHeight;

    var parent = this.d;
    while (parent.offsetParent) {
        //alert(x);
        parent = parent.offsetParent;
        //parent.style.border="2px solid red";
        //alert(parent.tagName);
        //alert(parent.offsetLeft);
        x += parent.offsetLeft;
        y += parent.offsetTop;
    }

    this.drawDatePicker(x, y);
}
np_cal.prototype.drawDatePicker = function(x, y) {
    var dt = getFieldDate(this.value);

    var d = this.calDiv;
    d.style.position = "absolute";
    //alert(document.body.clientWidth);
    //alert(this.d.offsetWidth);
    //alert(x);
    var cWidth = top.SupportOldGolestan ? window.innerWidth : document.body.clientWidth;
    d.style.right = (cWidth - this.d.offsetWidth - x - 1) + "px";
    d.style.top = y + "px";
    d.style.display = (d.style.display == "" ? "none" : "");
    d.style.zIndex = 10000;
    d.targetTop = y - this.d.offsetHeight;
    this.refreshDatePicker(dt[0], dt[1], dt[2]);
}
np_cal.prototype.showDatePicker = function(tf) {
    var i = this.ifr,
        d = this.calDiv;
    d.style.display = (!tf) ? "none" : "";
    i.style.display = d.style.display;
}

np_cal.prototype.refreshDatePicker = function(year, month, day) {
    var $ = $ ? $ : top.$;
    if (window.ActiveXObject)
        var th = 'var th=' + this.calDiv.uniqueID + '.par;';
    var thisDay = getTodayPersian();
    var weekday = (thisDay[3] - (thisDay[2] % 7) + 8) % 7;
    if (!day)
        day = null;
    if ((month >= 1) && (year > 0)) {
        thisDay = calcPersian(year, month, 1);
        weekday = thisDay[3];
        thisDay = new Array(year, month, day, weekday);
        thisDay[2] = 1;
    } else {
        day = thisDay[2];
        thisDay[2] = 1;
    }

    var crlf = "\r\n",
        xTABLE = "</table>" + crlf,
        TR = "<tr>",
        xTR = "</tr>" + crlf,
        TD = "<td class='calb' onMouseOut='this.className=\"calb\";' onMouseOver=' this.className=\"calTDHover\";' " // leave this tag open, because we'll be adding an onClick event

        ,
        TD_selected = "<td class='calHighlightTD' onMouseOut='this.className=\"calHighlightTD\";' onMouseOver='this.className=\"calTDHover\";' " // leave this tag open, because we'll be adding an onClick event
        ,
        xTD = "</td>" + crlf,
        DIV_selected = "<div class='calDayHighlight'>",
        xDIV = "</div>"

        ,
        Month_Tit = this.monthArrayLong[thisDay[1] - 1] + " " + thisDay[0],
        bl = '<td class="calb">&nbsp;</td>';
    if (window.ActiveXObject) {
        var Table_Tit = '<TABLE class="caltittab" ><col width="12px" align="center"/><col width="20px" align="center"/><col width="124px" align="center"/><col width="20px" align="center" /><tr><td class="caltittd" style="cursor:hand;font-size:11px;font-family:arial" align="center" onclick="' + th + ' th.displayDatePicker();">x</td><td class="caltittd">' + this.getButtonCode(thisDay, -1, "&lt;") + '</td><td class="caltittd">' + Month_Tit + '</td><td class="caltittd">' + this.getButtonCode(thisDay, 1, "&gt;") + '</td></tr></table>',
            html = Table_Tit;
    } else {
        var Table_Tit = '<TABLE class="caltittab" ><col width="12px" align="center"/><col width="20px" align="center"/><col width="124px" align="center"/><col width="20px" align="center" /><tr><td class="caltittd" style="cursor:hand;font-size:11px;font-family:arial" align="center" onclick="$(this).parent().parent().parent().parent()[0].par.displayDatePicker();">x</td><td class="caltittd">' + this.getButtonCode(thisDay, -1, "&lt;") + '</td><td class="caltittd">' + Month_Tit + '</td><td class="caltittd">' + this.getButtonCode(thisDay, 1, "&gt;") + '</td></tr></table>',
            html = Table_Tit;
    }
    html += '<table class="caldt">' + TR;
    for (var i = 0; i < this.dayArrayShort.length; i++)
        html += '<td align="center">' + this.dayArrayShort[i] + xTD;
    html += xTR + '</table>';

    html += '<div style="height:105px;width:179px;"><table style="table-layout:fixed;width:100%">' + TR;

    var len = 31;
    if (thisDay[1] > 6)
        len = 30;
    if (thisDay[1] == 12 && !leap_persian(thisDay[0]))
        len = 29;

    if (weekday != 6)
        for (i = 0; i <= weekday; i++)
            html += bl;


    for (var dayNum = thisDay[2]; dayNum <= len; dayNum++) {
        if (window.ActiveXObject)
            TD_onclick = " onclick=\"" + th + " th.updateDateField('" + getDateString(thisDay) + "');\">";
        else
            TD_onclick = " onclick=\"$(this).closest('div.calDiv')[0].par.updateDateField('" + getDateString(thisDay) + "');\">";
        if (dayNum == day)
            html += TD_selected + TD_onclick + DIV_selected + dayNum + xDIV + xTD;
        else
            html += TD + TD_onclick + dayNum + xTD;

        // if this is a Friday, start a new row
        if (weekday == 5)
            html += xTR + TR;
        weekday++;
        weekday = weekday % 7;

        // increment the day
        thisDay[2]++;
    }

    // fill in any trailing blanks
    //if (weekday > 0) {
    for (i = 6; i > weekday; i--)
        html += bl;
    //}
    html += xTR + '</table></div>';

    var today = new Date()
    if (window.ActiveXObject)
        html += "<div align='center'><button class='calTodayButton' onClick='" + th + " th.refreshDatePicker();'>&nbsp;&nbsp;&#1575;&#1605;&#1585;&#1608;&#1586;&nbsp;&nbsp;</button></div> ";
    else
        html += "<div align='center'><button class='calTodayButton' onClick='$(this).parent().parent()[0].par.refreshDatePicker();'>&nbsp;&nbsp;&#1575;&#1605;&#1585;&#1608;&#1586;&nbsp;&nbsp;</button></div> ";


    //html += "<button class='calTodayButton' onClick='updateDateField(\"" + dateFieldName + "\");'>&#1576;&#1587;&#1578;&#1606;</button>";
    //html += xTD + xTR;

    //html += xTABLE;
    this.calDiv.innerHTML = html;
    this.adjustiFrame();
}
np_cal.prototype.getButtonCode = function(dateVal, adjust, label) {
    var $ = $ ? $ : top.$;
    if (window.ActiveXObject)
        var th = 'var th=' + this.calDiv.uniqueID + '.par;';

    var newMonth = (dateVal[1] + adjust) % 12;
    var newYear = dateVal[0] + parseInt((dateVal[1] + adjust) / 12);
    if (newMonth < 1) {
        newMonth += 12;
        newYear += -1;
    }
    if (window.ActiveXObject)
        return "<button class='calButton' onClick='" + th + "th.refreshDatePicker(" + newYear + ", " + newMonth + ");'>" + label + "</button>";
    else {
        return "<button class='calButton' onClick='$(this).parent().parent().parent().parent().parent()[0].par.refreshDatePicker(" + newYear + ", " + newMonth + ");'>" + label + "</button>";
    }

}

np_cal.prototype.updateDateField = function(dateString) {
    if (top.SupportOldGolestan)
        return;
    if (dateString && !this.disabled)
        this.UpdateSndData(dateString);
    var d = this.calDiv;
    d.style.display = "none";

    this.adjustiFrame();
    this.SetFocus();

}
np_cal.prototype.adjustiFrame = function() {
    try {
        var $ = $ ? $ : top.$;
        var i = this.ifr,
            d = this.calDiv;
        i.style.position = "absolute";
        i.style.width = d.offsetWidth;
        i.style.height = d.offsetHeight;
        i.style.top = d.style.top;
        i.style.right = d.style.right;

        //alert(i.style.right);

        i.style.zIndex = d.style.zIndex - 1;
        i.style.display = d.style.display;
        if (d.offsetLeft < 0) {
            d.style.left = 0;
            i.style.left = d.style.left;
            d.style.right = '';
            i.style.right = d.style.right;
        }
        var cHeight = top.SupportOldGolestan ? window.innerHeight : document.body.clientHeight;
        if (window.ActiveXObject)
            var BodyH = cHeight + parseInt(document.body.topMargin, 10) + parseInt(document.body.bottomMargin, 10);
        else
            var BodyH = cHeight + parseInt($(document.body).attr("topMargin"), 10) + parseInt($(document.body).attr("bottomMargin"), 10);
        if (BodyH < (i.offsetTop + i.offsetHeight)) {
            var t = d.targetTop - i.offsetHeight;
            if (t < document.body.scrollTop) t = document.body.scrollTop;
            i.style.top = t;
            d.style.top = t;
        }
    } catch (e) {}
}
np_cal.prototype.show = function(tf) {
    this.d.style.display = (tf) ? '' : 'none';
}
np_cal.prototype.dispose = function() {
    this.r.onblur = null;
    this.r.onkeypress = null;
    this.r.onkeyup = null;

    this.m.onblur = null;
    this.m.onkeypress = null;
    this.m.onkeyup = null;

    this.s.onblur = null;
    this.s.onkeypress = null;
    this.s.onkeyup = null;

    this.r.UpdateSndData = null;
    this.m.UpdateSndData = null;
    this.s.UpdateSndData = null;

    this.d.onfocus = null;
    this.d.onclick = null;
}

function copyStyle(base, targ) { //cal
    var baseStyle = base.currentStyle || base.style;
    var targStyle = targ.style;

    for (var prop in baseStyle) {
        var str = "targStyle." + prop + " = baseStyle." + prop + ";";

        try {
            eval(str);
        } catch (e) {
            // Do nothing
        }
    }
    if (!window.ActiveXObject) {
        //targStyle.width="auto";
        targStyle.border = "1px solid #879eac";
    }
}

function copyStyle2(base, targ) { //bdo
    var baseStyle = base.currentStyle || base.style;
    var targStyle = targ.style;

    for (var prop in baseStyle) {
        var str = "targStyle." + prop + " = baseStyle." + prop + ";";

        try {
            eval(str);
        } catch (e) {
            // Do nothing
        }
    }
    if (!window.ActiveXObject) {
        targStyle.border = "1px solid #879eac";
        targStyle.backgroundColor = "#fff";
        targStyle.display = "flex";
        targStyle.paddingTop = "5px";
    }
}

function lpad(str, padString, length) {
    while (str.length < length)
        str = padString + str;
    return str;
}

function trim(s) {
    try {
        return s.replace(/^\s+|\s+$/g, "");
    } catch (e) {
        return ''
    };
}


function npobj_win(bod, disponclose) {
    var doc;
    if (typeof(bod.tagName) == 'undefined') {
        doc = bod;
        bod = doc.body;
    } else {
        doc = document;
    }
    var cont = doc.createElement('DIV'),
        titcont = doc.createElement('DIV'),
        tit = doc.createElement('DIV'),
        wbod = doc.createElement('DIV'),
        ifr = doc.createElement('IFRAME'),
        ic = doc.createElement('INPUT');
    ifr.src = '/blank.htm';
    cont.style.display = 'none';
    cont.style.position = 'absolute';
    ifr.style.display = 'none';
    ifr.frameBorder = '0';
    ifr.style.position = 'absolute';
    wbod.style.overflow = 'scroll';

    //if(!top.SupportOldGolestan){
    cont.style.width = 'auto';
    cont.style.height = 'auto';
    cont.style.background = '#fff';
    /* }
     else{
        cont.style.width = 100;
        cont.style.height = 100;
     }*/
    ifr.style.width = 100;
    ifr.style.height = 100;


    titcont.style.background = '#0000DD';

    tit.className = 'npwin_tit';

    ic.className = 'Comm';
    ic.style.styleFloat = 'right';
    ic.style.marginTop = 2;
    ic.style.marginRight = 2;
    ic.type = 'image';
    ic.src = '/_Images/CloseAll.gif';
    ic.par = this;
    ic.onclick = function() {
        this.par.show(false);
        if (this.par.disclose) this.par.dispose();
    };

    titcont.appendChild(ic);
    titcont.appendChild(tit);
    cont.appendChild(titcont);
    cont.appendChild(wbod);

    bod.appendChild(ifr);
    bod.appendChild(cont);

    cont.style.border = '1px black solid';
    this.doc = doc;
    this.bod = bod;
    this.ifr = ifr;
    this.cont = cont;
    this.titcont = titcont;
    this.tit = tit;
    this.wbod = wbod;
    this.ic = ic;
    this.width = 0;
    this.height = 0;
    this.cuswidth = 0;
    this.cusheight = 0;
    this.disclose = (typeof(disponclose) == 'undefined') ? false : disponclose;
}
npobj_win.prototype.show = function(tf) {
    var d = this.cont,
        ifr = this.ifr,
        titcont = this.titcont;
    if (tf) {
        var bod = this.bod,
            cWidth = top.SupportOldGolestan ? bod.parentNode.parentNode.parentWindow.innerWidth : bod.clientWidth,
            cHeight = top.SupportOldGolestan ? bod.parentNode.parentNode.parentWindow.innerHeight : bod.clientHeight,

            bh = cHeight * 0.9,
            bw = cWidth * 0.9,
            wbod = this.wbod,
            hscr = false;
        wbod.style.overflow = 'auto';
        ifr.style.display = '';
        d.style.display = '';

        var tw = this.cuswidth,
            th = this.cusheight,
            w = -1,
            h = -1;
        if (th != 0) h = th;
        if (tw != 0) w = tw;

        if (d.scrollWidth > bw && w < 0) {
            w = bw;
            hscr = true;
        }

        if (w > 0) wbod.style.width = w;
        else w = d.scrollWidth;
        //debugger;
        if (d.scrollHeight > bh && h < 0) {
            h = bh;
            hscr = true;
        }
        if (h < 0) h = d.scrollHeight;
        wbod.style.height = h - titcont.offsetHeight;
        //alert(d.offsetHeight);
        //alert(d.clientHeight);
        this.hscr = hscr;
        var t = bod.scrollTop + (cHeight - h) / 2,
            r = (cWidth - w) / 2;

        d.style.top = t;
        d.style.right = r;
        ifr.style.top = t;
        ifr.style.right = r + d.clientLeft;

        //ifr.style.top = 0;
        //ifr.style.right = 0;

        titcont.style.width = w;
        if (w > (this.ic.offsetWidth - 10)) this.tit.style.width = w - this.ic.offsetWidth - 10;

        ifr.style.width = w;
        //alert(h);
        ifr.style.height = h;
    } else {
        this.ifr.style.display = 'none';
        this.cont.style.display = 'none';
        try {
            this.onhide();
        } catch (e) {}
    }
};

npobj_win.prototype.setTit = function(tit) {
    this.tit.innerHTML = tit;
};
npobj_win.prototype.setWidth = function(w) {
    this.cuswidth = w;
};
npobj_win.prototype.setHeight = function(h) {
    this.cusheight = h;
};
npobj_win.prototype.appendChild = function(ch) {
    this.wbod.appendChild(ch);
};
npobj_win.prototype.fitSize = function() {
    var d = this.cont,
        bod = this.bod,
        cWidth = top.SupportOldGolestan ? bod.parentNode.parentNode.parentWindow.innerWidth : bod.clientWidth,
        cHeight = top.SupportOldGolestan ? bod.parentNode.parentNode.parentWindow.innerHeight : bod.clientHeight,
        bh = cHeight * 0.9,
        bw = cWidth * 0.9;

    var w = d.offsetWidth + 100,
        h = d.offsetHeight + 80;
    w = (w < 500) ? 500 : ((w > bw) ? bw : w);
    //h=(h<170)?170:((h>bh)?bh:h);
    this.cuswidth = w;
    //this.height=h;
};
npobj_win.prototype.dispose = function() {
    try {
        this.ondispose();
    } catch (e) {}
    this.ic.onclick = null;
    this.ondispose = null;
    this.onhide = null;
    this.bod.removeChild(this.ifr);
    this.bod.removeChild(this.cont);
    this.disposed = true;
};

function npobj_dlg(doc, typ) {
    var w = new npobj_win(doc, true),
        t = doc.createElement('DIV'),
        imb = doc.createElement('DIV');
    var im = new Array();
    this.im = im;
    this.imb = imb;
    imb.style.width = '100%';
    imb.style.padding = '10px';
    imb.align = 'center';
    if (!typ || typ == 0) {
        im[0] = doc.createElement('button');
        //im[0].type='image';
        im[0].style.border = 0;
        im[0].style.background = 0;
        im[0].style.width = 60;
        im[0].style.height = 30;
        im[0].innerHTML = "<img src='/_images/ok.gif' />";
        //im[0].className='comm';
        im[0].onclick = function() {
            this.par.dispose();
        }
        im[0].par = this;
        imb.appendChild(im[0]);
    }

    w.appendChild(t);
    w.appendChild(imb);

    this.w = w;
    this.t = t;

}
npobj_dlg.prototype.append = function(text) {
    this.t.innerHTML += text;
}
npobj_dlg.prototype.dispose = function() {
    for (var i = 0; i < this.im.length; i++) {
        this.im[i].onclick = null;
    }
    this.w.dispose();
    this.disposed = true;
};
np_editor = function(obj) {
    var th = this;
    var $ = $ ? $ : top.$;
    th.tagName = 'npobj_editor';
    th.id = obj.id.replace('ed_', '');
    th.Def = obj.Def || $(obj).attr("def");
    th.Lan = obj.Lan || $(obj).attr("lan");

    th.ta = obj;
    th.value = '';
    if ($("#" + obj.id).length > 0)
        var c = $("#" + obj.id).cleditor({
            docCSSFile: "/_styles/Forms.css",
            width: $(obj).width(),
            height: $(obj).height()
        });
    else {
        var c = jQuery("#" + obj.id).cleditor({
            docCSSFile: "/_styles/Forms.css",
            width: $(obj).width(),
            height: $(obj).height()
        });
    }
    th.cle = c;
    c.change(function() {
        if (window.ActiveXObject)
            th.UpdateSndData($(th.ta).text());
        else
            th.UpdateSndData(th.ta.value);

    });
};
np_editor.prototype.SetVal = function(v) {
    if (typeof(v) == 'undefined') {
        v = this.value;
    } else {
        this.value = v;
    }

    this.ta.innerText = v;
    this.ta.value = v;
    this.cle[0].updateFrame(this.cle);
};
np_editor.prototype.GetVal = function(v) {
    if (typeof(v) != 'undefined') {
        this.ta.value = v;
        this.ta.innerText = v;
        this.cle[0].updateFrame(this.cle);
    }
    return this.ta.innerText;
};
np_editor.prototype.FixNumber = function() {
    return (this.ta.innerText);
};
np_editor.prototype.Disable = function(bool) {
    if (typeof(bool) == 'undefined') bool = true;
    this.cle[0].disable(bool);
};
np_editor.prototype.UpdateSndData = function(v) {
    if (typeof(v) == 'undefined') {
        v = this.value;
    } else {
        this.value = v;
    }
    this.ta.innerText = v;
    if (window.ActiveXObject)
        XmlSnd.documentElement.setAttribute(this.id) = this.value;
    else {
        XmlSnd.documentElement.setAttribute(this.id, this.value);
        XmlSnd.xml = new XMLSerializer().serializeToString(XmlSnd.documentElement);

    }


};
np_editor.prototype.SetFocus = function() {
    this.cle[0].focus();
    return 1;
};
np_editor.prototype.focus = function() {
    return this.SetFocus();
};
np_editor.prototype.CheckVal = function() {
    return 1;
};
np_editor.prototype.change = function(event) {
    //this.UpdateSndData();
    var event = event || window.event;
    if (this.CheckVal() < 0) {
        this.isvalid = false;
        event.returnValue = false;
        return;
    } else {
        this.isvalid = true;
    }
};
np_editor.prototype.FocusNext = function(NoAct) {};
np_editor.prototype.select = function() {};
np_editor.prototype.dispose = function() {
    return;
};