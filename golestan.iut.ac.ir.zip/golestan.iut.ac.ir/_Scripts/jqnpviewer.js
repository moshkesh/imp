(function(d) {
    d.widget("np.npviewerLastSystem", {
        options: {
            url: null,
            autoOpen: !0,
            type: "img",
            src: null,
            ftck: null,
            docid: null,
            doctck: null,
            pgno: 1,
            hasconf: !1,
            conftext: "",
            conficon: "circle-plus",
            onconf: null,
            html: "<div />"
        },
        _$nex: null,
        _$prv: null,
        _justopen: !0,
        _pagecnt: -1,
        _rotatedeg: 0,
        _create: function() {
            var b = this.options;
            this.element.attr("id", "o" + Math.random());
            this.prv_button_disabled = this.nex_button_disabled = !1;
            "1" == b.pgno && (this.prv_button_disabled = !0);
            this.MakeUrl();
            this.SetType();
            var a = b.pgno ? b.pgno : 1;
            b.autoOpen &&
                (this.init(), this._showpage(a))
        },
        SetType: function() {
            var b = this.options;
            switch (b.type) {
                case "image/gif":
                case "image/pjpeg":
                case "image/x-png":
                case ".gif":
                case ".jpg":
                case "img":
                    b.type = "img";
                    break;
                case "application/pdf":
                case ".pdf":
                case "pdf":
                    b.type = "pdf";
                    break;
                case "":
                    b.type = "img";
                    break;
                default:
                    b.type = "othr"
            }
        },
        MakeUrl: function() {
            var b = this.options;
            b.url || (b.url = "/_Templates/ShowPic/ShowPic.aspx");
            u = b.url;
            u += (b.t ? "?t=" + b.t : "") + (b.docid ? "&pgno=" + b.pgno : "") + (b.docid ? "&docid=" + b.docid : "") + (b.src ? "&src=" +
                b.src : "") + (b.ftck ? "&ftck=" + b.ftck : "") + (b.doctck ? "&doctck=" + b.doctck : "");
            u += "&ttt" + parseInt(1E6 * Math.random()) + "=" + Math.random();
            b.docid && this._justopen && (u = u + "&r=" + Math.random());
            b.url = u
        },
        init: function(b) {
            var a = this,
                c = a.element,
                h = a.options;
            a.bodyscrolltop = document.body.scrollTop;
            var g = d("body").attr("scroll");
            d("body").attr("scroll", "no");
            b = 0 < parseInt(d("body").height() - 30) ? parseInt(d("body").height() - 30) : 700;
            var e = 0 < parseInt(d("body").width() - 20) ? parseInt(d("body").width() - 20) : 1400;
            c.dialog({
                title: "",
                width: e,
                height: b,
                zIndex: 1E8,
                beforeClose: function(a, b) {
                    d("body").attr("scroll", g)
                },
                close: function() {
                    a.$Ifr.attr("src", "");
                    c.dialog("destroy");
                    d(c).empty()
                },
                modal: !0
            });
            b = a.$Ifr = d('<IFRAME frameborder="0" />').appendTo(c).width(c.width());
            e = a.$bar = d("<div/>").appendTo(c);
            a._imglod = d("<img />").attr("src", "/_Images/WebBusy.gif").appendTo(e);
            a.ImageButton = d('<span id="ImageButton" />').hide().appendTo(e);
            var f = d("<button/>").text("\u0628\u0632\u0631\u06af \u0646\u0645\u0627\u064a\u064a").button({
                    icons: {
                        secondary: "ui-icon-zoomin"
                    }
                }).appendTo(a.ImageButton),
                k = d("<button/>").text("\u06a9\u0648\u0686\u06a9 \u0646\u0645\u0627\u064a\u064a").button({
                    icons: {
                        secondary: "ui-icon-zoomout"
                    }
                }).appendTo(a.ImageButton),
                l = d("<button/>").text("1:1").button({
                    icons: {
                        secondary: "ui-icon-arrow-4-diag"
                    },
                    classes: {
                        "font-size": "20pt"
                    }
                }).appendTo(a.ImageButton),
                m = d("<button/>").text("\u0646\u0645\u0627\u064a \u06a9\u0644\u064a").button({
                    icons: {
                        secondary: "ui-icon-image"
                    }
                }).appendTo(a.ImageButton),
                n = d("<button/>").text("\u0686\u0631\u062e\u0634").button({
                    icons: {
                        secondary: "ui-icon-arrowreturnthick-1-s"
                    }
                }).appendTo(a.ImageButton);
            d(a.ImageButton).hide();
            a._$nex = d("<button/>").text("\u0635\u0641\u062d\u0647 \u0628\u0639\u062f").button({
                disabled: a.nex_button_disabled,
                icons: {
                    secondary: "ui-icon-triangle-1-s"
                }
            }).appendTo(e).hide();
            a._$prv = d("<button/>").text("\u0635\u0641\u062d\u0647 \u0642\u0628\u0644").button({
                disabled: a.prv_button_disabled,
                icons: {
                    secondary: "ui-icon-triangle-1-n"
                }
            }).appendTo(e).hide();
            f.click(function() {
                a._zoom("+")
            });
            k.click(function() {
                a._zoom("-")
            });
            l.click(function() {
                a._zoom("nozoom")
            });
            m.click(function() {
                a._zoom("zoomfit")
            });
            n.click(function() {
                a._rotate(270)
            });
            a._$nex.click(function() {
                a._nextpage();
                a._$prv.button("option", "disabled", !1);
                h.pgno == a._pagecnt && a._$nex.button("option", "disabled", !0)
            });
            a._$prv.click(function() {
                a._prvpage();
                a._$nex.button("option", "disabled", !1);
                1 == h.pgno && a._$prv.button("option", "disabled", !0)
            });
            h.hasconf && d("<button/>").text(h.conftext).button({
                icons: {
                    secondary: "ui-icon-" + h.conficon
                }
            }).appendTo(a.$bar).click(function() {
                a._trigger("onconf");
                h.inwin && c.dialog("close")
            });
            a.IfrLoadDone = !1;
            b.bind("readystatechange",
                function() {
                    "complete" != this.readyState && "interactive" != this.readyState || a.IfrLoadDone || (a.IfrLoadDone = !0, a.AfterLoad(), a._imglod.css("visibility", "hidden"), a._$prv && (a.prv_button_disabled = a._$prv.button("option", "disabled")), a._$nex && (a.nex_button_disabled = a._$nex.button("option", "disabled")))
                });
            b.load(function() {
                a.IfrLoadDone || (a.IfrLoadDone = !0, a.AfterLoad(), a._imglod.css("visibility", "hidden"), a._$prv && (a.prv_button_disabled = a._$prv.button("option", "disabled")), a._$nex && (a.nex_button_disabled = a._$nex.button("option",
                    "disabled")))
            })
        },
        AfterLoad: function() {
            var b = this.element,
                a = this.options,
                c = this.$Ifr,
                h, g = this.$bar;
            c.show();
            c.siblings("img").remove();
            d(this.ImageButton).hide();
            if (0 > this._pagecnt)
                for (var e = document.cookie.split("; "), f = 0, k = e.length; f < k; f++) {
                    var l = e[f].split("=");
                    "picdata" == l[0] && (this._pagecnt = l[1])
                }
            1 == this._pagecnt && (this._$nex.button("option", "disabled", !0), this._$prv.button("option", "disabled", !0));
            this._pagecnt == a.pgno && this._$nex && this._$nex.button("option", "disabled", !0);
            try {
                if (h = c.contents()[0].contentType, !h) try {
                    if (0 < c.contents().find("img").length && 1 == d("*", c.contents().find("body")).length) {
                        var m = c.contents().find("img");
                        h = "img";
                        0 == d(".npIframeNewParent", b).length && c.wrap("<div class='npIframeNewParent' dir='rtl' style='positio_n:absolute;overflow:hidden;float:right'></div>");
                        d(".npIframeNewParent", b).find("img").remove();
                        d(".npIframeNewParent", b).css("width", c.width()).css("height", c.height()).append(m);
                        m.draggable();
                        c.hide()
                    } else h = "othr"
                } catch (n) {
                    h = "othr"
                }
            } catch (p) {
                h = "othr"
            }
            switch (h) {
                case "image/gif":
                case "image/pjpeg":
                case "image/x-png":
                case ".gif":
                case ".jpg":
                case "img":
                    a.type =
                        "img";
                    break;
                case "application/pdf":
                case ".pdf":
                case "pdf":
                    a.type = "pdf";
                    break;
                default:
                    a.type = "othr"
            }
            this.ShowExtra(g, c);
            document.body.scrollTop = this.bodyscrolltop
        },
        ShowExtra: function(b, a) {
            var c = this,
                h = c.element,
                g = c.options;
            switch (g.type) {
                case "img":
                    a.contents().find("body").css("overflow", "hidden");
                    d(c.ImageButton).show();
                    var e = 0 < c.$Ifr.contents().find("img").length ? c._img = c.$Ifr.contents().find("img").css("cursor", "move") : c._img = c.$Ifr.siblings("img").css("cursor", "move"),
                        f = c._imgdiv = a;
                    c._imgrealwidth =
                        e.width();
                    c._imgrealheight = e.height();
                    e.dblclick(function() {
                        var a = c._img;
                        a.width() > f.width() || a.height() > f.height() ? c._zoom("zoomfit") : c._zoom("nozoom")
                    })
            }
            g.docid && (d(c._$nex).show(), d(c._$prv).show());
            a.height(h.height() - c.$bar.height());
            d(".npIframeNewParent", h).css("height", a.height());
            "img" === g.type && c._zoom("zoomfit")
        },
        hide: function() {
            this.element.hide()
        },
        _zoom: function(b) {
            var a = this._imgdiv,
                c = a.width();
            if (0 < this.$Ifr.contents().find("img").length && this.$Ifr.contents().find("img").is(":visible")) var d =
                this.$Ifr.contents().find("img");
            else 0 < this.$Ifr.siblings("img").length && (d = this.$Ifr.siblings("img"));
            if (d) {
                var g = d.width(),
                    e = a.height(),
                    f = d.height(),
                    k;
                if (90 == this._rotatedeg || 270 == this._rotatedeg) a = c, c = e, e = a, a = g, g = f, f = a;
                switch (b) {
                    case "nozoom":
                        k = 1;
                        d.css("left", 0);
                        d.css("top", 0);
                        break;
                    case "zoomfit":
                        k = c / g > e / f ? e / f : c / g;
                        d.css("left", 0);
                        d.css("top", 0);
                        break;
                    case "+":
                        k = 1.1;
                        break;
                    case "-":
                        k = .9
                }
                1 == k ? (g = this._imgrealwidth, f = this._imgrealheight) : (g *= k, f *= k);
                d.effect("size", {
                    to: {
                        width: g,
                        height: f
                    }
                }, 200, function() {
                    d.attr("width",
                        g);
                    d.attr("height", f);
                    g <= c && f <= e ? d.css("cursor", "default") : d.css({
                        cursor: "move",
                        right: "auto"
                    })
                })
            }
        },
        _rotate: function(b) {
            if (0 < this.$Ifr.contents().find("img").length && this.$Ifr.contents().find("img").is(":visible")) var a = this.$Ifr.contents().find("img");
            else 0 < this.$Ifr.siblings("img").length && (a = this.$Ifr.siblings("img"));
            a && (b += this._rotatedeg, 360 < b && (b -= 360), this._rotatedeg = b, a.hide("fade", function() {
                a.css({
                    "-webkit-transform": "rotate(" + b + "deg)",
                    "-moz-transform": "rotate(" + b + "deg)",
                    "-ms-transform": "rotate(" +
                        b + "deg)",
                    "-o-transform": "rotate(" + b + "deg)",
                    transform: "rotate(" + b + "deg)",
                    filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=" + b / 90 + ")",
                    zoom: 1
                });
                a.show("fade");
                a.css({
                    top: 0
                });
                a.css("cursor", "move")
            }))
        },
        _showpage: function(b) {
            var a = this.options,
                c = a.url,
                c = c.replace("pgno=" + a.pgno, "pgno=" + b);
            a.url = c;
            a.pgno = b;
            this._imglod.css("visibility", "");
            this.IfrLoadDone = !1;
            this.$Ifr.attr("src", c)
        },
        _nextpage: function() {
            this._showpage(parseInt(this.options.pgno, 10) + 1)
        },
        _prvpage: function() {
            this._showpage(parseInt(this.options.pgno,
                10) - 1)
        },
        _destroy: function() {
            var b = this.element;
            this.$Ifr.attr("src", "");
            b.dialog("destroy")
        }
    });
    d.widget("np.npviewer", d.np.npviewerLastSystem, {})
})(jQuery);