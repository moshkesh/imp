(function(b, l) {
    function a(c, a) {
        var e = c.nodeName.toLowerCase();
        if ("area" === e) {
            var e = c.parentNode,
                f = e.name;
            if (!c.href || !f || "map" !== e.nodeName.toLowerCase()) return !1;
            e = b("img[usemap=#" + f + "]")[0];
            return !!e && d(e)
        }
        return (/input|select|textarea|button|object/.test(e) ? !c.disabled : "a" == e ? c.href || a : a) && d(c)
    }

    function d(c) {
        return !b(c).parents().andSelf().filter(function() {
            return "hidden" === b.curCSS(this, "visibility") || b.expr.filters.hidden(this)
        }).length
    }
    b.ui = b.ui || {};
    b.ui.version || (b.extend(b.ui, {
        version: "1.9m5",
        keyCode: {
            ALT: 18,
            BACKSPACE: 8,
            CAPS_LOCK: 20,
            COMMA: 188,
            COMMAND: 91,
            COMMAND_LEFT: 91,
            COMMAND_RIGHT: 93,
            CONTROL: 17,
            DELETE: 46,
            DOWN: 40,
            END: 35,
            ENTER: 13,
            ESCAPE: 27,
            HOME: 36,
            INSERT: 45,
            LEFT: 37,
            MENU: 93,
            NUMPAD_ADD: 107,
            NUMPAD_DECIMAL: 110,
            NUMPAD_DIVIDE: 111,
            NUMPAD_ENTER: 108,
            NUMPAD_MULTIPLY: 106,
            NUMPAD_SUBTRACT: 109,
            PAGE_DOWN: 34,
            PAGE_UP: 33,
            PERIOD: 190,
            RIGHT: 39,
            SHIFT: 16,
            SPACE: 32,
            TAB: 9,
            UP: 38,
            WINDOWS: 91
        }
    }), b.fn.extend({
        _focus: b.fn.focus,
        focus: function(c, a) {
            return "number" === typeof c ? this.each(function() {
                var d = this;
                setTimeout(function() {
                    b(d).focus();
                    a && a.call(d)
                }, c)
            }) : this._focus.apply(this, arguments)
        },
        scrollParent: function() {
            var c;
            c = b.browser.msie && /(static|relative)/.test(this.css("position")) || /absolute/.test(this.css("position")) ? this.parents().filter(function() {
                return /(relative|absolute|fixed)/.test(b.curCSS(this, "position", 1)) && /(auto|scroll)/.test(b.curCSS(this, "overflow", 1) + b.curCSS(this, "overflow-y", 1) + b.curCSS(this, "overflow-x", 1))
            }).eq(0) : this.parents().filter(function() {
                return /(auto|scroll)/.test(b.curCSS(this, "overflow", 1) + b.curCSS(this,
                    "overflow-y", 1) + b.curCSS(this, "overflow-x", 1))
            }).eq(0);
            return /fixed/.test(this.css("position")) || !c.length ? b(document) : c
        },
        zIndex: function(c) {
            if (c !== l) return this.css("zIndex", c);
            if (this.length) {
                c = b(this[0]);
                for (var a; c.length && c[0] !== document;) {
                    a = c.css("position");
                    if ("absolute" === a || "relative" === a || "fixed" === a)
                        if (a = parseInt(c.css("zIndex"), 10), !isNaN(a) && 0 !== a) return a;
                    c = c.parent()
                }
            }
            return 0
        },
        disableSelection: function() {
            return this.bind((b.support.selectstart ? "selectstart" : "mousedown") + ".ui-disableSelection",
                function(b) {
                    b.preventDefault()
                })
        },
        enableSelection: function() {
            return this.unbind(".ui-disableSelection")
        }
    }), b.each(["Width", "Height"], function(c, a) {
        function d(c, a, h, g) {
            b.each(f, function() {
                a -= parseFloat(b.curCSS(c, "padding" + this, !0)) || 0;
                h && (a -= parseFloat(b.curCSS(c, "border" + this + "Width", !0)) || 0);
                g && (a -= parseFloat(b.curCSS(c, "margin" + this, !0)) || 0)
            });
            return a
        }
        var f = "Width" === a ? ["Left", "Right"] : ["Top", "Bottom"],
            h = a.toLowerCase(),
            k = {
                innerWidth: b.fn.innerWidth,
                innerHeight: b.fn.innerHeight,
                outerWidth: b.fn.outerWidth,
                outerHeight: b.fn.outerHeight
            };
        b.fn["inner" + a] = function(c) {
            return c === l ? k["inner" + a].call(this) : this.each(function() {
                b(this).css(h, d(this, c) + "px")
            })
        };
        b.fn["outer" + a] = function(c, f) {
            return "number" !== typeof c ? k["outer" + a].call(this, c) : this.each(function() {
                b(this).css(h, d(this, c, !0, f) + "px")
            })
        }
    }), b.extend(b.expr[":"], {
        data: function(c, a, d) {
            return !!b.data(c, d[3])
        },
        focusable: function(c) {
            return a(c, !isNaN(b.attr(c, "tabindex")))
        },
        tabbable: function(c) {
            var d = b.attr(c, "tabindex"),
                e = isNaN(d);
            return (e || 0 <= d) && a(c, !e)
        }
    }), b(function() {
        var c = document.body,
            a = c.appendChild(a = document.createElement("div"));
        b.extend(a.style, {
            minHeight: "100px",
            height: "auto",
            padding: 0,
            borderWidth: 0
        });
        b.support.minHeight = 100 === a.offsetHeight;
        b.support.selectstart = "onselectstart" in a;
        c.removeChild(a).style.display = "none"
    }), b.extend(b.ui, {
        plugin: {
            add: function(c, a, d) {
                c = b.ui[c].prototype;
                for (var f in d) c.plugins[f] = c.plugins[f] || [], c.plugins[f].push([a, d[f]])
            },
            call: function(b, a, d) {
                if ((a = b.plugins[a]) && b.element[0].parentNode)
                    for (var f =
                            0; f < a.length; f++) b.options[a[f][0]] && a[f][1].apply(b.element, d)
            }
        },
        contains: b.contains,
        hasScroll: function(c, a) {
            if ("hidden" === b(c).css("overflow")) return !1;
            var d = a && "left" === a ? "scrollLeft" : "scrollTop",
                f = !1;
            if (0 < c[d]) return !0;
            c[d] = 1;
            f = 0 < c[d];
            c[d] = 0;
            return f
        },
        isOverAxis: function(b, a, d) {
            return b > a && b < a + d
        },
        isOver: function(c, a, d, f, h, k) {
            return b.ui.isOverAxis(c, d, h) && b.ui.isOverAxis(a, f, k)
        }
    }))
})(jQuery);
(function(b, l) {
    var a = Array.prototype.slice,
        d = b.cleanData;
    b.cleanData = function(c) {
        for (var a = 0, e; null != (e = c[a]); a++) b(e).triggerHandler("remove");
        d(c)
    };
    b.widget = function(c, d, e) {
        var f = c.split(".")[0],
            h;
        c = c.split(".")[1];
        h = f + "-" + c;
        e || (e = d, d = b.Widget);
        b.expr[":"][h] = function(f) {
            return !!b.data(f, c)
        };
        b[f] = b[f] || {};
        b[f][c] = b.extend(function(a, d) {
            if (!this._createWidget) return new b[f][c](a, d);
            arguments.length && this._createWidget(a, d)
        }, b[f][c]);
        var k = new d;
        k.options = b.widget.extend({}, k.options);
        b.each(e, function(c,
            f) {
            b.isFunction(f) && (e[c] = function() {
                var b = function(b) {
                        return d.prototype[b].apply(this, a.call(arguments, 1))
                    },
                    c = function(b, c) {
                        return d.prototype[b].apply(this, c)
                    };
                return function() {
                    var a = this._super,
                        d = this._superApply,
                        h;
                    this._super = b;
                    this._superApply = c;
                    h = f.apply(this, arguments);
                    this._super = a;
                    this._superApply = d;
                    return h
                }
            }())
        });
        b[f][c].prototype = b.widget.extend(k, {
            namespace: f,
            widgetName: c,
            widgetEventPrefix: c,
            widgetBaseClass: h
        }, e);
        b.widget.bridge(c, b[f][c])
    };
    b.widget.extend = function(c) {
        for (var d = a.call(arguments,
                1), e = 0, f = d.length, h, k; e < f; e++)
            for (h in d[e]) k = d[e][h], d[e].hasOwnProperty(h) && k !== l && (c[h] = b.isPlainObject(k) ? b.widget.extend({}, c[h], k) : k);
        return c
    };
    b.widget.bridge = function(c, d) {
        b.fn[c] = function(e) {
            var f = "string" === typeof e,
                h = a.call(arguments, 1),
                k = this;
            e = !f && h.length ? b.widget.extend.apply(null, [e].concat(h)) : e;
            f ? this.each(function() {
                var f = b.data(this, c);
                if (!f) return b.error("cannot call methods on " + c + " prior to initialization; attempted to call method '" + e + "'");
                if (!b.isFunction(f[e]) || "_" === e.charAt(0)) return b.error("no such method '" +
                    e + "' for " + c + " widget instance");
                var a = f[e].apply(f, h);
                if (a !== f && a !== l) return k = a.jquery ? k.pushStack(a.get()) : a, !1
            }) : this.each(function() {
                var f = b.data(this, c);
                f ? f.option(e || {})._init() : d(e, this)
            });
            return k
        }
    };
    b.Widget = function(c, a) {
        if (!this._createWidget) return new b[namespace][name](c, a);
        arguments.length && this._createWidget(c, a)
    };
    b.Widget.prototype = {
        widgetName: "widget",
        widgetEventPrefix: "",
        defaultElement: "<div>",
        options: {
            disabled: !1,
            create: null
        },
        _createWidget: function(c, a) {
            a = b(a || this.defaultElement ||
                this)[0];
            this.element = b(a);
            this.options = b.widget.extend({}, this.options, this._getCreateOptions(), c);
            this.bindings = b();
            this.hoverable = b();
            this.focusable = b();
            a !== this && (b.data(a, this.widgetName, this), this._bind({
                remove: "destroy"
            }));
            this._create();
            this._trigger("create");
            this._init()
        },
        _getCreateOptions: b.noop,
        _create: b.noop,
        _init: b.noop,
        destroy: function() {
            this._destroy();
            this.element.unbind("." + this.widgetName).removeData(this.widgetName);
            this.widget().unbind("." + this.widgetName).removeAttr("aria-disabled").removeClass(this.widgetBaseClass +
                "-disabled ui-state-disabled");
            this.bindings.unbind("." + this.widgetName);
            this.hoverable.removeClass("ui-state-hover");
            this.focusable.removeClass("ui-state-focus")
        },
        _destroy: b.noop,
        widget: function() {
            return this.element
        },
        option: function(c, a) {
            var d = c,
                f, h, k;
            if (0 === arguments.length) return b.widget.extend({}, this.options);
            if ("string" === typeof c) {
                if (a === l) return this.options[c];
                d = {};
                f = c.split(".");
                c = f.shift();
                if (f.length) {
                    h = d[c] = b.widget.extend({}, this.options[c]);
                    for (k = 0; k < f.length - 1; k++) h[f[k]] = h[f[k]] || {}, h = h[f[k]];
                    h[f.pop()] = a
                } else d[c] = a
            }
            this._setOptions(d);
            return this
        },
        _setOptions: function(c) {
            var a = this;
            b.each(c, function(b, c) {
                a._setOption(b, c)
            });
            return this
        },
        _setOption: function(b, a) {
            this.options[b] = a;
            "disabled" === b && (this.widget().toggleClass(this.widgetBaseClass + "-disabled ui-state-disabled", !!a).attr("aria-disabled", a), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus"));
            return this
        },
        enable: function() {
            return this._setOption("disabled", !1)
        },
        disable: function() {
            return this._setOption("disabled", !0)
        },
        _bind: function(c, a) {
            a ? (c = b(c), this.bindings = this.bindings.add(c)) : (a = c, c = this.element);
            var d = this;
            b.each(a, function(f, a) {
                c.bind(f + "." + d.widgetName, function() {
                    if (!0 !== d.options.disabled && !b(this).hasClass("ui-state-disabled")) return ("string" === typeof a ? d[a] : a).apply(d, arguments)
                })
            })
        },
        _hoverable: function(c) {
            this.hoverable = this.hoverable.add(c);
            this._bind(c, {
                mouseenter: function(c) {
                    b(c.currentTarget).addClass("ui-state-hover")
                },
                mouseleave: function(c) {
                    b(c.currentTarget).removeClass("ui-state-hover")
                }
            })
        },
        _focusable: function(c) {
            this.focusable = this.focusable.add(c);
            this._bind(c, {
                focusin: function(c) {
                    b(c.currentTarget).addClass("ui-state-focus")
                },
                focusout: function(c) {
                    b(c.currentTarget).removeClass("ui-state-focus")
                }
            })
        },
        _trigger: function(c, a, d) {
            var f = this.options[c];
            a = b.Event(a);
            a.type = (c === this.widgetEventPrefix ? c : this.widgetEventPrefix + c).toLowerCase();
            d = d || {};
            if (a.originalEvent) {
                c = b.event.props.length;
                for (var h; c;) h = b.event.props[--c], a[h] = a.originalEvent[h]
            }
            this.element.trigger(a, d);
            d = b.isArray(d) ? [a].concat(d) : [a, d];
            return !(b.isFunction(f) && !1 === f.apply(this.element[0], d) || a.isDefaultPrevented())
        }
    };
    b.each({
        show: "fadeIn",
        hide: "fadeOut"
    }, function(c, a) {
        b.Widget.prototype["_" + c] = function(d, f, h) {
            f = f || {};
            var k = !b.isEmptyObject(f),
                n = f.effect || a;
            f.complete = h;
            f.delay && d.delay(f.delay);
            if (k && b.effects && (b.effects.effect[n] || !1 !== b.uiBackCompat && b.effects[n])) d[c](f);
            else if (n !== c && d[n]) d[n](f.duration, f.easing, h);
            else d.queue(function() {
                b(this)[c]();
                h && h.call(d[0])
            })
        }
    });
    !1 !== b.uiBackCompat && (b.Widget.prototype._getCreateOptions =
        function() {
            return b.metadata && b.metadata.get(this.element[0])[this.widgetName]
        })
})(jQuery);
(function(b, l) {
    var a = !1;
    b(document).mousedown(function(b) {
        a = !1
    });
    b.widget("ui.mouse", {
        options: {
            cancel: ":input,option",
            distance: 1,
            delay: 0
        },
        _mouseInit: function() {
            var a = this;
            this.element.bind("mousedown." + this.widgetName, function(b) {
                return a._mouseDown(b)
            }).bind("click." + this.widgetName, function(c) {
                if (!0 === b.data(c.target, a.widgetName + ".preventClickEvent")) return b.removeData(c.target, a.widgetName + ".preventClickEvent"), c.stopImmediatePropagation(), !1
            });
            this.started = !1
        },
        _mouseDestroy: function() {
            this.element.unbind("." +
                this.widgetName)
        },
        _mouseDown: function(d) {
            if (!a) {
                this._mouseStarted && this._mouseUp(d);
                this._mouseDownEvent = d;
                var c = this,
                    g = 1 == d.which,
                    e = "string" == typeof this.options.cancel ? b(d.target).parents().add(d.target).filter(this.options.cancel).length : !1;
                if (!g || e || !this._mouseCapture(d)) return !0;
                this.mouseDelayMet = !this.options.delay;
                this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
                    c.mouseDelayMet = !0
                }, this.options.delay));
                if (this._mouseDistanceMet(d) && this._mouseDelayMet(d) && (this._mouseStarted = !1 !== this._mouseStart(d), !this._mouseStarted)) return d.preventDefault(), !0;
                !0 === b.data(d.target, this.widgetName + ".preventClickEvent") && b.removeData(d.target, this.widgetName + ".preventClickEvent");
                this._mouseMoveDelegate = function(b) {
                    return c._mouseMove(b)
                };
                this._mouseUpDelegate = function(b) {
                    return c._mouseUp(b)
                };
                b(document).bind("mousemove." + this.widgetName, this._mouseMoveDelegate).bind("mouseup." + this.widgetName, this._mouseUpDelegate);
                d.preventDefault();
                return a = !0
            }
        },
        _mouseMove: function(a) {
            if (b.browser.msie &&
                !(9 <= document.documentMode) && !a.button) return this._mouseUp(a);
            if (this._mouseStarted) return this._mouseDrag(a), a.preventDefault();
            this._mouseDistanceMet(a) && this._mouseDelayMet(a) && ((this._mouseStarted = !1 !== this._mouseStart(this._mouseDownEvent, a)) ? this._mouseDrag(a) : this._mouseUp(a));
            return !this._mouseStarted
        },
        _mouseUp: function(a) {
            b(document).unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate);
            this._mouseStarted && (this._mouseStarted = !1, a.target == this._mouseDownEvent.target && b.data(a.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(a));
            return !1
        },
        _mouseDistanceMet: function(b) {
            return Math.max(Math.abs(this._mouseDownEvent.pageX - b.pageX), Math.abs(this._mouseDownEvent.pageY - b.pageY)) >= this.options.distance
        },
        _mouseDelayMet: function(b) {
            return this.mouseDelayMet
        },
        _mouseStart: function(b) {},
        _mouseDrag: function(b) {},
        _mouseStop: function(b) {},
        _mouseCapture: function(b) {
            return !0
        }
    })
})(jQuery);
(function(b, l) {
    b.widget("ui.draggable", b.ui.mouse, {
        widgetEventPrefix: "drag",
        options: {
            addClasses: !0,
            appendTo: "parent",
            axis: !1,
            connectToSortable: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            iframeFix: !1,
            opacity: !1,
            refreshPositions: !1,
            revert: !1,
            revertDuration: 500,
            scope: "default",
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            snap: !1,
            snapMode: "both",
            snapTolerance: 20,
            stack: !1,
            zIndex: !1
        },
        _create: function() {
            "original" != this.options.helper || /^(?:r|a|f)/.test(this.element.css("position")) ||
                (this.element[0].style.position = "relative");
            this.options.addClasses && this.element.addClass("ui-draggable");
            this.options.disabled && this.element.addClass("ui-draggable-disabled");
            this._mouseInit()
        },
        destroy: function() {
            if (this.element.data("draggable")) return this.element.removeData("draggable").unbind(".draggable").removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled"), this._mouseDestroy(), this
        },
        _mouseCapture: function(a) {
            var d = this.options;
            if (this.helper || d.disabled || b(a.target).is(".ui-resizable-handle")) return !1;
            this.handle = this._getHandle(a);
            if (!this.handle) return !1;
            b(!0 === d.iframeFix ? "iframe" : d.iframeFix).each(function() {
                b('<div class="ui-draggable-iframeFix" style="background: #fff;"></div>').css({
                    width: this.offsetWidth + "px",
                    height: this.offsetHeight + "px",
                    position: "absolute",
                    opacity: "0.001",
                    zIndex: 1E3
                }).css(b(this).offset()).appendTo("body")
            });
            return !0
        },
        _mouseStart: function(a) {
            var d = this.options;
            this.helper = this._createHelper(a);
            this._cacheHelperProportions();
            b.ui.ddmanager && (b.ui.ddmanager.current = this);
            this._cacheMargins();
            this.cssPosition = this.helper.css("position");
            this.scrollParent = this.helper.scrollParent();
            this.offset = this.positionAbs = this.element.offset();
            this.offset = {
                top: this.offset.top - this.margins.top,
                left: this.offset.left - this.margins.left
            };
            b.extend(this.offset, {
                click: {
                    left: a.pageX - this.offset.left,
                    top: a.pageY - this.offset.top
                },
                parent: this._getParentOffset(),
                relative: this._getRelativeOffset()
            });
            this.originalPosition = this.position = this._generatePosition(a);
            this.originalPageX = a.pageX;
            this.originalPageY =
                a.pageY;
            d.cursorAt && this._adjustOffsetFromHelper(d.cursorAt);
            d.containment && this._setContainment();
            if (!1 === this._trigger("start", a)) return this._clear(), !1;
            this._cacheHelperProportions();
            b.ui.ddmanager && !d.dropBehaviour && b.ui.ddmanager.prepareOffsets(this, a);
            this.helper.addClass("ui-draggable-dragging");
            this._mouseDrag(a, !0);
            return !0
        },
        _mouseDrag: function(a, d) {
            this.position = this._generatePosition(a);
            this.positionAbs = this._convertPositionTo("absolute");
            if (!d) {
                var c = this._uiHash();
                if (!1 === this._trigger("drag",
                        a, c)) return this._mouseUp({}), !1;
                this.position = c.position
            }
            this.options.axis && "y" == this.options.axis || (this.helper[0].style.left = this.position.left + "px");
            this.options.axis && "x" == this.options.axis || (this.helper[0].style.top = this.position.top + "px");
            b.ui.ddmanager && b.ui.ddmanager.drag(this, a);
            return !1
        },
        _mouseStop: function(a) {
            var d = !1;
            b.ui.ddmanager && !this.options.dropBehaviour && (d = b.ui.ddmanager.drop(this, a));
            this.dropped && (d = this.dropped, this.dropped = !1);
            if (!this.element[0] || !this.element[0].parentNode) return !1;
            if ("invalid" == this.options.revert && !d || "valid" == this.options.revert && d || !0 === this.options.revert || b.isFunction(this.options.revert) && this.options.revert.call(this.element, d)) {
                var c = this;
                b(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
                    !1 !== c._trigger("stop", a) && c._clear()
                })
            } else !1 !== this._trigger("stop", a) && this._clear();
            return !1
        },
        _mouseUp: function(a) {
            !0 === this.options.iframeFix && b("div.ui-draggable-iframeFix").each(function() {
                this.parentNode.removeChild(this)
            });
            return b.ui.mouse.prototype._mouseUp.call(this, a)
        },
        cancel: function() {
            this.helper.is(".ui-draggable-dragging") ? this._mouseUp({}) : this._clear();
            return this
        },
        _getHandle: function(a) {
            var d = this.options.handle && b(this.options.handle, this.element).length ? !1 : !0;
            b(this.options.handle, this.element).find("*").andSelf().each(function() {
                this == a.target && (d = !0)
            });
            return d
        },
        _createHelper: function(a) {
            var d = this.options;
            a = b.isFunction(d.helper) ? b(d.helper.apply(this.element[0], [a])) : "clone" == d.helper ? this.element.clone().removeAttr("id") :
                this.element;
            a.parents("body").length || a.appendTo("parent" == d.appendTo ? this.element[0].parentNode : d.appendTo);
            a[0] == this.element[0] || /(fixed|absolute)/.test(a.css("position")) || a.css("position", "absolute");
            return a
        },
        _adjustOffsetFromHelper: function(a) {
            "string" == typeof a && (a = a.split(" "));
            b.isArray(a) && (a = {
                left: +a[0],
                top: +a[1] || 0
            });
            "left" in a && (this.offset.click.left = a.left + this.margins.left);
            "right" in a && (this.offset.click.left = this.helperProportions.width - a.right + this.margins.left);
            "top" in a && (this.offset.click.top =
                a.top + this.margins.top);
            "bottom" in a && (this.offset.click.top = this.helperProportions.height - a.bottom + this.margins.top)
        },
        _getParentOffset: function() {
            this.offsetParent = this.helper.offsetParent();
            var a = this.offsetParent.offset();
            "absolute" == this.cssPosition && this.scrollParent[0] != document && b.contains(this.scrollParent[0], this.offsetParent[0]) && (a.left += this.scrollParent.scrollLeft(), a.top += this.scrollParent.scrollTop());
            if (this.offsetParent[0] == document.body || this.offsetParent[0].tagName && "html" == this.offsetParent[0].tagName.toLowerCase() &&
                b.browser.msie) a = {
                top: 0,
                left: 0
            };
            return {
                top: a.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: a.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function() {
            if ("relative" == this.cssPosition) {
                var b = this.element.position();
                return {
                    top: b.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                    left: b.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                }
            }
            return {
                top: 0,
                left: 0
            }
        },
        _cacheMargins: function() {
            this.margins = {
                left: parseInt(this.element.css("marginLeft"), 10) || 0,
                top: parseInt(this.element.css("marginTop"), 10) || 0,
                right: parseInt(this.element.css("marginRight"), 10) || 0,
                bottom: parseInt(this.element.css("marginBottom"), 10) || 0
            }
        },
        _cacheHelperProportions: function() {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function() {
            var a = this.options;
            "parent" == a.containment && (a.containment = this.helper[0].parentNode);
            if ("document" == a.containment || "window" == a.containment) this.containment = ["document" == a.containment ? 0 : b(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, "document" == a.containment ? 0 : b(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, ("document" == a.containment ? 0 : b(window).scrollLeft()) + b("document" == a.containment ? document : window).width() - this.helperProportions.width - this.margins.left, ("document" == a.containment ? 0 : b(window).scrollTop()) + (b("document" == a.containment ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height -
                this.margins.top
            ];
            if (/^(document|window|parent)$/.test(a.containment) || a.containment.constructor == Array) a.containment.constructor == Array && (this.containment = a.containment);
            else {
                var a = b(a.containment),
                    d = a[0];
                if (d) {
                    a.offset();
                    var c = "hidden" != b(d).css("overflow");
                    this.containment = [(parseInt(b(d).css("borderLeftWidth"), 10) || 0) + (parseInt(b(d).css("paddingLeft"), 10) || 0), (parseInt(b(d).css("borderTopWidth"), 10) || 0) + (parseInt(b(d).css("paddingTop"), 10) || 0), (c ? Math.max(d.scrollWidth, d.offsetWidth) : d.offsetWidth) -
                        (parseInt(b(d).css("borderLeftWidth"), 10) || 0) - (parseInt(b(d).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (c ? Math.max(d.scrollHeight, d.offsetHeight) : d.offsetHeight) - (parseInt(b(d).css("borderTopWidth"), 10) || 0) - (parseInt(b(d).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom
                    ];
                    this.relative_container = a
                }
            }
        },
        _convertPositionTo: function(a, d) {
            d || (d = this.position);
            var c = "absolute" == a ? 1 : -1,
                g = "absolute" != this.cssPosition ||
                this.scrollParent[0] != document && b.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                e = /(html|body)/i.test(g[0].tagName);
            return {
                top: d.top + this.offset.relative.top * c + this.offset.parent.top * c - (b.browser.safari && 526 > b.browser.version && "fixed" == this.cssPosition ? 0 : ("fixed" == this.cssPosition ? -this.scrollParent.scrollTop() : e ? 0 : g.scrollTop()) * c),
                left: d.left + this.offset.relative.left * c + this.offset.parent.left * c - (b.browser.safari && 526 > b.browser.version && "fixed" == this.cssPosition ?
                    0 : ("fixed" == this.cssPosition ? -this.scrollParent.scrollLeft() : e ? 0 : g.scrollLeft()) * c)
            }
        },
        _generatePosition: function(a) {
            var d = this.options,
                c = "absolute" != this.cssPosition || this.scrollParent[0] != document && b.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                g = /(html|body)/i.test(c[0].tagName),
                e = a.pageX,
                f = a.pageY;
            if (this.originalPosition) {
                var h;
                this.containment && (this.relative_container ? (h = this.relative_container.offset(), h = [this.containment[0] + h.left, this.containment[1] +
                    h.top, this.containment[2] + h.left, this.containment[3] + h.top
                ]) : h = this.containment, a.pageX - this.offset.click.left < h[0] && (e = h[0] + this.offset.click.left), a.pageY - this.offset.click.top < h[1] && (f = h[1] + this.offset.click.top), a.pageX - this.offset.click.left > h[2] && (e = h[2] + this.offset.click.left), a.pageY - this.offset.click.top > h[3] && (f = h[3] + this.offset.click.top));
                d.grid && (f = d.grid[1] ? this.originalPageY + Math.round((f - this.originalPageY) / d.grid[1]) * d.grid[1] : this.originalPageY, f = h ? f - this.offset.click.top < h[1] ||
                    f - this.offset.click.top > h[3] ? f - this.offset.click.top < h[1] ? f + d.grid[1] : f - d.grid[1] : f : f, e = d.grid[0] ? this.originalPageX + Math.round((e - this.originalPageX) / d.grid[0]) * d.grid[0] : this.originalPageX, e = h ? e - this.offset.click.left < h[0] || e - this.offset.click.left > h[2] ? e - this.offset.click.left < h[0] ? e + d.grid[0] : e - d.grid[0] : e : e)
            }
            return {
                top: f - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (b.browser.safari && 526 > b.browser.version && "fixed" == this.cssPosition ? 0 : "fixed" == this.cssPosition ? -this.scrollParent.scrollTop() :
                    g ? 0 : c.scrollTop()),
                left: e - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (b.browser.safari && 526 > b.browser.version && "fixed" == this.cssPosition ? 0 : "fixed" == this.cssPosition ? -this.scrollParent.scrollLeft() : g ? 0 : c.scrollLeft())
            }
        },
        _clear: function() {
            this.helper.removeClass("ui-draggable-dragging");
            this.helper[0] == this.element[0] || this.cancelHelperRemoval || this.helper.remove();
            this.helper = null;
            this.cancelHelperRemoval = !1
        },
        _trigger: function(a, d, c) {
            c = c || this._uiHash();
            b.ui.plugin.call(this,
                a, [d, c]);
            "drag" == a && (this.positionAbs = this._convertPositionTo("absolute"));
            return b.Widget.prototype._trigger.call(this, a, d, c)
        },
        plugins: {},
        _uiHash: function(b) {
            return {
                helper: this.helper,
                position: this.position,
                originalPosition: this.originalPosition,
                offset: this.positionAbs
            }
        }
    });
    b.extend(b.ui.draggable, {
        version: "1.9m5"
    });
    b.ui.plugin.add("draggable", "connectToSortable", {
        start: function(a, d) {
            var c = b(this).data("draggable"),
                g = c.options,
                e = b.extend({}, d, {
                    item: c.element
                });
            c.sortables = [];
            b(g.connectToSortable).each(function() {
                var f =
                    b.data(this, "sortable");
                f && !f.options.disabled && (c.sortables.push({
                    instance: f,
                    shouldRevert: f.options.revert
                }), f.refreshPositions(), f._trigger("activate", a, e))
            })
        },
        stop: function(a, d) {
            var c = b(this).data("draggable"),
                g = b.extend({}, d, {
                    item: c.element
                });
            b.each(c.sortables, function() {
                this.instance.isOver ? (this.instance.isOver = 0, c.cancelHelperRemoval = !0, this.instance.cancelHelperRemoval = !1, this.shouldRevert && (this.instance.options.revert = !0), this.instance._mouseStop(a), this.instance.options.helper = this.instance.options._helper,
                    "original" == c.options.helper && this.instance.currentItem.css({
                        top: "auto",
                        left: "auto"
                    })) : (this.instance.cancelHelperRemoval = !1, this.instance._trigger("deactivate", a, g))
            })
        },
        drag: function(a, d) {
            var c = b(this).data("draggable"),
                g = this;
            b.each(c.sortables, function(e) {
                this.instance.positionAbs = c.positionAbs;
                this.instance.helperProportions = c.helperProportions;
                this.instance.offset.click = c.offset.click;
                this.instance._intersectsWith(this.instance.containerCache) ? (this.instance.isOver || (this.instance.isOver = 1, this.instance.currentItem =
                    b(g).clone().removeAttr("id").appendTo(this.instance.element).data("sortable-item", !0), this.instance.options._helper = this.instance.options.helper, this.instance.options.helper = function() {
                        return d.helper[0]
                    }, a.target = this.instance.currentItem[0], this.instance._mouseCapture(a, !0), this.instance._mouseStart(a, !0, !0), this.instance.offset.click.top = c.offset.click.top, this.instance.offset.click.left = c.offset.click.left, this.instance.offset.parent.left -= c.offset.parent.left - this.instance.offset.parent.left,
                    this.instance.offset.parent.top -= c.offset.parent.top - this.instance.offset.parent.top, c._trigger("toSortable", a), c.dropped = this.instance.element, c.currentItem = c.element, this.instance.fromOutside = c), this.instance.currentItem && this.instance._mouseDrag(a)) : this.instance.isOver && (this.instance.isOver = 0, this.instance.cancelHelperRemoval = !0, this.instance.options.revert = !1, this.instance._trigger("out", a, this.instance._uiHash(this.instance)), this.instance._mouseStop(a, !0), this.instance.options.helper = this.instance.options._helper,
                    this.instance.currentItem.remove(), this.instance.placeholder && this.instance.placeholder.remove(), c._trigger("fromSortable", a), c.dropped = !1)
            })
        }
    });
    b.ui.plugin.add("draggable", "cursor", {
        start: function(a, d) {
            var c = b("body"),
                g = b(this).data("draggable").options;
            c.css("cursor") && (g._cursor = c.css("cursor"));
            c.css("cursor", g.cursor)
        },
        stop: function(a, d) {
            var c = b(this).data("draggable").options;
            c._cursor && b("body").css("cursor", c._cursor)
        }
    });
    b.ui.plugin.add("draggable", "opacity", {
        start: function(a, d) {
            var c = b(d.helper),
                g = b(this).data("draggable").options;
            c.css("opacity") && (g._opacity = c.css("opacity"));
            c.css("opacity", g.opacity)
        },
        stop: function(a, d) {
            var c = b(this).data("draggable").options;
            c._opacity && b(d.helper).css("opacity", c._opacity)
        }
    });
    b.ui.plugin.add("draggable", "scroll", {
        start: function(a, d) {
            var c = b(this).data("draggable");
            c.scrollParent[0] != document && "HTML" != c.scrollParent[0].tagName && (c.overflowOffset = c.scrollParent.offset())
        },
        drag: function(a, d) {
            var c = b(this).data("draggable"),
                g = c.options,
                e = !1;
            c.scrollParent[0] !=
                document && "HTML" != c.scrollParent[0].tagName ? (g.axis && "x" == g.axis || (c.overflowOffset.top + c.scrollParent[0].offsetHeight - a.pageY < g.scrollSensitivity ? c.scrollParent[0].scrollTop = e = c.scrollParent[0].scrollTop + g.scrollSpeed : a.pageY - c.overflowOffset.top < g.scrollSensitivity && (c.scrollParent[0].scrollTop = e = c.scrollParent[0].scrollTop - g.scrollSpeed)), g.axis && "y" == g.axis || (c.overflowOffset.left + c.scrollParent[0].offsetWidth - a.pageX < g.scrollSensitivity ? c.scrollParent[0].scrollLeft = e = c.scrollParent[0].scrollLeft +
                    g.scrollSpeed : a.pageX - c.overflowOffset.left < g.scrollSensitivity && (c.scrollParent[0].scrollLeft = e = c.scrollParent[0].scrollLeft - g.scrollSpeed))) : (g.axis && "x" == g.axis || (a.pageY - b(document).scrollTop() < g.scrollSensitivity ? e = b(document).scrollTop(b(document).scrollTop() - g.scrollSpeed) : b(window).height() - (a.pageY - b(document).scrollTop()) < g.scrollSensitivity && (e = b(document).scrollTop(b(document).scrollTop() + g.scrollSpeed))), g.axis && "y" == g.axis || (a.pageX - b(document).scrollLeft() < g.scrollSensitivity ? e = b(document).scrollLeft(b(document).scrollLeft() -
                    g.scrollSpeed) : b(window).width() - (a.pageX - b(document).scrollLeft()) < g.scrollSensitivity && (e = b(document).scrollLeft(b(document).scrollLeft() + g.scrollSpeed))));
            !1 !== e && b.ui.ddmanager && !g.dropBehaviour && b.ui.ddmanager.prepareOffsets(c, a)
        }
    });
    b.ui.plugin.add("draggable", "snap", {
        start: function(a, d) {
            var c = b(this).data("draggable"),
                g = c.options;
            c.snapElements = [];
            b(g.snap.constructor != String ? g.snap.items || ":data(draggable)" : g.snap).each(function() {
                var a = b(this),
                    f = a.offset();
                this != c.element[0] && c.snapElements.push({
                    item: this,
                    width: a.outerWidth(),
                    height: a.outerHeight(),
                    top: f.top,
                    left: f.left
                })
            })
        },
        drag: function(a, d) {
            for (var c = b(this).data("draggable"), g = c.options, e = g.snapTolerance, f = d.offset.left, h = f + c.helperProportions.width, k = d.offset.top, n = k + c.helperProportions.height, m = c.snapElements.length - 1; 0 <= m; m--) {
                var p = c.snapElements[m].left,
                    v = p + c.snapElements[m].width,
                    q = c.snapElements[m].top,
                    l = q + c.snapElements[m].height;
                if (p - e < f && f < v + e && q - e < k && k < l + e || p - e < f && f < v + e && q - e < n && n < l + e || p - e < h && h < v + e && q - e < k && k < l + e || p - e < h && h < v + e && q - e < n &&
                    n < l + e) {
                    if ("inner" != g.snapMode) {
                        var r = Math.abs(q - n) <= e,
                            w = Math.abs(l - k) <= e,
                            u = Math.abs(p - h) <= e,
                            x = Math.abs(v - f) <= e;
                        r && (d.position.top = c._convertPositionTo("relative", {
                            top: q - c.helperProportions.height,
                            left: 0
                        }).top - c.margins.top);
                        w && (d.position.top = c._convertPositionTo("relative", {
                            top: l,
                            left: 0
                        }).top - c.margins.top);
                        u && (d.position.left = c._convertPositionTo("relative", {
                            top: 0,
                            left: p - c.helperProportions.width
                        }).left - c.margins.left);
                        x && (d.position.left = c._convertPositionTo("relative", {
                            top: 0,
                            left: v
                        }).left - c.margins.left)
                    }
                    var y =
                        r || w || u || x;
                    "outer" != g.snapMode && (r = Math.abs(q - k) <= e, w = Math.abs(l - n) <= e, u = Math.abs(p - f) <= e, x = Math.abs(v - h) <= e, r && (d.position.top = c._convertPositionTo("relative", {
                        top: q,
                        left: 0
                    }).top - c.margins.top), w && (d.position.top = c._convertPositionTo("relative", {
                        top: l - c.helperProportions.height,
                        left: 0
                    }).top - c.margins.top), u && (d.position.left = c._convertPositionTo("relative", {
                        top: 0,
                        left: p
                    }).left - c.margins.left), x && (d.position.left = c._convertPositionTo("relative", {
                        top: 0,
                        left: v - c.helperProportions.width
                    }).left - c.margins.left));
                    !c.snapElements[m].snapping && (r || w || u || x || y) && c.options.snap.snap && c.options.snap.snap.call(c.element, a, b.extend(c._uiHash(), {
                        snapItem: c.snapElements[m].item
                    }));
                    c.snapElements[m].snapping = r || w || u || x || y
                } else c.snapElements[m].snapping && c.options.snap.release && c.options.snap.release.call(c.element, a, b.extend(c._uiHash(), {
                    snapItem: c.snapElements[m].item
                })), c.snapElements[m].snapping = !1
            }
        }
    });
    b.ui.plugin.add("draggable", "stack", {
        start: function(a, d) {
            var c = b(this).data("draggable").options,
                c = b.makeArray(b(c.stack)).sort(function(c,
                    a) {
                    return (parseInt(b(c).css("zIndex"), 10) || 0) - (parseInt(b(a).css("zIndex"), 10) || 0)
                });
            if (c.length) {
                var g = parseInt(c[0].style.zIndex) || 0;
                b(c).each(function(b) {
                    this.style.zIndex = g + b
                });
                this[0].style.zIndex = g + c.length
            }
        }
    });
    b.ui.plugin.add("draggable", "zIndex", {
        start: function(a, d) {
            var c = b(d.helper),
                g = b(this).data("draggable").options;
            c.css("zIndex") && (g._zIndex = c.css("zIndex"));
            c.css("zIndex", g.zIndex)
        },
        stop: function(a, d) {
            var c = b(this).data("draggable").options;
            c._zIndex && b(d.helper).css("zIndex", c._zIndex)
        }
    })
})(jQuery);
(function(b, l) {
    b.widget("ui.droppable", {
        widgetEventPrefix: "drop",
        options: {
            accept: "*",
            activeClass: !1,
            addClasses: !0,
            greedy: !1,
            hoverClass: !1,
            scope: "default",
            tolerance: "intersect"
        },
        _create: function() {
            var a = this.options,
                d = a.accept;
            this.isover = 0;
            this.isout = 1;
            this.accept = b.isFunction(d) ? d : function(b) {
                return b.is(d)
            };
            this.proportions = {
                width: this.element[0].offsetWidth,
                height: this.element[0].offsetHeight
            };
            b.ui.ddmanager.droppables[a.scope] = b.ui.ddmanager.droppables[a.scope] || [];
            b.ui.ddmanager.droppables[a.scope].push(this);
            a.addClasses && this.element.addClass("ui-droppable")
        },
        destroy: function() {
            for (var a = b.ui.ddmanager.droppables[this.options.scope], d = 0; d < a.length; d++) a[d] == this && a.splice(d, 1);
            this.element.removeClass("ui-droppable ui-droppable-disabled").removeData("droppable").unbind(".droppable");
            return this
        },
        _setOption: function(a, d) {
            "accept" == a && (this.accept = b.isFunction(d) ? d : function(b) {
                return b.is(d)
            });
            b.Widget.prototype._setOption.apply(this, arguments)
        },
        _activate: function(a) {
            var d = b.ui.ddmanager.current;
            this.options.activeClass &&
                this.element.addClass(this.options.activeClass);
            d && this._trigger("activate", a, this.ui(d))
        },
        _deactivate: function(a) {
            var d = b.ui.ddmanager.current;
            this.options.activeClass && this.element.removeClass(this.options.activeClass);
            d && this._trigger("deactivate", a, this.ui(d))
        },
        _over: function(a) {
            var d = b.ui.ddmanager.current;
            d && (d.currentItem || d.element)[0] != this.element[0] && this.accept.call(this.element[0], d.currentItem || d.element) && (this.options.hoverClass && this.element.addClass(this.options.hoverClass), this._trigger("over",
                a, this.ui(d)))
        },
        _out: function(a) {
            var d = b.ui.ddmanager.current;
            d && (d.currentItem || d.element)[0] != this.element[0] && this.accept.call(this.element[0], d.currentItem || d.element) && (this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("out", a, this.ui(d)))
        },
        _drop: function(a, d) {
            var c = d || b.ui.ddmanager.current;
            if (!c || (c.currentItem || c.element)[0] == this.element[0]) return !1;
            var g = !1;
            this.element.find(":data(droppable)").not(".ui-draggable-dragging").each(function() {
                var a = b.data(this,
                    "droppable");
                if (a.options.greedy && !a.options.disabled && a.options.scope == c.options.scope && a.accept.call(a.element[0], c.currentItem || c.element) && b.ui.intersect(c, b.extend(a, {
                        offset: a.element.offset()
                    }), a.options.tolerance)) return g = !0, !1
            });
            return g ? !1 : this.accept.call(this.element[0], c.currentItem || c.element) ? (this.options.activeClass && this.element.removeClass(this.options.activeClass), this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("drop", a, this.ui(c)), this.element) :
                !1
        },
        ui: function(b) {
            return {
                draggable: b.currentItem || b.element,
                helper: b.helper,
                position: b.position,
                offset: b.positionAbs
            }
        }
    });
    b.extend(b.ui.droppable, {
        version: "1.9m5"
    });
    b.ui.intersect = function(a, d, c) {
        if (!d.offset) return !1;
        var g = (a.positionAbs || a.position.absolute).left,
            e = g + a.helperProportions.width,
            f = (a.positionAbs || a.position.absolute).top,
            h = f + a.helperProportions.height,
            k = d.offset.left,
            n = k + d.proportions.width,
            m = d.offset.top,
            p = m + d.proportions.height;
        switch (c) {
            case "fit":
                return k <= g && e <= n && m <= f && h <= p;
            case "intersect":
                return k < g + a.helperProportions.width / 2 && e - a.helperProportions.width / 2 < n && m < f + a.helperProportions.height / 2 && h - a.helperProportions.height / 2 < p;
            case "pointer":
                return b.ui.isOver((a.positionAbs || a.position.absolute).top + (a.clickOffset || a.offset.click).top, (a.positionAbs || a.position.absolute).left + (a.clickOffset || a.offset.click).left, m, k, d.proportions.height, d.proportions.width);
            case "touch":
                return (f >= m && f <= p || h >= m && h <= p || f < m && h > p) && (g >= k && g <= n || e >= k && e <= n || g < k && e > n);
            default:
                return !1
        }
    };
    b.ui.ddmanager = {
        current: null,
        droppables: {
            "default": []
        },
        prepareOffsets: function(a, d) {
            var c = b.ui.ddmanager.droppables[a.options.scope] || [],
                g = d ? d.type : null,
                e = (a.currentItem || a.element).find(":data(droppable)").andSelf(),
                f = 0;
            a: for (; f < c.length; f++)
                if (!(c[f].options.disabled || a && !c[f].accept.call(c[f].element[0], a.currentItem || a.element))) {
                    for (var h = 0; h < e.length; h++)
                        if (e[h] == c[f].element[0]) {
                            c[f].proportions.height = 0;
                            continue a
                        }
                    c[f].visible = "none" != c[f].element.css("display");
                    c[f].visible && ("mousedown" ==
                        g && c[f]._activate.call(c[f], d), c[f].offset = c[f].element.offset(), c[f].proportions = {
                            width: c[f].element[0].offsetWidth,
                            height: c[f].element[0].offsetHeight
                        })
                }
        },
        drop: function(a, d) {
            var c = !1;
            b.each(b.ui.ddmanager.droppables[a.options.scope] || [], function() {
                this.options && (!this.options.disabled && this.visible && b.ui.intersect(a, this, this.options.tolerance) && (c = c || this._drop.call(this, d)), !this.options.disabled && this.visible && this.accept.call(this.element[0], a.currentItem || a.element) && (this.isout = 1, this.isover =
                    0, this._deactivate.call(this, d)))
            });
            return c
        },
        drag: function(a, d) {
            a.options.refreshPositions && b.ui.ddmanager.prepareOffsets(a, d);
            b.each(b.ui.ddmanager.droppables[a.options.scope] || [], function() {
                if (!this.options.disabled && !this.greedyChild && this.visible) {
                    var c = b.ui.intersect(a, this, this.options.tolerance);
                    if (c = c || 1 != this.isover ? c && 0 == this.isover ? "isover" : null : "isout") {
                        var g;
                        if (this.options.greedy) {
                            var e = this.element.parents(":data(droppable):eq(0)");
                            e.length && (g = b.data(e[0], "droppable"), g.greedyChild =
                                "isover" == c ? 1 : 0)
                        }
                        g && "isover" == c && (g.isover = 0, g.isout = 1, g._out.call(g, d));
                        this[c] = 1;
                        this["isout" == c ? "isover" : "isout"] = 0;
                        this["isover" == c ? "_over" : "_out"].call(this, d);
                        g && "isout" == c && (g.isout = 0, g.isover = 1, g._over.call(g, d))
                    }
                }
            })
        }
    }
})(jQuery);
(function(b, l) {
    b.widget("ui.resizable", b.ui.mouse, {
        widgetEventPrefix: "resize",
        options: {
            alsoResize: !1,
            animate: !1,
            animateDuration: "slow",
            animateEasing: "swing",
            aspectRatio: !1,
            autoHide: !1,
            containment: !1,
            ghost: !1,
            grid: !1,
            handles: "e,s,se",
            helper: !1,
            maxHeight: null,
            maxWidth: null,
            minHeight: 10,
            minWidth: 10,
            zIndex: 1E3
        },
        _create: function() {
            var c = this,
                a = this.options;
            this.element.addClass("ui-resizable");
            b.extend(this, {
                _aspectRatio: !!a.aspectRatio,
                aspectRatio: a.aspectRatio,
                originalElement: this.element,
                _proportionallyResizeElements: [],
                _helper: a.helper || a.ghost || a.animate ? a.helper || "ui-resizable-helper" : null
            });
            this.element[0].nodeName.match(/canvas|textarea|input|select|button|img/i) && (/relative/.test(this.element.css("position")) && b.browser.opera && this.element.css({
                    position: "relative",
                    top: "auto",
                    left: "auto"
                }), this.element.wrap(b('<div class="ui-wrapper" style="overflow: hidden;"></div>').css({
                    position: this.element.css("position"),
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight(),
                    top: this.element.css("top"),
                    left: this.element.css("left")
                })),
                this.element = this.element.parent().data("resizable", this.element.data("resizable")), this.elementIsWrapper = !0, this.element.css({
                    marginLeft: this.originalElement.css("marginLeft"),
                    marginTop: this.originalElement.css("marginTop"),
                    marginRight: this.originalElement.css("marginRight"),
                    marginBottom: this.originalElement.css("marginBottom")
                }), this.originalElement.css({
                    marginLeft: 0,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0
                }), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize",
                    "none"), this._proportionallyResizeElements.push(this.originalElement.css({
                    position: "static",
                    zoom: 1,
                    display: "block"
                })), this.originalElement.css({
                    margin: this.originalElement.css("margin")
                }), this._proportionallyResize());
            this.handles = a.handles || (b(".ui-resizable-handle", this.element).length ? {
                n: ".ui-resizable-n",
                e: ".ui-resizable-e",
                s: ".ui-resizable-s",
                w: ".ui-resizable-w",
                se: ".ui-resizable-se",
                sw: ".ui-resizable-sw",
                ne: ".ui-resizable-ne",
                nw: ".ui-resizable-nw"
            } : "e,s,se");
            if (this.handles.constructor == String) {
                "all" ==
                this.handles && (this.handles = "n,e,s,w,se,sw,ne,nw");
                var d = this.handles.split(",");
                this.handles = {};
                for (var f = 0; f < d.length; f++) {
                    var h = b.trim(d[f]),
                        k = b('<div class="ui-resizable-handle ui-resizable-' + h + '"></div>');
                    /sw|se|ne|nw/.test(h) && k.css({
                        zIndex: ++a.zIndex
                    });
                    "se" == h && k.addClass("ui-icon ui-icon-gripsmall-diagonal-se");
                    this.handles[h] = ".ui-resizable-" + h;
                    this.element.append(k)
                }
            }
            this._renderAxis = function(c) {
                c = c || this.element;
                for (var a in this.handles) {
                    this.handles[a].constructor == String && (this.handles[a] =
                        b(this.handles[a], this.element).show());
                    if (this.elementIsWrapper && this.originalElement[0].nodeName.match(/textarea|input|select|button/i)) {
                        var f = b(this.handles[a], this.element),
                            d = 0,
                            d = /sw|ne|nw|se|n|s/.test(a) ? f.outerHeight() : f.outerWidth(),
                            f = ["padding", /ne|nw|n/.test(a) ? "Top" : /se|sw|s/.test(a) ? "Bottom" : /^e$/.test(a) ? "Right" : "Left"].join("");
                        c.css(f, d);
                        this._proportionallyResize()
                    }
                    b(this.handles[a])
                }
            };
            this._renderAxis(this.element);
            this._handles = b(".ui-resizable-handle", this.element).disableSelection();
            this._handles.mouseover(function() {
                if (!c.resizing) {
                    if (this.className) var b = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i);
                    c.axis = b && b[1] ? b[1] : "se"
                }
            });
            a.autoHide && (this._handles.hide(), b(this.element).addClass("ui-resizable-autohide").hover(function() {
                a.disabled || (b(this).removeClass("ui-resizable-autohide"), c._handles.show())
            }, function() {
                a.disabled || c.resizing || (b(this).addClass("ui-resizable-autohide"), c._handles.hide())
            }));
            this._mouseInit()
        },
        destroy: function() {
            this._mouseDestroy();
            var c = function(c) {
                b(c).removeClass("ui-resizable ui-resizable-disabled ui-resizable-resizing").removeData("resizable").unbind(".resizable").find(".ui-resizable-handle").remove()
            };
            if (this.elementIsWrapper) {
                c(this.element);
                var a = this.element;
                a.after(this.originalElement.css({
                    position: a.css("position"),
                    width: a.outerWidth(),
                    height: a.outerHeight(),
                    top: a.css("top"),
                    left: a.css("left")
                })).remove()
            }
            this.originalElement.css("resize", this.originalResizeStyle);
            c(this.originalElement);
            return this
        },
        _mouseCapture: function(c) {
            var a = !1,
                d;
            for (d in this.handles) b(this.handles[d])[0] == c.target && (a = !0);
            return !this.options.disabled && a
        },
        _mouseStart: function(c) {
            var d = this.options,
                e = this.element.position(),
                f = this.element;
            this.resizing = !0;
            this.documentScroll = {
                top: b(document).scrollTop(),
                left: b(document).scrollLeft()
            };
            (f.is(".ui-draggable") || /absolute/.test(f.css("position"))) && f.css({
                position: "absolute",
                top: e.top,
                left: e.left
            });
            b.browser.opera && /relative/.test(f.css("position")) && f.css({
                position: "relative",
                top: "auto",
                left: "auto"
            });
            this._renderProxy();
            var e = a(this.helper.css("left")),
                h = a(this.helper.css("top"));
            d.containment && (e += b(d.containment).scrollLeft() || 0, h += b(d.containment).scrollTop() || 0);
            this.offset = this.helper.offset();
            this.position = {
                left: e,
                top: h
            };
            this.size = this._helper ? {
                width: f.outerWidth(),
                height: f.outerHeight()
            } : {
                width: f.width(),
                height: f.height()
            };
            this.originalSize = this._helper ? {
                width: f.outerWidth(),
                height: f.outerHeight()
            } : {
                width: f.width(),
                height: f.height()
            };
            this.originalPosition = {
                left: e,
                top: h
            };
            this.sizeDiff = {
                width: f.outerWidth() -
                    f.width(),
                height: f.outerHeight() - f.height()
            };
            this.originalMousePosition = {
                left: c.pageX,
                top: c.pageY
            };
            this.aspectRatio = "number" == typeof d.aspectRatio ? d.aspectRatio : this.originalSize.width / this.originalSize.height || 1;
            d = b(".ui-resizable-" + this.axis).css("cursor");
            b("body").css("cursor", "auto" == d ? this.axis + "-resize" : d);
            f.addClass("ui-resizable-resizing");
            this._propagate("start", c);
            return !0
        },
        _mouseDrag: function(b) {
            var a = this.helper,
                d = this.originalMousePosition,
                f = this._change[this.axis];
            if (!f) return !1;
            d =
                f.apply(this, [b, b.pageX - d.left || 0, b.pageY - d.top || 0]);
            if (this._aspectRatio || b.shiftKey) d = this._updateRatio(d, b);
            d = this._respectSize(d, b);
            this._propagate("resize", b);
            a.css({
                top: this.position.top + "px",
                left: this.position.left + "px",
                width: this.size.width + "px",
                height: this.size.height + "px"
            });
            !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize();
            this._updateCache(d);
            this._trigger("resize", b, this.ui());
            return !1
        },
        _mouseStop: function(c) {
            this.resizing = !1;
            var a = this.options;
            if (this._helper) {
                var d =
                    this._proportionallyResizeElements,
                    f = d.length && /textarea/i.test(d[0].nodeName),
                    d = f && b.ui.hasScroll(d[0], "left") ? 0 : this.sizeDiff.height,
                    f = f ? 0 : this.sizeDiff.width,
                    f = {
                        width: this.helper.width() - f,
                        height: this.helper.height() - d
                    },
                    d = parseInt(this.element.css("left"), 10) + (this.position.left - this.originalPosition.left) || null,
                    h = parseInt(this.element.css("top"), 10) + (this.position.top - this.originalPosition.top) || null;
                a.animate || this.element.css(b.extend(f, {
                    top: h,
                    left: d
                }));
                this.helper.height(this.size.height);
                this.helper.width(this.size.width);
                this._helper && !a.animate && this._proportionallyResize()
            }
            b("body").css("cursor", "auto");
            this.element.removeClass("ui-resizable-resizing");
            this._propagate("stop", c);
            this._helper && this.helper.remove();
            return !1
        },
        _updateCache: function(b) {
            this.offset = this.helper.offset();
            d(b.left) && (this.position.left = b.left);
            d(b.top) && (this.position.top = b.top);
            d(b.height) && (this.size.height = b.height);
            d(b.width) && (this.size.width = b.width)
        },
        _updateRatio: function(b, a) {
            var d = this.position,
                f = this.size,
                h = this.axis;
            b.height ? b.width = f.height * this.aspectRatio : b.width && (b.height = f.width / this.aspectRatio);
            "sw" == h && (b.left = d.left + (f.width - b.width), b.top = null);
            "nw" == h && (b.top = d.top + (f.height - b.height), b.left = d.left + (f.width - b.width));
            return b
        },
        _respectSize: function(b, a) {
            var e = this.options,
                f = this.axis,
                h = d(b.width) && e.maxWidth && e.maxWidth < b.width,
                k = d(b.height) && e.maxHeight && e.maxHeight < b.height,
                n = d(b.width) && e.minWidth && e.minWidth > b.width,
                m = d(b.height) && e.minHeight && e.minHeight > b.height;
            n && (b.width =
                e.minWidth);
            m && (b.height = e.minHeight);
            h && (b.width = e.maxWidth);
            k && (b.height = e.maxHeight);
            var p = this.originalPosition.left + this.originalSize.width,
                v = this.position.top + this.size.height,
                q = /sw|nw|w/.test(f),
                f = /nw|ne|n/.test(f);
            n && q && (b.left = p - e.minWidth);
            h && q && (b.left = p - e.maxWidth);
            m && f && (b.top = v - e.minHeight);
            k && f && (b.top = v - e.maxHeight);
            (e = !b.width && !b.height) && !b.left && b.top ? b.top = null : e && !b.top && b.left && (b.left = null);
            return b
        },
        _proportionallyResize: function() {
            if (this._proportionallyResizeElements.length)
                for (var c =
                        this.helper || this.element, a = 0; a < this._proportionallyResizeElements.length; a++) {
                    var d = this._proportionallyResizeElements[a];
                    if (!this.borderDif) {
                        var f = [d.css("borderTopWidth"), d.css("borderRightWidth"), d.css("borderBottomWidth"), d.css("borderLeftWidth")],
                            h = [d.css("paddingTop"), d.css("paddingRight"), d.css("paddingBottom"), d.css("paddingLeft")];
                        this.borderDif = b.map(f, function(b, c) {
                            var a = parseInt(b, 10) || 0,
                                f = parseInt(h[c], 10) || 0;
                            return a + f
                        })
                    }
                    b.browser.msie && (b(c).is(":hidden") || b(c).parents(":hidden").length) ||
                        d.css({
                            height: c.height() - this.borderDif[0] - this.borderDif[2] || 0,
                            width: c.width() - this.borderDif[1] - this.borderDif[3] || 0
                        })
                }
        },
        _renderProxy: function() {
            var c = this.options;
            this.elementOffset = this.element.offset();
            if (this._helper) {
                this.helper = this.helper || b('<div style="overflow:hidden;"></div>');
                var a = b.browser.msie && 7 > b.browser.version,
                    d = a ? 1 : 0,
                    a = a ? 2 : -1;
                this.helper.addClass(this._helper).css({
                    width: this.element.outerWidth() + a,
                    height: this.element.outerHeight() + a,
                    position: "absolute",
                    left: this.elementOffset.left -
                        d + "px",
                    top: this.elementOffset.top - d + "px",
                    zIndex: ++c.zIndex
                });
                this.helper.appendTo("body").disableSelection()
            } else this.helper = this.element
        },
        _change: {
            e: function(b, a, d) {
                return {
                    width: this.originalSize.width + a
                }
            },
            w: function(b, a, d) {
                return {
                    left: this.originalPosition.left + a,
                    width: this.originalSize.width - a
                }
            },
            n: function(b, a, d) {
                return {
                    top: this.originalPosition.top + d,
                    height: this.originalSize.height - d
                }
            },
            s: function(b, a, d) {
                return {
                    height: this.originalSize.height + d
                }
            },
            se: function(c, a, d) {
                return b.extend(this._change.s.apply(this,
                    arguments), this._change.e.apply(this, [c, a, d]))
            },
            sw: function(c, a, d) {
                return b.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [c, a, d]))
            },
            ne: function(c, a, d) {
                return b.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [c, a, d]))
            },
            nw: function(a, d, e) {
                return b.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [a, d, e]))
            }
        },
        _propagate: function(a, d) {
            b.ui.plugin.call(this, a, [d, this.ui()]);
            "resize" != a && this._trigger(a, d, this.ui())
        },
        plugins: {},
        ui: function() {
            return {
                originalElement: this.originalElement,
                element: this.element,
                helper: this.helper,
                position: this.position,
                size: this.size,
                originalSize: this.originalSize,
                originalPosition: this.originalPosition
            }
        }
    });
    b.extend(b.ui.resizable, {
        version: "1.9m5"
    });
    b.ui.plugin.add("resizable", "alsoResize", {
        start: function(a, d) {
            var e = b(this).data("resizable").options,
                f = function(a) {
                    b(a).each(function() {
                        var a = b(this);
                        a.data("resizable-alsoresize", {
                            width: parseInt(a.width(), 10),
                            height: parseInt(a.height(), 10),
                            left: parseInt(a.css("left"), 10),
                            top: parseInt(a.css("top"), 10),
                            position: a.css("position")
                        })
                    })
                };
            "object" != typeof e.alsoResize || e.alsoResize.parentNode ? f(e.alsoResize) : e.alsoResize.length ? (e.alsoResize = e.alsoResize[0], f(e.alsoResize)) : b.each(e.alsoResize, function(b) {
                f(b)
            })
        },
        resize: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e.originalSize,
                k = e.originalPosition,
                n = {
                    height: e.size.height - h.height || 0,
                    width: e.size.width - h.width || 0,
                    top: e.position.top - k.top || 0,
                    left: e.position.left - k.left || 0
                },
                m = function(a, c) {
                    b(a).each(function() {
                        var a = b(this),
                            f = b(this).data("resizable-alsoresize"),
                            h = {},
                            k = c && c.length ? c : a.parents(d.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
                        b.each(k, function(b, a) {
                            var c = (f[a] || 0) + (n[a] || 0);
                            c && 0 <= c && (h[a] = c || null)
                        });
                        b.browser.opera && /relative/.test(a.css("position")) && (e._revertToRelativePosition = !0, a.css({
                            position: "absolute",
                            top: "auto",
                            left: "auto"
                        }));
                        a.css(h)
                    })
                };
            "object" != typeof f.alsoResize || f.alsoResize.nodeType ? m(f.alsoResize) : b.each(f.alsoResize, function(b, a) {
                m(b, a)
            })
        },
        stop: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = function(a) {
                    b(a).each(function() {
                        var a = b(this);
                        a.css({
                            position: a.data("resizable-alsoresize").position
                        })
                    })
                };
            e._revertToRelativePosition && (e._revertToRelativePosition = !1, "object" != typeof f.alsoResize || f.alsoResize.nodeType ? h(f.alsoResize) : b.each(f.alsoResize, function(b) {
                h(b)
            }));
            b(this).removeData("resizable-alsoresize")
        }
    });
    b.ui.plugin.add("resizable", "animate", {
        stop: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e._proportionallyResizeElements,
                k = h.length && /textarea/i.test(h[0].nodeName),
                n = k && b.ui.hasScroll(h[0], "left") ? 0 : e.sizeDiff.height,
                k = {
                    width: e.size.width - (k ? 0 : e.sizeDiff.width),
                    height: e.size.height - n
                },
                n = parseInt(e.element.css("left"), 10) + (e.position.left - e.originalPosition.left) || null,
                m = parseInt(e.element.css("top"), 10) + (e.position.top - e.originalPosition.top) || null;
            e.element.animate(b.extend(k, m && n ? {
                top: m,
                left: n
            } : {}), {
                duration: f.animateDuration,
                easing: f.animateEasing,
                step: function() {
                    var f = {
                        width: parseInt(e.element.css("width"), 10),
                        height: parseInt(e.element.css("height"), 10),
                        top: parseInt(e.element.css("top"), 10),
                        left: parseInt(e.element.css("left"), 10)
                    };
                    h && h.length && b(h[0]).css({
                        width: f.width,
                        height: f.height
                    });
                    e._updateCache(f);
                    e._propagate("resize", a)
                }
            })
        }
    });
    b.ui.plugin.add("resizable", "containment", {
        start: function(c, d) {
            var e = b(this).data("resizable"),
                f = e.element,
                h = e.options.containment;
            if (f = h instanceof b ? h.get(0) : /parent/.test(h) ? f.parent().get(0) : h)
                if (e.containerElement = b(f), /document/.test(h) || h == document) e.containerOffset = {
                    left: 0,
                    top: 0
                }, e.containerPosition = {
                    left: 0,
                    top: 0
                }, e.parentData = {
                    element: b(document),
                    left: 0,
                    top: 0,
                    width: b(document).width(),
                    height: b(document).height() || document.body.parentNode.scrollHeight
                };
                else {
                    var k = b(f),
                        n = [];
                    b(["Top", "Right", "Left", "Bottom"]).each(function(b, c) {
                        n[b] = a(k.css("padding" + c))
                    });
                    e.containerOffset = k.offset();
                    e.containerPosition = k.position();
                    e.containerSize = {
                        height: k.innerHeight() - n[3],
                        width: k.innerWidth() - n[1]
                    };
                    var h = e.containerOffset,
                        m = e.containerSize.height,
                        p = e.containerSize.width,
                        p = b.ui.hasScroll(f, "left") ? f.scrollWidth : p,
                        m = b.ui.hasScroll(f) ? f.scrollHeight : m;
                    e.parentData = {
                        element: f,
                        left: h.left,
                        top: h.top,
                        width: p,
                        height: m
                    }
                }
        },
        resize: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e.containerOffset,
                k = e.position,
                n = e._aspectRatio || a.shiftKey,
                m = {
                    top: 0,
                    left: 0
                },
                p = e.containerElement;
            p[0] != document && /static/.test(p.css("position")) && (m = h);
            k.left < (e._helper ? h.left : 0) && (e.size.width += e._helper ? e.position.left - h.left : e.position.left - m.left, n && (e.size.height = e.size.width / f.aspectRatio), e.position.left = f.helper ? h.left :
                0);
            k.top < (e._helper ? h.top : 0) && (e.size.height += e._helper ? e.position.top - h.top : e.position.top, n && (e.size.width = e.size.height * f.aspectRatio), e.position.top = e._helper ? h.top : 0);
            e.offset.left = e.parentData.left + e.position.left;
            e.offset.top = e.parentData.top + e.position.top;
            f = Math.abs(e.offset.left - m.left + e.sizeDiff.width);
            h = Math.abs((e._helper ? e.offset.top - m.top : e.offset.top - h.top) + e.sizeDiff.height);
            m = e.containerElement.get(0) == e.element.parent().get(0);
            k = /relative|absolute/.test(e.containerElement.css("position"));
            m && k && (f -= e.parentData.left);
            f + e.size.width >= e.parentData.width && (e.size.width = e.parentData.width - f, n && (e.size.height = e.size.width / e.aspectRatio));
            h + e.size.height >= e.parentData.height && (e.size.height = e.parentData.height - h, n && (e.size.width = e.size.height * e.aspectRatio))
        },
        stop: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e.containerOffset,
                k = e.containerPosition,
                n = e.containerElement,
                m = b(e.helper),
                p = m.offset(),
                v = m.outerWidth() - e.sizeDiff.width,
                m = m.outerHeight() - e.sizeDiff.height;
            e._helper &&
                !f.animate && /relative/.test(n.css("position")) && b(this).css({
                    left: p.left - k.left - h.left,
                    width: v,
                    height: m
                });
            e._helper && !f.animate && /static/.test(n.css("position")) && b(this).css({
                left: p.left - k.left - h.left,
                width: v,
                height: m
            })
        }
    });
    b.ui.plugin.add("resizable", "ghost", {
        start: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e.size;
            e.ghost = e.originalElement.clone();
            e.ghost.css({
                opacity: .25,
                display: "block",
                position: "relative",
                height: h.height,
                width: h.width,
                margin: 0,
                left: 0,
                top: 0
            }).addClass("ui-resizable-ghost").addClass("string" ==
                typeof f.ghost ? f.ghost : "");
            e.ghost.appendTo(e.helper)
        },
        resize: function(a, d) {
            var e = b(this).data("resizable");
            e.ghost && e.ghost.css({
                position: "relative",
                height: e.size.height,
                width: e.size.width
            })
        },
        stop: function(a, d) {
            var e = b(this).data("resizable");
            e.ghost && e.helper && e.helper.get(0).removeChild(e.ghost.get(0))
        }
    });
    b.ui.plugin.add("resizable", "grid", {
        resize: function(a, d) {
            var e = b(this).data("resizable"),
                f = e.options,
                h = e.size,
                k = e.originalSize,
                n = e.originalPosition,
                m = e.axis;
            f.grid = "number" == typeof f.grid ? [f.grid,
                f.grid
            ] : f.grid;
            var p = Math.round((h.width - k.width) / (f.grid[0] || 1)) * (f.grid[0] || 1),
                f = Math.round((h.height - k.height) / (f.grid[1] || 1)) * (f.grid[1] || 1);
            /^(se|s|e)$/.test(m) ? (e.size.width = k.width + p, e.size.height = k.height + f) : /^(ne)$/.test(m) ? (e.size.width = k.width + p, e.size.height = k.height + f, e.position.top = n.top - f) : (/^(sw)$/.test(m) ? (e.size.width = k.width + p, e.size.height = k.height + f) : (e.size.width = k.width + p, e.size.height = k.height + f, e.position.top = n.top - f), e.position.left = n.left - p)
        }
    });
    var a = function(b) {
            return parseInt(b,
                10) || 0
        },
        d = function(b) {
            return !isNaN(parseInt(b, 10))
        }
})(jQuery);
(function(b, l) {
    b.widget("ui.selectable", b.ui.mouse, {
        options: {
            appendTo: "body",
            autoRefresh: !0,
            distance: 0,
            filter: "*",
            tolerance: "touch"
        },
        _create: function() {
            var a = this;
            this.element.addClass("ui-selectable");
            this.dragged = !1;
            var d;
            this.refresh = function() {
                d = b(a.options.filter, a.element[0]);
                d.each(function() {
                    var a = b(this),
                        d = a.offset();
                    b.data(this, "selectable-item", {
                        element: this,
                        $element: a,
                        left: d.left,
                        top: d.top,
                        right: d.left + a.outerWidth(),
                        bottom: d.top + a.outerHeight(),
                        startselected: !1,
                        selected: a.hasClass("ui-selected"),
                        selecting: a.hasClass("ui-selecting"),
                        unselecting: a.hasClass("ui-unselecting")
                    })
                })
            };
            this.refresh();
            this.selectees = d.addClass("ui-selectee");
            this._mouseInit();
            this.helper = b("<div class='ui-selectable-helper'></div>")
        },
        destroy: function() {
            this.selectees.removeClass("ui-selectee").removeData("selectable-item");
            this.element.removeClass("ui-selectable ui-selectable-disabled").removeData("selectable").unbind(".selectable");
            this._mouseDestroy();
            return this
        },
        _mouseStart: function(a) {
            var d = this;
            this.opos = [a.pageX,
                a.pageY
            ];
            if (!this.options.disabled) {
                var c = this.options;
                this.selectees = b(c.filter, this.element[0]);
                this._trigger("start", a);
                b(c.appendTo).append(this.helper);
                this.helper.css({
                    left: a.clientX,
                    top: a.clientY,
                    width: 0,
                    height: 0
                });
                c.autoRefresh && this.refresh();
                this.selectees.filter(".ui-selected").each(function() {
                    var c = b.data(this, "selectable-item");
                    c.startselected = !0;
                    a.metaKey || (c.$element.removeClass("ui-selected"), c.selected = !1, c.$element.addClass("ui-unselecting"), c.unselecting = !0, d._trigger("unselecting",
                        a, {
                            unselecting: c.element
                        }))
                });
                b(a.target).parents().andSelf().each(function() {
                    var c = b.data(this, "selectable-item");
                    if (c) {
                        var e = !a.metaKey || !c.$element.hasClass("ui-selected");
                        c.$element.removeClass(e ? "ui-unselecting" : "ui-selected").addClass(e ? "ui-selecting" : "ui-unselecting");
                        c.unselecting = !e;
                        c.selecting = e;
                        (c.selected = e) ? d._trigger("selecting", a, {
                            selecting: c.element
                        }): d._trigger("unselecting", a, {
                            unselecting: c.element
                        });
                        return !1
                    }
                })
            }
        },
        _mouseDrag: function(a) {
            var d = this;
            this.dragged = !0;
            if (!this.options.disabled) {
                var c =
                    this.options,
                    g = this.opos[0],
                    e = this.opos[1],
                    f = a.pageX,
                    h = a.pageY;
                if (g > f) var k = f,
                    f = g,
                    g = k;
                e > h && (k = h, h = e, e = k);
                this.helper.css({
                    left: g,
                    top: e,
                    width: f - g,
                    height: h - e
                });
                this.selectees.each(function() {
                    var k = b.data(this, "selectable-item");
                    if (k && k.element != d.element[0]) {
                        var m = !1;
                        "touch" == c.tolerance ? m = !(k.left > f || k.right < g || k.top > h || k.bottom < e) : "fit" == c.tolerance && (m = k.left > g && k.right < f && k.top > e && k.bottom < h);
                        m ? (k.selected && (k.$element.removeClass("ui-selected"), k.selected = !1), k.unselecting && (k.$element.removeClass("ui-unselecting"),
                            k.unselecting = !1), k.selecting || (k.$element.addClass("ui-selecting"), k.selecting = !0, d._trigger("selecting", a, {
                            selecting: k.element
                        }))) : (k.selecting && (a.metaKey && k.startselected ? (k.$element.removeClass("ui-selecting"), k.selecting = !1, k.$element.addClass("ui-selected"), k.selected = !0) : (k.$element.removeClass("ui-selecting"), k.selecting = !1, k.startselected && (k.$element.addClass("ui-unselecting"), k.unselecting = !0), d._trigger("unselecting", a, {
                                unselecting: k.element
                            }))), !k.selected || a.metaKey || k.startselected ||
                            (k.$element.removeClass("ui-selected"), k.selected = !1, k.$element.addClass("ui-unselecting"), k.unselecting = !0, d._trigger("unselecting", a, {
                                unselecting: k.element
                            })))
                    }
                });
                return !1
            }
        },
        _mouseStop: function(a) {
            var d = this;
            this.dragged = !1;
            b(".ui-unselecting", this.element[0]).each(function() {
                var c = b.data(this, "selectable-item");
                c.$element.removeClass("ui-unselecting");
                c.unselecting = !1;
                c.startselected = !1;
                d._trigger("unselected", a, {
                    unselected: c.element
                })
            });
            b(".ui-selecting", this.element[0]).each(function() {
                var c =
                    b.data(this, "selectable-item");
                c.$element.removeClass("ui-selecting").addClass("ui-selected");
                c.selecting = !1;
                c.selected = !0;
                c.startselected = !0;
                d._trigger("selected", a, {
                    selected: c.element
                })
            });
            this._trigger("stop", a);
            this.helper.remove();
            return !1
        }
    });
    b.extend(b.ui.selectable, {
        version: "1.9m5"
    })
})(jQuery);
(function(b, l) {
    b.widget("ui.sortable", b.ui.mouse, {
        widgetEventPrefix: "sort",
        options: {
            appendTo: "parent",
            axis: !1,
            connectWith: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            dropOnEmpty: !0,
            forcePlaceholderSize: !1,
            forceHelperSize: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            items: "> *",
            opacity: !1,
            placeholder: !1,
            revert: !1,
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            scope: "default",
            tolerance: "intersect",
            zIndex: 1E3
        },
        _create: function() {
            var b = this.options;
            this.containerCache = {};
            this.element.addClass("ui-sortable");
            this.refresh();
            this.floating = this.items.length ? "x" === b.axis || /left|right/.test(this.items[0].item.css("float")) || /inline|table-cell/.test(this.items[0].item.css("display")) : !1;
            this.offset = this.element.offset();
            this._mouseInit()
        },
        destroy: function() {
            this.element.removeClass("ui-sortable ui-sortable-disabled").removeData("sortable").unbind(".sortable");
            this._mouseDestroy();
            for (var b = this.items.length - 1; 0 <= b; b--) this.items[b].item.removeData("sortable-item");
            return this
        },
        _setOption: function(a, d) {
            "disabled" ===
            a ? (this.options[a] = d, this.widget().toggleClass("ui-sortable-disabled", !!d)) : b.Widget.prototype._setOption.apply(this, arguments)
        },
        _mouseCapture: function(a, d) {
            if (this.reverting || this.options.disabled || "static" == this.options.type) return !1;
            this._refreshItems(a);
            var c = null,
                g = this;
            b(a.target).parents().each(function() {
                if (b.data(this, "sortable-item") == g) return c = b(this), !1
            });
            b.data(a.target, "sortable-item") == g && (c = b(a.target));
            if (!c) return !1;
            if (this.options.handle && !d) {
                var e = !1;
                b(this.options.handle, c).find("*").andSelf().each(function() {
                    this ==
                        a.target && (e = !0)
                });
                if (!e) return !1
            }
            this.currentItem = c;
            this._removeCurrentsFromItems();
            return !0
        },
        _mouseStart: function(a, d, c) {
            d = this.options;
            this.currentContainer = this;
            this.refreshPositions();
            this.helper = this._createHelper(a);
            this._cacheHelperProportions();
            this._cacheMargins();
            this.scrollParent = this.helper.scrollParent();
            this.offset = this.currentItem.offset();
            this.offset = {
                top: this.offset.top - this.margins.top,
                left: this.offset.left - this.margins.left
            };
            this.helper.css("position", "absolute");
            this.cssPosition =
                this.helper.css("position");
            b.extend(this.offset, {
                click: {
                    left: a.pageX - this.offset.left,
                    top: a.pageY - this.offset.top
                },
                parent: this._getParentOffset(),
                relative: this._getRelativeOffset()
            });
            this.originalPosition = this._generatePosition(a);
            this.originalPageX = a.pageX;
            this.originalPageY = a.pageY;
            d.cursorAt && this._adjustOffsetFromHelper(d.cursorAt);
            this.domPosition = {
                prev: this.currentItem.prev()[0],
                parent: this.currentItem.parent()[0]
            };
            this.helper[0] != this.currentItem[0] && this.currentItem.hide();
            this._createPlaceholder();
            d.containment && this._setContainment();
            d.cursor && (b("body").css("cursor") && (this._storedCursor = b("body").css("cursor")), b("body").css("cursor", d.cursor));
            d.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", d.opacity));
            d.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", d.zIndex));
            this.scrollParent[0] != document && "HTML" != this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset());
            this._trigger("start", a, this._uiHash());
            this._preserveHelperProportions || this._cacheHelperProportions();
            if (!c)
                for (c = this.containers.length - 1; 0 <= c; c--) this.containers[c]._trigger("activate", a, this._uiHash(this));
            b.ui.ddmanager && (b.ui.ddmanager.current = this);
            b.ui.ddmanager && !d.dropBehaviour && b.ui.ddmanager.prepareOffsets(this, a);
            this.dragging = !0;
            this.helper.addClass("ui-sortable-helper");
            this._mouseDrag(a);
            return !0
        },
        _mouseDrag: function(a) {
            this.position = this._generatePosition(a);
            this.positionAbs = this._convertPositionTo("absolute");
            this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs);
            if (this.options.scroll) {
                var d = this.options,
                    c = !1;
                this.scrollParent[0] != document && "HTML" != this.scrollParent[0].tagName ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - a.pageY < d.scrollSensitivity ? this.scrollParent[0].scrollTop = c = this.scrollParent[0].scrollTop + d.scrollSpeed : a.pageY - this.overflowOffset.top < d.scrollSensitivity && (this.scrollParent[0].scrollTop = c = this.scrollParent[0].scrollTop - d.scrollSpeed), this.overflowOffset.left +
                    this.scrollParent[0].offsetWidth - a.pageX < d.scrollSensitivity ? this.scrollParent[0].scrollLeft = c = this.scrollParent[0].scrollLeft + d.scrollSpeed : a.pageX - this.overflowOffset.left < d.scrollSensitivity && (this.scrollParent[0].scrollLeft = c = this.scrollParent[0].scrollLeft - d.scrollSpeed)) : (a.pageY - b(document).scrollTop() < d.scrollSensitivity ? c = b(document).scrollTop(b(document).scrollTop() - d.scrollSpeed) : b(window).height() - (a.pageY - b(document).scrollTop()) < d.scrollSensitivity && (c = b(document).scrollTop(b(document).scrollTop() +
                    d.scrollSpeed)), a.pageX - b(document).scrollLeft() < d.scrollSensitivity ? c = b(document).scrollLeft(b(document).scrollLeft() - d.scrollSpeed) : b(window).width() - (a.pageX - b(document).scrollLeft()) < d.scrollSensitivity && (c = b(document).scrollLeft(b(document).scrollLeft() + d.scrollSpeed)));
                !1 !== c && b.ui.ddmanager && !d.dropBehaviour && b.ui.ddmanager.prepareOffsets(this, a)
            }
            this.positionAbs = this._convertPositionTo("absolute");
            this.options.axis && "y" == this.options.axis || (this.helper[0].style.left = this.position.left + "px");
            this.options.axis && "x" == this.options.axis || (this.helper[0].style.top = this.position.top + "px");
            for (d = this.items.length - 1; 0 <= d; d--) {
                var c = this.items[d],
                    g = c.item[0],
                    e = this._intersectsWithPointer(c);
                if (e && g != this.currentItem[0] && this.placeholder[1 == e ? "next" : "prev"]()[0] != g && !b.contains(this.placeholder[0], g) && ("semi-dynamic" == this.options.type ? !b.contains(this.element[0], g) : 1)) {
                    this.direction = 1 == e ? "down" : "up";
                    if ("pointer" == this.options.tolerance || this._intersectsWithSides(c)) this._rearrange(a, c);
                    else break;
                    this._trigger("change", a, this._uiHash());
                    break
                }
            }
            this._contactContainers(a);
            b.ui.ddmanager && b.ui.ddmanager.drag(this, a);
            this._trigger("sort", a, this._uiHash());
            this.lastPositionAbs = this.positionAbs;
            return !1
        },
        _mouseStop: function(a, d) {
            if (a) {
                b.ui.ddmanager && !this.options.dropBehaviour && b.ui.ddmanager.drop(this, a);
                if (this.options.revert) {
                    var c = this,
                        g = c.placeholder.offset();
                    c.reverting = !0;
                    b(this.helper).animate({
                        left: g.left - this.offset.parent.left - c.margins.left + (this.offsetParent[0] == document.body ? 0 : this.offsetParent[0].scrollLeft),
                        top: g.top - this.offset.parent.top - c.margins.top + (this.offsetParent[0] == document.body ? 0 : this.offsetParent[0].scrollTop)
                    }, parseInt(this.options.revert, 10) || 500, function() {
                        c._clear(a)
                    })
                } else this._clear(a, d);
                return !1
            }
        },
        cancel: function() {
            if (this.dragging) {
                this._mouseUp({
                    target: null
                });
                "original" == this.options.helper ? this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper") : this.currentItem.show();
                for (var a = this.containers.length - 1; 0 <= a; a--) this.containers[a]._trigger("deactivate", null, this._uiHash(this)),
                    this.containers[a].containerCache.over && (this.containers[a]._trigger("out", null, this._uiHash(this)), this.containers[a].containerCache.over = 0)
            }
            this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), "original" != this.options.helper && this.helper && this.helper[0].parentNode && this.helper.remove(), b.extend(this, {
                helper: null,
                dragging: !1,
                reverting: !1,
                _noFinalSort: null
            }), this.domPosition.prev ? b(this.domPosition.prev).after(this.currentItem) : b(this.domPosition.parent).prepend(this.currentItem));
            return this
        },
        serialize: function(a) {
            var d = this._getItemsAsjQuery(a && a.connected),
                c = [];
            a = a || {};
            b(d).each(function() {
                var d = (b(a.item || this).attr(a.attribute || "id") || "").match(a.expression || /(.+)[-=_](.+)/);
                d && c.push((a.key || d[1] + "[]") + "=" + (a.key && a.expression ? d[1] : d[2]))
            });
            !c.length && a.key && c.push(a.key + "=");
            return c.join("&")
        },
        toArray: function(a) {
            var d = this._getItemsAsjQuery(a && a.connected),
                c = [];
            a = a || {};
            d.each(function() {
                c.push(b(a.item || this).attr(a.attribute || "id") || "")
            });
            return c
        },
        _intersectsWith: function(b) {
            var d =
                this.positionAbs.left,
                c = d + this.helperProportions.width,
                g = this.positionAbs.top,
                e = g + this.helperProportions.height,
                f = b.left,
                h = f + b.width,
                k = b.top,
                n = k + b.height,
                m = this.offset.click.top,
                p = this.offset.click.left;
            return "pointer" == this.options.tolerance || this.options.forcePointerForContainers || "pointer" != this.options.tolerance && this.helperProportions[this.floating ? "width" : "height"] > b[this.floating ? "width" : "height"] ? g + m > k && g + m < n && d + p > f && d + p < h : f < d + this.helperProportions.width / 2 && c - this.helperProportions.width /
                2 < h && k < g + this.helperProportions.height / 2 && e - this.helperProportions.height / 2 < n
        },
        _intersectsWithPointer: function(a) {
            var d = b.ui.isOverAxis(this.positionAbs.top + this.offset.click.top, a.top, a.height);
            a = b.ui.isOverAxis(this.positionAbs.left + this.offset.click.left, a.left, a.width);
            d = d && a;
            a = this._getDragVerticalDirection();
            var c = this._getDragHorizontalDirection();
            return d ? this.floating ? c && "right" == c || "down" == a ? 2 : 1 : a && ("down" == a ? 2 : 1) : !1
        },
        _intersectsWithSides: function(a) {
            var d = b.ui.isOverAxis(this.positionAbs.top +
                this.offset.click.top, a.top + a.height / 2, a.height);
            a = b.ui.isOverAxis(this.positionAbs.left + this.offset.click.left, a.left + a.width / 2, a.width);
            var c = this._getDragVerticalDirection(),
                g = this._getDragHorizontalDirection();
            return this.floating && g ? "right" == g && a || "left" == g && !a : c && ("down" == c && d || "up" == c && !d)
        },
        _getDragVerticalDirection: function() {
            var b = this.positionAbs.top - this.lastPositionAbs.top;
            return 0 != b && (0 < b ? "down" : "up")
        },
        _getDragHorizontalDirection: function() {
            var b = this.positionAbs.left - this.lastPositionAbs.left;
            return 0 != b && (0 < b ? "right" : "left")
        },
        refresh: function(b) {
            this._refreshItems(b);
            this.refreshPositions();
            return this
        },
        _connectWith: function() {
            var b = this.options;
            return b.connectWith.constructor == String ? [b.connectWith] : b.connectWith
        },
        _getItemsAsjQuery: function(a) {
            var d = [],
                c = [],
                g = this._connectWith();
            if (g && a)
                for (a = g.length - 1; 0 <= a; a--)
                    for (var e = b(g[a]), f = e.length - 1; 0 <= f; f--) {
                        var h = b.data(e[f], "sortable");
                        h && h != this && !h.options.disabled && c.push([b.isFunction(h.options.items) ? h.options.items.call(h.element) :
                            b(h.options.items, h.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), h
                        ])
                    }
            c.push([b.isFunction(this.options.items) ? this.options.items.call(this.element, null, {
                options: this.options,
                item: this.currentItem
            }) : b(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]);
            for (a = c.length - 1; 0 <= a; a--) c[a][0].each(function() {
                d.push(this)
            });
            return b(d)
        },
        _removeCurrentsFromItems: function() {
            for (var b = this.currentItem.find(":data(sortable-item)"), d = 0; d < this.items.length; d++)
                for (var c =
                        0; c < b.length; c++) b[c] == this.items[d].item[0] && this.items.splice(d, 1)
        },
        _refreshItems: function(a) {
            this.items = [];
            this.containers = [this];
            var d = this.items,
                c = [
                    [b.isFunction(this.options.items) ? this.options.items.call(this.element[0], a, {
                        item: this.currentItem
                    }) : b(this.options.items, this.element), this]
                ],
                g = this._connectWith();
            if (g)
                for (var e = g.length - 1; 0 <= e; e--)
                    for (var f = b(g[e]), h = f.length - 1; 0 <= h; h--) {
                        var k = b.data(f[h], "sortable");
                        k && k != this && !k.options.disabled && (c.push([b.isFunction(k.options.items) ? k.options.items.call(k.element[0],
                            a, {
                                item: this.currentItem
                            }) : b(k.options.items, k.element), k]), this.containers.push(k))
                    }
            for (e = c.length - 1; 0 <= e; e--)
                for (a = c[e][1], g = c[e][0], h = 0, f = g.length; h < f; h++) k = b(g[h]), k.data("sortable-item", a), d.push({
                    item: k,
                    instance: a,
                    width: 0,
                    height: 0,
                    left: 0,
                    top: 0
                })
        },
        refreshPositions: function(a) {
            this.offsetParent && this.helper && (this.offset.parent = this._getParentOffset());
            for (var d = this.items.length - 1; 0 <= d; d--) {
                var c = this.items[d];
                if (c.instance == this.currentContainer || !this.currentContainer || c.item[0] == this.currentItem[0]) {
                    var g =
                        this.options.toleranceElement ? b(this.options.toleranceElement, c.item) : c.item;
                    a || (c.width = g.outerWidth(), c.height = g.outerHeight());
                    g = g.offset();
                    c.left = g.left;
                    c.top = g.top
                }
            }
            if (this.options.custom && this.options.custom.refreshContainers) this.options.custom.refreshContainers.call(this);
            else
                for (d = this.containers.length - 1; 0 <= d; d--) g = this.containers[d].element.offset(), this.containers[d].containerCache.left = g.left, this.containers[d].containerCache.top = g.top, this.containers[d].containerCache.width = this.containers[d].element.outerWidth(),
                    this.containers[d].containerCache.height = this.containers[d].element.outerHeight();
            return this
        },
        _createPlaceholder: function(a) {
            var d = a || this,
                c = d.options;
            if (!c.placeholder || c.placeholder.constructor == String) {
                var g = c.placeholder;
                c.placeholder = {
                    element: function() {
                        var a = b(document.createElement(d.currentItem[0].nodeName)).addClass(g || d.currentItem[0].className + " ui-sortable-placeholder").removeClass("ui-sortable-helper")[0];
                        g || (a.style.visibility = "hidden");
                        return a
                    },
                    update: function(b, a) {
                        if (!g || c.forcePlaceholderSize) a.height() ||
                            a.height(d.currentItem.innerHeight() - parseInt(d.currentItem.css("paddingTop") || 0, 10) - parseInt(d.currentItem.css("paddingBottom") || 0, 10)), a.width() || a.width(d.currentItem.innerWidth() - parseInt(d.currentItem.css("paddingLeft") || 0, 10) - parseInt(d.currentItem.css("paddingRight") || 0, 10))
                    }
                }
            }
            d.placeholder = b(c.placeholder.element.call(d.element, d.currentItem));
            d.currentItem.after(d.placeholder);
            c.placeholder.update(d, d.placeholder)
        },
        _contactContainers: function(a) {
            for (var d = null, c = null, g = this.containers.length -
                    1; 0 <= g; g--) b.contains(this.currentItem[0], this.containers[g].element[0]) || (this._intersectsWith(this.containers[g].containerCache) ? d && b.contains(this.containers[g].element[0], d.element[0]) || (d = this.containers[g], c = g) : this.containers[g].containerCache.over && (this.containers[g]._trigger("out", a, this._uiHash(this)), this.containers[g].containerCache.over = 0));
            if (d)
                if (1 === this.containers.length) this.containers[c]._trigger("over", a, this._uiHash(this)), this.containers[c].containerCache.over = 1;
                else if (this.currentContainer !=
                this.containers[c]) {
                for (var d = 1E4, g = null, e = this.positionAbs[this.containers[c].floating ? "left" : "top"], f = this.items.length - 1; 0 <= f; f--)
                    if (b.contains(this.containers[c].element[0], this.items[f].item[0])) {
                        var h = this.items[f][this.containers[c].floating ? "left" : "top"];
                        Math.abs(h - e) < d && (d = Math.abs(h - e), g = this.items[f])
                    }
                if (g || this.options.dropOnEmpty) this.currentContainer = this.containers[c], g ? this._rearrange(a, g, null, !0) : this._rearrange(a, null, this.containers[c].element, !0), this._trigger("change", a, this._uiHash()),
                    this.containers[c]._trigger("change", a, this._uiHash(this)), this.options.placeholder.update(this.currentContainer, this.placeholder), this.containers[c]._trigger("over", a, this._uiHash(this)), this.containers[c].containerCache.over = 1
            }
        },
        _createHelper: function(a) {
            var d = this.options;
            a = b.isFunction(d.helper) ? b(d.helper.apply(this.element[0], [a, this.currentItem])) : "clone" == d.helper ? this.currentItem.clone() : this.currentItem;
            a.parents("body").length || b("parent" != d.appendTo ? d.appendTo : this.currentItem[0].parentNode)[0].appendChild(a[0]);
            a[0] == this.currentItem[0] && (this._storedCSS = {
                width: this.currentItem[0].style.width,
                height: this.currentItem[0].style.height,
                position: this.currentItem.css("position"),
                top: this.currentItem.css("top"),
                left: this.currentItem.css("left")
            });
            ("" == a[0].style.width || d.forceHelperSize) && a.width(this.currentItem.width());
            ("" == a[0].style.height || d.forceHelperSize) && a.height(this.currentItem.height());
            return a
        },
        _adjustOffsetFromHelper: function(a) {
            "string" == typeof a && (a = a.split(" "));
            b.isArray(a) && (a = {
                left: +a[0],
                top: +a[1] || 0
            });
            "left" in a && (this.offset.click.left = a.left + this.margins.left);
            "right" in a && (this.offset.click.left = this.helperProportions.width - a.right + this.margins.left);
            "top" in a && (this.offset.click.top = a.top + this.margins.top);
            "bottom" in a && (this.offset.click.top = this.helperProportions.height - a.bottom + this.margins.top)
        },
        _getParentOffset: function() {
            this.offsetParent = this.helper.offsetParent();
            var a = this.offsetParent.offset();
            "absolute" == this.cssPosition && this.scrollParent[0] != document && b.contains(this.scrollParent[0],
                this.offsetParent[0]) && (a.left += this.scrollParent.scrollLeft(), a.top += this.scrollParent.scrollTop());
            if (this.offsetParent[0] == document.body || this.offsetParent[0].tagName && "html" == this.offsetParent[0].tagName.toLowerCase() && b.browser.msie) a = {
                top: 0,
                left: 0
            };
            return {
                top: a.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: a.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function() {
            if ("relative" == this.cssPosition) {
                var b = this.currentItem.position();
                return {
                    top: b.top -
                        (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                    left: b.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                }
            }
            return {
                top: 0,
                left: 0
            }
        },
        _cacheMargins: function() {
            this.margins = {
                left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
                top: parseInt(this.currentItem.css("marginTop"), 10) || 0
            }
        },
        _cacheHelperProportions: function() {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function() {
            var a = this.options;
            "parent" == a.containment && (a.containment = this.helper[0].parentNode);
            if ("document" == a.containment || "window" == a.containment) this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, b("document" == a.containment ? document : window).width() - this.helperProportions.width - this.margins.left, (b("document" == a.containment ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top];
            if (!/^(document|window|parent)$/.test(a.containment)) {
                var d =
                    b(a.containment)[0],
                    a = b(a.containment).offset(),
                    c = "hidden" != b(d).css("overflow");
                this.containment = [a.left + (parseInt(b(d).css("borderLeftWidth"), 10) || 0) + (parseInt(b(d).css("paddingLeft"), 10) || 0) - this.margins.left, a.top + (parseInt(b(d).css("borderTopWidth"), 10) || 0) + (parseInt(b(d).css("paddingTop"), 10) || 0) - this.margins.top, a.left + (c ? Math.max(d.scrollWidth, d.offsetWidth) : d.offsetWidth) - (parseInt(b(d).css("borderLeftWidth"), 10) || 0) - (parseInt(b(d).css("paddingRight"), 10) || 0) - this.helperProportions.width -
                    this.margins.left, a.top + (c ? Math.max(d.scrollHeight, d.offsetHeight) : d.offsetHeight) - (parseInt(b(d).css("borderTopWidth"), 10) || 0) - (parseInt(b(d).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top
                ]
            }
        },
        _convertPositionTo: function(a, d) {
            d || (d = this.position);
            var c = "absolute" == a ? 1 : -1,
                g = "absolute" != this.cssPosition || this.scrollParent[0] != document && b.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                e = /(html|body)/i.test(g[0].tagName);
            return {
                top: d.top +
                    this.offset.relative.top * c + this.offset.parent.top * c - (b.browser.safari && "fixed" == this.cssPosition ? 0 : ("fixed" == this.cssPosition ? -this.scrollParent.scrollTop() : e ? 0 : g.scrollTop()) * c),
                left: d.left + this.offset.relative.left * c + this.offset.parent.left * c - (b.browser.safari && "fixed" == this.cssPosition ? 0 : ("fixed" == this.cssPosition ? -this.scrollParent.scrollLeft() : e ? 0 : g.scrollLeft()) * c)
            }
        },
        _generatePosition: function(a) {
            var d = this.options,
                c = "absolute" != this.cssPosition || this.scrollParent[0] != document && b.contains(this.scrollParent[0],
                    this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                g = /(html|body)/i.test(c[0].tagName);
            "relative" != this.cssPosition || this.scrollParent[0] != document && this.scrollParent[0] != this.offsetParent[0] || (this.offset.relative = this._getRelativeOffset());
            var e = a.pageX,
                f = a.pageY;
            this.originalPosition && (this.containment && (a.pageX - this.offset.click.left < this.containment[0] && (e = this.containment[0] + this.offset.click.left), a.pageY - this.offset.click.top < this.containment[1] && (f = this.containment[1] + this.offset.click.top),
                a.pageX - this.offset.click.left > this.containment[2] && (e = this.containment[2] + this.offset.click.left), a.pageY - this.offset.click.top > this.containment[3] && (f = this.containment[3] + this.offset.click.top)), d.grid && (f = this.originalPageY + Math.round((f - this.originalPageY) / d.grid[1]) * d.grid[1], f = this.containment ? f - this.offset.click.top < this.containment[1] || f - this.offset.click.top > this.containment[3] ? f - this.offset.click.top < this.containment[1] ? f + d.grid[1] : f - d.grid[1] : f : f, e = this.originalPageX + Math.round((e - this.originalPageX) /
                d.grid[0]) * d.grid[0], e = this.containment ? e - this.offset.click.left < this.containment[0] || e - this.offset.click.left > this.containment[2] ? e - this.offset.click.left < this.containment[0] ? e + d.grid[0] : e - d.grid[0] : e : e));
            return {
                top: f - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (b.browser.safari && "fixed" == this.cssPosition ? 0 : "fixed" == this.cssPosition ? -this.scrollParent.scrollTop() : g ? 0 : c.scrollTop()),
                left: e - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (b.browser.safari &&
                    "fixed" == this.cssPosition ? 0 : "fixed" == this.cssPosition ? -this.scrollParent.scrollLeft() : g ? 0 : c.scrollLeft())
            }
        },
        _rearrange: function(b, d, c, g) {
            c ? c[0].appendChild(this.placeholder[0]) : d.item[0].parentNode.insertBefore(this.placeholder[0], "down" == this.direction ? d.item[0] : d.item[0].nextSibling);
            this.counter = this.counter ? ++this.counter : 1;
            var e = this,
                f = this.counter;
            window.setTimeout(function() {
                f == e.counter && e.refreshPositions(!g)
            }, 0)
        },
        _clear: function(a, d) {
            this.reverting = !1;
            var c = [];
            !this._noFinalSort && this.currentItem[0].parentNode &&
                this.placeholder.before(this.currentItem);
            this._noFinalSort = null;
            if (this.helper[0] == this.currentItem[0]) {
                for (var g in this._storedCSS)
                    if ("auto" == this._storedCSS[g] || "static" == this._storedCSS[g]) this._storedCSS[g] = "";
                this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper")
            } else this.currentItem.show();
            this.fromOutside && !d && c.push(function(b) {
                this._trigger("receive", b, this._uiHash(this.fromOutside))
            });
            !this.fromOutside && this.domPosition.prev == this.currentItem.prev().not(".ui-sortable-helper")[0] &&
                this.domPosition.parent == this.currentItem.parent()[0] || d || c.push(function(b) {
                    this._trigger("update", b, this._uiHash())
                });
            if (!b.contains(this.element[0], this.currentItem[0]))
                for (d || c.push(function(b) {
                        this._trigger("remove", b, this._uiHash())
                    }), g = this.containers.length - 1; 0 <= g; g--) b.contains(this.containers[g].element[0], this.currentItem[0]) && !d && (c.push(function(b) {
                    return function(a) {
                        b._trigger("receive", a, this._uiHash(this))
                    }
                }.call(this, this.containers[g])), c.push(function(b) {
                    return function(a) {
                        b._trigger("update",
                            a, this._uiHash(this))
                    }
                }.call(this, this.containers[g])));
            for (g = this.containers.length - 1; 0 <= g; g--) d || c.push(function(b) {
                return function(a) {
                    b._trigger("deactivate", a, this._uiHash(this))
                }
            }.call(this, this.containers[g])), this.containers[g].containerCache.over && (c.push(function(b) {
                return function(a) {
                    b._trigger("out", a, this._uiHash(this))
                }
            }.call(this, this.containers[g])), this.containers[g].containerCache.over = 0);
            this._storedCursor && b("body").css("cursor", this._storedCursor);
            this._storedOpacity && this.helper.css("opacity",
                this._storedOpacity);
            this._storedZIndex && this.helper.css("zIndex", "auto" == this._storedZIndex ? "" : this._storedZIndex);
            this.dragging = !1;
            if (this.cancelHelperRemoval) {
                if (!d) {
                    this._trigger("beforeStop", a, this._uiHash());
                    for (g = 0; g < c.length; g++) c[g].call(this, a);
                    this._trigger("stop", a, this._uiHash())
                }
                return !1
            }
            d || this._trigger("beforeStop", a, this._uiHash());
            this.placeholder[0].parentNode.removeChild(this.placeholder[0]);
            this.helper[0] != this.currentItem[0] && this.helper.remove();
            this.helper = null;
            if (!d) {
                for (g =
                    0; g < c.length; g++) c[g].call(this, a);
                this._trigger("stop", a, this._uiHash())
            }
            this.fromOutside = !1;
            return !0
        },
        _trigger: function() {
            !1 === b.Widget.prototype._trigger.apply(this, arguments) && this.cancel()
        },
        _uiHash: function(a) {
            var d = a || this;
            return {
                helper: d.helper,
                placeholder: d.placeholder || b([]),
                position: d.position,
                originalPosition: d.originalPosition,
                offset: d.positionAbs,
                item: d.currentItem,
                sender: a ? a.element : null
            }
        }
    });
    b.extend(b.ui.sortable, {
        version: "1.9m5"
    })
})(jQuery);
jQuery.effects || function(b, l) {
    function a(a) {
        var c;
        return a && a.constructor === Array && 3 === a.length ? a : (c = /rgb\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*\)/.exec(a)) ? [parseInt(c[1], 10), parseInt(c[2], 10), parseInt(c[3], 10)] : (c = /rgb\(\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*\)/.exec(a)) ? [2.55 * parseFloat(c[1]), 2.55 * parseFloat(c[2]), 2.55 * parseFloat(c[3])] : (c = /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec(a)) ? [parseInt(c[1], 16), parseInt(c[2],
            16), parseInt(c[3], 16)] : (c = /#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/.exec(a)) ? [parseInt(c[1] + c[1], 16), parseInt(c[2] + c[2], 16), parseInt(c[3] + c[3], 16)] : /rgba\(0, 0, 0, 0\)/.exec(a) ? f.transparent : f[b.trim(a).toLowerCase()]
    }

    function d() {
        var a = document.defaultView ? document.defaultView.getComputedStyle(this, null) : this.currentStyle,
            c = {},
            f, d;
        if (a && a.length && a[0] && a[a[0]])
            for (d = a.length; d--;) f = a[d], "string" === typeof a[f] && (c[b.camelCase(f)] = a[f]);
        else
            for (f in a) "string" === typeof a[f] && (c[f] = a[f]);
        return c
    }

    function c(a, c, f, d) {
        if (b.isPlainObject(a)) return a;
        a = {
            effect: a
        };
        c === l && (c = {});
        b.isFunction(c) && (d = c, f = null, c = {});
        if ("number" === b.type(c) || b.fx.speeds[c]) d = f, f = c, c = {};
        b.isFunction(f) && (d = f, f = null);
        c && b.extend(a, c);
        f = f || c.duration;
        a.duration = b.fx.off ? 0 : "number" === typeof f ? f : f in b.fx.speeds ? b.fx.speeds[f] : b.fx.speeds._default;
        a.complete = d || c.complete;
        return a
    }

    function g(a) {
        return !a || "number" === typeof a || b.fx.speeds[a] ? !0 : "string" !== typeof a || b.effects.effect[a] ? !1 : e && b.effects[a] ? !1 : !0
    }
    var e = !1 !== b.uiBackCompat;
    b.effects = {
        effect: {}
    };
    b.each("backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor borderColor color outlineColor".split(" "), function(c, f) {
        b.fx.step[f] = function(c) {
            if (!c.colorInit) {
                var d;
                d = c.elem;
                var h = f,
                    e;
                do {
                    e = b.curCSS(d, h);
                    if ("" != e && "transparent" !== e || b.nodeName(d, "body")) break;
                    h = "backgroundColor"
                } while (d = d.parentNode);
                d = a(e);
                c.start = d;
                c.end = a(c.end);
                c.colorInit = !0
            }
            c.elem.style[f] = "rgb(" + Math.max(Math.min(parseInt(c.pos * (c.end[0] - c.start[0]) + c.start[0], 10), 255), 0) +
                "," + Math.max(Math.min(parseInt(c.pos * (c.end[1] - c.start[1]) + c.start[1], 10), 255), 0) + "," + Math.max(Math.min(parseInt(c.pos * (c.end[2] - c.start[2]) + c.start[2], 10), 255), 0) + ")"
        }
    });
    var f = {
            aqua: [0, 255, 255],
            azure: [240, 255, 255],
            beige: [245, 245, 220],
            black: [0, 0, 0],
            blue: [0, 0, 255],
            brown: [165, 42, 42],
            cyan: [0, 255, 255],
            darkblue: [0, 0, 139],
            darkcyan: [0, 139, 139],
            darkgrey: [169, 169, 169],
            darkgreen: [0, 100, 0],
            darkkhaki: [189, 183, 107],
            darkmagenta: [139, 0, 139],
            darkolivegreen: [85, 107, 47],
            darkorange: [255, 140, 0],
            darkorchid: [153, 50, 204],
            darkred: [139, 0, 0],
            darksalmon: [233, 150, 122],
            darkviolet: [148, 0, 211],
            fuchsia: [255, 0, 255],
            gold: [255, 215, 0],
            green: [0, 128, 0],
            indigo: [75, 0, 130],
            khaki: [240, 230, 140],
            lightblue: [173, 216, 230],
            lightcyan: [224, 255, 255],
            lightgreen: [144, 238, 144],
            lightgrey: [211, 211, 211],
            lightpink: [255, 182, 193],
            lightyellow: [255, 255, 224],
            lime: [0, 255, 0],
            magenta: [255, 0, 255],
            maroon: [128, 0, 0],
            navy: [0, 0, 128],
            olive: [128, 128, 0],
            orange: [255, 165, 0],
            pink: [255, 192, 203],
            purple: [128, 0, 128],
            violet: [128, 0, 128],
            red: [255, 0, 0],
            silver: [192, 192, 192],
            white: [255,
                255, 255
            ],
            yellow: [255, 255, 0],
            transparent: [255, 255, 255]
        },
        h = ["add", "remove", "toggle"],
        k = {
            border: 1,
            borderBottom: 1,
            borderColor: 1,
            borderLeft: 1,
            borderRight: 1,
            borderTop: 1,
            borderWidth: 1,
            margin: 1,
            padding: 1
        };
    b.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(a, c) {
        b.fx.step[c] = function(b) {
            if ("none" !== b.end && !b.setAttr || 1 === b.pos && !b.setAttr) jQuery.style(b.elem, c, b.end), b.setAttr = !0
        }
    });
    b.effects.animateClass = function(a, c, f, e) {
        var g = b.speed(c, f, e);
        return this.queue(function() {
            var c =
                b(this),
                f = c.attr("class"),
                e, m = g.children ? c.find("*").andSelf() : c,
                m = m.map(function() {
                    var a = b(this);
                    return {
                        el: a,
                        originalStyleAttr: a.attr("style") || " ",
                        start: d.call(this)
                    }
                });
            b.each(h, function(b, f) {
                if (a[f]) c[f + "Class"](a[f])
            });
            e = c.attr("class");
            m = m.map(function() {
                this.end = d.call(this.el[0]);
                var a = this.start,
                    c = this.end,
                    f = {},
                    h, e;
                for (h in c) e = c[h], a[h] == e || k[h] || !b.fx.step[h] && isNaN(parseFloat(e)) || (f[h] = e);
                this.diff = f;
                return this
            });
            c.attr("class", f);
            m = m.map(function() {
                var a = this,
                    c = b.Deferred();
                this.el.animate(this.diff, {
                    duration: g.duration,
                    easing: g.easing,
                    queue: !1,
                    complete: function() {
                        c.resolve(a)
                    }
                });
                return c.promise()
            });
            b.when.apply(b, m.get()).done(function() {
                c.attr("class", e);
                b.each(arguments, function() {
                    "object" === typeof this.el.attr("style") ? (this.el.attr("style").cssText = "", this.el.attr("style").cssText = this.originalStyleAttr) : this.el.attr("style", this.originalStyleAttr)
                });
                g.complete.call(c[0])
            })
        })
    };
    b.fn.extend({
        _addClass: b.fn.addClass,
        addClass: function(a, c, f, d) {
            return c ? b.effects.animateClass.apply(this, [{
                    add: a
                },
                c, f, d
            ]) : this._addClass(a)
        },
        _removeClass: b.fn.removeClass,
        removeClass: function(a, c, f, d) {
            return c ? b.effects.animateClass.apply(this, [{
                remove: a
            }, c, f, d]) : this._removeClass(a)
        },
        _toggleClass: b.fn.toggleClass,
        toggleClass: function(a, c, f, d, h) {
            return "boolean" === typeof c || c === l ? f ? b.effects.animateClass.apply(this, [c ? {
                add: a
            } : {
                remove: a
            }, f, d, h]) : this._toggleClass(a, c) : b.effects.animateClass.apply(this, [{
                toggle: a
            }, c, f, d])
        },
        switchClass: function(a, c, f, d, h) {
            return b.effects.animateClass.apply(this, [{
                    add: c,
                    remove: a
                },
                f, d, h
            ])
        }
    });
    b.extend(b.effects, {
        version: "1.9m5",
        save: function(b, a) {
            for (var c = 0; c < a.length; c++) null !== a[c] && b.data("ec.storage." + a[c], b[0].style[a[c]])
        },
        restore: function(b, a) {
            for (var c = 0; c < a.length; c++) null !== a[c] && b.css(a[c], b.data("ec.storage." + a[c]))
        },
        setMode: function(b, a) {
            "toggle" === a && (a = b.is(":hidden") ? "show" : "hide");
            return a
        },
        getBaseline: function(b, a) {
            var c, f;
            switch (b[0]) {
                case "top":
                    c = 0;
                    break;
                case "middle":
                    c = .5;
                    break;
                case "bottom":
                    c = 1;
                    break;
                default:
                    c = b[0] / a.height
            }
            switch (b[1]) {
                case "left":
                    f =
                        0;
                    break;
                case "center":
                    f = .5;
                    break;
                case "right":
                    f = 1;
                    break;
                default:
                    f = b[1] / a.width
            }
            return {
                x: f,
                y: c
            }
        },
        createWrapper: function(a) {
            if (a.parent().is(".ui-effects-wrapper")) return a.parent();
            var c = {
                    width: a.outerWidth(!0),
                    height: a.outerHeight(!0),
                    "float": a.css("float")
                },
                f = b("<div></div>").addClass("ui-effects-wrapper").css({
                    fontSize: "100%",
                    background: "transparent",
                    border: "none",
                    margin: 0,
                    padding: 0
                });
            a.wrap(f);
            f = a.parent();
            "static" === a.css("position") ? (f.css({
                    position: "relative"
                }), a.css({
                    position: "relative"
                })) :
                (b.extend(c, {
                    position: a.css("position"),
                    zIndex: a.css("z-index")
                }), b.each(["top", "left", "bottom", "right"], function(b, f) {
                    c[f] = a.css(f);
                    isNaN(parseInt(c[f], 10)) && (c[f] = "auto")
                }), a.css({
                    position: "relative",
                    top: 0,
                    left: 0,
                    right: "auto",
                    bottom: "auto"
                }));
            return f.css(c).show()
        },
        removeWrapper: function(b) {
            return b.parent().is(".ui-effects-wrapper") ? b.parent().replaceWith(b) : b
        },
        setTransition: function(a, c, f, d) {
            d = d || {};
            b.each(c, function(b, c) {
                var h = a.cssUnit(c);
                0 < h[0] && (d[c] = h[0] * f + h[1])
            });
            return d
        }
    });
    b.fn.extend({
        effect: function(a,
            f, d, h) {
            var g = c.apply(this, arguments),
                k = g.mode,
                l = b.effects.effect[g.effect],
                w = !l && e && b.effects[g.effect];
            return b.fx.off || !l && !w ? k ? this[k](g.duration, g.complete) : this.each(function() {
                g.complete && g.complete.call(this)
            }) : l ? l.call(this, g) : w.call(this, {
                options: g,
                duration: g.duration,
                callback: g.complete,
                mode: g.mode
            })
        },
        _show: b.fn.show,
        show: function(b) {
            if (g(b)) return this._show.apply(this, arguments);
            var a = c.apply(this, arguments);
            a.mode = "show";
            return this.effect.call(this, a)
        },
        _hide: b.fn.hide,
        hide: function(b) {
            if (g(b)) return this._hide.apply(this,
                arguments);
            var a = c.apply(this, arguments);
            a.mode = "hide";
            return this.effect.call(this, a)
        },
        __toggle: b.fn.toggle,
        toggle: function(a) {
            if (g(a) || "boolean" === typeof a || b.isFunction(a)) return this.__toggle.apply(this, arguments);
            var f = c.apply(this, arguments);
            f.mode = "toggle";
            return this.effect.call(this, f)
        },
        cssUnit: function(a) {
            var c = this.css(a),
                f = [];
            b.each(["em", "px", "%", "pt"], function(b, a) {
                0 < c.indexOf(a) && (f = [parseFloat(c), a])
            });
            return f
        }
    });
    b.easing.jswing = b.easing.swing;
    b.extend(b.easing, {
        def: "easeOutQuad",
        swing: function(a, c, f, d, h) {
            return b.easing[b.easing.def](a, c, f, d, h)
        },
        easeInQuad: function(b, a, c, f, d) {
            return f * (a /= d) * a + c
        },
        easeOutQuad: function(b, a, c, f, d) {
            return -f * (a /= d) * (a - 2) + c
        },
        easeInOutQuad: function(b, a, c, f, d) {
            return 1 > (a /= d / 2) ? f / 2 * a * a + c : -f / 2 * (--a * (a - 2) - 1) + c
        },
        easeInCubic: function(b, a, c, f, d) {
            return f * (a /= d) * a * a + c
        },
        easeOutCubic: function(b, a, c, f, d) {
            return f * ((a = a / d - 1) * a * a + 1) + c
        },
        easeInOutCubic: function(b, a, c, f, d) {
            return 1 > (a /= d / 2) ? f / 2 * a * a * a + c : f / 2 * ((a -= 2) * a * a + 2) + c
        },
        easeInQuart: function(b, a, c, f, d) {
            return f *
                (a /= d) * a * a * a + c
        },
        easeOutQuart: function(b, a, c, f, d) {
            return -f * ((a = a / d - 1) * a * a * a - 1) + c
        },
        easeInOutQuart: function(b, a, c, f, d) {
            return 1 > (a /= d / 2) ? f / 2 * a * a * a * a + c : -f / 2 * ((a -= 2) * a * a * a - 2) + c
        },
        easeInQuint: function(b, a, c, f, d) {
            return f * (a /= d) * a * a * a * a + c
        },
        easeOutQuint: function(b, a, c, f, d) {
            return f * ((a = a / d - 1) * a * a * a * a + 1) + c
        },
        easeInOutQuint: function(b, a, c, f, d) {
            return 1 > (a /= d / 2) ? f / 2 * a * a * a * a * a + c : f / 2 * ((a -= 2) * a * a * a * a + 2) + c
        },
        easeInSine: function(b, a, c, f, d) {
            return -f * Math.cos(a / d * (Math.PI / 2)) + f + c
        },
        easeOutSine: function(b, a, c, f, d) {
            return f *
                Math.sin(a / d * (Math.PI / 2)) + c
        },
        easeInOutSine: function(b, a, c, f, d) {
            return -f / 2 * (Math.cos(Math.PI * a / d) - 1) + c
        },
        easeInExpo: function(b, a, c, f, d) {
            return 0 == a ? c : f * Math.pow(2, 10 * (a / d - 1)) + c
        },
        easeOutExpo: function(b, a, c, f, d) {
            return a == d ? c + f : f * (-Math.pow(2, -10 * a / d) + 1) + c
        },
        easeInOutExpo: function(b, a, c, f, d) {
            return 0 == a ? c : a == d ? c + f : 1 > (a /= d / 2) ? f / 2 * Math.pow(2, 10 * (a - 1)) + c : f / 2 * (-Math.pow(2, -10 * --a) + 2) + c
        },
        easeInCirc: function(b, a, c, f, d) {
            return -f * (Math.sqrt(1 - (a /= d) * a) - 1) + c
        },
        easeOutCirc: function(b, a, c, f, d) {
            return f * Math.sqrt(1 -
                (a = a / d - 1) * a) + c
        },
        easeInOutCirc: function(b, a, c, f, d) {
            return 1 > (a /= d / 2) ? -f / 2 * (Math.sqrt(1 - a * a) - 1) + c : f / 2 * (Math.sqrt(1 - (a -= 2) * a) + 1) + c
        },
        easeInElastic: function(b, a, c, f, d) {
            b = 1.70158;
            var h = .3 * d,
                e = f;
            if (0 == a) return c;
            if (1 == (a /= d)) return c + f;
            e < Math.abs(f) ? (e = f, b = h / 4) : b = h / (2 * Math.PI) * Math.asin(f / e);
            return -(e * Math.pow(2, 10 * --a) * Math.sin(2 * (a * d - b) * Math.PI / h)) + c
        },
        easeOutElastic: function(b, a, c, f, d) {
            b = 1.70158;
            var h = .3 * d,
                e = f;
            if (0 == a) return c;
            if (1 == (a /= d)) return c + f;
            e < Math.abs(f) ? (e = f, b = h / 4) : b = h / (2 * Math.PI) * Math.asin(f /
                e);
            return e * Math.pow(2, -10 * a) * Math.sin(2 * (a * d - b) * Math.PI / h) + f + c
        },
        easeInOutElastic: function(b, a, c, f, d) {
            b = 1.70158;
            var h = .3 * d * 1.5,
                e = f;
            if (0 == a) return c;
            if (2 == (a /= d / 2)) return c + f;
            e < Math.abs(f) ? (e = f, b = h / 4) : b = h / (2 * Math.PI) * Math.asin(f / e);
            return 1 > a ? -.5 * e * Math.pow(2, 10 * --a) * Math.sin(2 * (a * d - b) * Math.PI / h) + c : e * Math.pow(2, -10 * --a) * Math.sin(2 * (a * d - b) * Math.PI / h) * .5 + f + c
        },
        easeInBack: function(b, a, c, f, d, h) {
            h == l && (h = 1.70158);
            return f * (a /= d) * a * ((h + 1) * a - h) + c
        },
        easeOutBack: function(b, a, c, f, d, h) {
            h == l && (h = 1.70158);
            return f *
                ((a = a / d - 1) * a * ((h + 1) * a + h) + 1) + c
        },
        easeInOutBack: function(b, a, c, f, d, h) {
            h == l && (h = 1.70158);
            return 1 > (a /= d / 2) ? f / 2 * a * a * (((h *= 1.525) + 1) * a - h) + c : f / 2 * ((a -= 2) * a * (((h *= 1.525) + 1) * a + h) + 2) + c
        },
        easeInBounce: function(a, c, f, d, h) {
            return d - b.easing.easeOutBounce(a, h - c, 0, d, h) + f
        },
        easeOutBounce: function(b, a, c, f, d) {
            return (a /= d) < 1 / 2.75 ? 7.5625 * f * a * a + c : a < 2 / 2.75 ? f * (7.5625 * (a -= 1.5 / 2.75) * a + .75) + c : a < 2.5 / 2.75 ? f * (7.5625 * (a -= 2.25 / 2.75) * a + .9375) + c : f * (7.5625 * (a -= 2.625 / 2.75) * a + .984375) + c
        },
        easeInOutBounce: function(a, c, f, d, h) {
            return c < h /
                2 ? .5 * b.easing.easeInBounce(a, 2 * c, 0, d, h) + f : .5 * b.easing.easeOutBounce(a, 2 * c - h, 0, d, h) + .5 * d + f
        }
    })
}(jQuery);
(function(b, l) {
    var a = /up|down|vertical/,
        d = /up|left|vertical|horizontal/;
    b.effects.effect.blind = function(c) {
        return this.queue(function() {
            var g = b(this),
                e = ["position", "top", "bottom", "left", "right"],
                f = b.effects.setMode(g, c.mode || "hide"),
                h = c.direction || "up",
                k = a.test(h),
                n = k ? "height" : "width",
                m = k ? "top" : "left",
                h = d.test(h),
                p = {},
                l, q;
            b.effects.save(g, e);
            g.show();
            l = b.effects.createWrapper(g).css({
                overflow: "hidden"
            });
            q = l[n]();
            p[n] = "show" === f ? q : 0;
            h || (g.css(k ? "bottom" : "right", 0).css(k ? "top" : "left", "").css({
                    position: "absolute"
                }),
                p[m] = "show" === f ? 0 : q);
            "show" == f && (l.css(n, 0), h || l.css(m, q));
            l.animate(p, {
                duration: c.duration,
                easing: c.easing,
                queue: !1,
                complete: function() {
                    "hide" == f && g.hide();
                    b.effects.restore(g, e);
                    b.effects.removeWrapper(g);
                    b.isFunction(c.complete) && c.complete.apply(g[0], arguments);
                    g.dequeue()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.bounce = function(a) {
        return this.queue(function(d) {
            var c = b(this),
                g = ["position", "top", "bottom", "left", "right"],
                e = b.effects.setMode(c, a.mode || "effect"),
                f = "hide" === e,
                h = "show" === e,
                k = a.direction || "up",
                e = a.distance,
                n = a.times || 5,
                m = 2 * n + (h || f ? 1 : 0),
                p = a.duration / m,
                l = a.easing,
                q = "up" === k || "down" === k ? "top" : "left",
                k = "up" === k || "left" === k,
                t, r, w = c.queue(),
                u = w.length;
            (h || f) && g.push("opacity");
            b.effects.save(c, g);
            c.show();
            b.effects.createWrapper(c);
            e || (e = c["top" === q ? "outerHeight" : "outerWidth"]() /
                3);
            h && (r = {
                opacity: 1
            }, r[q] = 0, c.css("opacity", 0).css(q, k ? 2 * -e : 2 * e).animate(r, p, l));
            f && (e /= Math.pow(2, n - 1));
            r = {};
            for (h = r[q] = 0; h < n; h++) t = {}, t[q] = (k ? "-=" : "+=") + e, c.animate(t, p, l).animate(r, p, l), e = f ? 2 * e : e / 2;
            f && (t = {
                opacity: 0
            }, t[q] = (k ? "-=" : "+=") + e, c.animate(t, p, l));
            c.queue(function(d) {
                f && c.hide();
                b.effects.restore(c, g);
                b.effects.removeWrapper(c);
                a.complete && a.complete.apply(c[0]);
                d()
            });
            1 < u && w.splice.apply(w, [1, 0].concat(w.splice(u, m + 1)));
            d()
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.clip = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = "position top bottom left right height width".split(" "),
                g = b.effects.setMode(d, a.mode || "hide"),
                e = a.direction || "vertical",
                f = "vertical" == e ? "height" : "width",
                e = "vertical" == e ? "top" : "left",
                h = {},
                k, n;
            b.effects.save(d, c);
            d.show();
            k = b.effects.createWrapper(d).css({
                overflow: "hidden"
            });
            k = "IMG" == d[0].tagName ? k : d;
            n = k[f]();
            "show" == g && (k.css(f, 0), k.css(e, n / 2));
            h[f] = "show" == g ? n : 0;
            h[e] = "show" == g ? 0 : n / 2;
            k.animate(h, {
                queue: !1,
                duration: a.duration,
                easing: a.easing,
                complete: function() {
                    "hide" == g && d.hide();
                    b.effects.restore(d, c);
                    b.effects.removeWrapper(d);
                    b.isFunction(a.complete) && a.complete.apply(d[0], arguments);
                    d.dequeue()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.drop = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = "position top bottom left right opacity".split(" "),
                g = b.effects.setMode(d, a.mode || "hide"),
                e = a.direction || "left",
                f = "up" == e || "down" == e ? "top" : "left",
                e = "up" == e || "left" == e ? "pos" : "neg",
                h = {
                    opacity: "show" == g ? 1 : 0
                },
                k;
            b.effects.save(d, c);
            d.show();
            b.effects.createWrapper(d);
            k = a.distance || d["top" == f ? "outerHeight" : "outerWidth"]({
                margin: !0
            }) / 2;
            "show" == g && d.css("opacity", 0).css(f, "pos" == e ? -k : k);
            h[f] = ("show" == g ? "pos" == e ?
                "+=" : "-=" : "pos" == e ? "-=" : "+=") + k;
            d.animate(h, {
                queue: !1,
                duration: a.duration,
                easing: a.easing,
                complete: function() {
                    "hide" == g && d.hide();
                    b.effects.restore(d, c);
                    b.effects.removeWrapper(d);
                    b.isFunction(a.complete) && a.complete.apply(this, arguments);
                    d.dequeue()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.explode = function(a) {
        return this.queue(function(d) {
            function c() {
                p.push(this);
                p.length == g * e && (f.css({
                    visibility: "visible"
                }), b(p).remove(), h || f.hide(), b.isFunction(a.complete) && a.complete.apply(f[0]), d())
            }
            var g = a.pieces ? Math.round(Math.sqrt(a.pieces)) : 3,
                e = g,
                f = b(this),
                h = "show" == b.effects.setMode(f, a.mode || "hide"),
                k = f.show().css("visibility", "hidden").offset(),
                n = Math.ceil(f.outerWidth() / e),
                m = Math.ceil(f.outerHeight() / g),
                p = [],
                l, q, t, r, w, u;
            for (l = 0; l < g; l++)
                for (r = k.top + l * m, u =
                    l - (g - 1) / 2, q = 0; q < e; q++) t = k.left + q * n, w = q - (e - 1) / 2, f.clone().appendTo("body").wrap("<div></div>").css({
                    position: "absolute",
                    visibility: "visible",
                    left: -q * n,
                    top: -l * m
                }).parent().addClass("ui-effects-explode").css({
                    position: "absolute",
                    overflow: "hidden",
                    width: n,
                    height: m,
                    left: t + (h ? w * n : 0),
                    top: r + (h ? u * m : 0),
                    opacity: h ? 0 : 1
                }).animate({
                    left: t + (h ? 0 : w * n),
                    top: r + (h ? 0 : u * m),
                    opacity: h ? 1 : 0
                }, a.duration || 500, a.easing, c)
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.fade = function(a) {
        return this.queue(function(d) {
            var c = b(this),
                g = "hide" === b.effects.setMode(c, a.mode || "toggle");
            c.show();
            c.animate({
                opacity: g ? 0 : 1
            }, {
                queue: !1,
                duration: a.duration,
                easing: a.easing,
                complete: function() {
                    g && c.hide();
                    a.complete && a.complete.call(this);
                    d()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.fold = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = ["position", "top", "bottom", "left", "right"],
                g = b.effects.setMode(d, a.mode || "hide"),
                e = a.size || 15,
                f = /([0-9]+)%/.exec(e),
                h = !!a.horizFirst,
                k = "show" == g != h,
                n = k ? ["width", "height"] : ["height", "width"],
                m = a.duration / 2,
                p;
            b.effects.save(d, c);
            d.show();
            p = b.effects.createWrapper(d).css({
                overflow: "hidden"
            });
            k = k ? [p.width(), p.height()] : [p.height(), p.width()];
            f && (e = parseInt(f[1], 10) / 100 * k["hide" == g ? 0 : 1]);
            "show" == g && p.css(h ? {
                height: 0,
                width: e
            } : {
                height: e,
                width: 0
            });
            f = {};
            h = {};
            f[n[0]] = "show" == g ? k[0] : e;
            h[n[1]] = "show" == g ? k[1] : 0;
            p.animate(f, m, a.easing).animate(h, m, a.easing, function() {
                "hide" == g && d.hide();
                b.effects.restore(d, c);
                b.effects.removeWrapper(d);
                jQuery.isFunction(a.complete) && a.complete.apply(d[0], arguments);
                d.dequeue()
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.highlight = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = ["backgroundImage", "backgroundColor", "opacity"],
                g = b.effects.setMode(d, a.mode || "show"),
                e = {
                    backgroundColor: d.css("backgroundColor")
                };
            "hide" == g && (e.opacity = 0);
            b.effects.save(d, c);
            d.show().css({
                backgroundImage: "none",
                backgroundColor: a.color || "#ffff99"
            }).animate(e, {
                queue: !1,
                duration: a.duration,
                easing: a.easing,
                complete: function() {
                    "hide" == g && d.hide();
                    b.effects.restore(d, c);
                    "show" == g && !b.support.opacity && this.style.removeAttribute("filter");
                    jQuery.isFunction(a.complete) && a.complete.apply(this, arguments);
                    d.dequeue()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.pulsate = function(a) {
        return this.queue(function(d) {
            var c = b(this),
                g = b.effects.setMode(c, a.mode || "show"),
                e = "show" === g,
                f = "hide" === g,
                g = 2 * (a.times || 5) + (e || "hide" === g ? 1 : 0),
                h = a.duration / g,
                k = 0,
                n = c.queue(),
                m = n.length;
            if (e || !c.is(":visible")) c.css("opacity", 0).show(), k = 1;
            for (e = 1; e < g; e++) c.animate({
                opacity: k
            }, h, a.easing), k = 1 - k;
            c.animate({
                opacity: k
            }, h, a.easing);
            c.queue(function(b) {
                f && c.hide();
                a.complete && a.complete.apply(this);
                b()
            });
            1 < m && n.splice.apply(n, [1, 0].concat(n.splice(m,
                g + 1)));
            d()
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.puff = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = b.effects.setMode(d, a.mode || "hide"),
                g = parseInt(a.percent, 10) || 150,
                e = g / 100,
                f = {
                    height: d.height(),
                    width: d.width()
                };
            b.extend(a, {
                effect: "scale",
                queue: !1,
                fade: !0,
                mode: c,
                percent: "hide" == c ? g : 100,
                from: "hide" == c ? f : {
                    height: f.height * e,
                    width: f.width * e
                }
            });
            d.effect(a)
        })
    };
    b.effects.effect.scale = function(a) {
        return this[!1 === a.queue ? "each" : "queue"](function() {
            var d = b(this),
                c = b.extend(!0, {}, a),
                g = b.effects.setMode(d, a.mode ||
                    "effect"),
                e = parseInt(a.percent, 10) || (0 == parseInt(a.percent, 10) ? 0 : "hide" == g ? 0 : 100),
                f = a.direction || "both",
                h = a.origin,
                k = {
                    height: d.height(),
                    width: d.width()
                };
            c.effect = "size";
            c.queue = !1;
            "effect" != g && (c.origin = h || ["middle", "center"], c.restore = !0);
            c.from = a.from || ("show" == g ? {
                height: 0,
                width: 0
            } : k);
            c.to = {
                height: k.height * ("horizontal" != f ? e / 100 : 1),
                width: k.width * ("vertical" != f ? e / 100 : 1)
            };
            c.fade && ("show" == g && (c.from.opacity = 0, c.to.opacity = 1), "hide" == g && (c.from.opacity = 1, c.to.opacity = 0));
            d.effect(c)
        })
    };
    b.effects.effect.size =
        function(a) {
            return this[!1 === a.queue ? "each" : "queue"](function() {
                var d, c, g, e, f = b(this),
                    h = "position top bottom left right width height overflow opacity".split(" "),
                    k = "position top bottom left right overflow opacity".split(" "),
                    n = ["width", "height", "overflow"],
                    m = ["fontSize"],
                    p = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
                    l = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
                    q = b.effects.setMode(f, a.mode || "effect"),
                    t = a.restore || !1,
                    r = a.scale || "both",
                    w = a.origin,
                    u;
                "show" ===
                q && f.show();
                u = {
                    height: f.height(),
                    width: f.width()
                };
                f.from = a.from || u;
                f.to = a.to || u;
                w && (w = b.effects.getBaseline(w, u), f.from.top = (u.height - f.from.height) * w.y, f.from.left = (u.width - f.from.width) * w.x, f.to.top = (u.height - f.to.height) * w.y, f.to.left = (u.width - f.to.width) * w.x);
                g = f.from.height / u.height;
                e = f.from.width / u.width;
                d = f.to.height / u.height;
                c = f.to.width / u.width;
                if ("box" == r || "both" == r) g !== d && (h = h.concat(p), f.from = b.effects.setTransition(f, p, g, f.from), f.to = b.effects.setTransition(f, p, d, f.to)), e !== c && (h = h.concat(l),
                    f.from = b.effects.setTransition(f, l, e, f.from), f.to = b.effects.setTransition(f, l, c, f.to));
                "content" != r && "both" != r || g === d || (h = h.concat(m), f.from = b.effects.setTransition(f, m, g, f.from), f.to = b.effects.setTransition(f, m, d, f.to));
                b.effects.save(f, t ? h : k);
                f.show();
                b.effects.createWrapper(f);
                f.css("overflow", "hidden").css(f.from);
                if ("content" == r || "both" == r) p = p.concat(["marginTop", "marginBottom"]).concat(m), l = l.concat(["marginLeft", "marginRight"]), n = h.concat(p).concat(l), f.find("*[width]").each(function() {
                    var f =
                        b(this),
                        h = f.height(),
                        k = f.width();
                    t && b.effects.save(f, n);
                    f.from = {
                        height: h * g,
                        width: k * e
                    };
                    f.to = {
                        height: h * d,
                        width: k * c
                    };
                    g != d && (f.from = b.effects.setTransition(f, p, g, f.from), f.to = b.effects.setTransition(f, p, d, f.to));
                    e != c && (f.from = b.effects.setTransition(f, l, e, f.from), f.to = b.effects.setTransition(f, l, c, f.to));
                    f.css(f.from);
                    f.animate(f.to, a.duration, a.easing, function() {
                        t && b.effects.restore(f, n)
                    })
                });
                f.animate(f.to, {
                    queue: !1,
                    duration: a.duration,
                    easing: a.easing,
                    complete: function() {
                        0 === f.to.opacity && f.css("opacity",
                            f.from.opacity);
                        "hide" == q && f.hide();
                        b.effects.restore(f, t ? h : k);
                        b.effects.removeWrapper(f);
                        b.isFunction(a.complete) && a.complete.apply(this, arguments);
                        f.dequeue()
                    }
                })
            })
        }
})(jQuery);
(function(b, l) {
    b.effects.effect.shake = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = ["position", "top", "bottom", "left", "right"],
                g = b.effects.setMode(d, a.mode || "effect"),
                e = a.direction || "left",
                f = a.distance || 20,
                h = a.times || 3,
                k = 2 * h + 1,
                n = a.duration,
                m = "up" == e || "down" == e ? "top" : "left",
                l = "up" == e || "left" == e ? "pos" : "neg",
                e = {},
                v = {},
                q = {},
                t = d.queue(),
                r = t.length;
            b.effects.save(d, c);
            d.show();
            b.effects.createWrapper(d);
            e[m] = ("pos" == l ? "-=" : "+=") + f;
            v[m] = ("pos" == l ? "+=" : "-=") + 2 * f;
            q[m] = ("pos" == l ? "-=" : "+=") + 2 * f;
            d.animate(e,
                n, a.easing);
            for (f = 1; f < h; f++) d.animate(v, n, a.easing).animate(q, n, a.easing);
            d.animate(v, n, a.easing).animate(e, n / 2, a.easing).queue(function(f) {
                "hide" === g && d.hide();
                b.effects.restore(d, c);
                b.effects.removeWrapper(d);
                b.isFunction(a.complete) && a.complete.apply(this, arguments);
                f()
            });
            1 < r && t.splice.apply(t, [1, 0].concat(t.splice(r, k + 1)));
            d.dequeue()
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.slide = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = ["position", "top", "bottom", "left", "right"],
                g = b.effects.setMode(d, a.mode || "show"),
                e = a.direction || "left",
                f = "up" == e || "down" == e ? "top" : "left",
                e = "up" == e || "left" == e ? "pos" : "neg",
                h, k = {};
            b.effects.save(d, c);
            d.show();
            b.effects.createWrapper(d).css({
                overflow: "hidden"
            });
            h = a.distance || d["top" == f ? "outerHeight" : "outerWidth"]({
                margin: !0
            });
            "show" == g && d.css(f, "pos" == e ? isNaN(h) ? "-" + h : -h : h);
            k[f] = ("show" == g ? "pos" == e ? "+=" : "-=" :
                "pos" == e ? "-=" : "+=") + h;
            d.animate(k, {
                queue: !1,
                duration: a.duration,
                easing: a.easing,
                complete: function() {
                    "hide" == g && d.hide();
                    b.effects.restore(d, c);
                    b.effects.removeWrapper(d);
                    b.isFunction(a.complete) && a.complete.apply(this, arguments);
                    d.dequeue()
                }
            })
        })
    }
})(jQuery);
(function(b, l) {
    b.effects.effect.transfer = function(a) {
        return this.queue(function() {
            var d = b(this),
                c = b(a.to),
                g = c.offset(),
                c = {
                    top: g.top,
                    left: g.left,
                    height: c.innerHeight(),
                    width: c.innerWidth()
                },
                g = d.offset(),
                e = b('<div class="ui-effects-transfer"></div>').appendTo(document.body).addClass(a.className).css({
                    top: g.top,
                    left: g.left,
                    height: d.innerHeight(),
                    width: d.innerWidth(),
                    position: "absolute"
                }).animate(c, a.duration, a.easing, function() {
                    e.remove();
                    b.isFunction(a.complete) && a.complete.apply(d[0], arguments);
                    d.dequeue()
                })
        })
    }
})(jQuery);
(function(b, l) {
    b.widget("ui.accordion", {
        options: {
            active: 0,
            animated: "slide",
            collapsible: !1,
            event: "click",
            header: "> li > :first-child,> :not(li):even",
            heightStyle: "auto",
            icons: {
                activeHeader: "ui-icon-triangle-1-s",
                header: "ui-icon-triangle-1-e"
            },
            activate: null,
            beforeActivate: null
        },
        _create: function() {
            var a = this.options;
            this.running = !1;
            this.element.addClass("ui-accordion ui-widget ui-helper-reset");
            this.headers = this.element.find(a.header).addClass("ui-accordion-header ui-helper-reset ui-state-default ui-corner-all");
            this._hoverable(this.headers);
            this._focusable(this.headers);
            this.headers.find(":first-child").addClass("ui-accordion-heading");
            this.headers.next().addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom");
            a.collapsible || !1 !== a.active || (a.active = 0);
            0 > a.active && (a.active += this.headers.length);
            this.active = this._findActive(a.active).addClass("ui-state-default ui-state-active").toggleClass("ui-corner-all").toggleClass("ui-corner-top");
            this.active.next().addClass("ui-accordion-content-active");
            this._createIcons();
            this.refresh();
            this.element.attr("role", "tablist");
            this.headers.attr("role", "tab").bind("keydown.accordion", b.proxy(this, "_keydown")).next().attr("role", "tabpanel");
            this.headers.not(this.active).attr({
                "aria-expanded": "false",
                "aria-selected": "false",
                tabIndex: -1
            }).next().hide();
            this.active.length ? this.active.attr({
                "aria-expanded": "true",
                "aria-selected": "true",
                tabIndex: 0
            }) : this.headers.eq(0).attr("tabIndex", 0);
            b.browser.safari || this.headers.find("a").attr("tabIndex", -1);
            this._setupEvents(a.event)
        },
        _createIcons: function() {
            var a = this.options.icons;
            a && (b("<span>").addClass("ui-accordion-header-icon ui-icon " + a.header).prependTo(this.headers), this.active.children(".ui-accordion-header-icon").removeClass(a.header).addClass(a.activeHeader), this.element.addClass("ui-accordion-icons"))
        },
        _destroyIcons: function() {
            this.headers.children(".ui-accordion-header-icon").remove();
            this.element.removeClass("ui-accordion-icons")
        },
        _destroy: function() {
            this.element.removeClass("ui-accordion ui-widget ui-helper-reset").removeAttr("role");
            this.headers.unbind(".accordion").removeClass("ui-accordion-header ui-accordion-disabled ui-helper-reset ui-state-default ui-corner-all ui-state-active ui-state-disabled ui-corner-top").removeAttr("role").removeAttr("aria-expanded").removeAttr("aria-selected").removeAttr("tabIndex").find("a").removeAttr("tabIndex").end().find(".ui-accordion-heading").removeClass("ui-accordion-heading");
            this._destroyIcons();
            var b = this.headers.next().css("display", "").removeAttr("role").removeClass("ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content ui-accordion-content-active ui-accordion-disabled ui-state-disabled");
            "content" !== this.options.heightStyle && b.css("height", "")
        },
        _setOption: function(b, d) {
            "active" === b ? this._activate(d) : (this._super("_setOption", b, d), "collapsible" !== b || d || !1 !== this.options.active || this._activate(0), "event" === b && this._setupEvents(d), "icons" === b && (this._destroyIcons(), d && this._createIcons()), "disabled" === b && this.headers.add(this.headers.next()).toggleClass("ui-accordion-disabled ui-state-disabled", !!d))
        },
        _keydown: function(a) {
            if (!(this.options.disabled || a.altKey || a.ctrlKey)) {
                var d = b.ui.keyCode,
                    c = this.headers.length,
                    g = this.headers.index(a.target),
                    e = !1;
                switch (a.keyCode) {
                    case d.RIGHT:
                    case d.DOWN:
                        e = this.headers[(g + 1) % c];
                        break;
                    case d.LEFT:
                    case d.UP:
                        e = this.headers[(g - 1 + c) % c];
                        break;
                    case d.SPACE:
                    case d.ENTER:
                        this._eventHandler(a)
                }
                e && (b(a.target).attr("tabIndex", -1), b(e).attr("tabIndex", 0), e.focus(), a.preventDefault())
            }
        },
        refresh: function() {
            var a = this.options,
                d = this.element.parent(),
                c, g;
            "fill" === a.heightStyle ? (b.support.minHeight || (g = d.css("overflow"), d.css("overflow", "hidden")), c = d.height(), this.element.siblings(":visible").each(function() {
                var a =
                    b(this),
                    f = a.css("position");
                "absolute" !== f && "fixed" !== f && (c -= a.outerHeight(!0))
            }), g && d.css("overflow", g), this.headers.each(function() {
                c -= b(this).outerHeight(!0)
            }), this.headers.next().each(function() {
                b(this).height(Math.max(0, c - b(this).innerHeight() + b(this).height()))
            }).css("overflow", "auto")) : "auto" === a.heightStyle && (c = 0, this.headers.next().each(function() {
                c = Math.max(c, b(this).height("").height())
            }).height(c));
            return this
        },
        _activate: function(a) {
            a = this._findActive(a)[0];
            a !== this.active[0] && (a = a || this.active[0],
                this._eventHandler({
                    target: a,
                    currentTarget: a,
                    preventDefault: b.noop
                }))
        },
        _findActive: function(a) {
            return "number" === typeof a ? this.headers.eq(a) : b()
        },
        _setupEvents: function(a) {
            this.headers.unbind(".accordion");
            a && this.headers.bind(a.split(" ").join(".accordion ") + ".accordion", b.proxy(this, "_eventHandler"))
        },
        _eventHandler: function(a) {
            var d = this.options,
                c = this.active,
                g = b(a.currentTarget),
                e = g[0] === c[0],
                f = e && d.collapsible,
                h = f ? b() : g.next(),
                k = c.next(),
                h = {
                    oldHeader: c,
                    oldContent: k,
                    newHeader: f ? b() : g,
                    newContent: h
                };
            a.preventDefault();
            d.disabled || this.running || e && !d.collapsible || !1 === this._trigger("beforeActivate", a, h) || (d.active = f ? !1 : this.headers.index(g), this.active = e ? b() : g, this._toggle(h), c.removeClass("ui-state-active ui-corner-top").addClass("ui-state-default ui-corner-all").children(".ui-accordion-header-icon").removeClass(d.icons.activeHeader).addClass(d.icons.header), e || (g.removeClass("ui-state-default ui-corner-all").addClass("ui-state-active ui-corner-top").children(".ui-accordion-header-icon").removeClass(d.icons.header).addClass(d.icons.activeHeader),
                g.next().addClass("ui-accordion-content-active")))
        },
        _toggle: function(a) {
            function d() {
                c._completed(a)
            }
            var c = this,
                g = c.options,
                e = a.newContent,
                f = a.oldContent;
            c.running = !0;
            if (g.animated) {
                var h = b.ui.accordion.animations,
                    g = g.animated,
                    k;
                h[g] || (k = {
                    easing: b.easing[g] ? g : "slide",
                    duration: 700
                }, g = "slide");
                h[g]({
                    toShow: e,
                    toHide: f,
                    complete: d,
                    down: e.length && (!f.length || e.index() < f.index())
                }, k)
            } else f.hide(), e.show(), d();
            f.prev().attr({
                "aria-expanded": "false",
                "aria-selected": "false",
                tabIndex: -1
            }).blur();
            e.prev().attr({
                "aria-expanded": "true",
                "aria-selected": "true",
                tabIndex: 0
            }).focus()
        },
        _completed: function(b) {
            var d = b.newContent,
                c = b.oldContent;
            this.running = !1;
            "content" === this.options.heightStyle && d.add(c).css({
                height: "",
                overflow: ""
            });
            c.removeClass("ui-accordion-content-active");
            c.length && (c.parent()[0].className = c.parent()[0].className);
            this._trigger("activate", null, b)
        }
    });
    b.extend(b.ui.accordion, {
        version: "1.9m5",
        animations: {
            slide: function(a, d) {
                var c = a.toShow.css("overflow"),
                    g = a.toHide.css("overflow"),
                    e = 0,
                    f = {},
                    h = {},
                    k = ["height", "paddingTop",
                        "paddingBottom"
                    ],
                    n;
                a = b.extend({
                    easing: "swing",
                    duration: 300
                }, a, d);
                if (a.toHide.size())
                    if (a.toShow.size()) {
                        var m = a.toShow;
                        n = m[0].style.width;
                        m.width(parseInt(m.parent().width(), 10) - parseInt(m.css("paddingLeft"), 10) - parseInt(m.css("paddingRight"), 10) - (parseInt(m.css("borderLeftWidth"), 10) || 0) - (parseInt(m.css("borderRightWidth"), 10) || 0));
                        b.each(k, function(c, d) {
                            h[d] = "hide";
                            var e = ("" + b.css(a.toShow[0], d)).match(/^([\d+-.]+)(.*)$/);
                            f[d] = {
                                value: "height" === d && "0" === e[1] ? 1 : e[1],
                                unit: e[2] || "px"
                            }
                        });
                        a.toShow.css({
                            height: 0,
                            overflow: "hidden"
                        }).show();
                        a.toHide.filter(":hidden").each(a.complete).end().filter(":visible").animate(h, {
                            step: function(b, c) {
                                "height" == c.prop && (e = 0 === c.end - c.start ? 0 : (c.now - c.start) / (c.end - c.start));
                                a.toShow[0].style[c.prop] = e * f[c.prop].value + f[c.prop].unit
                            },
                            duration: a.duration,
                            easing: a.easing,
                            complete: function() {
                                a.toShow.css({
                                    width: n,
                                    overflow: c
                                });
                                a.toHide.css("overflow", g);
                                a.complete()
                            }
                        })
                    } else a.toHide.animate({
                        height: "hide",
                        paddingTop: "hide",
                        paddingBottom: "hide"
                    }, a);
                else n = a.toShow[0].style.width,
                    a.toShow.show().width(a.toShow.width()).hide().animate({
                        height: "show",
                        paddingTop: "show",
                        paddingBottom: "show"
                    }, {
                        duration: a.duration,
                        easing: a.easing,
                        complete: function() {
                            a.toShow.width(n);
                            a.complete()
                        }
                    })
            },
            bounceslide: function(b) {
                this.slide(b, {
                    easing: b.down ? "easeOutBounce" : "swing",
                    duration: b.down ? 1E3 : 200
                })
            }
        }
    });
    !1 !== b.uiBackCompat && (function(b, d) {
        b.extend(d.options, {
            navigation: !1,
            navigationFilter: function() {
                return this.href.toLowerCase() === location.href.toLowerCase()
            }
        });
        var c = d._create;
        d._create = function() {
            if (this.options.navigation) {
                var d =
                    this,
                    e = this.element.find(this.options.header),
                    f = e.next(),
                    h = e.add(f).find("a").filter(this.options.navigationFilter)[0];
                h && e.add(f).each(function(c) {
                    if (b.contains(this, h)) return d.options.active = Math.floor(c / 2), !1
                })
            }
            c.call(this)
        }
    }(jQuery, jQuery.ui.accordion.prototype), function(b, d) {
        b.extend(d.options, {
            heightStyle: null,
            autoHeight: !0,
            clearStyle: !1,
            fillSpace: !1
        });
        var c = d._create,
            g = d._setOption;
        b.extend(d, {
            _create: function() {
                this.options.heightStyle = this.options.heightStyle || this._mergeHeightStyle();
                c.call(this)
            },
            _setOption: function(b, a) {
                if ("autoHeight" === b || "clearStyle" === b || "fillSpace" === b) this.options.heightStyle = this._mergeHeightStyle();
                g.apply(this, arguments)
            },
            _mergeHeightStyle: function() {
                var b = this.options;
                if (b.fillSpace) return "fill";
                if (b.clearStyle) return "content";
                if (b.autoHeight) return "auto"
            }
        })
    }(jQuery, jQuery.ui.accordion.prototype), function(b, d) {
        b.extend(d.options.icons, {
            activeHeader: null,
            headerSelected: "ui-icon-triangle-1-s"
        });
        var c = d._createIcons;
        d._createIcons = function() {
            this.options.icons.activeHeader =
                this.options.icons.activeHeader || this.options.icons.headerSelected;
            c.call(this)
        }
    }(jQuery, jQuery.ui.accordion.prototype), function(b, d) {
        d.activate = d._activate;
        var c = d._findActive;
        d._findActive = function(b) {
            -1 === b && (b = !1);
            b && "number" !== typeof b && (b = this.headers.index(this.headers.filter(b)), -1 === b && (b = !1));
            return c.call(this, b)
        }
    }(jQuery, jQuery.ui.accordion.prototype), jQuery.ui.accordion.prototype.resize = jQuery.ui.accordion.prototype.refresh, function(b, d) {
        b.extend(d.options, {
            change: null,
            changestart: null
        });
        var c = d._trigger;
        d._trigger = function(b, a, f) {
            var d = c.apply(this, arguments);
            if (!d) return !1;
            "beforeActivate" === b ? d = c.call(this, "changestart", a, f) : "activate" === b && (d = c.call(this, "change", a, f));
            return d
        }
    }(jQuery, jQuery.ui.accordion.prototype))
})(jQuery);
(function(b, l) {
    var a = 0;
    b.widget("ui.autocomplete", {
        defaultElement: "<input>",
        options: {
            appendTo: "body",
            autoFocus: !1,
            delay: 300,
            minLength: 1,
            position: {
                my: "left top",
                at: "left bottom",
                collision: "none"
            },
            source: null,
            change: null,
            close: null,
            focus: null,
            open: null,
            response: null,
            search: null,
            select: null
        },
        pending: 0,
        _create: function() {
            var a = this,
                c = this.element[0].ownerDocument,
                g, e, f;
            this.valueMethod = this.element[this.element.is("input") ? "val" : "text"];
            this.element.addClass("ui-autocomplete-input").attr("autocomplete",
                "off").attr({
                role: "textbox",
                "aria-autocomplete": "list",
                "aria-haspopup": "true"
            }).bind("keydown.autocomplete", function(c) {
                if (a.options.disabled || a.element.attr("readonly")) f = e = g = !0;
                else {
                    f = e = g = !1;
                    var k = b.ui.keyCode;
                    switch (c.keyCode) {
                        case k.PAGE_UP:
                            g = !0;
                            a._move("previousPage", c);
                            break;
                        case k.PAGE_DOWN:
                            g = !0;
                            a._move("nextPage", c);
                            break;
                        case k.UP:
                            g = !0;
                            a._move("previous", c);
                            c.preventDefault();
                            break;
                        case k.DOWN:
                            g = !0;
                            a._move("next", c);
                            c.preventDefault();
                            break;
                        case k.ENTER:
                        case k.NUMPAD_ENTER:
                            a.menu.active &&
                                (g = !0, c.preventDefault());
                        case k.TAB:
                            if (!a.menu.active) break;
                            a.menu.select(c);
                            break;
                        case k.ESCAPE:
                            a._value(a.term);
                            a.close(c);
                            break;
                        default:
                            f = !0, a._searchTimeout(c)
                    }
                }
            }).bind("keypress.autocomplete", function(c) {
                if (g) g = !1, c.preventDefault();
                else if (!f) {
                    var e = b.ui.keyCode;
                    switch (c.keyCode) {
                        case e.PAGE_UP:
                            a._move("previousPage", c);
                            break;
                        case e.PAGE_DOWN:
                            a._move("nextPage", c);
                            break;
                        case e.UP:
                            a._move("previous", c);
                            c.preventDefault();
                            break;
                        case e.DOWN:
                            a._move("next", c), c.preventDefault()
                    }
                }
            }).bind("input.autocomplete",
                function(b) {
                    e ? (e = !1, b.preventDefault()) : a._searchTimeout(b)
                }).bind("focus.autocomplete", function() {
                a.options.disabled || (a.selectedItem = null, a.previous = a._value())
            }).bind("blur.autocomplete", function(b) {
                a.options.disabled || (clearTimeout(a.searching), a.closing = setTimeout(function() {
                    a.close(b);
                    a._change(b)
                }, 150))
            });
            this._initSource();
            this.response = function() {
                return a._response.apply(a, arguments)
            };
            this.menu = b("<ul></ul>").addClass("ui-autocomplete").appendTo(b(this.options.appendTo || "body", c)[0]).mousedown(function(c) {
                var f =
                    a.menu.element[0];
                b(c.target).closest(".ui-menu-item").length || setTimeout(function() {
                    b(document).one("mousedown", function(c) {
                        c.target === a.element[0] || c.target === f || b.contains(f, c.target) || a.close()
                    })
                }, 1);
                setTimeout(function() {
                    clearTimeout(a.closing)
                }, 13)
            }).menu({
                input: b(),
                focus: function(b, c) {
                    var f = c.item.data("item.autocomplete");
                    !1 !== a._trigger("focus", b, {
                        item: f
                    }) && /^key/.test(b.originalEvent.type) && a._value(f.value)
                },
                select: function(b, f) {
                    var e = f.item.data("item.autocomplete"),
                        g = a.previous;
                    a.element[0] !==
                        c.activeElement && (a.element.focus(), a.previous = g, setTimeout(function() {
                            a.previous = g;
                            a.selectedItem = e
                        }, 1));
                    !1 !== a._trigger("select", b, {
                        item: e
                    }) && a._value(e.value);
                    a.term = a._value();
                    a.close(b);
                    a.selectedItem = e
                },
                blur: function(b, c) {
                    a.menu.element.is(":visible") && a._value() !== a.term && a._value(a.term)
                }
            }).zIndex(this.element.zIndex() + 1).hide().data("menu");
            b.fn.bgiframe && this.menu.element.bgiframe()
        },
        _destroy: function() {
            this.element.removeClass("ui-autocomplete-input").removeAttr("autocomplete").removeAttr("role").removeAttr("aria-autocomplete").removeAttr("aria-haspopup");
            this.menu.element.remove()
        },
        _setOption: function(a, c) {
            this._super("_setOption", a, c);
            "source" === a && this._initSource();
            "appendTo" === a && this.menu.element.appendTo(b(c || "body", this.element[0].ownerDocument)[0]);
            "disabled" === a && c && this.xhr && this.xhr.abort()
        },
        _initSource: function() {
            var d = this,
                c, g;
            b.isArray(this.options.source) ? (c = this.options.source, this.source = function(a, f) {
                f(b.ui.autocomplete.filter(c, a.term))
            }) : "string" === typeof this.options.source ? (g = this.options.source, this.source = function(c, f) {
                d.xhr &&
                    d.xhr.abort();
                d.xhr = b.ajax({
                    url: g,
                    data: c,
                    dataType: "json",
                    autocompleteRequest: ++a,
                    success: function(b, c) {
                        this.autocompleteRequest === a && f(b)
                    },
                    error: function() {
                        this.autocompleteRequest === a && f([])
                    }
                })
            }) : this.source = this.options.source
        },
        _searchTimeout: function(b) {
            var a = this;
            a.searching = setTimeout(function() {
                a.term != a.element.val() && (a.selectedItem = null, a.search(null, b))
            }, a.options.delay)
        },
        search: function(b, a) {
            b = null != b ? b : this._value();
            this.term = this._value();
            if (b.length < this.options.minLength) return this.close(a);
            clearTimeout(this.closing);
            if (!1 !== this._trigger("search", a)) return this._search(b)
        },
        _search: function(b) {
            this.pending++;
            this.element.addClass("ui-autocomplete-loading");
            this.source({
                term: b
            }, this.response)
        },
        _response: function(b) {
            b && (b = this._normalize(b));
            this._trigger("response", null, {
                content: b
            });
            !this.options.disabled && b && b.length ? (this._suggest(b), this._trigger("open")) : this.close();
            this.pending--;
            this.pending || this.element.removeClass("ui-autocomplete-loading")
        },
        close: function(b) {
            clearTimeout(this.closing);
            this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this._trigger("close", b))
        },
        _change: function(b) {
            this.previous !== this._value() && this._trigger("change", b, {
                item: this.selectedItem
            })
        },
        _normalize: function(a) {
            return a.length && a[0].label && a[0].value ? a : b.map(a, function(a) {
                return "string" === typeof a ? {
                    label: a,
                    value: a
                } : b.extend({
                    label: a.label || a.value,
                    value: a.value || a.label
                }, a)
            })
        },
        _suggest: function(a) {
            var c = this.menu.element.empty().zIndex(this.element.zIndex() + 1);
            this._renderMenu(c,
                a);
            this.menu.blur();
            this.menu.refresh();
            c.show();
            this._resizeMenu();
            c.position(b.extend({ of: this.element
            }, this.options.position));
            this.options.autoFocus && this.menu.next(new b.Event("mouseover"))
        },
        _resizeMenu: function() {
            var b = this.menu.element;
            b.outerWidth(Math.max(b.width("").outerWidth(), this.element.outerWidth()))
        },
        _renderMenu: function(a, c) {
            var g = this;
            b.each(c, function(b, c) {
                g._renderItem(a, c)
            })
        },
        _renderItem: function(a, c) {
            return b("<li></li>").data("item.autocomplete", c).append(b("<a></a>").text(c.label)).appendTo(a)
        },
        _move: function(b, a) {
            if (this.menu.element.is(":visible"))
                if (this.menu.first() && /^previous/.test(b) || this.menu.last() && /^next/.test(b)) this._value(this.term), this.menu.blur();
                else this.menu[b](a);
            else this.search(null, a)
        },
        widget: function() {
            return this.menu.element
        },
        _value: function(b) {
            return this.valueMethod.apply(this.element, arguments)
        }
    });
    b.extend(b.ui.autocomplete, {
        version: "1.9m5",
        escapeRegex: function(b) {
            return b.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
        },
        filter: function(a, c) {
            var g = new RegExp(b.ui.autocomplete.escapeRegex(c),
                "i");
            return b.grep(a, function(b) {
                return g.test(b.label || b.value || b)
            })
        }
    })
})(jQuery);
(function(b, l) {
    var a, d, c, g, e = function() {
            var a = b(this).find(":ui-button");
            setTimeout(function() {
                a.button("refresh")
            }, 1)
        },
        f = function(a) {
            var c = a.name,
                f = a.form,
                d = b([]);
            c && (d = f ? b(f).find("[name='" + c + "']") : b("[name='" + c + "']", a.ownerDocument).filter(function() {
                return !this.form
            }));
            return d
        };
    b.widget("ui.button", {
        defaultElement: "<button>",
        options: {
            disabled: null,
            text: !0,
            label: null,
            icons: {
                primary: null,
                secondary: null
            }
        },
        _create: function() {
            this.element.closest("form").unbind("reset.button").bind("reset.button", e);
            "boolean" !== typeof this.options.disabled && (this.options.disabled = this.element.attr("disabled"));
            this._determineButtonType();
            this.hasTitle = !!this.buttonElement.attr("title");
            var h = this,
                k = this.options,
                n = "checkbox" === this.type || "radio" === this.type,
                m = "ui-state-hover" + (n ? "" : " ui-state-active");
            null === k.label && (k.label = this.buttonElement.html());
            this.element.is(":disabled") && (k.disabled = !0);
            this.buttonElement.addClass("ui-button ui-widget ui-state-default ui-corner-all").attr("role", "button").bind("mouseenter.button",
                function() {
                    k.disabled || (b(this).addClass("ui-state-hover"), this === a && b(this).addClass("ui-state-active"))
                }).bind("mouseleave.button", function() {
                k.disabled || b(this).removeClass(m)
            }).bind("focus.button", function() {
                b(this).addClass("ui-state-focus")
            }).bind("blur.button", function() {
                b(this).removeClass("ui-state-focus")
            }).bind("click.button", function(b) {
                k.disabled && b.stopImmediatePropagation()
            });
            n && (this.element.bind("change.button", function() {
                g || h.refresh()
            }), this.buttonElement.bind("mousedown.button",
                function(b) {
                    k.disabled || (g = !1, d = b.pageX, c = b.pageY)
                }).bind("mouseup.button", function(b) {
                k.disabled || d === b.pageX && c === b.pageY || (g = !0)
            }));
            "checkbox" === this.type ? this.buttonElement.bind("click.button", function() {
                if (k.disabled || g) return !1;
                b(this).toggleClass("ui-state-active");
                h.buttonElement.attr("aria-pressed", h.element[0].checked)
            }) : "radio" === this.type ? this.buttonElement.bind("click.button", function() {
                if (k.disabled || g) return !1;
                b(this).addClass("ui-state-active");
                h.buttonElement.attr("aria-pressed", !0);
                var a = h.element[0];
                f(a).not(a).map(function() {
                    return b(this).button("widget")[0]
                }).removeClass("ui-state-active").attr("aria-pressed", !1)
            }) : (this.buttonElement.bind("mousedown.button", function() {
                if (k.disabled) return !1;
                b(this).addClass("ui-state-active");
                a = this;
                b(document).one("mouseup", function() {
                    a = null
                })
            }).bind("mouseup.button", function() {
                if (k.disabled) return !1;
                b(this).removeClass("ui-state-active")
            }).bind("keydown.button", function(a) {
                if (k.disabled) return !1;
                a.keyCode != b.ui.keyCode.SPACE && a.keyCode !=
                    b.ui.keyCode.ENTER || b(this).addClass("ui-state-active")
            }).bind("keyup.button", function() {
                b(this).removeClass("ui-state-active")
            }), this.buttonElement.is("a") && this.buttonElement.keyup(function(a) {
                a.keyCode === b.ui.keyCode.SPACE && b(this).click()
            }));
            this._setOption("disabled", k.disabled);
            this._resetButton()
        },
        _determineButtonType: function() {
            this.element.is(":checkbox") ? this.type = "checkbox" : this.element.is(":radio") ? this.type = "radio" : this.element.is("input") ? this.type = "input" : this.type = "button";
            if ("checkbox" ===
                this.type || "radio" === this.type) {
                var b = this.element.parents().last(),
                    a = "label[for=" + this.element.attr("id") + "]";
                this.buttonElement = b.find(a);
                this.buttonElement.length || (b = b.length ? b.siblings() : this.element.siblings(), this.buttonElement = b.filter(a), this.buttonElement.length || (this.buttonElement = b.find(a)));
                this.element.addClass("ui-helper-hidden-accessible");
                (b = this.element.is(":checked")) && this.buttonElement.addClass("ui-state-active");
                this.buttonElement.attr("aria-pressed", b)
            } else this.buttonElement =
                this.element
        },
        widget: function() {
            return this.buttonElement
        },
        _destroy: function() {
            this.element.removeClass("ui-helper-hidden-accessible");
            this.buttonElement.removeClass("ui-button ui-widget ui-state-default ui-corner-all ui-state-hover ui-state-active  ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only").removeAttr("role").removeAttr("aria-pressed").html(this.buttonElement.find(".ui-button-text").html());
            this.hasTitle ||
                this.buttonElement.removeAttr("title")
        },
        _setOption: function(b, a) {
            this._super("_setOption", b, a);
            "disabled" === b ? a ? this.element.attr("disabled", !0) : this.element.removeAttr("disabled") : this._resetButton()
        },
        refresh: function() {
            var a = this.element.is(":disabled");
            a !== this.options.disabled && this._setOption("disabled", a);
            "radio" === this.type ? f(this.element[0]).each(function() {
                b(this).is(":checked") ? b(this).button("widget").addClass("ui-state-active").attr("aria-pressed", !0) : b(this).button("widget").removeClass("ui-state-active").attr("aria-pressed", !1)
            }) : "checkbox" === this.type && (this.element.is(":checked") ? this.buttonElement.addClass("ui-state-active").attr("aria-pressed", !0) : this.buttonElement.removeClass("ui-state-active").attr("aria-pressed", !1))
        },
        _resetButton: function() {
            if ("input" === this.type) this.options.label && this.element.val(this.options.label);
            else {
                var a = this.buttonElement.removeClass("ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only"),
                    c = b("<span></span>").addClass("ui-button-text").html(this.options.label).appendTo(a.empty()).text(),
                    f = this.options.icons,
                    d = f.primary && f.secondary,
                    e = [];
                f.primary || f.secondary ? (this.options.text && e.push("ui-button-text-icon" + (d ? "s" : f.primary ? "-primary" : "-secondary")), f.primary && a.prepend("<span class='ui-button-icon-primary ui-icon " + f.primary + "'></span>"), f.secondary && a.append("<span class='ui-button-icon-secondary ui-icon " + f.secondary + "'></span>"), this.options.text || (e.push(d ? "ui-button-icons-only" : "ui-button-icon-only"), this.hasTitle || a.attr("title", c))) : e.push("ui-button-text-only");
                a.addClass(e.join(" "))
            }
        }
    });
    b.ui.button.version = "1.9m5";
    b.widget("ui.buttonset", {
        options: {
            items: ":button, :submit, :reset, :checkbox, :radio, a, :data(button)"
        },
        _create: function() {
            this.element.addClass("ui-buttonset")
        },
        _init: function() {
            this.refresh()
        },
        _setOption: function(b, a) {
            "disabled" === b && this.buttons.button("option", b, a);
            this._super("_setOption", b, a)
        },
        refresh: function() {
            var a = "ltr" === this.element.css("direction");
            this.buttons = this.element.find(this.options.items).filter(":ui-button").button("refresh").end().not(":ui-button").button().end().map(function() {
                return b(this).button("widget")[0]
            }).removeClass("ui-corner-all ui-corner-left ui-corner-right").filter(":first").addClass(a ?
                "ui-corner-left" : "ui-corner-right").end().filter(":last").addClass(a ? "ui-corner-right" : "ui-corner-left").end().end()
        },
        _destroy: function() {
            this.element.removeClass("ui-buttonset");
            this.buttons.map(function() {
                return b(this).button("widget")[0]
            }).removeClass("ui-corner-left ui-corner-right").end().button("destroy")
        }
    });
    b.ui.buttonset.version = "1.9m5"
})(jQuery);
(function(b, l) {
    function a() {
        this.debug = !1;
        this._curInst = null;
        this._keyEvent = !1;
        this._disabledInputs = [];
        this._inDialog = this._datepickerShowing = !1;
        this._mainDivId = "ui-datepicker-div";
        this._inlineClass = "ui-datepicker-inline";
        this._appendClass = "ui-datepicker-append";
        this._triggerClass = "ui-datepicker-trigger";
        this._dialogClass = "ui-datepicker-dialog";
        this._disableClass = "ui-datepicker-disabled";
        this._unselectableClass = "ui-datepicker-unselectable";
        this._currentClass = "ui-datepicker-current-day";
        this._dayOverClass =
            "ui-datepicker-days-cell-over";
        this.regional = [];
        this.regional[""] = {
            closeText: "Done",
            prevText: "Prev",
            nextText: "Next",
            currentText: "Today",
            monthNames: "January February March April May June July August September October November December".split(" "),
            monthNamesShort: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),
            dayNames: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
            dayNamesShort: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
            dayNamesMin: "Su Mo Tu We Th Fr Sa".split(" "),
            weekHeader: "Wk",
            dateFormat: "mm/dd/yy",
            firstDay: 0,
            isRTL: !1,
            showMonthAfterYear: !1,
            yearSuffix: ""
        };
        this._defaults = {
            showOn: "focus",
            showAnim: "fadeIn",
            showOptions: {},
            defaultDate: null,
            appendText: "",
            buttonText: "...",
            buttonImage: "",
            buttonImageOnly: !1,
            hideIfNoPrevNext: !1,
            navigationAsDateFormat: !1,
            gotoCurrent: !1,
            changeMonth: !1,
            changeYear: !1,
            yearRange: "c-10:c+10",
            showOtherMonths: !1,
            selectOtherMonths: !1,
            showWeek: !1,
            calculateWeek: this.iso8601Week,
            shortYearCutoff: "+10",
            minDate: null,
            maxDate: null,
            duration: "fast",
            beforeShowDay: null,
            beforeShow: null,
            onSelect: null,
            onChangeMonthYear: null,
            onClose: null,
            numberOfMonths: 1,
            showCurrentAtPos: 0,
            stepMonths: 1,
            stepBigMonths: 12,
            altField: "",
            altFormat: "",
            constrainInput: !0,
            showButtonPanel: !1,
            autoSize: !1
        };
        b.extend(this._defaults, this.regional[""]);
        this.dpDiv = d(b('<div id="' + this._mainDivId + '" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>'))
    }

    function d(a) {
        return a.delegate("button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a",
            "mouseout",
            function() {
                b(this).removeClass("ui-state-hover"); - 1 != this.className.indexOf("ui-datepicker-prev") && b(this).removeClass("ui-datepicker-prev-hover"); - 1 != this.className.indexOf("ui-datepicker-next") && b(this).removeClass("ui-datepicker-next-hover")
            }).delegate("button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a", "mouseover", function() {
            b.datepicker._isDisabledDatepicker(e.inline ? a.parent()[0] : e.input[0]) || (b(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"),
                b(this).addClass("ui-state-hover"), -1 != this.className.indexOf("ui-datepicker-prev") && b(this).addClass("ui-datepicker-prev-hover"), -1 != this.className.indexOf("ui-datepicker-next") && b(this).addClass("ui-datepicker-next-hover"))
        })
    }

    function c(a, c) {
        b.extend(a, c);
        for (var d in c)
            if (null == c[d] || c[d] == l) a[d] = c[d];
        return a
    }
    b.extend(b.ui, {
        datepicker: {
            version: "1.9m5"
        }
    });
    var g = (new Date).getTime(),
        e;
    b.extend(a.prototype, {
        markerClassName: "hasDatepicker",
        log: function() {
            this.debug && console.log.apply("", arguments)
        },
        _widgetDatepicker: function() {
            return this.dpDiv
        },
        setDefaults: function(b) {
            c(this._defaults, b || {});
            return this
        },
        _attachDatepicker: function(a, c) {
            var d = null,
                e;
            for (e in this._defaults) {
                var g = a.getAttribute("date:" + e);
                if (g) {
                    d = d || {};
                    try {
                        d[e] = eval(g)
                    } catch (l) {
                        d[e] = g
                    }
                }
            }
            e = a.nodeName.toLowerCase();
            g = "div" == e || "span" == e;
            a.id || (this.uuid += 1, a.id = "dp" + this.uuid);
            var v = this._newInst(b(a), g);
            v.settings = b.extend({}, c || {}, d || {});
            "input" == e ? this._connectDatepicker(a, v) : g && this._inlineDatepicker(a, v)
        },
        _newInst: function(a,
            c) {
            return {
                id: a[0].id.replace(/([^A-Za-z0-9_-])/g, "\\\\$1"),
                input: a,
                selectedDay: 0,
                selectedMonth: 0,
                selectedYear: 0,
                drawMonth: 0,
                drawYear: 0,
                inline: c,
                dpDiv: c ? d(b('<div class="' + this._inlineClass + ' ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>')) : this.dpDiv
            }
        },
        _connectDatepicker: function(a, c) {
            var d = b(a);
            c.append = b([]);
            c.trigger = b([]);
            d.hasClass(this.markerClassName) || (this._attachments(d, c), d.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp).bind("setData.datepicker",
                function(b, a, f) {
                    c.settings[a] = f
                }).bind("getData.datepicker", function(b, a) {
                return this._get(c, a)
            }), this._autoSize(c), b.data(a, "datepicker", c))
        },
        _attachments: function(a, c) {
            var d = this._get(c, "appendText"),
                e = this._get(c, "isRTL");
            c.append && c.append.remove();
            d && (c.append = b('<span class="' + this._appendClass + '">' + d + "</span>"), a[e ? "before" : "after"](c.append));
            a.unbind("focus", this._showDatepicker);
            c.trigger && c.trigger.remove();
            d = this._get(c, "showOn");
            "focus" != d && "both" != d || a.focus(this._showDatepicker);
            if ("button" ==
                d || "both" == d) {
                var d = this._get(c, "buttonText"),
                    g = this._get(c, "buttonImage");
                c.trigger = b(this._get(c, "buttonImageOnly") ? b("<img/>").addClass(this._triggerClass).attr({
                    src: g,
                    alt: d,
                    title: d
                }) : b('<button type="button"></button>').addClass(this._triggerClass).html("" == g ? d : b("<img/>").attr({
                    src: g,
                    alt: d,
                    title: d
                })));
                a[e ? "before" : "after"](c.trigger);
                c.trigger.click(function() {
                    b.datepicker._datepickerShowing && b.datepicker._lastInput == a[0] ? b.datepicker._hideDatepicker() : b.datepicker._showDatepicker(a[0]);
                    return !1
                })
            }
        },
        _autoSize: function(b) {
            if (this._get(b, "autoSize") && !b.inline) {
                var a = new Date(2009, 11, 20),
                    c = this._get(b, "dateFormat");
                if (c.match(/[DM]/)) {
                    var d = function(b) {
                        for (var a = 0, c = 0, f = 0; f < b.length; f++) b[f].length > a && (a = b[f].length, c = f);
                        return c
                    };
                    a.setMonth(d(this._get(b, c.match(/MM/) ? "monthNames" : "monthNamesShort")));
                    a.setDate(d(this._get(b, c.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - a.getDay())
                }
                b.input.attr("size", this._formatDate(b, a).length)
            }
        },
        _inlineDatepicker: function(a, c) {
            var d = b(a);
            d.hasClass(this.markerClassName) ||
                (d.addClass(this.markerClassName).append(c.dpDiv).bind("setData.datepicker", function(b, a, f) {
                    c.settings[a] = f
                }).bind("getData.datepicker", function(b, a) {
                    return this._get(c, a)
                }), b.data(a, "datepicker", c), this._setDate(c, this._getDefaultDate(c), !0), this._updateDatepicker(c), this._updateAlternate(c), c.dpDiv.show())
        },
        _dialogDatepicker: function(a, d, e, g, m) {
            a = this._dialogInst;
            a || (this.uuid += 1, this._dialogInput = b('<input type="text" id="dp' + this.uuid + '" style="position: absolute; top: -100px; width: 0px; z-index: -10;"/>'),
                this._dialogInput.keydown(this._doKeyDown), b("body").append(this._dialogInput), a = this._dialogInst = this._newInst(this._dialogInput, !1), a.settings = {}, b.data(this._dialogInput[0], "datepicker", a));
            c(a.settings, g || {});
            d = d && d.constructor == Date ? this._formatDate(a, d) : d;
            this._dialogInput.val(d);
            this._pos = m ? m.length ? m : [m.pageX, m.pageY] : null;
            this._pos || (this._pos = [document.documentElement.clientWidth / 2 - 100 + (document.documentElement.scrollLeft || document.body.scrollLeft), document.documentElement.clientHeight /
                2 - 150 + (document.documentElement.scrollTop || document.body.scrollTop)
            ]);
            this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px");
            a.settings.onSelect = e;
            this._inDialog = !0;
            this.dpDiv.addClass(this._dialogClass);
            this._showDatepicker(this._dialogInput[0]);
            b.blockUI && b.blockUI(this.dpDiv);
            b.data(this._dialogInput[0], "datepicker", a);
            return this
        },
        _destroyDatepicker: function(a) {
            var c = b(a),
                d = b.data(a, "datepicker");
            if (c.hasClass(this.markerClassName)) {
                var e = a.nodeName.toLowerCase();
                b.removeData(a,
                    "datepicker");
                "input" == e ? (d.append.remove(), d.trigger.remove(), c.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp)) : "div" != e && "span" != e || c.removeClass(this.markerClassName).empty()
            }
        },
        _enableDatepicker: function(a) {
            var c = b(a),
                d = b.data(a, "datepicker");
            if (c.hasClass(this.markerClassName)) {
                var e = a.nodeName.toLowerCase();
                if ("input" == e) a.disabled = !1, d.trigger.filter("button").each(function() {
                    this.disabled = !1
                }).end().filter("img").css({
                    opacity: "1.0",
                    cursor: ""
                });
                else if ("div" == e || "span" == e) c = c.children("." + this._inlineClass), c.children().removeClass("ui-state-disabled"), c.find("select.ui-datepicker-month, select.ui-datepicker-year").removeAttr("disabled");
                this._disabledInputs = b.map(this._disabledInputs, function(b) {
                    return b == a ? null : b
                })
            }
        },
        _disableDatepicker: function(a) {
            var c = b(a),
                d = b.data(a, "datepicker");
            if (c.hasClass(this.markerClassName)) {
                var e = a.nodeName.toLowerCase();
                if ("input" == e) a.disabled = !0, d.trigger.filter("button").each(function() {
                    this.disabled = !0
                }).end().filter("img").css({
                    opacity: "0.5",
                    cursor: "default"
                });
                else if ("div" == e || "span" == e) c = c.children("." + this._inlineClass), c.children().addClass("ui-state-disabled"), c.find("select.ui-datepicker-month, select.ui-datepicker-year").attr("disabled", "disabled");
                this._disabledInputs = b.map(this._disabledInputs, function(b) {
                    return b == a ? null : b
                });
                this._disabledInputs[this._disabledInputs.length] = a
            }
        },
        _isDisabledDatepicker: function(a) {
            if (!a) return !1;
            for (var b = 0; b < this._disabledInputs.length; b++)
                if (this._disabledInputs[b] ==
                    a) return !0;
            return !1
        },
        _getInst: function(a) {
            try {
                return b.data(a, "datepicker")
            } catch (c) {
                throw "Missing instance data for this datepicker";
            }
        },
        _optionDatepicker: function(a, d, e) {
            var g = this._getInst(a);
            if (2 == arguments.length && "string" == typeof d) return "defaults" == d ? b.extend({}, b.datepicker._defaults) : g ? "all" == d ? b.extend({}, g.settings) : this._get(g, d) : null;
            var m = d || {};
            "string" == typeof d && (m = {}, m[d] = e);
            if (g) {
                this._curInst == g && this._hideDatepicker();
                var p = this._getDateDatepicker(a, !0),
                    v = this._getMinMaxDate(g,
                        "min"),
                    q = this._getMinMaxDate(g, "max");
                c(g.settings, m);
                null !== v && m.dateFormat !== l && m.minDate === l && (g.settings.minDate = this._formatDate(g, v));
                null !== q && m.dateFormat !== l && m.maxDate === l && (g.settings.maxDate = this._formatDate(g, q));
                this._attachments(b(a), g);
                this._autoSize(g);
                this._setDate(g, p);
                this._updateAlternate(g);
                this._updateDatepicker(g)
            }
        },
        _changeDatepicker: function(a, b, c) {
            this._optionDatepicker(a, b, c)
        },
        _refreshDatepicker: function(a) {
            (a = this._getInst(a)) && this._updateDatepicker(a)
        },
        _setDateDatepicker: function(a,
            b) {
            var c = this._getInst(a);
            c && (this._setDate(c, b), this._updateDatepicker(c), this._updateAlternate(c))
        },
        _getDateDatepicker: function(a, b) {
            var c = this._getInst(a);
            c && !c.inline && this._setDateFromField(c, b);
            return c ? this._getDate(c) : null
        },
        _doKeyDown: function(a) {
            var c = b.datepicker._getInst(a.target),
                d = !0,
                e = c.dpDiv.is(".ui-datepicker-rtl");
            c._keyEvent = !0;
            if (b.datepicker._datepickerShowing) switch (a.keyCode) {
                case 9:
                    b.datepicker._hideDatepicker();
                    d = !1;
                    break;
                case 13:
                    return d = b("td." + b.datepicker._dayOverClass +
                        ":not(." + b.datepicker._currentClass + ")", c.dpDiv), d[0] ? b.datepicker._selectDay(a.target, c.selectedMonth, c.selectedYear, d[0]) : b.datepicker._hideDatepicker(), !1;
                case 27:
                    b.datepicker._hideDatepicker();
                    break;
                case 33:
                    b.datepicker._adjustDate(a.target, a.ctrlKey ? -b.datepicker._get(c, "stepBigMonths") : -b.datepicker._get(c, "stepMonths"), "M");
                    break;
                case 34:
                    b.datepicker._adjustDate(a.target, a.ctrlKey ? +b.datepicker._get(c, "stepBigMonths") : +b.datepicker._get(c, "stepMonths"), "M");
                    break;
                case 35:
                    (a.ctrlKey || a.metaKey) &&
                    b.datepicker._clearDate(a.target);
                    d = a.ctrlKey || a.metaKey;
                    break;
                case 36:
                    (a.ctrlKey || a.metaKey) && b.datepicker._gotoToday(a.target);
                    d = a.ctrlKey || a.metaKey;
                    break;
                case 37:
                    (a.ctrlKey || a.metaKey) && b.datepicker._adjustDate(a.target, e ? 1 : -1, "D");
                    d = a.ctrlKey || a.metaKey;
                    a.originalEvent.altKey && b.datepicker._adjustDate(a.target, a.ctrlKey ? -b.datepicker._get(c, "stepBigMonths") : -b.datepicker._get(c, "stepMonths"), "M");
                    break;
                case 38:
                    (a.ctrlKey || a.metaKey) && b.datepicker._adjustDate(a.target, -7, "D");
                    d = a.ctrlKey || a.metaKey;
                    break;
                case 39:
                    (a.ctrlKey || a.metaKey) && b.datepicker._adjustDate(a.target, e ? -1 : 1, "D");
                    d = a.ctrlKey || a.metaKey;
                    a.originalEvent.altKey && b.datepicker._adjustDate(a.target, a.ctrlKey ? +b.datepicker._get(c, "stepBigMonths") : +b.datepicker._get(c, "stepMonths"), "M");
                    break;
                case 40:
                    (a.ctrlKey || a.metaKey) && b.datepicker._adjustDate(a.target, 7, "D");
                    d = a.ctrlKey || a.metaKey;
                    break;
                default:
                    d = !1
            } else 36 == a.keyCode && a.ctrlKey ? b.datepicker._showDatepicker(this) : d = !1;
            d && (a.preventDefault(), a.stopPropagation())
        },
        _doKeyPress: function(a) {
            var c =
                b.datepicker._getInst(a.target);
            if (b.datepicker._get(c, "constrainInput")) {
                var c = b.datepicker._possibleChars(b.datepicker._get(c, "dateFormat")),
                    d = String.fromCharCode(a.charCode == l ? a.keyCode : a.charCode);
                return a.ctrlKey || a.metaKey || " " > d || !c || -1 < c.indexOf(d)
            }
        },
        _doKeyUp: function(a) {
            a = b.datepicker._getInst(a.target);
            if (a.input.val() != a.lastVal) try {
                b.datepicker.parseDate(b.datepicker._get(a, "dateFormat"), a.input ? a.input.val() : null, b.datepicker._getFormatConfig(a)) && (b.datepicker._setDateFromField(a), b.datepicker._updateAlternate(a),
                    b.datepicker._updateDatepicker(a))
            } catch (c) {
                b.datepicker.log(c)
            }
            return !0
        },
        _showDatepicker: function(a) {
            a = a.target || a;
            "input" != a.nodeName.toLowerCase() && (a = b("input", a.parentNode)[0]);
            if (!b.datepicker._isDisabledDatepicker(a) && b.datepicker._lastInput != a) {
                var d = b.datepicker._getInst(a);
                b.datepicker._curInst && b.datepicker._curInst != d && (b.datepicker._datepickerShowing && b.datepicker._triggerOnClose(b.datepicker._curInst), b.datepicker._curInst.dpDiv.stop(!0, !0));
                var e = b.datepicker._get(d, "beforeShow");
                c(d.settings,
                    e ? e.apply(a, [a, d]) : {});
                d.lastVal = null;
                b.datepicker._lastInput = a;
                b.datepicker._setDateFromField(d);
                b.datepicker._inDialog && (a.value = "");
                b.datepicker._pos || (b.datepicker._pos = b.datepicker._findPos(a), b.datepicker._pos[1] += a.offsetHeight);
                var g = !1;
                b(a).parents().each(function() {
                    g |= "fixed" == b(this).css("position");
                    return !g
                });
                g && b.browser.opera && (b.datepicker._pos[0] -= document.documentElement.scrollLeft, b.datepicker._pos[1] -= document.documentElement.scrollTop);
                e = {
                    left: b.datepicker._pos[0],
                    top: b.datepicker._pos[1]
                };
                b.datepicker._pos = null;
                d.dpDiv.empty();
                d.dpDiv.css({
                    position: "absolute",
                    display: "block",
                    top: "-1000px"
                });
                b.datepicker._updateDatepicker(d);
                e = b.datepicker._checkOffset(d, e, g);
                d.dpDiv.css({
                    position: b.datepicker._inDialog && b.blockUI ? "static" : g ? "fixed" : "absolute",
                    display: "none",
                    left: e.left + "px",
                    top: e.top + "px"
                });
                if (!d.inline) {
                    var e = b.datepicker._get(d, "showAnim"),
                        m = b.datepicker._get(d, "duration"),
                        l = function() {
                            var a = d.dpDiv.find("iframe.ui-datepicker-cover");
                            if (a.length) {
                                var c = b.datepicker._getBorders(d.dpDiv);
                                a.css({
                                    left: -c[0],
                                    top: -c[1],
                                    width: d.dpDiv.outerWidth(),
                                    height: d.dpDiv.outerHeight()
                                })
                            }
                        };
                    d.dpDiv.zIndex(b(a).zIndex() + 1);
                    b.datepicker._datepickerShowing = !0;
                    if (b.effects && (b.effects.effect[e] || b.effects[e])) d.dpDiv.show(e, b.datepicker._get(d, "showOptions"), m, l);
                    else d.dpDiv[e || "show"](e ? m : null, l);
                    e && m || l();
                    d.input.is(":visible") && !d.input.is(":disabled") && d.input.focus();
                    b.datepicker._curInst = d
                }
            }
        },
        _updateDatepicker: function(a) {
            var c = b.datepicker._getBorders(a.dpDiv);
            e = a;
            a.dpDiv.empty().append(this._generateHTML(a));
            var d = a.dpDiv.find("iframe.ui-datepicker-cover");
            d.length && d.css({
                left: -c[0],
                top: -c[1],
                width: a.dpDiv.outerWidth(),
                height: a.dpDiv.outerHeight()
            });
            a.dpDiv.find("." + this._dayOverClass + " a").mouseover();
            c = this._getNumberOfMonths(a);
            d = c[1];
            a.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width("");
            1 < d && a.dpDiv.addClass("ui-datepicker-multi-" + d).css("width", 17 * d + "em");
            a.dpDiv[(1 != c[0] || 1 != c[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi");
            a.dpDiv[(this._get(a, "isRTL") ?
                "add" : "remove") + "Class"]("ui-datepicker-rtl");
            a == b.datepicker._curInst && b.datepicker._datepickerShowing && a.input && a.input.is(":visible") && !a.input.is(":disabled") && a.input[0] != document.activeElement && a.input.focus();
            if (a.yearshtml) {
                var g = a.yearshtml;
                setTimeout(function() {
                    g === a.yearshtml && a.yearshtml && a.dpDiv.find("select.ui-datepicker-year:first").replaceWith(a.yearshtml);
                    g = a.yearshtml = null
                }, 0)
            }
        },
        _getBorders: function(a) {
            var b = function(a) {
                return {
                    thin: 1,
                    medium: 2,
                    thick: 3
                }[a] || a
            };
            return [parseFloat(b(a.css("border-left-width"))),
                parseFloat(b(a.css("border-top-width")))
            ]
        },
        _checkOffset: function(a, c, d) {
            var e = a.dpDiv.outerWidth(),
                g = a.dpDiv.outerHeight(),
                l = a.input ? a.input.outerWidth() : 0,
                v = a.input ? a.input.outerHeight() : 0,
                q = document.documentElement.clientWidth + b(document).scrollLeft(),
                t = document.documentElement.clientHeight + b(document).scrollTop();
            c.left -= this._get(a, "isRTL") ? e - l : 0;
            c.left -= d && c.left == a.input.offset().left ? b(document).scrollLeft() : 0;
            c.top -= d && c.top == a.input.offset().top + v ? b(document).scrollTop() : 0;
            c.left -= Math.min(c.left,
                c.left + e > q && q > e ? Math.abs(c.left + e - q) : 0);
            c.top -= Math.min(c.top, c.top + g > t && t > g ? Math.abs(g + v) : 0);
            return c
        },
        _findPos: function(a) {
            for (var c = this._getInst(a), c = this._get(c, "isRTL"); a && ("hidden" == a.type || 1 != a.nodeType || b.expr.filters.hidden(a));) a = a[c ? "previousSibling" : "nextSibling"];
            a = b(a).offset();
            return [a.left, a.top]
        },
        _triggerOnClose: function(a) {
            var b = this._get(a, "onClose");
            b && b.apply(a.input ? a.input[0] : null, [a.input ? a.input.val() : "", a])
        },
        _hideDatepicker: function(a) {
            var c = this._curInst;
            if (c && (!a || c ==
                    b.data(a, "datepicker")) && this._datepickerShowing) {
                a = this._get(c, "showAnim");
                var d = this._get(c, "duration"),
                    e = function() {
                        b.datepicker._tidyDialog(c);
                        this._curInst = null
                    };
                if (b.effects && (b.effects.effect[a] || b.effects[a])) c.dpDiv.hide(a, b.datepicker._get(c, "showOptions"), d, e);
                else c.dpDiv["slideDown" == a ? "slideUp" : "fadeIn" == a ? "fadeOut" : "hide"](a ? d : null, e);
                a || e();
                b.datepicker._triggerOnClose(c);
                this._datepickerShowing = !1;
                this._lastInput = null;
                this._inDialog && (this._dialogInput.css({
                    position: "absolute",
                    left: "0",
                    top: "-100px"
                }), b.blockUI && (b.unblockUI(), b("body").append(this.dpDiv)));
                this._inDialog = !1
            }
        },
        _tidyDialog: function(a) {
            a.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
        },
        _checkExternalClick: function(a) {
            b.datepicker._curInst && (a = b(a.target), a[0].id == b.datepicker._mainDivId || 0 != a.parents("#" + b.datepicker._mainDivId).length || a.hasClass(b.datepicker.markerClassName) || a.hasClass(b.datepicker._triggerClass) || !b.datepicker._datepickerShowing || b.datepicker._inDialog && b.blockUI || b.datepicker._hideDatepicker())
        },
        _adjustDate: function(a, c, d) {
            a = b(a);
            var e = this._getInst(a[0]);
            this._isDisabledDatepicker(a[0]) || (this._adjustInstDate(e, c + ("M" == d ? this._get(e, "showCurrentAtPos") : 0), d), this._updateDatepicker(e))
        },
        _gotoToday: function(a) {
            a = b(a);
            var c = this._getInst(a[0]);
            if (this._get(c, "gotoCurrent") && c.currentDay) c.selectedDay = c.currentDay, c.drawMonth = c.selectedMonth = c.currentMonth, c.drawYear = c.selectedYear = c.currentYear;
            else {
                var d = new Date;
                c.selectedDay = d.getDate();
                c.drawMonth = c.selectedMonth = d.getMonth();
                c.drawYear =
                    c.selectedYear = d.getFullYear()
            }
            this._notifyChange(c);
            this._adjustDate(a)
        },
        _selectMonthYear: function(a, c, d) {
            a = b(a);
            var e = this._getInst(a[0]);
            e._selectingMonthYear = !1;
            e["selected" + ("M" == d ? "Month" : "Year")] = e["draw" + ("M" == d ? "Month" : "Year")] = parseInt(c.options[c.selectedIndex].value, 10);
            this._notifyChange(e);
            this._adjustDate(a)
        },
        _clickMonthYear: function(a) {
            a = b(a);
            var c = this._getInst(a[0]);
            c.input && c._selectingMonthYear && setTimeout(function() {
                c.input.focus()
            }, 0);
            c._selectingMonthYear = !c._selectingMonthYear
        },
        _selectDay: function(a, c, d, e) {
            var g = b(a);
            b(e).hasClass(this._unselectableClass) || this._isDisabledDatepicker(g[0]) || (g = this._getInst(g[0]), g.selectedDay = g.currentDay = b("a", e).html(), g.selectedMonth = g.currentMonth = c, g.selectedYear = g.currentYear = d, this._selectDate(a, this._formatDate(g, g.currentDay, g.currentMonth, g.currentYear)))
        },
        _clearDate: function(a) {
            a = b(a);
            this._getInst(a[0]);
            this._selectDate(a, "")
        },
        _selectDate: function(a, c) {
            var d = b(a),
                d = this._getInst(d[0]);
            c = null != c ? c : this._formatDate(d);
            d.input &&
                d.input.val(c);
            this._updateAlternate(d);
            var e = this._get(d, "onSelect");
            e ? e.apply(d.input ? d.input[0] : null, [c, d]) : d.input && d.input.trigger("change");
            d.inline ? this._updateDatepicker(d) : (this._hideDatepicker(), this._lastInput = d.input[0], "object" != typeof d.input[0] && d.input.focus(), this._lastInput = null)
        },
        _updateAlternate: function(a) {
            var c = this._get(a, "altField");
            if (c) {
                var d = this._get(a, "altFormat") || this._get(a, "dateFormat"),
                    e = this._getDate(a),
                    g = this.formatDate(d, e, this._getFormatConfig(a));
                b(c).each(function() {
                    b(this).val(g)
                })
            }
        },
        noWeekends: function(a) {
            a = a.getDay();
            return [0 < a && 6 > a, ""]
        },
        iso8601Week: function(a) {
            a = new Date(a.getTime());
            a.setDate(a.getDate() + 4 - (a.getDay() || 7));
            var b = a.getTime();
            a.setMonth(0);
            a.setDate(1);
            return Math.floor(Math.round((b - a) / 864E5) / 7) + 1
        },
        parseDate: function(a, c, d) {
            if (null == a || null == c) throw "Invalid arguments";
            c = "object" == typeof c ? c.toString() : c + "";
            if ("" == c) return null;
            for (var e = (d ? d.shortYearCutoff : null) || this._defaults.shortYearCutoff, e = "string" != typeof e ? e : (new Date).getFullYear() % 100 + parseInt(e,
                    10), g = (d ? d.dayNamesShort : null) || this._defaults.dayNamesShort, l = (d ? d.dayNames : null) || this._defaults.dayNames, v = (d ? d.monthNamesShort : null) || this._defaults.monthNamesShort, q = (d ? d.monthNames : null) || this._defaults.monthNames, t = d = -1, r = -1, w = -1, u = !1, x = function(b) {
                    (b = G + 1 < a.length && a.charAt(G + 1) == b) && G++;
                    return b
                }, y = function(a) {
                    var b = x(a);
                    a = new RegExp("^\\d{1," + ("@" == a ? 14 : "!" == a ? 20 : "y" == a && b ? 4 : "o" == a ? 3 : 2) + "}");
                    a = c.substring(F).match(a);
                    if (!a) throw "Missing number at position " + F;
                    F += a[0].length;
                    return parseInt(a[0],
                        10)
                }, z = function(a, d, f) {
                    a = b.map(x(a) ? f : d, function(a, b) {
                        return [
                            [b, a]
                        ]
                    }).sort(function(a, b) {
                        return -(a[1].length - b[1].length)
                    });
                    var e = -1;
                    b.each(a, function(a, b) {
                        var d = b[1];
                        if (c.substr(F, d.length).toLowerCase() == d.toLowerCase()) return e = b[0], F += d.length, !1
                    });
                    if (-1 != e) return e + 1;
                    throw "Unknown name at position " + F;
                }, C = function() {
                    if (c.charAt(F) != a.charAt(G)) throw "Unexpected literal at position " + F;
                    F++
                }, F = 0, G = 0; G < a.length; G++)
                if (u) "'" != a.charAt(G) || x("'") ? C() : u = !1;
                else switch (a.charAt(G)) {
                    case "d":
                        r = y("d");
                        break;
                    case "D":
                        z("D", g, l);
                        break;
                    case "o":
                        w = y("o");
                        break;
                    case "m":
                        t = y("m");
                        break;
                    case "M":
                        t = z("M", v, q);
                        break;
                    case "y":
                        d = y("y");
                        break;
                    case "@":
                        var D = new Date(y("@"));
                        d = D.getFullYear();
                        t = D.getMonth() + 1;
                        r = D.getDate();
                        break;
                    case "!":
                        D = new Date((y("!") - this._ticksTo1970) / 1E4);
                        d = D.getFullYear();
                        t = D.getMonth() + 1;
                        r = D.getDate();
                        break;
                    case "'":
                        x("'") ? C() : u = !0;
                        break;
                    default:
                        C()
                }
            if (F < c.length) throw "Extra/unparsed characters found in date: " + c.substring(F); - 1 == d ? d = (new Date).getFullYear() : 100 > d && (d += (new Date).getFullYear() -
                (new Date).getFullYear() % 100 + (d <= e ? 0 : -100));
            if (-1 < w) {
                t = 1;
                r = w;
                do {
                    e = this._getDaysInMonth(d, t - 1);
                    if (r <= e) break;
                    t++;
                    r -= e
                } while (1)
            }
            D = this._daylightSavingAdjust(new Date(d, t - 1, r));
            if (D.getFullYear() != d || D.getMonth() + 1 != t || D.getDate() != r) throw "Invalid date";
            return D
        },
        ATOM: "yy-mm-dd",
        COOKIE: "D, dd M yy",
        ISO_8601: "yy-mm-dd",
        RFC_822: "D, d M y",
        RFC_850: "DD, dd-M-y",
        RFC_1036: "D, d M y",
        RFC_1123: "D, d M yy",
        RFC_2822: "D, d M yy",
        RSS: "D, d M y",
        TICKS: "!",
        TIMESTAMP: "@",
        W3C: "yy-mm-dd",
        _ticksTo1970: 864E9 * (718685 + Math.floor(492.5) -
            Math.floor(19.7) + Math.floor(4.925)),
        formatDate: function(a, b, c) {
            if (!b) return "";
            var d = (c ? c.dayNamesShort : null) || this._defaults.dayNamesShort,
                e = (c ? c.dayNames : null) || this._defaults.dayNames,
                g = (c ? c.monthNamesShort : null) || this._defaults.monthNamesShort;
            c = (c ? c.monthNames : null) || this._defaults.monthNames;
            var l = function(b) {
                    (b = u + 1 < a.length && a.charAt(u + 1) == b) && u++;
                    return b
                },
                q = function(a, b, c) {
                    b = "" + b;
                    if (l(a))
                        for (; b.length < c;) b = "0" + b;
                    return b
                },
                t = function(a, b, c, d) {
                    return l(a) ? d[b] : c[b]
                },
                r = "",
                w = !1;
            if (b)
                for (var u =
                        0; u < a.length; u++)
                    if (w) "'" != a.charAt(u) || l("'") ? r += a.charAt(u) : w = !1;
                    else switch (a.charAt(u)) {
                        case "d":
                            r += q("d", b.getDate(), 2);
                            break;
                        case "D":
                            r += t("D", b.getDay(), d, e);
                            break;
                        case "o":
                            r += q("o", Math.round(((new Date(b.getFullYear(), b.getMonth(), b.getDate())).getTime() - (new Date(b.getFullYear(), 0, 0)).getTime()) / 864E5), 3);
                            break;
                        case "m":
                            r += q("m", b.getMonth() + 1, 2);
                            break;
                        case "M":
                            r += t("M", b.getMonth(), g, c);
                            break;
                        case "y":
                            r += l("y") ? b.getFullYear() : (10 > b.getYear() % 100 ? "0" : "") + b.getYear() % 100;
                            break;
                        case "@":
                            r +=
                                b.getTime();
                            break;
                        case "!":
                            r += 1E4 * b.getTime() + this._ticksTo1970;
                            break;
                        case "'":
                            l("'") ? r += "'" : w = !0;
                            break;
                        default:
                            r += a.charAt(u)
                    }
            return r
        },
        _possibleChars: function(a) {
            for (var b = "", c = !1, d = function(b) {
                    (b = e + 1 < a.length && a.charAt(e + 1) == b) && e++;
                    return b
                }, e = 0; e < a.length; e++)
                if (c) "'" != a.charAt(e) || d("'") ? b += a.charAt(e) : c = !1;
                else switch (a.charAt(e)) {
                    case "d":
                    case "m":
                    case "y":
                    case "@":
                        b += "0123456789";
                        break;
                    case "D":
                    case "M":
                        return null;
                    case "'":
                        d("'") ? b += "'" : c = !0;
                        break;
                    default:
                        b += a.charAt(e)
                }
            return b
        },
        _get: function(a,
            b) {
            return a.settings[b] !== l ? a.settings[b] : this._defaults[b]
        },
        _setDateFromField: function(a, b) {
            if (a.input.val() != a.lastVal) {
                var c = this._get(a, "dateFormat"),
                    d = a.lastVal = a.input ? a.input.val() : null,
                    e, g;
                e = g = this._getDefaultDate(a);
                var l = this._getFormatConfig(a);
                try {
                    e = this.parseDate(c, d, l) || g
                } catch (q) {
                    this.log(q), d = b ? "" : d
                }
                a.selectedDay = e.getDate();
                a.drawMonth = a.selectedMonth = e.getMonth();
                a.drawYear = a.selectedYear = e.getFullYear();
                a.currentDay = d ? e.getDate() : 0;
                a.currentMonth = d ? e.getMonth() : 0;
                a.currentYear =
                    d ? e.getFullYear() : 0;
                this._adjustInstDate(a)
            }
        },
        _getDefaultDate: function(a) {
            return this._restrictMinMax(a, this._determineDate(a, this._get(a, "defaultDate"), new Date))
        },
        _determineDate: function(a, c, d) {
            var e = function(a) {
                    var b = new Date;
                    b.setDate(b.getDate() + a);
                    return b
                },
                g = function(c) {
                    try {
                        return b.datepicker.parseDate(b.datepicker._get(a, "dateFormat"), c, b.datepicker._getFormatConfig(a))
                    } catch (d) {}
                    for (var e = (c.toLowerCase().match(/^c/) ? b.datepicker._getDate(a) : null) || new Date, g = e.getFullYear(), h = e.getMonth(),
                            e = e.getDate(), k = /([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, l = k.exec(c); l;) {
                        switch (l[2] || "d") {
                            case "d":
                            case "D":
                                e += parseInt(l[1], 10);
                                break;
                            case "w":
                            case "W":
                                e += 7 * parseInt(l[1], 10);
                                break;
                            case "m":
                            case "M":
                                h += parseInt(l[1], 10);
                                e = Math.min(e, b.datepicker._getDaysInMonth(g, h));
                                break;
                            case "y":
                            case "Y":
                                g += parseInt(l[1], 10), e = Math.min(e, b.datepicker._getDaysInMonth(g, h))
                        }
                        l = k.exec(c)
                    }
                    return new Date(g, h, e)
                };
            if (c = (c = null == c || "" === c ? d : "string" == typeof c ? g(c) : "number" == typeof c ? isNaN(c) ? d : e(c) : new Date(c.getTime())) &&
                "Invalid Date" == c.toString() ? d : c) c.setHours(0), c.setMinutes(0), c.setSeconds(0), c.setMilliseconds(0);
            return this._daylightSavingAdjust(c)
        },
        _daylightSavingAdjust: function(a) {
            if (!a) return null;
            a.setHours(12 < a.getHours() ? a.getHours() + 2 : 0);
            return a
        },
        _setDate: function(a, b, c) {
            var d = !b,
                e = a.selectedMonth,
                g = a.selectedYear;
            b = this._restrictMinMax(a, this._determineDate(a, b, new Date));
            a.selectedDay = a.currentDay = b.getDate();
            a.drawMonth = a.selectedMonth = a.currentMonth = b.getMonth();
            a.drawYear = a.selectedYear = a.currentYear =
                b.getFullYear();
            e == a.selectedMonth && g == a.selectedYear || c || this._notifyChange(a);
            this._adjustInstDate(a);
            a.input && a.input.val(d ? "" : this._formatDate(a))
        },
        _getDate: function(a) {
            return !a.currentYear || a.input && "" == a.input.val() ? null : this._daylightSavingAdjust(new Date(a.currentYear, a.currentMonth, a.currentDay))
        },
        _generateHTML: function(a) {
            var c = new Date,
                c = this._daylightSavingAdjust(new Date(c.getFullYear(), c.getMonth(), c.getDate())),
                d = this._get(a, "isRTL"),
                e = this._get(a, "showButtonPanel"),
                l = this._get(a, "hideIfNoPrevNext"),
                p = this._get(a, "navigationAsDateFormat"),
                v = this._getNumberOfMonths(a),
                q = this._get(a, "showCurrentAtPos"),
                t = this._get(a, "stepMonths"),
                r = 1 != v[0] || 1 != v[1],
                w = this._daylightSavingAdjust(a.currentDay ? new Date(a.currentYear, a.currentMonth, a.currentDay) : new Date(9999, 9, 9)),
                u = this._getMinMaxDate(a, "min"),
                x = this._getMinMaxDate(a, "max"),
                q = a.drawMonth - q,
                y = a.drawYear;
            0 > q && (q += 12, y--);
            if (x)
                for (var z = this._daylightSavingAdjust(new Date(x.getFullYear(), x.getMonth() - v[0] * v[1] + 1, x.getDate())), z = u && z < u ? u : z; this._daylightSavingAdjust(new Date(y,
                        q, 1)) > z;) q--, 0 > q && (q = 11, y--);
            a.drawMonth = q;
            a.drawYear = y;
            var z = this._get(a, "prevText"),
                z = p ? this.formatDate(z, this._daylightSavingAdjust(new Date(y, q - t, 1)), this._getFormatConfig(a)) : z,
                z = this._canAdjustMonth(a, -1, y, q) ? '<a class="ui-datepicker-prev ui-corner-all" onclick="DP_jQuery_' + g + ".datepicker._adjustDate('#" + a.id + "', -" + t + ", 'M');\" title=\"" + z + '"><span class="ui-icon ui-icon-circle-triangle-' + (d ? "e" : "w") + '">' + z + "</span></a>" : l ? "" : '<a class="ui-datepicker-prev ui-corner-all ui-state-disabled" title="' +
                z + '"><span class="ui-icon ui-icon-circle-triangle-' + (d ? "e" : "w") + '">' + z + "</span></a>",
                C = this._get(a, "nextText"),
                C = p ? this.formatDate(C, this._daylightSavingAdjust(new Date(y, q + t, 1)), this._getFormatConfig(a)) : C,
                l = this._canAdjustMonth(a, 1, y, q) ? '<a class="ui-datepicker-next ui-corner-all" onclick="DP_jQuery_' + g + ".datepicker._adjustDate('#" + a.id + "', +" + t + ", 'M');\" title=\"" + C + '"><span class="ui-icon ui-icon-circle-triangle-' + (d ? "w" : "e") + '">' + C + "</span></a>" : l ? "" : '<a class="ui-datepicker-next ui-corner-all ui-state-disabled" title="' +
                C + '"><span class="ui-icon ui-icon-circle-triangle-' + (d ? "w" : "e") + '">' + C + "</span></a>",
                t = this._get(a, "currentText"),
                C = this._get(a, "gotoCurrent") && a.currentDay ? w : c,
                t = p ? this.formatDate(t, C, this._getFormatConfig(a)) : t,
                p = a.inline ? "" : '<button type="button" class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" onclick="DP_jQuery_' + g + '.datepicker._hideDatepicker();">' + this._get(a, "closeText") + "</button>",
                e = e ? '<div class="ui-datepicker-buttonpane ui-widget-content">' + (d ? p : "") + (this._isInRange(a,
                    C) ? '<button type="button" class="ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all" onclick="DP_jQuery_' + g + ".datepicker._gotoToday('#" + a.id + "');\">" + t + "</button>" : "") + (d ? "" : p) + "</div>" : "",
                p = parseInt(this._get(a, "firstDay"), 10),
                p = isNaN(p) ? 0 : p,
                t = this._get(a, "showWeek"),
                C = this._get(a, "dayNames");
            this._get(a, "dayNamesShort");
            var F = this._get(a, "dayNamesMin"),
                G = this._get(a, "monthNames"),
                D = this._get(a, "monthNamesShort"),
                J = this._get(a, "beforeShowDay"),
                O = this._get(a, "showOtherMonths"),
                V = this._get(a, "selectOtherMonths");
            this._get(a, "calculateWeek");
            for (var S = this._getDefaultDate(a), K = "", L = 0; L < v[0]; L++) {
                for (var P = "", M = 0; M < v[1]; M++) {
                    var T = this._daylightSavingAdjust(new Date(y, q, a.selectedDay)),
                        E = " ui-corner-all",
                        B = "";
                    if (r) {
                        B += '<div class="ui-datepicker-group';
                        if (1 < v[1]) switch (M) {
                            case 0:
                                B += " ui-datepicker-group-first";
                                E = " ui-corner-" + (d ? "right" : "left");
                                break;
                            case v[1] - 1:
                                B += " ui-datepicker-group-last";
                                E = " ui-corner-" + (d ? "left" : "right");
                                break;
                            default:
                                B += " ui-datepicker-group-middle",
                                    E = ""
                        }
                        B += '">'
                    }
                    for (var B = B + ('<div class="ui-datepicker-header ui-widget-header ui-helper-clearfix' + E + '">' + (/all|left/.test(E) && 0 == L ? d ? l : z : "") + (/all|right/.test(E) && 0 == L ? d ? z : l : "") + this._generateMonthYearHeader(a, q, y, u, x, 0 < L || 0 < M, G, D) + '</div><table class="ui-datepicker-calendar"><thead><tr>'), H = t ? '<th class="ui-datepicker-week-col">' + this._get(a, "weekHeader") + "</th>" : "", E = 0; 7 > E; E++) var A = (E + p) % 7,
                        H = H + ("<th" + (5 <= (E + p + 6) % 7 ? ' class="ui-datepicker-week-end"' : "") + '><span title="' + C[A] + '">' + F[A] + "</span></th>");
                    B += H + "</tr></thead><tbody>";
                    H = this._getDaysInMonth(y, q);
                    y == a.selectedYear && q == a.selectedMonth && (a.selectedDay = Math.min(a.selectedDay, H));
                    for (var E = (this._getFirstDayOfMonth(y, q) - p + 7) % 7, H = r ? 6 : Math.ceil((E + H) / 7), A = this._daylightSavingAdjust(new Date(y, q, 1 - E)), U = 0; U < H; U++) {
                        for (var B = B + "<tr>", Q = t ? '<td class="ui-datepicker-week-col">' + this._get(a, "calculateWeek")(A) + "</td>" : "", E = 0; 7 > E; E++) {
                            var N = J ? J.apply(a.input ? a.input[0] : null, [A]) : [!0, ""],
                                I = A.getMonth() != q,
                                R = I && !V || !N[0] || u && A < u || x && A > x,
                                Q = Q + ('<td class="' +
                                    (5 <= (E + p + 6) % 7 ? " ui-datepicker-week-end" : "") + (I ? " ui-datepicker-other-month" : "") + (A.getTime() == T.getTime() && q == a.selectedMonth && a._keyEvent || S.getTime() == A.getTime() && S.getTime() == T.getTime() ? " " + this._dayOverClass : "") + (R ? " " + this._unselectableClass + " ui-state-disabled" : "") + (I && !O ? "" : " " + N[1] + (A.getTime() == w.getTime() ? " " + this._currentClass : "") + (A.getTime() == c.getTime() ? " ui-datepicker-today" : "")) + '"' + (I && !O || !N[2] ? "" : ' title="' + N[2] + '"') + (R ? "" : ' onclick="DP_jQuery_' + g + ".datepicker._selectDay('#" +
                                        a.id + "'," + A.getMonth() + "," + A.getFullYear() + ', this);return false;"') + ">" + (I && !O ? "&#xa0;" : R ? '<span class="ui-state-default">' + A.getDate() + "</span>" : '<a class="ui-state-default' + (A.getTime() == c.getTime() ? " ui-state-highlight" : "") + (A.getTime() == w.getTime() ? " ui-state-active" : "") + (I ? " ui-priority-secondary" : "") + '" href="#">' + A.getDate() + "</a>") + "</td>");
                            A.setDate(A.getDate() + 1);
                            A = this._daylightSavingAdjust(A)
                        }
                        B += Q + "</tr>"
                    }
                    q++;
                    11 < q && (q = 0, y++);
                    B += "</tbody></table>" + (r ? "</div>" + (0 < v[0] && M == v[1] - 1 ? '<div class="ui-datepicker-row-break"></div>' :
                        "") : "");
                    P += B
                }
                K += P
            }
            K += e + (b.browser.msie && 7 > parseInt(b.browser.version, 10) && !a.inline ? '<iframe src="javascript:false;" class="ui-datepicker-cover" frameborder="0"></iframe>' : "");
            a._keyEvent = !1;
            return K
        },
        _generateMonthYearHeader: function(a, b, c, d, e, l, v, q) {
            var t = this._get(a, "changeMonth"),
                r = this._get(a, "changeYear"),
                w = this._get(a, "showMonthAfterYear"),
                u = '<div class="ui-datepicker-title">',
                x = "";
            if (l || !t) x += '<span class="ui-datepicker-month">' + v[b] + "</span>";
            else {
                v = d && d.getFullYear() == c;
                for (var y = e && e.getFullYear() ==
                        c, x = x + ('<select class="ui-datepicker-month" onchange="DP_jQuery_' + g + ".datepicker._selectMonthYear('#" + a.id + "', this, 'M');\" onclick=\"DP_jQuery_" + g + ".datepicker._clickMonthYear('#" + a.id + "');\">"), z = 0; 12 > z; z++)(!v || z >= d.getMonth()) && (!y || z <= e.getMonth()) && (x += '<option value="' + z + '"' + (z == b ? ' selected="selected"' : "") + ">" + q[z] + "</option>");
                x += "</select>"
            }
            w || (u += x + (!l && t && r ? "" : "&#xa0;"));
            if (!a.yearshtml)
                if (a.yearshtml = "", l || !r) u += '<span class="ui-datepicker-year">' + c + "</span>";
                else {
                    q = this._get(a, "yearRange").split(":");
                    var C = (new Date).getFullYear();
                    v = function(a) {
                        a = a.match(/c[+-].*/) ? c + parseInt(a.substring(1), 10) : a.match(/[+-].*/) ? C + parseInt(a, 10) : parseInt(a, 10);
                        return isNaN(a) ? C : a
                    };
                    b = v(q[0]);
                    q = Math.max(b, v(q[1] || ""));
                    b = d ? Math.max(b, d.getFullYear()) : b;
                    q = e ? Math.min(q, e.getFullYear()) : q;
                    for (a.yearshtml += '<select class="ui-datepicker-year" onchange="DP_jQuery_' + g + ".datepicker._selectMonthYear('#" + a.id + "', this, 'Y');\" onclick=\"DP_jQuery_" + g + ".datepicker._clickMonthYear('#" + a.id + "');\">"; b <= q; b++) a.yearshtml += '<option value="' +
                        b + '"' + (b == c ? ' selected="selected"' : "") + ">" + b + "</option>";
                    a.yearshtml += "</select>";
                    u += a.yearshtml;
                    a.yearshtml = null
                }
            u += this._get(a, "yearSuffix");
            w && (u += (!l && t && r ? "" : "&#xa0;") + x);
            return u + "</div>"
        },
        _adjustInstDate: function(a, b, c) {
            var d = a.drawYear + ("Y" == c ? b : 0),
                e = a.drawMonth + ("M" == c ? b : 0);
            b = Math.min(a.selectedDay, this._getDaysInMonth(d, e)) + ("D" == c ? b : 0);
            d = this._restrictMinMax(a, this._daylightSavingAdjust(new Date(d, e, b)));
            a.selectedDay = d.getDate();
            a.drawMonth = a.selectedMonth = d.getMonth();
            a.drawYear = a.selectedYear =
                d.getFullYear();
            "M" != c && "Y" != c || this._notifyChange(a)
        },
        _restrictMinMax: function(a, b) {
            var c = this._getMinMaxDate(a, "min"),
                d = this._getMinMaxDate(a, "max"),
                c = c && b < c ? c : b;
            return d && c > d ? d : c
        },
        _notifyChange: function(a) {
            var b = this._get(a, "onChangeMonthYear");
            b && b.apply(a.input ? a.input[0] : null, [a.selectedYear, a.selectedMonth + 1, a])
        },
        _getNumberOfMonths: function(a) {
            a = this._get(a, "numberOfMonths");
            return null == a ? [1, 1] : "number" == typeof a ? [1, a] : a
        },
        _getMinMaxDate: function(a, b) {
            return this._determineDate(a, this._get(a,
                b + "Date"), null)
        },
        _getDaysInMonth: function(a, b) {
            return 32 - this._daylightSavingAdjust(new Date(a, b, 32)).getDate()
        },
        _getFirstDayOfMonth: function(a, b) {
            return (new Date(a, b, 1)).getDay()
        },
        _canAdjustMonth: function(a, b, c, d) {
            var e = this._getNumberOfMonths(a);
            c = this._daylightSavingAdjust(new Date(c, d + (0 > b ? b : e[0] * e[1]), 1));
            0 > b && c.setDate(this._getDaysInMonth(c.getFullYear(), c.getMonth()));
            return this._isInRange(a, c)
        },
        _isInRange: function(a, b) {
            var c = this._getMinMaxDate(a, "min"),
                d = this._getMinMaxDate(a, "max");
            return (!c ||
                b.getTime() >= c.getTime()) && (!d || b.getTime() <= d.getTime())
        },
        _getFormatConfig: function(a) {
            var b = this._get(a, "shortYearCutoff"),
                b = "string" != typeof b ? b : (new Date).getFullYear() % 100 + parseInt(b, 10);
            return {
                shortYearCutoff: b,
                dayNamesShort: this._get(a, "dayNamesShort"),
                dayNames: this._get(a, "dayNames"),
                monthNamesShort: this._get(a, "monthNamesShort"),
                monthNames: this._get(a, "monthNames")
            }
        },
        _formatDate: function(a, b, c, d) {
            b || (a.currentDay = a.selectedDay, a.currentMonth = a.selectedMonth, a.currentYear = a.selectedYear);
            b = b ? "object" == typeof b ? b : this._daylightSavingAdjust(new Date(d, c, b)) : this._daylightSavingAdjust(new Date(a.currentYear, a.currentMonth, a.currentDay));
            return this.formatDate(this._get(a, "dateFormat"), b, this._getFormatConfig(a))
        }
    });
    b.fn.datepicker = function(a) {
        if (!this.length) return this;
        b.datepicker.initialized || (b(document).mousedown(b.datepicker._checkExternalClick).find("body").append(b.datepicker.dpDiv), b.datepicker.initialized = !0);
        var c = Array.prototype.slice.call(arguments, 1);
        return "string" == typeof a &&
            ("isDisabled" == a || "getDate" == a || "widget" == a) || "option" == a && 2 == arguments.length && "string" == typeof arguments[1] ? b.datepicker["_" + a + "Datepicker"].apply(b.datepicker, [this[0]].concat(c)) : this.each(function() {
                "string" == typeof a ? b.datepicker["_" + a + "Datepicker"].apply(b.datepicker, [this].concat(c)) : b.datepicker._attachDatepicker(this, a)
            })
    };
    b.datepicker = new a;
    b.datepicker.initialized = !1;
    b.datepicker.uuid = (new Date).getTime();
    b.datepicker.version = "1.9m5";
    window["DP_jQuery_" + g] = b
})(jQuery);
(function(b, l) {
    var a = {
            buttons: !0,
            height: !0,
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0,
            width: !0
        },
        d = {
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0
        };
    b.widget("ui.dialog", {
        options: {
            autoOpen: !0,
            buttons: {},
            closeOnEscape: !0,
            closeText: "close",
            dialogClass: "",
            draggable: !0,
            hide: null,
            height: "auto",
            maxHeight: !1,
            maxWidth: !1,
            minHeight: 150,
            minWidth: 150,
            modal: !1,
            position: {
                my: "center",
                at: "center",
                of: window,
                collision: "fit",
                using: function(a) {
                    var d = b(this).css(a).offset().top;
                    0 > d && b(this).css("top", a.top - d)
                }
            },
            resizable: !0,
            show: null,
            stack: !0,
            title: "",
            width: 300,
            zIndex: 1E3
        },
        _create: function() {
            this.originalTitle = this.element.attr("title");
            "string" !== typeof this.originalTitle && (this.originalTitle = "");
            this.options.title = this.options.title || this.originalTitle;
            var a = this,
                d = a.options,
                e = d.title || "&#160;",
                f = b.ui.dialog.getTitleId(a.element),
                h = (a.uiDialog = b("<div>")).addClass("ui-dialog ui-widget ui-widget-content ui-corner-all " + d.dialogClass).css({
                    display: "none",
                    outline: 0,
                    zIndex: d.zIndex
                }).attr("tabIndex", -1).keydown(function(e) {
                    d.closeOnEscape &&
                        !e.isDefaultPrevented() && e.keyCode && e.keyCode === b.ui.keyCode.ESCAPE && (a.close(e), e.preventDefault())
                }).attr({
                    role: "dialog",
                    "aria-labelledby": f
                }).mousedown(function(b) {
                    a.moveToTop(!1, b)
                });
            a.element.show().removeAttr("title").addClass("ui-dialog-content ui-widget-content").appendTo(h);
            var k = (a.uiDialogTitlebar = b("<div>")).addClass("ui-dialog-titlebar  ui-widget-header  ui-corner-all  ui-helper-clearfix").prependTo(h),
                l = b("<a href='#'></a>").addClass("ui-dialog-titlebar-close  ui-corner-all").attr("role",
                    "button").click(function(b) {
                    b.preventDefault();
                    a.close(b)
                }).appendTo(k);
            (a.uiDialogTitlebarCloseText = b("<span>")).addClass("ui-icon ui-icon-closethick").text(d.closeText).appendTo(l);
            b("<span>").addClass("ui-dialog-title").attr("id", f).html(e).prependTo(k);
            k.find("*").add(k).disableSelection();
            this._hoverable(l);
            this._focusable(l);
            d.draggable && b.fn.draggable && a._makeDraggable();
            d.resizable && b.fn.resizable && a._makeResizable();
            a._createButtons(d.buttons);
            a._isOpen = !1;
            h.appendTo(document.body);
            b.fn.bgiframe &&
                h.bgiframe()
        },
        _init: function() {
            this.options.autoOpen && this.open()
        },
        _destroy: function() {
            this.overlay && this.overlay.destroy();
            this.uiDialog.hide();
            this.element.removeClass("ui-dialog-content ui-widget-content").hide().appendTo("body");
            this.uiDialog.remove();
            this.originalTitle && this.element.attr("title", this.originalTitle)
        },
        widget: function() {
            return this.uiDialog
        },
        close: function(a) {
            var d = this,
                e, f;
            if (!1 !== d._trigger("beforeClose", a)) return d.overlay && d.overlay.destroy(), d.uiDialog.unbind("keypress.ui-dialog"),
                d._isOpen = !1, d.options.hide ? d.uiDialog.hide(d.options.hide, function() {
                    d._trigger("close", a)
                }) : (d.uiDialog.hide(), d._trigger("close", a)), b.ui.dialog.overlay.resize(), d.options.modal && (e = 0, b(".ui-dialog").each(function() {
                    this !== d.uiDialog[0] && (f = b(this).css("z-index"), isNaN(f) || (e = Math.max(e, f)))
                }), b.ui.dialog.maxZ = e), d
        },
        isOpen: function() {
            return this._isOpen
        },
        moveToTop: function(a, d) {
            var e = this.options;
            if (e.modal && !a || !e.stack && !e.modal) return this._trigger("focus", d);
            e.zIndex > b.ui.dialog.maxZ && (b.ui.dialog.maxZ =
                e.zIndex);
            this.overlay && (b.ui.dialog.maxZ += 1, b.ui.dialog.overlay.maxZ = b.ui.dialog.maxZ, this.overlay.$el.css("z-index", b.ui.dialog.overlay.maxZ));
            e = {
                scrollTop: this.element.attr("scrollTop"),
                scrollLeft: this.element.attr("scrollLeft")
            };
            b.ui.dialog.maxZ += 1;
            this.uiDialog.css("z-index", b.ui.dialog.maxZ);
            this.element.attr(e);
            this._trigger("focus", d);
            return this
        },
        open: function() {
            if (!this._isOpen) {
                var a = this.options,
                    d = this.uiDialog;
                this._size();
                this._position(a.position);
                d.show(a.show);
                this.overlay = a.modal ?
                    new b.ui.dialog.overlay(this) : null;
                this.moveToTop(!0);
                a.modal && d.bind("keypress.ui-dialog", function(a) {
                    if (a.keyCode === b.ui.keyCode.TAB) {
                        var c = b(":tabbable", this),
                            d = c.filter(":first"),
                            c = c.filter(":last");
                        if (a.target === c[0] && !a.shiftKey) return d.focus(1), !1;
                        if (a.target === d[0] && a.shiftKey) return c.focus(1), !1
                    }
                });
                a = this.element.find(":tabbable");
                a.length || (a = d.find(".ui-dialog-buttonpane :tabbable"), a.length || (a = d));
                a.eq(0).focus();
                this._isOpen = !0;
                this._trigger("open");
                return this
            }
        },
        _createButtons: function(a) {
            var d =
                this,
                e = !1;
            d.uiDialog.find(".ui-dialog-buttonpane").remove();
            "object" === typeof a && null !== a && b.each(a, function() {
                return !(e = !0)
            });
            if (e) {
                var f = b("<div>").addClass("ui-dialog-buttonpane  ui-widget-content ui-helper-clearfix"),
                    h = b("<div>").addClass("ui-dialog-buttonset").appendTo(f);
                b.each(a, function(a, c) {
                    c = b.isFunction(c) ? {
                        click: c,
                        text: a
                    } : c;
                    var e = b("<button type='button'>").attr(c, !0).unbind("click").click(function() {
                        c.click.apply(d.element[0], arguments)
                    }).appendTo(h);
                    b.fn.button && e.button()
                });
                d.uiDialog.addClass("ui-dialog-buttons");
                f.appendTo(d.uiDialog)
            } else d.uiDialog.removeClass("ui-dialog-buttons")
        },
        _makeDraggable: function() {
            function a(b) {
                return {
                    position: b.position,
                    offset: b.offset
                }
            }
            var d = this,
                e = d.options,
                f = b(document),
                h;
            d.uiDialog.draggable({
                cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
                handle: ".ui-dialog-titlebar",
                containment: "document",
                start: function(f, l) {
                    h = "auto" === e.height ? "auto" : b(this).height();
                    b(this).height(b(this).height()).addClass("ui-dialog-dragging");
                    d._trigger("dragStart", f, a(l))
                },
                drag: function(b,
                    e) {
                    d._trigger("drag", b, a(e))
                },
                stop: function(k, l) {
                    e.position = [l.position.left - f.scrollLeft(), l.position.top - f.scrollTop()];
                    b(this).removeClass("ui-dialog-dragging").height(h);
                    d._trigger("dragStop", k, a(l));
                    b.ui.dialog.overlay.resize()
                }
            })
        },
        _makeResizable: function(a) {
            function d(a) {
                return {
                    originalPosition: a.originalPosition,
                    originalSize: a.originalSize,
                    position: a.position,
                    size: a.size
                }
            }
            a = a === l ? this.options.resizable : a;
            var e = this,
                f = e.options,
                h = e.uiDialog.css("position");
            a = "string" === typeof a ? a : "n,e,s,w,se,sw,ne,nw";
            e.uiDialog.resizable({
                cancel: ".ui-dialog-content",
                containment: "document",
                alsoResize: e.element,
                maxWidth: f.maxWidth,
                maxHeight: f.maxHeight,
                minWidth: f.minWidth,
                minHeight: e._minHeight(),
                handles: a,
                start: function(a, c) {
                    b(this).addClass("ui-dialog-resizing");
                    e._trigger("resizeStart", a, d(c))
                },
                resize: function(a, b) {
                    e._trigger("resize", a, d(b))
                },
                stop: function(a, c) {
                    b(this).removeClass("ui-dialog-resizing");
                    f.height = b(this).height();
                    f.width = b(this).width();
                    e._trigger("resizeStop", a, d(c));
                    b.ui.dialog.overlay.resize()
                }
            }).css("position",
                h).find(".ui-resizable-se").addClass("ui-icon ui-icon-grip-diagonal-se")
        },
        _minHeight: function() {
            var a = this.options;
            return "auto" === a.height ? a.minHeight : Math.min(a.minHeight, a.height)
        },
        _position: function(a) {
            var d = [],
                e = [0, 0],
                f;
            if (a) {
                if ("string" === typeof a || "object" === typeof a && "0" in a) d = a.split ? a.split(" ") : [a[0], a[1]], 1 === d.length && (d[1] = d[0]), b.each(["left", "top"], function(a, b) {
                    +d[a] === d[a] && (e[a] = d[a], d[a] = b)
                }), a = {
                    my: d.join(" "),
                    at: d.join(" "),
                    offset: e.join(" ")
                };
                a = b.extend({}, b.ui.dialog.prototype.options.position,
                    a)
            } else a = b.ui.dialog.prototype.options.position;
            (f = this.uiDialog.is(":visible")) || this.uiDialog.show();
            this.uiDialog.position(a);
            f || this.uiDialog.hide()
        },
        _setOptions: function(c) {
            var g = this,
                e = {},
                f = !1;
            b.each(c, function(b, c) {
                g._setOption(b, c);
                b in a && (f = !0);
                b in d && (e[b] = c)
            });
            f && this._size();
            this.uiDialog.is(":data(resizable)") && this.uiDialog.resizable("option", e)
        },
        _setOption: function(a, d) {
            var e = this.uiDialog;
            switch (a) {
                case "buttons":
                    this._createButtons(d);
                    break;
                case "closeText":
                    this.uiDialogTitlebarCloseText.text("" +
                        d);
                    break;
                case "dialogClass":
                    e.removeClass(this.options.dialogClass).addClass("ui-dialog ui-widget ui-widget-content ui-corner-all " + d);
                    break;
                case "disabled":
                    d ? e.addClass("ui-dialog-disabled") : e.removeClass("ui-dialog-disabled");
                    break;
                case "draggable":
                    var f = e.is(":data(draggable)");
                    f && !d && e.draggable("destroy");
                    !f && d && this._makeDraggable();
                    break;
                case "position":
                    this._position(d);
                    break;
                case "resizable":
                    (f = e.is(":data(resizable)")) && !d && e.resizable("destroy");
                    f && "string" === typeof d && e.resizable("option",
                        "handles", d);
                    f || !1 === d || this._makeResizable(d);
                    break;
                case "title":
                    b(".ui-dialog-title", this.uiDialogTitlebar).html("" + (d || "&#160;"))
            }
            this._super("_setOption", a, d)
        },
        _size: function() {
            var a = this.options,
                d, e, f = this.uiDialog.is(":visible");
            this.element.show().css({
                width: "auto",
                minHeight: 0,
                height: 0
            });
            a.minWidth > a.width && (a.width = a.minWidth);
            d = this.uiDialog.css({
                height: "auto",
                width: a.width
            }).height();
            e = Math.max(0, a.minHeight - d);
            "auto" === a.height ? b.support.minHeight ? this.element.css({
                    minHeight: e,
                    height: "auto"
                }) :
                (this.uiDialog.show(), a = this.element.css("height", "auto").height(), f || this.uiDialog.hide(), this.element.height(Math.max(a, e))) : this.element.height(Math.max(a.height - d, 0));
            this.uiDialog.is(":data(resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight())
        }
    });
    b.extend(b.ui.dialog, {
        version: "1.9m5",
        uuid: 0,
        maxZ: 0,
        getTitleId: function(a) {
            a = a.attr("id");
            a || (a = this.uuid += 1);
            return "ui-dialog-title-" + a
        },
        overlay: function(a) {
            this.$el = b.ui.dialog.overlay.create(a)
        }
    });
    b.extend(b.ui.dialog.overlay, {
        instances: [],
        oldInstances: [],
        maxZ: 0,
        events: b.map("focus mousedown mouseup keydown keypress click".split(" "), function(a) {
            return a + ".dialog-overlay"
        }).join(" "),
        create: function(a) {
            0 === this.instances.length && (setTimeout(function() {
                b.ui.dialog.overlay.instances.length && b(document).bind(b.ui.dialog.overlay.events, function(a) {
                    if (b(a.target).zIndex() < b.ui.dialog.overlay.maxZ) return !1
                })
            }, 1), b(document).bind("keydown.dialog-overlay", function(d) {
                a.options.closeOnEscape && !d.isDefaultPrevented() && d.keyCode &&
                    d.keyCode === b.ui.keyCode.ESCAPE && (a.close(d), d.preventDefault())
            }), b(window).bind("resize.dialog-overlay", b.ui.dialog.overlay.resize));
            var d = (this.oldInstances.pop() || b("<div>").addClass("ui-widget-overlay")).appendTo(document.body).css({
                width: this.width(),
                height: this.height()
            });
            b.fn.bgiframe && d.bgiframe();
            this.instances.push(d);
            return d
        },
        destroy: function(a) {
            var d = b.inArray(a, this.instances); - 1 !== d && this.oldInstances.push(this.instances.splice(d, 1)[0]);
            0 === this.instances.length && b([document, window]).unbind(".dialog-overlay");
            a.height(0).width(0).remove();
            var e = 0;
            b.each(this.instances, function() {
                e = Math.max(e, this.css("z-index"))
            });
            this.maxZ = e
        },
        height: function() {
            var a, d;
            return b.browser.msie ? (a = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight), d = Math.max(document.documentElement.offsetHeight, document.body.offsetHeight), a < d ? b(window).height() + "px" : a + "px") : b(document).height() + "px"
        },
        width: function() {
            var a, d;
            return b.browser.msie ? (a = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
                d = Math.max(document.documentElement.offsetWidth, document.body.offsetWidth), a < d ? b(window).width() + "px" : a + "px") : b(document).width() + "px"
        },
        resize: function() {
            var a = b([]);
            b.each(b.ui.dialog.overlay.instances, function() {
                a = a.add(this)
            });
            a.css({
                width: 0,
                height: 0
            }).css({
                width: b.ui.dialog.overlay.width(),
                height: b.ui.dialog.overlay.height()
            })
        }
    });
    b.extend(b.ui.dialog.overlay.prototype, {
        destroy: function() {
            b.ui.dialog.overlay.destroy(this.$el)
        }
    })
})(jQuery);
(function(b) {
    var l = 0;
    b.widget("ui.menu", {
        defaultElement: "<ul>",
        delay: 150,
        options: {
            position: {
                my: "left top",
                at: "right top"
            }
        },
        _create: function() {
            var a = this;
            this.activeMenu = this.element;
            this.menuId = this.element.attr("id") || "ui-menu-" + l++;
            this.element.find(".ui-icon").length && this.element.addClass("ui-menu-icons");
            this.element.addClass("ui-menu ui-widget ui-widget-content ui-corner-all").attr({
                id: this.menuId,
                role: "menu"
            }).bind("click.menu", function(d) {
                var c = b(d.target).closest(".ui-menu-item:has(a)");
                if (a.options.disabled) return !1;
                c.length && (a.active && a.active[0] === c[0] || a.focus(d, c), a.select(d))
            }).bind("mouseover.menu", function(d) {
                if (!a.options.disabled) {
                    var c = b(d.target).closest(".ui-menu-item");
                    c.length && a.focus(d, c)
                }
            }).bind("mouseout.menu", function(d) {
                a.options.disabled || b(d.target).closest(".ui-menu-item").length && a.blur(d)
            });
            this.refresh();
            this.element.attr("tabIndex", 0).bind("keydown.menu", function(d) {
                if (!a.options.disabled) switch (d.keyCode) {
                    case b.ui.keyCode.PAGE_UP:
                        a.previousPage(d);
                        d.preventDefault();
                        d.stopImmediatePropagation();
                        break;
                    case b.ui.keyCode.PAGE_DOWN:
                        a.nextPage(d);
                        d.preventDefault();
                        d.stopImmediatePropagation();
                        break;
                    case b.ui.keyCode.UP:
                        a.previous(d);
                        d.preventDefault();
                        d.stopImmediatePropagation();
                        break;
                    case b.ui.keyCode.DOWN:
                        a.next(d);
                        d.preventDefault();
                        d.stopImmediatePropagation();
                        break;
                    case b.ui.keyCode.LEFT:
                        a.left(d) && d.stopImmediatePropagation();
                        d.preventDefault();
                        break;
                    case b.ui.keyCode.RIGHT:
                        a.right(d) && d.stopImmediatePropagation();
                        d.preventDefault();
                        break;
                    case b.ui.keyCode.ENTER:
                        a.active.children("a[aria-haspopup='true']").length ? a.right(d) && d.stopImmediatePropagation() : (a.select(d), d.stopImmediatePropagation());
                        d.preventDefault();
                        break;
                    case b.ui.keyCode.ESCAPE:
                        a.left(d) && d.stopImmediatePropagation();
                        d.preventDefault();
                        break;
                    default:
                        var c = function(a) {
                            return a.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
                        };
                        d.stopPropagation();
                        clearTimeout(a.filterTimer);
                        var g = a.previousFilter || "",
                            e = String.fromCharCode(d.keyCode),
                            f = !1;
                        e == g ? f = !0 : e = g + e;
                        g = a.activeMenu.children(".ui-menu-item").filter(function() {
                            return (new RegExp("^" +
                                c(e), "i")).test(b(this).children("a").text())
                        });
                        g = f && -1 != g.index(a.active.next()) ? a.active.nextAll(".ui-menu-item") : g;
                        g.length || (e = String.fromCharCode(d.keyCode), g = a.activeMenu.children(".ui-menu-item").filter(function() {
                            return (new RegExp("^" + c(e), "i")).test(b(this).children("a").text())
                        }));
                        g.length ? (a.focus(d, g), 1 < g.length ? (a.previousFilter = e, a.filterTimer = setTimeout(function() {
                            delete a.previousFilter
                        }, 1E3)) : delete a.previousFilter) : delete a.previousFilter
                }
            })
        },
        _destroy: function() {
            this.element.removeAttr("aria-activedescendant").find("ul").andSelf().removeClass("ui-menu ui-widget ui-widget-content ui-corner-all").removeAttr("role").removeAttr("tabIndex").removeAttr("aria-labelledby").removeAttr("aria-expanded").removeAttr("aria-hidden").show();
            this.element.find(".ui-menu-item").unbind(".menu").removeClass("ui-menu-item").removeAttr("role").children("a").removeClass("ui-corner-all ui-state-hover").removeAttr("tabIndex").removeAttr("role").removeAttr("aria-haspopup").removeAttr("id").children(".ui-icon").remove()
        },
        refresh: function() {
            var a = this,
                d = this.element.find("ul:not(.ui-menu)").addClass("ui-menu ui-widget ui-widget-content ui-corner-all").attr("role", "menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false");
            d.add(this.element).children("li:not(.ui-menu-item):has(a)").addClass("ui-menu-item").attr("role",
                "presentation").children("a").addClass("ui-corner-all").attr("tabIndex", -1).attr("role", "menuitem").attr("id", function(b) {
                return a.element.attr("id") + "-" + b
            });
            d.each(function() {
                var a = b(this),
                    d = a.prev("a");
                d.attr("aria-haspopup", "true").prepend('<span class="ui-menu-icon ui-icon ui-icon-carat-1-e"></span>');
                a.attr("aria-labelledby", d.attr("id"))
            })
        },
        focus: function(a, d) {
            var c = this;
            this.blur();
            if (this._hasScroll()) {
                var g = parseFloat(b.curCSS(this.element[0], "borderTopWidth", !0)) || 0,
                    e = parseFloat(b.curCSS(this.element[0],
                        "paddingTop", !0)) || 0,
                    g = d.offset().top - this.element.offset().top - g - e,
                    e = this.element.scrollTop(),
                    f = this.element.height(),
                    h = d.height();
                0 > g ? this.element.scrollTop(e + g) : g + h > f && this.element.scrollTop(e + g - f + h)
            }
            this.active = d.first().children("a").addClass("ui-state-focus").end();
            c.element.attr("aria-activedescendant", c.active.children("a").attr("id"));
            this.active.parent().closest(".ui-menu-item").children("a:first").addClass("ui-state-active");
            c.timer = setTimeout(function() {
                c._close()
            }, c.delay);
            g = b(">ul",
                d);
            g.length && /^mouse/.test(a.type) && c._startOpening(g);
            this.activeMenu = d.parent();
            this._trigger("focus", a, {
                item: d
            })
        },
        blur: function(a) {
            this.active && (clearTimeout(this.timer), this.active.children("a").removeClass("ui-state-focus"), this.active = null)
        },
        _startOpening: function(a) {
            clearTimeout(this.timer);
            var b = this;
            b.timer = setTimeout(function() {
                b._close();
                b._open(a)
            }, b.delay)
        },
        _open: function(a) {
            clearTimeout(this.timer);
            this.element.find(".ui-menu").not(a.parents()).hide().attr("aria-hidden", "true");
            var d =
                b.extend({}, { of: this.active
                }, "function" == b.type(this.options.position) ? this.options.position(this.active) : this.options.position);
            a.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(d)
        },
        closeAll: function() {
            this.element.find("ul").hide().attr("aria-hidden", "true").attr("aria-expanded", "false").end().find("a.ui-state-active").removeClass("ui-state-active");
            this.blur();
            this.activeMenu = this.element
        },
        _close: function() {
            this.active.parent().find("ul").hide().attr("aria-hidden", "true").attr("aria-expanded",
                "false").end().find("a.ui-state-active").removeClass("ui-state-active")
        },
        left: function(a) {
            var b = this.active && this.active.parents("li:not(.ui-menubar-item)").first();
            if (b && b.length) return this.active.parent().attr("aria-hidden", "true").attr("aria-expanded", "false").hide(), this.focus(a, b), !0
        },
        right: function(a) {
            var b = this,
                c = this.active && this.active.children("ul").children("li").first();
            if (c && c.length) return this._open(c.parent()), setTimeout(function() {
                b.focus(a, c)
            }, 20), !0
        },
        next: function(a) {
            this._move("next",
                ".ui-menu-item", "first", a)
        },
        previous: function(a) {
            this._move("prev", ".ui-menu-item", "last", a)
        },
        first: function() {
            return this.active && !this.active.prevAll(".ui-menu-item").length
        },
        last: function() {
            return this.active && !this.active.nextAll(".ui-menu-item").length
        },
        _move: function(a, b, c, g) {
            this.active ? (a = this.active[a + "All"](".ui-menu-item").eq(0), a.length ? this.focus(g, a) : this.focus(g, this.activeMenu.children(b)[c]())) : this.focus(g, this.activeMenu.children(b)[c]())
        },
        nextPage: function(a) {
            if (this._hasScroll())
                if (!this.active ||
                    this.last()) this.focus(a, this.activeMenu.children(".ui-menu-item").first());
                else {
                    var d = this.active.offset().top,
                        c = this.element.height(),
                        g;
                    this.active.nextAll(".ui-menu-item").each(function() {
                        g = b(this);
                        return 0 > b(this).offset().top - d - c
                    });
                    this.focus(a, g)
                }
            else this.focus(a, this.activeMenu.children(".ui-menu-item")[!this.active || this.last() ? "first" : "last"]())
        },
        previousPage: function(a) {
            if (this._hasScroll())
                if (!this.active || this.first()) this.focus(a, this.activeMenu.children(".ui-menu-item").last());
                else {
                    var d =
                        this.active.offset().top,
                        c = this.element.height(),
                        g;
                    this.active.prevAll(".ui-menu-item").each(function() {
                        g = b(this);
                        return 0 < b(this).offset().top - d + c
                    });
                    this.focus(a, g)
                }
            else this.focus(a, this.activeMenu.children(".ui-menu-item")[!this.active || this.first() ? ":last" : ":first"]())
        },
        _hasScroll: function() {
            return this.element.height() < this.element[b.fn.prop ? "prop" : "attr"]("scrollHeight")
        },
        select: function(a) {
            var b = {
                item: this.active
            };
            this.closeAll();
            this._trigger("select", a, b)
        }
    });
    b.ui.menu.version = "1.9m5"
})(jQuery);
(function(b) {
    b.widget("ui.menubar", {
        options: {
            buttons: !1,
            menuIcon: !1
        },
        _create: function() {
            var l = this,
                a = this.items = this.element.children("li").addClass("ui-menubar-item").attr("role", "presentation").children("button, a");
            a.slice(1).attr("tabIndex", -1);
            this.element.addClass("ui-menubar ui-widget-header ui-helper-clearfix").attr("role", "menubar");
            this._focusable(a);
            this._hoverable(a);
            a.next("ul").menu({
                select: function(a, c) {
                    c.item.parents("ul.ui-menu:last").hide();
                    l._trigger("select", a, c);
                    l._close();
                    b(a.target).prev().focus()
                }
            }).hide().attr("aria-hidden",
                "true").attr("aria-expanded", "false").bind("keydown.menubar", function(a) {
                if (!b(this).is(":hidden")) switch (a.keyCode) {
                    case b.ui.keyCode.LEFT:
                        l._left(a);
                        a.preventDefault();
                        break;
                    case b.ui.keyCode.RIGHT:
                        l._right(a), a.preventDefault()
                }
            });
            a.each(function() {
                var a = b(this),
                    c = a.next("ul");
                a.bind("click.menubar focus.menubar mouseenter.menubar", function(a) {
                    if ("focus" != a.type || a.originalEvent) a.preventDefault(), "click" == a.type && c.is(":visible") && l.active && l.active[0] == c[0] ? l._close() : (l.open && "mouseenter" ==
                        a.type || "click" == a.type) && l._open(a, c)
                }).bind("keydown", function(a) {
                    switch (a.keyCode) {
                        case b.ui.keyCode.SPACE:
                        case b.ui.keyCode.UP:
                        case b.ui.keyCode.DOWN:
                            l._open(a, b(this).next());
                            a.preventDefault();
                            break;
                        case b.ui.keyCode.LEFT:
                            l._prev(a, b(this));
                            a.preventDefault();
                            break;
                        case b.ui.keyCode.RIGHT:
                            l._next(a, b(this)), a.preventDefault()
                    }
                }).addClass("ui-button ui-widget ui-button-text-only ui-menubar-link").attr("role", "menuitem").attr("aria-haspopup", "true").wrapInner("<span class='ui-button-text'></span>");
                l.options.menuIcon && (a.addClass("ui-state-default").append("<span class='ui-button-icon-secondary ui-icon ui-icon-triangle-1-s'></span>"), a.removeClass("ui-button-text-only").addClass("ui-button-text-icon-secondary"));
                l.options.buttons || a.addClass("ui-menubar-link").removeClass("ui-state-default")
            });
            l._bind({
                keydown: function(a) {
                    if (a.keyCode == b.ui.keyCode.ESCAPE && l.active && !0 !== l.active.menu("left", a)) {
                        var c = l.active;
                        l.active.blur();
                        l._close(a);
                        c.prev().focus()
                    }
                },
                focusin: function(a) {
                    clearTimeout(l.closeTimer)
                },
                focusout: function(a) {
                    l.closeTimer = setTimeout(function() {
                        l._close(a)
                    }, 100)
                }
            })
        },
        _destroy: function() {
            var l = this.element.children("li").removeClass("ui-menubar-item").removeAttr("role", "presentation").children("button, a");
            this.element.removeClass("ui-menubar ui-widget-header ui-helper-clearfix").removeAttr("role", "menubar").unbind(".menubar");
            l.unbind(".menubar").removeClass("ui-button ui-widget ui-button-text-only ui-menubar-link ui-state-default").removeAttr("role", "menuitem").removeAttr("aria-haspopup",
                "true").children("span.ui-button-text").each(function(a, d) {
                var c = b(this);
                c.parent().html(c.html())
            }).end().children(".ui-icon").remove();
            this.element.find(":ui-menu").menu("destroy").show().removeAttr("aria-hidden", "true").removeAttr("aria-expanded", "false").removeAttr("tabindex").unbind(".menubar")
        },
        _close: function() {
            this.active && this.active.length && (this.active.menu("closeAll").hide().attr("aria-hidden", "true").attr("aria-expanded", "false"), this.active.prev().removeClass("ui-state-active").removeAttr("tabIndex"),
                this.active = null, this.open = !1)
        },
        _open: function(b, a) {
            if (!this.active || this.active[0] != a[0]) {
                this.active && (this.active.menu("closeAll").hide().attr("aria-hidden", "true").attr("aria-expanded", "false"), this.active.prev().removeClass("ui-state-active"));
                var d = a.prev().addClass("ui-state-active").attr("tabIndex", -1);
                this.active = a.show().position({
                    my: "left top",
                    at: "left bottom",
                    of: d
                }).removeAttr("aria-hidden").attr("aria-expanded", "true").menu("focus", b, a.children("li").first()).focus().focusin();
                this.open = !0
            }
        },
        _prev: function(b, a) {
            a.attr("tabIndex", -1);
            var d = a.parent().prevAll("li").children(".ui-button").eq(0);
            d.length ? d.removeAttr("tabIndex")[0].focus() : this.element.children("li:last").children(".ui-button:last").removeAttr("tabIndex")[0].focus()
        },
        _next: function(b, a) {
            a.attr("tabIndex", -1);
            var d = a.parent().nextAll("li").children(".ui-button").eq(0);
            d.length ? d.removeAttr("tabIndex")[0].focus() : this.element.children("li:first").children(".ui-button:first").removeAttr("tabIndex")[0].focus()
        },
        _left: function(b) {
            var a =
                this.active.parent().prevAll("li:eq(0)").children(".ui-menu").eq(0);
            a.length || (a = this.element.children("li:last").children(".ui-menu:first"));
            this._open(b, a)
        },
        _right: function(b) {
            var a = this.active.parent().nextAll("li:eq(0)").children(".ui-menu").eq(0);
            a.length || (a = this.element.children("li:first").children(".ui-menu:first"));
            this._open(b, a)
        }
    })
})(jQuery);
(function(b) {
    var l = 0;
    b.widget("ui.popup", {
        options: {
            position: {
                my: "left top",
                at: "left bottom"
            }
        },
        _create: function() {
            this.options.trigger || (this.options.trigger = this.element.prev());
            this.element.attr("id") || (this.element.attr("id", "ui-popup-" + l++), this.generatedId = !0);
            this.element.attr("role") || (this.element.attr("role", "tooltip"), this.generatedRole = !0);
            this.options.trigger.attr("aria-haspopup", !0).attr("aria-owns", this.element.attr("id"));
            this.element.addClass("ui-popup");
            this.close();
            this._bind(this.options.trigger, {
                keydown: function(a) {
                    this.options.trigger.is("a:ui-button") && a.keyCode == b.ui.keyCode.SPACE && a.preventDefault();
                    a.keyCode == b.ui.keyCode.SPACE && this.options.trigger.is("a:not(:ui-button)") && this.options.trigger.trigger("click", a);
                    a.keyCode == b.ui.keyCode.DOWN && (a.preventDefault(), this.options.trigger.trigger("click", a))
                },
                click: function(a) {
                    a.preventDefault();
                    if (!this.isOpen) {
                        var b = this;
                        clearTimeout(this.closeTimer);
                        setTimeout(function() {
                            b.open(a)
                        }, 1)
                    }
                }
            });
            this._bind(this.element, {
                blur: function(a) {
                    var b =
                        this;
                    b.closeTimer = setTimeout(function() {
                        b.close(a)
                    }, 100)
                }
            });
            this._bind({
                keyup: function(a) {
                    a.keyCode == b.ui.keyCode.ESCAPE && this.element.is(":visible") && (this.close(a), this.options.trigger.focus())
                }
            });
            this._bind(document, {
                click: function(a) {
                    this.isOpen && !b(a.target).closest(".ui-popup").length && this.close(a)
                }
            })
        },
        _destroy: function() {
            this.element.show().removeClass("ui-popup").removeAttr("aria-hidden").removeAttr("aria-expanded");
            this.options.trigger.removeAttr("aria-haspopup").removeAttr("aria-owns");
            this.generatedId && this.element.removeAttr("id");
            this.generatedRole && this.element.removeAttr("role")
        },
        open: function(a) {
            var d = b.extend({}, { of: this.options.trigger
            }, this.options.position);
            this.element.show().attr("aria-hidden", !1).attr("aria-expanded", !0).position(d).focus();
            this.element.is(":ui-menu") && this.element.menu("focus", a, this.element.children("li").first());
            this.options.trigger.attr("tabindex", -1);
            this.isOpen = !0;
            this._trigger("open", a)
        },
        close: function(a) {
            this.element.hide().attr("aria-hidden", !0).attr("aria-expanded", !1);
            this.options.trigger.attr("tabindex", 0);
            this.isOpen = !1;
            this._trigger("close", a)
        }
    })
})(jQuery);
(function(b, l) {
    b.ui = b.ui || {};
    var a = /left|center|right/,
        d = /top|center|bottom/,
        c = /[+-]\d+%?/,
        g = /^\w+/,
        e = /%$/,
        f = b.fn.position;
    b.fn.position = function(h) {
        if (!h || !h.of) return f.apply(this, arguments);
        h = b.extend({}, h);
        var k = b(h.of),
            l = k[0],
            m = (h.collision || "flip").split(" "),
            p = {},
            v, q, t, r;
        9 === l.nodeType ? (q = k.width(), t = k.height(), r = {
            top: 0,
            left: 0
        }) : b.isWindow(l) ? (q = k.width(), t = k.height(), r = {
            top: k.scrollTop(),
            left: k.scrollLeft()
        }) : l.preventDefault ? (h.at = "left top", q = t = 0, r = {
            top: h.of.pageY,
            left: h.of.pageX
        }) : (q = k.outerWidth(),
            t = k.outerHeight(), r = k.offset());
        b.each(["my", "at"], function() {
            var b = (h[this] || "").split(" "),
                e, f;
            1 === b.length && (b = a.test(b[0]) ? b.concat(["center"]) : d.test(b[0]) ? ["center"].concat(b) : ["center", "center"]);
            b[0] = a.test(b[0]) ? b[0] : "center";
            b[1] = d.test(b[1]) ? b[1] : "center";
            e = c.exec(b[0]);
            f = c.exec(b[1]);
            p[this] = [e ? e[0] : 0, f ? f[0] : 0];
            h[this] = [g.exec(b[0])[0], g.exec(b[1])[0]]
        });
        1 === m.length && (m[1] = m[0]);
        "right" === h.at[0] ? r.left += q : "center" === h.at[0] && (r.left += q / 2);
        "bottom" === h.at[1] ? r.top += t : "center" === h.at[1] &&
            (r.top += t / 2);
        v = [parseInt(p.at[0], 10) * (e.test(p.at[0]) ? q / 100 : 1), parseInt(p.at[1], 10) * (e.test(p.at[1]) ? t / 100 : 1)];
        r.left += v[0];
        r.top += v[1];
        return this.each(function() {
            var a = b(this),
                c = a.outerWidth(),
                d = a.outerHeight(),
                f = parseInt(b.curCSS(this, "marginLeft", !0)) || 0,
                g = parseInt(b.curCSS(this, "marginTop", !0)) || 0,
                k = c + f + (parseInt(b.curCSS(this, "marginRight", !0)) || 0),
                l = d + g + (parseInt(b.curCSS(this, "marginBottom", !0)) || 0),
                n = b.extend({}, r),
                D = [parseInt(p.my[0], 10) * (e.test(p.my[0]) ? a.outerWidth() / 100 : 1), parseInt(p.my[1],
                    10) * (e.test(p.my[1]) ? a.outerHeight() / 100 : 1)],
                J;
            "right" === h.my[0] ? n.left -= c : "center" === h.my[0] && (n.left -= c / 2);
            "bottom" === h.my[1] ? n.top -= d : "center" === h.my[1] && (n.top -= d / 2);
            n.left += D[0];
            n.top += D[1];
            n.left = Math.round(n.left);
            n.top = Math.round(n.top);
            J = {
                left: n.left - f,
                top: n.top - g
            };
            b.each(["left", "top"], function(a, e) {
                if (b.ui.position[m[a]]) b.ui.position[m[a]][e](n, {
                    targetWidth: q,
                    targetHeight: t,
                    elemWidth: c,
                    elemHeight: d,
                    collisionPosition: J,
                    collisionWidth: k,
                    collisionHeight: l,
                    offset: [v[0] + D[0], v[1] + D[1]],
                    my: h.my,
                    at: h.at
                })
            });
            b.fn.bgiframe && a.bgiframe();
            a.offset(b.extend(n, {
                using: h.using
            }))
        })
    };
    b.ui.position = {
        fit: {
            left: function(a, c) {
                var d = b(window),
                    e = d.scrollLeft() - c.collisionPosition.left,
                    f = c.collisionPosition.left + c.collisionWidth - d.width() - d.scrollLeft();
                c.collisionWidth > d.width() || 0 < e ? a.left += e : a.left = 0 < f ? a.left - f : Math.max(a.left - c.collisionPosition.left, a.left)
            },
            top: function(a, c) {
                var d = b(window),
                    e = d.scrollTop() - c.collisionPosition.top,
                    f = c.collisionPosition.top + c.collisionHeight - d.height() - d.scrollTop();
                c.collisionHeight > d.height() || 0 < e ? a.top += e : a.top = 0 < f ? a.top - f : Math.max(a.top - c.collisionPosition.top, a.top)
            }
        },
        flip: {
            left: function(a, c) {
                if ("center" !== c.at[0]) {
                    var d = b(window),
                        d = c.collisionPosition.left + c.collisionWidth - d.width() - d.scrollLeft(),
                        e = "left" === c.my[0] ? -c.elemWidth : "right" === c.my[0] ? c.elemWidth : 0,
                        f = "left" === c.at[0] ? c.targetWidth : -c.targetWidth,
                        g = -2 * c.offset[0];
                    a.left += 0 > c.collisionPosition.left ? e + f + g : 0 < d ? e + f + g : 0
                }
            },
            top: function(a, c) {
                if ("center" !== c.at[1]) {
                    var d = b(window),
                        d = c.collisionPosition.top +
                        c.collisionHeight - d.height() - d.scrollTop(),
                        e = "top" === c.my[1] ? -c.elemHeight : "bottom" === c.my[1] ? c.elemHeight : 0,
                        f = "top" === c.at[1] ? c.targetHeight : -c.targetHeight,
                        g = -2 * c.offset[1];
                    a.top += 0 > c.collisionPosition.top ? e + f + g : 0 < d ? e + f + g : 0
                }
            }
        }
    };
    !1 !== b.uiBackCompat && function(a) {
        var b = a.fn.position;
        a.fn.position = function(c) {
            if (!(c && "offset" in c)) return b.call(this, c);
            var d = c.offset.split(" "),
                e = c.at.split(" ");
            1 === d.length && (d[1] = d[0]);
            /^\d/.test(d[0]) && (d[0] = "+" + d[0]);
            /^\d/.test(d[1]) && (d[1] = "+" + d[1]);
            1 === e.length &&
                (/left|center|right/.test(e[0]) ? e[1] = "center" : (e[1] = e[0], e[0] = "center"));
            return b.call(this, a.extend(c, {
                at: e[0] + d[0] + " " + e[1] + d[1],
                offset: l
            }))
        }
    }(jQuery)
})(jQuery);
(function(b, l) {
    b.widget("ui.progressbar", {
        options: {
            value: 0,
            max: 100
        },
        min: 0,
        _create: function() {
            this.element.addClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").attr({
                role: "progressbar",
                "aria-valuemin": this.min,
                "aria-valuemax": this.options.max,
                "aria-valuenow": this._value()
            });
            this.valueDiv = b("<div class='ui-progressbar-value ui-widget-header ui-corner-left'></div>").appendTo(this.element);
            this.oldValue = this._value();
            this._refreshValue()
        },
        _destroy: function() {
            this.element.removeClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow");
            this.valueDiv.remove()
        },
        value: function(a) {
            if (a === l) return this._value();
            this._setOption("value", a);
            return this
        },
        _setOption: function(a, b) {
            "value" === a && (this.options.value = b, this._refreshValue(), this._value() === this.options.max && this._trigger("complete"));
            this._super("_setOption", a, b)
        },
        _value: function() {
            var a = this.options.value;
            "number" !== typeof a && (a = 0);
            return Math.min(this.options.max, Math.max(this.min, a))
        },
        _percentage: function() {
            return 100 * this._value() / this.options.max
        },
        _refreshValue: function() {
            var a =
                this.value(),
                b = this._percentage();
            this.oldValue !== a && (this.oldValue = a, this._trigger("change"));
            this.valueDiv.toggle(a > this.min).toggleClass("ui-corner-right", a === this.options.max).width(b.toFixed(0) + "%");
            this.element.attr("aria-valuenow", a)
        }
    });
    b.extend(b.ui.progressbar, {
        version: "1.9m5"
    })
})(jQuery);
(function(b, l) {
    b.widget("ui.slider", b.ui.mouse, {
        widgetEventPrefix: "slide",
        options: {
            animate: !1,
            distance: 0,
            max: 100,
            min: 0,
            orientation: "horizontal",
            range: !1,
            step: 1,
            value: 0,
            values: null
        },
        _create: function() {
            var a = this,
                d = this.options,
                c = this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),
                g = d.values && d.values.length || 1,
                e = [];
            this._mouseSliding = this._keySliding = !1;
            this._animateOff = !0;
            this._handleIndex = null;
            this._detectOrientation();
            this._mouseInit();
            this.element.addClass("ui-slider ui-slider-" +
                this.orientation + " ui-widget ui-widget-content ui-corner-all" + (d.disabled ? " ui-slider-disabled ui-disabled" : ""));
            this.range = b([]);
            d.range && (!0 === d.range && (d.values || (d.values = [this._valueMin(), this._valueMin()]), d.values.length && 2 !== d.values.length && (d.values = [d.values[0], d.values[0]])), this.range = b("<div></div>").appendTo(this.element).addClass("ui-slider-range ui-widget-header" + ("min" === d.range || "max" === d.range ? " ui-slider-range-" + d.range : "")));
            for (var f = c.length; f < g; f += 1) e.push("<a class='ui-slider-handle ui-state-default ui-corner-all' href='#'></a>");
            this.handles = c.add(b(e.join("")).appendTo(a.element));
            this.handle = this.handles.eq(0);
            this.handles.add(this.range).filter("a").click(function(a) {
                a.preventDefault()
            }).hover(function() {
                d.disabled || b(this).addClass("ui-state-hover")
            }, function() {
                b(this).removeClass("ui-state-hover")
            }).focus(function() {
                d.disabled ? b(this).blur() : (b(".ui-slider .ui-state-focus").removeClass("ui-state-focus"), b(this).addClass("ui-state-focus"))
            }).blur(function() {
                b(this).removeClass("ui-state-focus")
            });
            this.handles.each(function(a) {
                b(this).data("index.ui-slider-handle",
                    a)
            });
            this.handles.keydown(function(c) {
                var d = !0,
                    e = b(this).data("index.ui-slider-handle"),
                    f, g, l;
                if (!a.options.disabled) {
                    switch (c.keyCode) {
                        case b.ui.keyCode.HOME:
                        case b.ui.keyCode.END:
                        case b.ui.keyCode.PAGE_UP:
                        case b.ui.keyCode.PAGE_DOWN:
                        case b.ui.keyCode.UP:
                        case b.ui.keyCode.RIGHT:
                        case b.ui.keyCode.DOWN:
                        case b.ui.keyCode.LEFT:
                            if (d = !1, !a._keySliding && (a._keySliding = !0, b(this).addClass("ui-state-active"), f = a._start(c, e), !1 === f)) return
                    }
                    l = a.options.step;
                    f = a.options.values && a.options.values.length ? g = a.values(e) :
                        g = a.value();
                    switch (c.keyCode) {
                        case b.ui.keyCode.HOME:
                            g = a._valueMin();
                            break;
                        case b.ui.keyCode.END:
                            g = a._valueMax();
                            break;
                        case b.ui.keyCode.PAGE_UP:
                            g = a._trimAlignValue(f + (a._valueMax() - a._valueMin()) / 5);
                            break;
                        case b.ui.keyCode.PAGE_DOWN:
                            g = a._trimAlignValue(f - (a._valueMax() - a._valueMin()) / 5);
                            break;
                        case b.ui.keyCode.UP:
                        case b.ui.keyCode.RIGHT:
                            if (f === a._valueMax()) return;
                            g = a._trimAlignValue(f + l);
                            break;
                        case b.ui.keyCode.DOWN:
                        case b.ui.keyCode.LEFT:
                            if (f === a._valueMin()) return;
                            g = a._trimAlignValue(f - l)
                    }
                    a._slide(c,
                        e, g);
                    return d
                }
            }).keyup(function(c) {
                var d = b(this).data("index.ui-slider-handle");
                a._keySliding && (a._keySliding = !1, a._stop(c, d), a._change(c, d), b(this).removeClass("ui-state-active"))
            });
            this._refreshValue();
            this._animateOff = !1
        },
        destroy: function() {
            this.handles.remove();
            this.range.remove();
            this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-slider-disabled ui-widget ui-widget-content ui-corner-all").removeData("slider").unbind(".slider");
            this._mouseDestroy();
            return this
        },
        _mouseCapture: function(a) {
            var d =
                this.options,
                c, g, e, f, h;
            if (d.disabled) return !1;
            this.elementSize = {
                width: this.element.outerWidth(),
                height: this.element.outerHeight()
            };
            this.elementOffset = this.element.offset();
            c = this._normValueFromMouse({
                x: a.pageX,
                y: a.pageY
            });
            g = this._valueMax() - this._valueMin() + 1;
            f = this;
            this.handles.each(function(a) {
                var d = Math.abs(c - f.values(a));
                g > d && (g = d, e = b(this), h = a)
            });
            !0 === d.range && this.values(1) === d.min && (h += 1, e = b(this.handles[h]));
            if (!1 === this._start(a, h)) return !1;
            this._mouseSliding = !0;
            f._handleIndex = h;
            e.addClass("ui-state-active").focus();
            d = e.offset();
            this._clickOffset = b(a.target).parents().andSelf().is(".ui-slider-handle") ? {
                left: a.pageX - d.left - e.width() / 2,
                top: a.pageY - d.top - e.height() / 2 - (parseInt(e.css("borderTopWidth"), 10) || 0) - (parseInt(e.css("borderBottomWidth"), 10) || 0) + (parseInt(e.css("marginTop"), 10) || 0)
            } : {
                left: 0,
                top: 0
            };
            this.handles.hasClass("ui-state-hover") || this._slide(a, h, c);
            return this._animateOff = !0
        },
        _mouseStart: function(a) {
            return !0
        },
        _mouseDrag: function(a) {
            var b = this._normValueFromMouse({
                x: a.pageX,
                y: a.pageY
            });
            this._slide(a,
                this._handleIndex, b);
            return !1
        },
        _mouseStop: function(a) {
            this.handles.removeClass("ui-state-active");
            this._mouseSliding = !1;
            this._stop(a, this._handleIndex);
            this._change(a, this._handleIndex);
            this._clickOffset = this._handleIndex = null;
            return this._animateOff = !1
        },
        _detectOrientation: function() {
            this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal"
        },
        _normValueFromMouse: function(a) {
            var b;
            "horizontal" === this.orientation ? (b = this.elementSize.width, a = a.x - this.elementOffset.left - (this._clickOffset ?
                this._clickOffset.left : 0)) : (b = this.elementSize.height, a = a.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0));
            b = a / b;
            1 < b && (b = 1);
            0 > b && (b = 0);
            "vertical" === this.orientation && (b = 1 - b);
            a = this._valueMax() - this._valueMin();
            b = this._valueMin() + b * a;
            return this._trimAlignValue(b)
        },
        _start: function(a, b) {
            var c = {
                handle: this.handles[b],
                value: this.value()
            };
            this.options.values && this.options.values.length && (c.value = this.values(b), c.values = this.values());
            return this._trigger("start", a, c)
        },
        _slide: function(a,
            b, c) {
            var g;
            this.options.values && this.options.values.length ? (g = this.values(b ? 0 : 1), 2 === this.options.values.length && !0 === this.options.range && (0 === b && c > g || 1 === b && c < g) && (c = g), c !== this.values(b) && (g = this.values(), g[b] = c, a = this._trigger("slide", a, {
                handle: this.handles[b],
                value: c,
                values: g
            }), this.values(b ? 0 : 1), !1 !== a && this.values(b, c, !0))) : c !== this.value() && (a = this._trigger("slide", a, {
                handle: this.handles[b],
                value: c
            }), !1 !== a && this.value(c))
        },
        _stop: function(a, b) {
            var c = {
                handle: this.handles[b],
                value: this.value()
            };
            this.options.values && this.options.values.length && (c.value = this.values(b), c.values = this.values());
            this._trigger("stop", a, c)
        },
        _change: function(a, b) {
            if (!this._keySliding && !this._mouseSliding) {
                var c = {
                    handle: this.handles[b],
                    value: this.value()
                };
                this.options.values && this.options.values.length && (c.value = this.values(b), c.values = this.values());
                this._trigger("change", a, c)
            }
        },
        value: function(a) {
            if (arguments.length) this.options.value = this._trimAlignValue(a), this._refreshValue(), this._change(null, 0);
            else return this._value()
        },
        values: function(a, d) {
            var c, g, e;
            if (1 < arguments.length) this.options.values[a] = this._trimAlignValue(d), this._refreshValue(), this._change(null, a);
            else if (arguments.length)
                if (b.isArray(arguments[0])) {
                    c = this.options.values;
                    g = arguments[0];
                    for (e = 0; e < c.length; e += 1) c[e] = this._trimAlignValue(g[e]), this._change(null, e);
                    this._refreshValue()
                } else return this.options.values && this.options.values.length ? this._values(a) : this.value();
            else return this._values()
        },
        _setOption: function(a, d) {
            var c, g = 0;
            b.isArray(this.options.values) &&
                (g = this.options.values.length);
            b.Widget.prototype._setOption.apply(this, arguments);
            switch (a) {
                case "disabled":
                    d ? (this.handles.filter(".ui-state-focus").blur(), this.handles.removeClass("ui-state-hover"), this.handles.attr("disabled", "disabled"), this.element.addClass("ui-disabled")) : (this.handles.removeAttr("disabled"), this.element.removeClass("ui-disabled"));
                    break;
                case "orientation":
                    this._detectOrientation();
                    this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-" + this.orientation);
                    this._refreshValue();
                    break;
                case "value":
                    this._animateOff = !0;
                    this._refreshValue();
                    this._change(null, 0);
                    this._animateOff = !1;
                    break;
                case "values":
                    this._animateOff = !0;
                    this._refreshValue();
                    for (c = 0; c < g; c += 1) this._change(null, c);
                    this._animateOff = !1
            }
        },
        _value: function() {
            var a = this.options.value;
            return a = this._trimAlignValue(a)
        },
        _values: function(a) {
            var b, c;
            if (arguments.length) return b = this.options.values[a], b = this._trimAlignValue(b);
            b = this.options.values.slice();
            for (c = 0; c < b.length; c += 1) b[c] = this._trimAlignValue(b[c]);
            return b
        },
        _trimAlignValue: function(a) {
            if (a <= this._valueMin()) return this._valueMin();
            if (a >= this._valueMax()) return this._valueMax();
            var b = 0 < this.options.step ? this.options.step : 1,
                c = (a - this._valueMin()) % b;
            a -= c;
            2 * Math.abs(c) >= b && (a += 0 < c ? b : -b);
            return parseFloat(a.toFixed(5))
        },
        _valueMin: function() {
            return this.options.min
        },
        _valueMax: function() {
            return this.options.max
        },
        _refreshValue: function() {
            var a = this.options.range,
                d = this.options,
                c = this,
                g = this._animateOff ? !1 : d.animate,
                e, f = {},
                h, k, l, m;
            if (this.options.values &&
                this.options.values.length) this.handles.each(function(a, k) {
                e = (c.values(a) - c._valueMin()) / (c._valueMax() - c._valueMin()) * 100;
                f["horizontal" === c.orientation ? "left" : "bottom"] = e + "%";
                b(this).stop(1, 1)[g ? "animate" : "css"](f, d.animate);
                if (!0 === c.options.range)
                    if ("horizontal" === c.orientation) {
                        if (0 === a) c.range.stop(1, 1)[g ? "animate" : "css"]({
                            left: e + "%"
                        }, d.animate);
                        if (1 === a) c.range[g ? "animate" : "css"]({
                            width: e - h + "%"
                        }, {
                            queue: !1,
                            duration: d.animate
                        })
                    } else {
                        if (0 === a) c.range.stop(1, 1)[g ? "animate" : "css"]({
                                bottom: e + "%"
                            },
                            d.animate);
                        if (1 === a) c.range[g ? "animate" : "css"]({
                            height: e - h + "%"
                        }, {
                            queue: !1,
                            duration: d.animate
                        })
                    }
                h = e
            });
            else {
                k = this.value();
                l = this._valueMin();
                m = this._valueMax();
                e = m !== l ? (k - l) / (m - l) * 100 : 0;
                f["horizontal" === c.orientation ? "left" : "bottom"] = e + "%";
                this.handle.stop(1, 1)[g ? "animate" : "css"](f, d.animate);
                if ("min" === a && "horizontal" === this.orientation) this.range.stop(1, 1)[g ? "animate" : "css"]({
                    width: e + "%"
                }, d.animate);
                if ("max" === a && "horizontal" === this.orientation) this.range[g ? "animate" : "css"]({
                    width: 100 - e + "%"
                }, {
                    queue: !1,
                    duration: d.animate
                });
                if ("min" === a && "vertical" === this.orientation) this.range.stop(1, 1)[g ? "animate" : "css"]({
                    height: e + "%"
                }, d.animate);
                if ("max" === a && "vertical" === this.orientation) this.range[g ? "animate" : "css"]({
                    height: 100 - e + "%"
                }, {
                    queue: !1,
                    duration: d.animate
                })
            }
        }
    });
    b.extend(b.ui.slider, {
        version: "1.9m5"
    })
})(jQuery);
(function(b) {
    b.widget("ui.spinner", {
        defaultElement: "<input>",
        widgetEventPrefix: "spin",
        options: {
            incremental: !0,
            max: null,
            min: null,
            numberformat: null,
            page: 10,
            step: null,
            value: null
        },
        _create: function() {
            this._draw();
            this._markupOptions();
            this._mousewheel();
            this._aria()
        },
        _markupOptions: function() {
            var l = this;
            b.each({
                min: -Number.MAX_VALUE,
                max: Number.MAX_VALUE,
                step: 1
            }, function(a, b) {
                if (null === l.options[a]) {
                    var c = l.element.attr(a);
                    l.options[a] = "string" === typeof c && 0 < c.length ? l._parse(c) : b
                }
            });
            this.value(null !==
                this.options.value ? this.options.value : this.element.val() || 0)
        },
        _draw: function() {
            var l = this,
                a = l.options,
                d = this.uiSpinner = l.element.addClass("ui-spinner-input").attr("autocomplete", "off").wrap(l._uiSpinnerHtml()).parent().append(l._buttonHtml()).hover(function() {
                    a.disabled || b(this).addClass("ui-state-hover");
                    l.hovered = !0
                }, function() {
                    b(this).removeClass("ui-state-hover");
                    l.hovered = !1
                });
            this.element.attr("role", "spinbutton").bind("keydown.spinner", function(b) {
                if (!a.disabled) return l._start(b) ? l._keydown(b) :
                    !0
            }).bind("keyup.spinner", function(b) {
                !a.disabled && l.spinning && (l._stop(b), l._change(b))
            }).bind("focus.spinner", function() {
                d.addClass("ui-state-active");
                l.focused = !0
            }).bind("blur.spinner", function(a) {
                l.value(l.element.val());
                l.hovered || d.removeClass("ui-state-active");
                l.focused = !1
            });
            this.buttons = d.find(".ui-spinner-button").attr("tabIndex", -1).button().removeClass("ui-corner-all").bind("mousedown", function(c) {
                if (!a.disabled) {
                    if (!1 === l._start(c)) return !1;
                    l._repeat(null, b(this).hasClass("ui-spinner-up") ?
                        1 : -1, c)
                }
            }).bind("mouseup", function(b) {
                !a.disabled && l.spinning && (l._stop(b), l._change(b))
            }).bind("mouseenter", function() {
                if (!l.options.disabled && b(this).hasClass("ui-state-active")) {
                    if (!1 === l._start(event)) return !1;
                    l._repeat(null, b(this).hasClass("ui-spinner-up") ? 1 : -1, event)
                }
            }).bind("mouseleave", function() {
                l.spinning && (l._stop(event), l._change(event))
            });
            a.disabled && this.disable()
        },
        _keydown: function(l) {
            var a = this.options,
                d = b.ui.keyCode;
            switch (l.keyCode) {
                case d.UP:
                    return this._repeat(null, 1, l), !1;
                case d.DOWN:
                    return this._repeat(null, -1, l), !1;
                case d.PAGE_UP:
                    return this._repeat(null, a.page, l), !1;
                case d.PAGE_DOWN:
                    return this._repeat(null, -a.page, l), !1;
                case d.ENTER:
                    this.value(this.element.val())
            }
            return !0
        },
        _mousewheel: function() {
            if (b.fn.mousewheel) {
                var l = this;
                this.element.bind("mousewheel.spinner", function(a, b) {
                    if (!l.options.disabled && b) {
                        if (!l.spinning && !l._start(a)) return !1;
                        l._spin((0 < b ? 1 : -1) * l.options.step, a);
                        clearTimeout(l.timeout);
                        l.timeout = setTimeout(function() {
                            l.spinning && (l._stop(a), l._change(a))
                        }, 100);
                        a.preventDefault()
                    }
                })
            }
        },
        _uiSpinnerHtml: function() {
            return "<span class='ui-spinner ui-state-default ui-widget ui-widget-content ui-corner-all'></span>"
        },
        _buttonHtml: function() {
            return "<a class='ui-spinner-button ui-spinner-up ui-corner-tr'><span class='ui-icon ui-icon-triangle-1-n'>&#9650;</span></a><a class='ui-spinner-button ui-spinner-down ui-corner-br'><span class='ui-icon ui-icon-triangle-1-s'>&#9660;</span></a>"
        },
        _start: function(b) {
            if (!this.spinning && !1 === this._trigger("start", b)) return !1;
            this.counter || (this.counter =
                1);
            return this.spinning = !0
        },
        _repeat: function(b, a, d) {
            var c = this;
            b = b || 500;
            clearTimeout(this.timer);
            this.timer = setTimeout(function() {
                c._repeat(40, a, d)
            }, b);
            c._spin(a * c.options.step, d)
        },
        _spin: function(b, a) {
            this.counter || (this.counter = 1);
            var d = this.value() + b * (this.options.incremental && 20 < this.counter ? 100 < this.counter ? 200 < this.counter ? 100 : 10 : 2 : 1);
            !1 !== this._trigger("spin", a, {
                value: d
            }) && (this.value(d), this.counter++)
        },
        _stop: function(b) {
            this.counter = 0;
            this.timer && clearTimeout(this.timer);
            this.element.focus();
            this.spinning = !1;
            this._trigger("stop", b)
        },
        _change: function(b) {
            this._trigger("change", b)
        },
        _setOption: function(b, a) {
            "value" === b && (a = this._parse(a), a < this.options.min && (a = this.options.min), a > this.options.max && (a = this.options.max));
            "disabled" === b && (a ? (this.element.attr("disabled", !0), this.buttons.button("disable")) : (this.element.removeAttr("disabled"), this.buttons.button("enable")));
            this._super("_setOption", b, a)
        },
        _setOptions: function(b) {
            this._super("_setOptions", b);
            "value" in b && this._format(this.options.value);
            this._aria()
        },
        _aria: function() {
            this.element.attr({
                "aria-valuemin": this.options.min,
                "aria-valuemax": this.options.max,
                "aria-valuenow": this.options.value
            })
        },
        _parse: function(l) {
            "string" === typeof l && (l = b.global && this.options.numberformat ? b.global.parseFloat(l) : +l);
            return isNaN(l) ? null : l
        },
        _format: function(l) {
            this.element.val(b.global && this.options.numberformat ? b.global.format(l, this.options.numberformat) : l)
        },
        destroy: function() {
            this.element.removeClass("ui-spinner-input").removeAttr("disabled").removeAttr("autocomplete").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow");
            this._super("destroy");
            this.uiSpinner.replaceWith(this.element)
        },
        stepUp: function(b) {
            this._spin((b || 1) * this.options.step)
        },
        stepDown: function(b) {
            this._spin((b || 1) * -this.options.step)
        },
        pageUp: function(b) {
            this.stepUp((b || 1) * this.options.page)
        },
        pageDown: function(b) {
            this.stepDown((b || 1) * this.options.page)
        },
        value: function(b) {
            if (!arguments.length) return this._parse(this.element.val());
            this.option("value", b)
        },
        widget: function() {
            return this.uiSpinner
        }
    });
    b.ui.spinner.version = "1.9m5"
})(jQuery);
(function(b, l) {
    var a = 0;
    b.widget("ui.tabs", {
        options: {
            active: null,
            collapsible: !1,
            event: "click",
            fx: null,
            activate: null,
            beforeActivate: null,
            beforeLoad: null,
            load: null
        },
        _create: function() {
            var a = this,
                d = a.options,
                e = d.active;
            a.running = !1;
            a.element.addClass("ui-tabs ui-widget ui-widget-content ui-corner-all");
            a._processTabs();
            null === e && (location.hash && a.anchors.each(function(a, b) {
                if (b.hash === location.hash) return e = a, !1
            }), null === e && (e = a.lis.filter(".ui-tabs-active").index()), null === e || -1 === e) && (e = a.lis.length ?
                0 : !1);
            !1 !== e && (e = this.lis.eq(e).index(), -1 === e && (e = d.collapsible ? !1 : 0));
            d.active = e;
            !d.collapsible && !1 === d.active && this.anchors.length && (d.active = 0);
            b.isArray(d.disabled) && (d.disabled = b.unique(d.disabled.concat(b.map(this.lis.filter(".ui-state-disabled"), function(b, d) {
                return a.lis.index(b)
            }))).sort());
            this._setupFx(d.fx);
            this._refresh();
            this.panels.hide();
            this.lis.removeClass("ui-tabs-active ui-state-active");
            !1 !== d.active && this.anchors.length ? (this.active = this._findActive(d.active), a._getPanelForTab(this.active).show(),
                this.lis.eq(d.active).addClass("ui-tabs-active ui-state-active"), this.load(d.active)) : this.active = b()
        },
        _setOption: function(a, b) {
            "active" == a ? this._activate(b) : "disabled" === a ? this._setupDisabled(b) : (this._super("_setOption", a, b), "collapsible" !== a || b || !1 !== this.options.active || this._activate(0), "event" === a && this._setupEvents(b), "fx" === a && this._setupFx(b))
        },
        _tabId: function(c) {
            return b(c).attr("aria-controls") || "ui-tabs-" + ++a
        },
        _sanitizeSelector: function(a) {
            return a ? a.replace(/[!"$%&'()*+,.\/:;<=>?@[\]^`{|}~]/g,
                "\\$&") : ""
        },
        refresh: function() {
            var a = this.options,
                d = this.list.children(":has(a[href])");
            a.disabled = b.map(d.filter(".ui-state-disabled"), function(a) {
                return d.index(a)
            });
            this._processTabs();
            this._refresh();
            this.panels.not(this._getPanelForTab(this.active)).hide();
            !1 !== a.active && this.anchors.length ? this.active.length && !b.contains(this.list[0], this.active[0]) ? (a = a.active - 1, this._activate(0 <= a ? a : 0)) : a.active = this.anchors.index(this.active) : (a.active = !1, this.active = b())
        },
        _refresh: function() {
            var a = this.options;
            this.element.toggleClass("ui-tabs-collapsible", a.collapsible);
            this.list.addClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all");
            this.lis.addClass("ui-state-default ui-corner-top");
            this.panels.addClass("ui-tabs-panel ui-widget-content ui-corner-bottom");
            this._setupDisabled(a.disabled);
            this._setupEvents(a.event);
            this.lis.unbind(".tabs");
            this._focusable(this.lis);
            this._hoverable(this.lis)
        },
        _processTabs: function() {
            var a = this,
                d = /^#.+/;
            this.list = this.element.find("ol,ul").eq(0);
            this.lis = b(" > li:has(a[href])", this.list);
            this.anchors = this.lis.map(function() {
                return b("a", this)[0]
            });
            this.panels = b([]);
            this.anchors.each(function(e, f) {
                var h = b(f).attr("href"),
                    k = h.split("#")[0],
                    l, m, p;
                k && (k === location.toString().split("#")[0] || (p = b("base")[0]) && k === p.href) && (h = f.hash, f.href = h);
                d.test(h) ? (l = h, m = a.element.find(a._sanitizeSelector(l))) : h && "#" !== h ? (h = a._tabId(f), l = "#" + h, m = a.element.find(l), m.length || (m = a._createPanel(h), m.insertAfter(a.panels[e - 1] || a.list))) : a.options.disabled.push(e);
                m.length && (a.panels = a.panels.add(m));
                b(f).attr("aria-controls", l.substring(1))
            })
        },
        _createPanel: function(a) {
            return b("<div></div>").attr("id", a).addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").data("destroy.tabs", !0)
        },
        _setupDisabled: function(a) {
            b.isArray(a) && (a.length ? a.length === this.anchors.length && (a = !0) : a = !1);
            for (var d = 0, e; e = this.lis[d]; d++) b(e).toggleClass("ui-state-disabled", !0 === a || -1 !== b.inArray(d, a));
            this.options.disabled = a
        },
        _setupFx: function(a) {
            a && (b.isArray(a) ? (this.hideFx = a[0],
                this.showFx = a[1]) : this.hideFx = this.showFx = a)
        },
        _resetStyle: function(a, d) {
            !b.support.opacity && d.opacity && a[0].style.removeAttribute("filter")
        },
        _setupEvents: function(a) {
            this.anchors.unbind(".tabs");
            a && this.anchors.bind(a.split(" ").join(".tabs ") + ".tabs", b.proxy(this, "_eventHandler"));
            this.anchors.bind("click.tabs", function(a) {
                a.preventDefault()
            })
        },
        _eventHandler: function(a) {
            var d = this.options,
                e = this.active,
                f = b(a.currentTarget),
                h = f[0] === e[0],
                k = h && d.collapsible,
                l = k ? b() : this._getPanelForTab(f),
                m = e.length ?
                this._getPanelForTab(e) : b(),
                p = f.closest("li"),
                e = {
                    oldTab: e,
                    oldPanel: m,
                    newTab: k ? b() : f,
                    newPanel: l
                };
            a.preventDefault();
            if (p.hasClass("ui-state-disabled") || p.hasClass("ui-tabs-loading") || this.running || h && !d.collapsible || !1 === this._trigger("beforeActivate", a, e)) f[0].blur();
            else {
                d.active = k ? !1 : this.anchors.index(f);
                this.active = h ? b() : f;
                this.xhr && this.xhr.abort();
                if (!m.length && !l.length) throw "jQuery UI Tabs: Mismatching fragment identifier.";
                l.length && (this.load(this.anchors.index(f), a), f[0].blur());
                this._toggle(a,
                    e)
            }
        },
        _toggle: function(a, d) {
            function e() {
                h.running = !1;
                h._trigger("activate", a, d)
            }

            function f() {
                d.newTab.closest("li").addClass("ui-tabs-active ui-state-active");
                k.length && h.showFx ? k.animate(h.showFx, h.showFx.duration || "normal", function() {
                    h._resetStyle(b(this), h.showFx);
                    e()
                }) : (k.show(), e())
            }
            var h = this,
                k = d.newPanel,
                l = d.oldPanel;
            h.running = !0;
            l.length && h.hideFx ? l.animate(h.hideFx, h.hideFx.duration || "normal", function() {
                d.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active");
                h._resetStyle(b(this),
                    h.hideFx);
                f()
            }) : (d.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active"), l.hide(), f())
        },
        _activate: function(a) {
            a = this._findActive(a)[0];
            a !== this.active[0] && (a = a || this.active[0], this._eventHandler({
                target: a,
                currentTarget: a,
                preventDefault: b.noop
            }))
        },
        _findActive: function(a) {
            return "number" === typeof a ? this.anchors.eq(a) : "string" === typeof a ? this.anchors.filter("[href$='" + a + "']") : b()
        },
        _getIndex: function(a) {
            "string" == typeof a && (a = this.anchors.index(this.anchors.filter("[href$=" + a + "]")));
            return a
        },
        _destroy: function() {
            this.xhr && this.xhr.abort();
            this.element.removeClass("ui-tabs ui-widget ui-widget-content ui-corner-all ui-tabs-collapsible");
            this.list.removeClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all");
            this.anchors.each(function() {
                var a = b(this).unbind(".tabs");
                b.each(["href", "load"], function(b, d) {
                    a.removeData(d + ".tabs")
                })
            });
            this.lis.unbind(".tabs").add(this.panels).each(function() {
                b.data(this, "destroy.tabs") ? b(this).remove() : b(this).removeClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active ui-state-disabled ui-tabs-panel ui-widget-content ui-corner-bottom")
            });
            return this
        },
        enable: function(a) {
            var d = this.options.disabled;
            !1 !== d && (a === l ? d = !1 : (a = this._getIndex(a), d = b.isArray(d) ? b.map(d, function(b) {
                return b !== a ? b : null
            }) : b.map(this.lis, function(b, d) {
                return d !== a ? d : null
            })), this._setupDisabled(d))
        },
        disable: function(a) {
            var d = this.options.disabled;
            if (!0 !== d) {
                if (a === l) d = !0;
                else {
                    a = this._getIndex(a);
                    if (-1 !== b.inArray(a, d)) return;
                    d = b.isArray(d) ? b.merge([a], d).sort() : [a]
                }
                this._setupDisabled(d)
            }
        },
        load: function(a, d) {
            a = this._getIndex(a);
            var e = this,
                f = this.anchors.eq(a),
                h =
                e._getPanelForTab(f),
                k = f.attr("href").replace(/#.*$/, ""),
                l = {
                    tab: f,
                    panel: h
                };
            if (k) {
                if (this.xhr = b.ajax({
                        url: k,
                        beforeSend: function(a, c) {
                            return e._trigger("beforeLoad", d, b.extend({
                                jqXHR: a,
                                ajaxSettings: c
                            }, l))
                        }
                    })) this.lis.eq(a).addClass("ui-tabs-loading"), this.xhr.success(function(a) {
                    h.html(a);
                    e._trigger("load", d, l)
                }).complete(function(b, d) {
                    "abort" === d && e.panels.stop(!1, !0);
                    e.lis.eq(a).removeClass("ui-tabs-loading");
                    b === e.xhr && delete e.xhr
                });
                return this
            }
        },
        _getPanelForTab: function(a) {
            a = b(a).attr("aria-controls");
            return this.element.find(this._sanitizeSelector("#" + a))
        }
    });
    b.extend(b.ui.tabs, {
        version: "1.9m5"
    });
    if (!1 !== b.uiBackCompat) {
        b.ui.tabs.prototype._ui = function(a, b) {
            return {
                tab: a,
                panel: b,
                index: this.anchors.index(a)
            }
        };
        (function(a, b) {
            b.url = function(a, b) {
                this.anchors.eq(a).attr("href", b)
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            a.extend(b.options, {
                ajaxOptions: null,
                cache: !1
            });
            var d = b._create,
                f = b._setOption,
                h = b._destroy,
                k = b.url || a.noop;
            a.extend(b, {
                _create: function() {
                    d.call(this);
                    var b = this;
                    this.element.bind("tabsbeforeload.tabs",
                        function(d, e) {
                            a.data(e.tab[0], "cache.tabs") ? d.preventDefault() : (a.extend(e.ajaxSettings, b.options.ajaxOptions, {
                                error: function(a, c, d) {
                                    try {
                                        b.options.ajaxOptions.error(a, c, e.tab.closest("li").index(), e.tab[0])
                                    } catch (f) {}
                                }
                            }), e.jqXHR.success(function() {
                                b.options.cache && a.data(e.tab[0], "cache.tabs", !0)
                            }))
                        })
                },
                _setOption: function(a, b) {
                    "cache" === a && !1 === b && this.anchors.removeData("cache.tabs");
                    f.apply(this, arguments)
                },
                _destroy: function() {
                    this.anchors.removeData("cache.tabs");
                    h.call(this)
                },
                url: function(a, b) {
                    this.anchors.eq(a).removeData("cache.tabs");
                    k.apply(this, arguments)
                }
            })
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            b.abort = function() {
                this.xhr && this.xhr.abort()
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        b.widget("ui.tabs", b.ui.tabs, {
            options: {
                spinner: "<em>Loading&#8230;</em>"
            },
            _create: function() {
                this._super("_create");
                this._bind({
                    tabsbeforeload: function(a, b) {
                        if (this.options.spinner) {
                            var d = b.tab.find("span"),
                                f = d.html();
                            d.html(this.options.spinner);
                            b.jqXHR.complete(function() {
                                d.html(f)
                            })
                        }
                    }
                })
            }
        });
        (function(a, b) {
            a.extend(b.options, {
                enable: null,
                disable: null
            });
            var d = b.enable,
                f = b.disable;
            b.enable = function(b) {
                var f = this.options,
                    g;
                if (b && !0 === f.disabled || a.isArray(f.disabled) && -1 !== a.inArray(b, f.disabled)) g = !0;
                d.apply(this, arguments);
                g && this._trigger("enable", null, this._ui(this.anchors[b], this.panels[b]))
            };
            b.disable = function(b) {
                var d = this.options,
                    e;
                if (b && !1 === d.disabled || a.isArray(d.disabled) && -1 === a.inArray(b, d.disabled)) e = !0;
                f.apply(this, arguments);
                e && this._trigger("disable", null, this._ui(this.anchors[b], this.panels[b]))
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            a.extend(b.options, {
                add: null,
                remove: null,
                tabTemplate: "<li><a href='#{href}'><span>#{label}</span></a></li>"
            });
            b.add = function(b, d, g) {
                g === l && (g = this.anchors.length);
                var k = this.options;
                d = a(k.tabTemplate.replace(/#\{href\}/g, b).replace(/#\{label\}/g, d));
                b = b.indexOf("#") ? this._tabId(d.find("a")[0]) : b.replace("#", "");
                d.addClass("ui-state-default ui-corner-top").data("destroy.tabs", !0);
                d.find("a").attr("aria-controls", b);
                var n = g >= this.lis.length,
                    m = this.element.find("#" + b);
                m.length || (m = this._createPanel(b),
                    n ? 0 < g ? m.insertAfter(this.panels.eq(-1)) : m.appendTo(this.element) : m.insertBefore(this.panels[g]));
                m.addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").hide();
                n ? d.appendTo(this.list) : d.insertBefore(this.lis[g]);
                k.disabled = a.map(k.disabled, function(a) {
                    return a >= g ? ++a : a
                });
                this.refresh();
                1 === this.lis.length && !1 === k.active && this.option("active", 0);
                this._trigger("add", null, this._ui(this.anchors[g], this.panels[g]));
                return this
            };
            b.remove = function(b) {
                b = this._getIndex(b);
                var d = this.options,
                    g = this.lis.eq(b).remove(),
                    k = this.panels.eq(b).remove();
                g.hasClass("ui-tabs-active") && 1 < this.anchors.length && this._activate(b + (b + 1 < this.anchors.length ? 1 : -1));
                d.disabled = a.map(a.grep(d.disabled, function(a) {
                    return a !== b
                }), function(a) {
                    return a >= b ? --a : a
                });
                this.refresh();
                this._trigger("remove", null, this._ui(g.find("a")[0], k[0]));
                return this
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            b.length = function() {
                return this.anchors.length
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(b, d) {
            b.extend(d.options, {
                idPrefix: "ui-tabs-"
            });
            d._tabId = function(d) {
                return b(d).attr("aria-controls") || d.title && d.title.replace(/\s/g, "_").replace(/[^\w\u00c0-\uFFFF-]/g, "") || this.options.idPrefix + ++a
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            a.extend(b.options, {
                panelTemplate: "<div></div>"
            });
            b._createPanel = function(b) {
                return a(this.options.panelTemplate).attr("id", b).addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").data("destroy.tabs", !0)
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            var d = b._create,
                f = b._setOption,
                h =
                b._eventHandler;
            b._create = function() {
                var a = this.options;
                null === a.active && a.selected !== l && (a.active = -1 === a.selected ? !1 : a.selected);
                d.call(this);
                a.selected = a.active;
                !1 === a.selected && (a.selected = -1)
            };
            b._setOption = function(a, b) {
                if ("selected" !== a) return f.apply(this, arguments);
                var c = this.options;
                f.call(this, "active", -1 === b ? !1 : b);
                c.selected = c.active;
                !1 === c.selected && (c.selected = -1)
            };
            b._eventHandler = function(a) {
                h.apply(this, arguments);
                this.options.selected = this.options.active;
                !1 === this.options.selected &&
                    (this.options.selected = -1)
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            a.extend(b.options, {
                show: null,
                select: null
            });
            var d = b._create,
                f = b._trigger;
            b._create = function() {
                d.call(this);
                !1 !== this.options.active && this._trigger("show", null, this._ui(this.active[0], this._getPanelForTab(this.active)[0]))
            };
            b._trigger = function(a, b, c) {
                if (!f.apply(this, arguments)) return !1;
                "beforeActivate" === a && c.newTab.length ? f.call(this, "select", b, {
                        tab: c.newTab[0],
                        panel: c.newPanel[0],
                        index: c.newTab.closest("li").index()
                    }) :
                    "activate" === a && c.newTab.length && f.call(this, "show", b, {
                        tab: c.newTab[0],
                        panel: c.newPanel[0],
                        index: c.newTab.closest("li").index()
                    })
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        (function(a, b) {
            b.select = function(a) {
                a = this._getIndex(a);
                if (-1 === a)
                    if (this.options.collapsible && -1 !== this.options.selected) a = this.options.selected;
                    else return;
                this.anchors.eq(a).trigger(this.options.event + ".tabs")
            }
        })(jQuery, jQuery.ui.tabs.prototype);
        var d = 0;
        b.widget("ui.tabs", b.ui.tabs, {
            options: {
                cookie: null
            },
            _create: function() {
                var a = this.options,
                    b;
                null == a.active && a.cookie && (b = parseInt(this._cookie(), 10), -1 === b && (b = !1), a.active = b);
                this._super("_create")
            },
            _cookie: function(a) {
                var g = [this.cookie || (this.cookie = this.options.cookie.name || "ui-tabs-" + ++d)];
                arguments.length && (g.push(!1 === a ? -1 : a), g.push(this.options.cookie));
                return b.cookie.apply(null, g)
            },
            _refresh: function() {
                this._super("_refresh");
                this.options.cookie && this._cookie(this.options.active, this.options.cookie)
            },
            _eventHandler: function(a) {
                this._superApply("_eventHandler", arguments);
                this.options.cookie &&
                    this._cookie(this.options.active, this.options.cookie)
            },
            _destroy: function() {
                this._super("_destroy");
                this.options.cookie && this._cookie(null, this.options.cookie)
            }
        });
        b.widget("ui.tabs", b.ui.tabs, {
            _trigger: function(a, d, e) {
                e = b.extend({}, e);
                "load" === a && (e.panel = e.panel[0], e.tab = e.tab[0]);
                return this._super("_trigger", a, d, e)
            }
        })
    }
})(jQuery);
(function(b) {
    var l = 0;
    b.widget("ui.tooltip", {
        options: {
            tooltipClass: null,
            items: "[title]",
            content: function() {
                return b(this).attr("title")
            },
            position: {
                my: "left+15 center",
                at: "right center"
            }
        },
        _create: function() {
            this._bind({
                mouseover: "open",
                focusin: "open"
            })
        },
        enable: function() {
            this.options.disabled = !1
        },
        disable: function() {
            this.options.disabled = !0
        },
        open: function(a) {
            var d = b(a && a.target || this.element).closest(this.options.items);
            if (d.length) {
                var c = this;
                d.data("tooltip-title") || d.data("tooltip-title", d.attr("title"));
                var g = this.options.content.call(d[0], function(b) {
                    setTimeout(function() {
                        void 0 !== d.attr("aria-describedby") && c._open(a, d, b)
                    }, 13)
                });
                g && c._open(a, d, g)
            }
        },
        _open: function(a, d, c) {
            if (c && (d.attr("title", ""), !this.options.disabled)) {
                var g = this._find(d);
                g.length || (g = this._tooltip(), d.attr("aria-describedby", g.attr("id")));
                g.find(".ui-tooltip-content").html(c);
                g.position(b.extend({ of: d
                }, this.options.position)).hide();
                g.stop(!0);
                this._show(g, this.options.show);
                this._trigger("open", a);
                this._bind(d, {
                    mouseleave: "close",
                    blur: "close",
                    click: "close"
                })
            }
        },
        close: function(a) {
            var d = b(a && a.currentTarget || this.element);
            d.attr("title", d.data("tooltip-title"));
            if (!this.options.disabled) {
                var c = this._find(d);
                d.removeAttr("aria-describedby");
                c.stop(!0);
                this._hide(c, this.options.hide, function() {
                    b(this).remove()
                });
                d.unbind("mouseleave.tooltip blur.tooltip");
                this._trigger("close", a)
            }
        },
        _tooltip: function() {
            var a = b("<div></div>").attr("id", "ui-tooltip-" + l++).attr("role", "tooltip").addClass("ui-tooltip ui-widget ui-corner-all ui-widget-content");
            this.options.tooltipClass && a.addClass(this.options.tooltipClass);
            b("<div></div>").addClass("ui-tooltip-content").appendTo(a);
            a.appendTo(document.body);
            return a
        },
        _find: function(a) {
            return (a = a.attr("aria-describedby")) ? b(document.getElementById(a)) : b()
        }
    });
    b.ui.tooltip.version = "1.9m5"
})(jQuery);