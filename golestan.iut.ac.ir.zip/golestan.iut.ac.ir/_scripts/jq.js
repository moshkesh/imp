(function(r, p) {
    function va(a, b, d) {
        if (d === p && 1 === a.nodeType)
            if (d = "data-" + b.replace(ib, "$1-$2").toLowerCase(), d = a.getAttribute(d), "string" === typeof d) {
                try {
                    d = "true" === d ? !0 : "false" === d ? !1 : "null" === d ? null : c.isNaN(d) ? jb.test(d) ? c.parseJSON(d) : d : parseFloat(d)
                } catch (e) {}
                c.data(a, b, d)
            } else d = p;
        return d
    }

    function ga(a) {
        for (var b in a)
            if ("toJSON" !== b) return !1;
        return !0
    }

    function wa(a, b, d) {
        var e = b + "defer",
            f = b + "queue",
            g = b + "mark",
            h = c.data(a, e, p, !0);
        !h || "queue" !== d && c.data(a, f, p, !0) || "mark" !== d && c.data(a, g, p, !0) ||
            setTimeout(function() {
                c.data(a, f, p, !0) || c.data(a, g, p, !0) || (c.removeData(a, e, !0), h.resolve())
            }, 0)
    }

    function F() {
        return !1
    }

    function Y() {
        return !0
    }

    function xa(a, b, d) {
        var e = c.extend({}, d[0]);
        e.type = a;
        e.originalEvent = {};
        e.liveFired = p;
        c.event.handle.call(b, e);
        e.isDefaultPrevented() && d[0].preventDefault()
    }

    function kb(a) {
        var b, d, e, f, g, h, k, l, m, q, p, n = [];
        f = [];
        g = c._data(this, "events");
        if (a.liveFired !== this && g && g.live && !a.target.disabled && (!a.button || "click" !== a.type)) {
            a.namespace && (p = new RegExp("(^|\\.)" + a.namespace.split(".").join("\\.(?:.*\\.)?") +
                "(\\.|$)"));
            a.liveFired = this;
            var r = g.live.slice(0);
            for (k = 0; k < r.length; k++) g = r[k], g.origType.replace(ha, "") === a.type ? f.push(g.selector) : r.splice(k--, 1);
            f = c(a.target).closest(f, a.currentTarget);
            l = 0;
            for (m = f.length; l < m; l++)
                for (q = f[l], k = 0; k < r.length; k++)
                    if (g = r[k], q.selector === g.selector && (!p || p.test(g.namespace)) && !q.elem.disabled) {
                        h = q.elem;
                        e = null;
                        if ("mouseenter" === g.preType || "mouseleave" === g.preType) a.type = g.preType, (e = c(a.relatedTarget).closest(g.selector)[0]) && c.contains(h, e) && (e = h);
                        e && e === h || n.push({
                            elem: h,
                            handleObj: g,
                            level: q.level
                        })
                    }
            l = 0;
            for (m = n.length; l < m; l++) {
                f = n[l];
                if (d && f.level > d) break;
                a.currentTarget = f.elem;
                a.data = f.handleObj.data;
                a.handleObj = f.handleObj;
                p = f.handleObj.origHandler.apply(f.elem, arguments);
                if (!1 === p || a.isPropagationStopped())
                    if (d = f.level, !1 === p && (b = !1), a.isImmediatePropagationStopped()) break
            }
            return b
        }
    }

    function Z(a, b) {
        return (a && "*" !== a ? a + "." : "") + b.replace(lb, "`").replace(mb, "&")
    }

    function ya(a) {
        return !a || !a.parentNode || 11 === a.parentNode.nodeType
    }

    function za(a, b, d) {
        b = b || 0;
        if (c.isFunction(b)) return c.grep(a,
            function(a, c) {
                return !!b.call(a, c, a) === d
            });
        if (b.nodeType) return c.grep(a, function(a, c) {
            return a === b === d
        });
        if ("string" === typeof b) {
            var e = c.grep(a, function(a) {
                return 1 === a.nodeType
            });
            if (nb.test(b)) return c.filter(b, e, !d);
            b = c.filter(b, e)
        }
        return c.grep(a, function(a, e) {
            return 0 <= c.inArray(a, b) === d
        })
    }

    function ob(a, b) {
        return c.nodeName(a, "table") ? a.getElementsByTagName("tbody")[0] || a.appendChild(a.ownerDocument.createElement("tbody")) : a
    }

    function Aa(a, b) {
        if (1 === b.nodeType && c.hasData(a)) {
            var d = c.expando,
                e =
                c.data(a),
                f = c.data(b, e);
            if (e = e[d]) {
                var g = e.events,
                    f = f[d] = c.extend({}, e);
                if (g) {
                    delete f.handle;
                    f.events = {};
                    for (var h in g)
                        for (d = 0, e = g[h].length; d < e; d++) c.event.add(b, h + (g[h][d].namespace ? "." : "") + g[h][d].namespace, g[h][d], g[h][d].data)
                }
            }
        }
    }

    function Ba(a, b) {
        var d, e, f;
        if (1 === b.nodeType) {
            d = b.nodeName.toLowerCase();
            if (!c.support.noCloneEvent && b[c.expando]) {
                f = c._data(b);
                for (e in f.events) c.removeEvent(b, e, f.handle);
                b.removeAttribute(c.expando)
            }
            if ("script" === d && b.text !== a.text) disableScript(b).text = a.text,
                restoreScript(b);
            else if ("object" === d) b.parentNode && (b.outerHTML = a.outerHTML), c.support.html5Clone && a.innerHTML && !c.trim(b.innerHTML) && (b.innerHTML = a.innerHTML);
            else if ("input" === d) b.defaultChecked = b.checked = a.checked, b.value !== a.value && (b.value = a.value);
            else if ("option" === d) b.defaultSelected = b.selected = a.defaultSelected;
            else if ("input" === d || "textarea" === d) b.defaultValue = a.defaultValue
        }
    }

    function aa(a) {
        return "getElementsByTagName" in a ? a.getElementsByTagName("*") : "querySelectorAll" in a ? a.querySelectorAll("*") : []
    }

    function Ca(a) {
        if ("checkbox" === a.type || "radio" === a.type) a.defaultChecked = a.checked
    }

    function Da(a) {
        c.nodeName(a, "input") ? Ca(a) : "getElementsByTagName" in a && c.grep(a.getElementsByTagName("input"), Ca)
    }

    function pb(a, b) {
        b.src ? c.ajax({
            url: b.src,
            async: !1,
            dataType: "script"
        }) : c.globalEval((b.text || b.textContent || b.innerHTML || "").replace(qb, "/*$0*/"));
        b.parentNode && b.parentNode.removeChild(b)
    }

    function Ea(a, b, d) {
        var e = "width" === b ? a.offsetWidth : a.offsetHeight,
            f = "width" === b ? rb : sb;
        if (0 < e) return "border" !== d &&
            c.each(f, function() {
                d || (e -= parseFloat(c.css(a, "padding" + this)) || 0);
                e = "margin" === d ? e + (parseFloat(c.css(a, d + this)) || 0) : e - (parseFloat(c.css(a, "border" + this + "Width")) || 0)
            }), e + "px";
        e = J(a, b, b);
        if (0 > e || null == e) e = a.style[b] || 0;
        e = parseFloat(e) || 0;
        d && c.each(f, function() {
            e += parseFloat(c.css(a, "padding" + this)) || 0;
            "padding" !== d && (e += parseFloat(c.css(a, "border" + this + "Width")) || 0);
            "margin" === d && (e += parseFloat(c.css(a, d + this)) || 0)
        });
        return e + "px"
    }

    function Fa(a) {
        return function(b, d) {
            "string" !== typeof b && (d = b, b = "*");
            if (c.isFunction(d))
                for (var e = b.toLowerCase().split(Ga), f = 0, g = e.length, h, k; f < g; f++) h = e[f], (k = /^\+/.test(h)) && (h = h.substr(1) || "*"), h = a[h] = a[h] || [], h[k ? "unshift" : "push"](d)
        }
    }

    function ba(a, b, c, e, f, g) {
        f = f || b.dataTypes[0];
        g = g || {};
        g[f] = !0;
        f = a[f];
        for (var h = 0, k = f ? f.length : 0, l = a === ia, m; h < k && (l || !m); h++) m = f[h](b, c, e), "string" === typeof m && (!l || g[m] ? m = p : (b.dataTypes.unshift(m), m = ba(a, b, c, e, m, g)));
        !l && m || g["*"] || (m = ba(a, b, c, e, "*", g));
        return m
    }

    function ja(a, b, d, e) {
        if (c.isArray(b)) c.each(b, function(b, f) {
            d || tb.test(a) ?
                e(a, f) : ja(a + "[" + ("object" === typeof f || c.isArray(f) ? b : "") + "]", f, d, e)
        });
        else if (d || null == b || "object" !== typeof b) e(a, b);
        else
            for (var f in b) ja(a + "[" + f + "]", b[f], d, e)
    }

    function Ha() {
        try {
            return new r.XMLHttpRequest
        } catch (a) {}
    }

    function Ia() {
        setTimeout(ub, 0);
        return ca = c.now()
    }

    function ub() {
        ca = p
    }

    function P(a, b) {
        var d = {};
        c.each(Ja.concat.apply([], Ja.slice(0, b)), function() {
            d[this] = a
        });
        return d
    }

    function Ka(a) {
        if (!ka[a]) {
            var b = n.body,
                d = c("<" + a + ">").appendTo(b),
                e = d.css("display");
            d.remove();
            if ("none" === e || "" ===
                e) z || (z = n.createElement("iframe"), z.frameBorder = z.width = z.height = 0), b.appendChild(z), K && z.createElement || (K = (z.contentWindow || z.contentDocument).document, K.write(("CSS1Compat" === n.compatMode ? "<!doctype html>" : "") + "<html><body>"), K.close()), d = K.createElement(a), K.body.appendChild(d), e = c.css(d, "display"), b.removeChild(z);
            ka[a] = e
        }
        return ka[a]
    }

    function la(a) {
        return c.isWindow(a) ? a : 9 === a.nodeType ? a.defaultView || a.parentWindow : !1
    }
    var n = r.document,
        vb = r.navigator,
        wb = r.location,
        c = function() {
            function a() {
                if (!b.isReady) {
                    try {
                        n.documentElement.doScroll("left")
                    } catch (c) {
                        setTimeout(a,
                            1);
                        return
                    }
                    b.ready()
                }
            }
            var b = function(a, c) {
                    return new b.fn.init(a, c, f)
                },
                c = r.jQuery,
                e = r.$,
                f, g = /^(?:[^<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
                h = /\S/,
                k = /^\s+/,
                l = /\s+$/,
                m = /\d/,
                q = /^<(\w+)\s*\/?>(?:<\/\1>)?$/,
                I = /^[\],:{}\s]*$/,
                O = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
                u = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
                w = /(?:^|:|,)(?:\s*\[)+/g,
                A = /(webkit)[ \/]([\w.]+)/,
                y = /(opera)(?:.*version)?[ \/]([\w.]+)/,
                C = /(msie) ([\w.]+)/,
                z = /(mozilla)(?:.*? rv:([\w.]+))?/,
                x = /-([a-z])/ig,
                t = function(a, b) {
                    return b.toUpperCase()
                },
                D = vb.userAgent,
                da, V, xb = Object.prototype.toString,
                ma = Object.prototype.hasOwnProperty,
                na = Array.prototype.push,
                X = Array.prototype.slice,
                La = String.prototype.trim,
                Ma = Array.prototype.indexOf,
                S = {};
            b.fn = b.prototype = {
                constructor: b,
                init: function(a, c, d) {
                    var e;
                    if (!a) return this;
                    if (a.nodeType) return this.context = this[0] = a, this.length = 1, this;
                    if ("body" === a && !c && n.body) return this.context = n, this[0] = n.body, this.selector = a, this.length = 1, this;
                    if ("string" === typeof a) {
                        e = "<" === a.charAt(0) && ">" === a.charAt(a.length - 1) && 3 <=
                            a.length ? [null, a, null] : g.exec(a);
                        if (!e || !e[1] && c) return !c || c.jquery ? (c || d).find(a) : this.constructor(c).find(a);
                        if (e[1]) return d = (c = c instanceof b ? c[0] : c) ? c.ownerDocument || c : n, (a = q.exec(a)) ? b.isPlainObject(c) ? (a = [n.createElement(a[1])], b.fn.attr.call(a, c, !0)) : a = [d.createElement(a[1])] : (a = b.buildFragment([e[1]], [d]), a = (a.cacheable ? b.clone(a.fragment) : a.fragment).childNodes), b.merge(this, a);
                        if ((c = n.getElementById(e[2])) && c.parentNode) {
                            if (c.id !== e[2]) return d.find(a);
                            this.length = 1;
                            this[0] = c
                        }
                        this.context =
                            n;
                        this.selector = a;
                        return this
                    }
                    if (b.isFunction(a)) return d.ready(a);
                    a.selector !== p && (this.selector = a.selector, this.context = a.context);
                    return b.makeArray(a, this)
                },
                selector: "",
                jquery: "1.6.2",
                length: 0,
                size: function() {
                    return this.length
                },
                toArray: function() {
                    return X.call(this, 0)
                },
                get: function(a) {
                    return null == a ? this.toArray() : 0 > a ? this[this.length + a] : this[a]
                },
                pushStack: function(a, c, d) {
                    var e = this.constructor();
                    b.isArray(a) ? na.apply(e, a) : b.merge(e, a);
                    e.prevObject = this;
                    e.context = this.context;
                    "find" === c ? e.selector =
                        this.selector + (this.selector ? " " : "") + d : c && (e.selector = this.selector + "." + c + "(" + d + ")");
                    return e
                },
                each: function(a, c) {
                    return b.each(this, a, c)
                },
                ready: function(a) {
                    b.bindReady();
                    da.done(a);
                    return this
                },
                eq: function(a) {
                    return -1 === a ? this.slice(a) : this.slice(a, +a + 1)
                },
                first: function() {
                    return this.eq(0)
                },
                last: function() {
                    return this.eq(-1)
                },
                slice: function() {
                    return this.pushStack(X.apply(this, arguments), "slice", X.call(arguments).join(","))
                },
                map: function(a) {
                    return this.pushStack(b.map(this, function(b, c) {
                        return a.call(b,
                            c, b)
                    }))
                },
                end: function() {
                    return this.prevObject || this.constructor(null)
                },
                push: na,
                sort: [].sort,
                splice: [].splice
            };
            b.fn.init.prototype = b.fn;
            b.extend = b.fn.extend = function() {
                var a, c, d, e, f, g = arguments[0] || {},
                    x = 1,
                    h = arguments.length,
                    t = !1;
                "boolean" === typeof g && (t = g, g = arguments[1] || {}, x = 2);
                "object" === typeof g || b.isFunction(g) || (g = {});
                h === x && (g = this, --x);
                for (; x < h; x++)
                    if (null != (a = arguments[x]))
                        for (c in a) d = g[c], e = a[c], g !== e && (t && e && (b.isPlainObject(e) || (f = b.isArray(e))) ? (f ? (f = !1, d = d && b.isArray(d) ? d : []) : d = d && b.isPlainObject(d) ?
                            d : {}, g[c] = b.extend(t, d, e)) : e !== p && (g[c] = e));
                return g
            };
            b.extend({
                noConflict: function(a) {
                    r.$ === b && (r.$ = e);
                    a && r.jQuery === b && (r.jQuery = c);
                    return b
                },
                isReady: !1,
                readyWait: 1,
                holdReady: function(a) {
                    a ? b.readyWait++ : b.ready(!0)
                },
                ready: function(a) {
                    if (!0 === a && !--b.readyWait || !0 !== a && !b.isReady) {
                        if (!n.body) return setTimeout(b.ready, 1);
                        b.isReady = !0;
                        !0 !== a && 0 < --b.readyWait || (da.resolveWith(n, [b]), b.fn.trigger && b(n).trigger("ready").unbind("ready"))
                    }
                },
                bindReady: function() {
                    if (!da) {
                        da = b._Deferred();
                        if ("complete" ===
                            n.readyState) return setTimeout(b.ready, 1);
                        if (n.addEventListener) n.addEventListener("DOMContentLoaded", V, !1), r.addEventListener("load", b.ready, !1);
                        else if (n.attachEvent) {
                            n.attachEvent("onreadystatechange", V);
                            r.attachEvent("onload", b.ready);
                            var c = !1;
                            try {
                                c = null == r.frameElement
                            } catch (d) {}
                            n.documentElement.doScroll && c && a()
                        }
                    }
                },
                isFunction: function(a) {
                    return "function" === b.type(a)
                },
                isArray: Array.isArray || function(a) {
                    return "array" === b.type(a)
                },
                isWindow: function(a) {
                    return a && "object" === typeof a && "setInterval" in
                        a
                },
                isNaN: function(a) {
                    return null == a || !m.test(a) || isNaN(a)
                },
                type: function(a) {
                    return null == a ? String(a) : S[xb.call(a)] || "object"
                },
                isPlainObject: function(a) {
                    if (!a || "object" !== b.type(a) || a.nodeType || b.isWindow(a) || a.constructor && !ma.call(a, "constructor") && !ma.call(a.constructor.prototype, "isPrototypeOf")) return !1;
                    for (var c in a);
                    return c === p || ma.call(a, c)
                },
                isEmptyObject: function(a) {
                    for (var b in a) return !1;
                    return !0
                },
                error: function(a) {
                    throw a;
                },
                parseJSON: function(a) {
                    if ("string" !== typeof a || !a) return null;
                    a = b.trim(a);
                    if (r.JSON && r.JSON.parse) return r.JSON.parse(a);
                    if (I.test(a.replace(O, "@").replace(u, "]").replace(w, ""))) return (new Function("return " + a))();
                    b.error("Invalid JSON: " + a)
                },
                parseXML: function(a, c, d) {
                    r.DOMParser ? (d = new DOMParser, c = d.parseFromString(a, "text/xml")) : (c = new ActiveXObject("Microsoft.XMLDOM"), c.async = "false", c.loadXML(a));
                    (d = c.documentElement) && d.nodeName && "parsererror" !== d.nodeName || b.error("Invalid XML: " + a);
                    return c
                },
                noop: function() {},
                globalEval: function(a) {
                    a && h.test(a) && (r.execScript ||
                        function(a) {
                            r.eval.call(r, a)
                        })(a)
                },
                camelCase: function(a) {
                    return a.replace(x, t)
                },
                nodeName: function(a, b) {
                    return a.nodeName && a.nodeName.toUpperCase() === b.toUpperCase()
                },
                each: function(a, c, d) {
                    var e, f = 0,
                        g = a.length,
                        x = g === p || b.isFunction(a);
                    if (d)
                        if (x)
                            for (e in a) {
                                if (!1 === c.apply(a[e], d)) break
                            } else
                                for (; f < g && !1 !== c.apply(a[f++], d););
                        else if (x)
                        for (e in a) {
                            if (!1 === c.call(a[e], e, a[e])) break
                        } else
                            for (; f < g && !1 !== c.call(a[f], f, a[f++]););
                    return a
                },
                trim: La ? function(a) {
                    return null == a ? "" : La.call(a)
                } : function(a) {
                    return null ==
                        a ? "" : a.toString().replace(k, "").replace(l, "")
                },
                makeArray: function(a, c) {
                    var d = c || [];
                    if (null != a) {
                        var e = b.type(a);
                        null == a.length || "string" === e || "function" === e || "regexp" === e || b.isWindow(a) ? na.call(d, a) : b.merge(d, a)
                    }
                    return d
                },
                inArray: function(a, b) {
                    if (Ma) return Ma.call(b, a);
                    for (var c = 0, d = b.length; c < d; c++)
                        if (b[c] === a) return c;
                    return -1
                },
                merge: function(a, b) {
                    var c = a.length,
                        d = 0;
                    if ("number" === typeof b.length)
                        for (var e = b.length; d < e; d++) a[c++] = b[d];
                    else
                        for (; b[d] !== p;) a[c++] = b[d++];
                    a.length = c;
                    return a
                },
                grep: function(a,
                    b, c) {
                    var d = [],
                        e;
                    c = !!c;
                    for (var f = 0, g = a.length; f < g; f++) e = !!b(a[f], f), c !== e && d.push(a[f]);
                    return d
                },
                map: function(a, c, d) {
                    var e, f, g = [],
                        x = 0,
                        h = a.length;
                    if (a instanceof b || h !== p && "number" === typeof h && (0 < h && a[0] && a[h - 1] || 0 === h || b.isArray(a)))
                        for (; x < h; x++) e = c(a[x], x, d), null != e && (g[g.length] = e);
                    else
                        for (f in a) e = c(a[f], f, d), null != e && (g[g.length] = e);
                    return g.concat.apply([], g)
                },
                guid: 1,
                proxy: function(a, c) {
                    if ("string" === typeof c) {
                        var d = a[c];
                        c = a;
                        a = d
                    }
                    if (!b.isFunction(a)) return p;
                    var e = X.call(arguments, 2),
                        d = function() {
                            return a.apply(c,
                                e.concat(X.call(arguments)))
                        };
                    d.guid = a.guid = a.guid || d.guid || b.guid++;
                    return d
                },
                access: function(a, c, d, e, f, g) {
                    var x = a.length;
                    if ("object" === typeof c) {
                        for (var h in c) b.access(a, h, c[h], e, f, d);
                        return a
                    }
                    if (d !== p) {
                        e = !g && e && b.isFunction(d);
                        for (h = 0; h < x; h++) f(a[h], c, e ? d.call(a[h], h, f(a[h], c)) : d, g);
                        return a
                    }
                    return x ? f(a[0], c) : p
                },
                now: function() {
                    return (new Date).getTime()
                },
                uaMatch: function(a) {
                    a = a.toLowerCase();
                    a = A.exec(a) || y.exec(a) || C.exec(a) || 0 > a.indexOf("compatible") && z.exec(a) || [];
                    return {
                        browser: a[1] || "",
                        version: a[2] ||
                            "0"
                    }
                },
                sub: function() {
                    function a(b, c) {
                        return new a.fn.init(b, c)
                    }
                    b.extend(!0, a, this);
                    a.superclass = this;
                    a.fn = a.prototype = this();
                    a.fn.constructor = a;
                    a.sub = this.sub;
                    a.fn.init = function(d, e) {
                        e && e instanceof b && !(e instanceof a) && (e = a(e));
                        return b.fn.init.call(this, d, e, c)
                    };
                    a.fn.init.prototype = a.fn;
                    var c = a(n);
                    return a
                },
                browser: {}
            });
            b.each("Boolean Number String Function Array Date RegExp Object".split(" "), function(a, b) {
                S["[object " + b + "]"] = b.toLowerCase()
            });
            D = b.uaMatch(D);
            D.browser && (b.browser[D.browser] = !0,
                b.browser.version = D.version);
            b.browser.webkit && (b.browser.safari = !0);
            h.test("\u00a0") && (k = /^[\s\xA0]+/, l = /[\s\xA0]+$/);
            f = b(n);
            n.addEventListener ? V = function() {
                n.removeEventListener("DOMContentLoaded", V, !1);
                b.ready()
            } : n.attachEvent && (V = function() {
                "complete" === n.readyState && (n.detachEvent("onreadystatechange", V), b.ready())
            });
            return b
        }(),
        oa = "done fail isResolved isRejected promise then always pipe".split(" "),
        Na = [].slice;
    c.extend({
        _Deferred: function() {
            var a = [],
                b, d, e, f = {
                    done: function() {
                        if (!e) {
                            var d = arguments,
                                h, k, l, m, q;
                            b && (q = b, b = 0);
                            h = 0;
                            for (k = d.length; h < k; h++) l = d[h], m = c.type(l), "array" === m ? f.done.apply(f, l) : "function" === m && a.push(l);
                            q && f.resolveWith(q[0], q[1])
                        }
                        return this
                    },
                    resolveWith: function(c, f) {
                        if (!e && !b && !d) {
                            f = f || [];
                            d = 1;
                            try {
                                for (; a[0];) a.shift().apply(c, f)
                            } finally {
                                b = [c, f], d = 0
                            }
                        }
                        return this
                    },
                    resolve: function() {
                        f.resolveWith(this, arguments);
                        return this
                    },
                    isResolved: function() {
                        return !(!d && !b)
                    },
                    cancel: function() {
                        e = 1;
                        a = [];
                        return this
                    }
                };
            return f
        },
        Deferred: function(a) {
            var b = c._Deferred(),
                d = c._Deferred(),
                e;
            c.extend(b, {
                then: function(a, c) {
                    b.done(a).fail(c);
                    return this
                },
                always: function() {
                    return b.done.apply(b, arguments).fail.apply(this, arguments)
                },
                fail: d.done,
                rejectWith: d.resolveWith,
                reject: d.resolve,
                isRejected: d.isResolved,
                pipe: function(a, d) {
                    return c.Deferred(function(e) {
                        c.each({
                            done: [a, "resolve"],
                            fail: [d, "reject"]
                        }, function(a, d) {
                            var f = d[0],
                                g = d[1],
                                p;
                            if (c.isFunction(f)) b[a](function() {
                                if ((p = f.apply(this, arguments)) && c.isFunction(p.promise)) p.promise().then(e.resolve, e.reject);
                                else e[g](p)
                            });
                            else b[a](e[g])
                        })
                    }).promise()
                },
                promise: function(a) {
                    if (null == a) {
                        if (e) return e;
                        e = a = {}
                    }
                    for (var c = oa.length; c--;) a[oa[c]] = b[oa[c]];
                    return a
                }
            });
            b.done(d.cancel).fail(b.cancel);
            delete b.cancel;
            a && a.call(b, b);
            return b
        },
        when: function(a) {
            function b(a) {
                return function(b) {
                    d[a] = 1 < arguments.length ? Na.call(arguments, 0) : b;
                    --g || h.resolveWith(h, Na.call(d, 0))
                }
            }
            var d = arguments,
                e = 0,
                f = d.length,
                g = f,
                h = 1 >= f && a && c.isFunction(a.promise) ? a : c.Deferred();
            if (1 < f) {
                for (; e < f; e++) d[e] && c.isFunction(d[e].promise) ? d[e].promise().then(b(e), h.reject) : --g;
                g || h.resolveWith(h,
                    d)
            } else h !== a && h.resolveWith(h, f ? [a] : []);
            return h.promise()
        }
    });
    c.support = function() {
        var a = n.createElement("div"),
            b = n.documentElement,
            d, e, f, g, h, k;
        a.setAttribute("className", "t");
        a.innerHTML = "   <link/><table></table><a href='/a' style='top:1px;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
        d = a.getElementsByTagName("*");
        e = a.getElementsByTagName("a")[0];
        if (!d || !d.length || !e) return {};
        f = n.createElement("select");
        g = f.appendChild(n.createElement("option"));
        d = a.getElementsByTagName("input")[0];
        h = {
            leadingWhitespace: 3 === a.firstChild.nodeType,
            tbody: !a.getElementsByTagName("tbody").length,
            htmlSerialize: !!a.getElementsByTagName("link").length,
            style: /top/.test(e.getAttribute("style")),
            hrefNormalized: "/a" === e.getAttribute("href"),
            opacity: /^0.55$/.test(e.style.opacity),
            cssFloat: !!e.style.cssFloat,
            checkOn: "on" === d.value,
            optSelected: g.selected,
            getSetAttribute: "t" !== a.className,
            submitBubbles: !0,
            changeBubbles: !0,
            focusinBubbles: !1,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0
        };
        d.checked = !0;
        h.noCloneChecked = d.cloneNode(!0).checked;
        f.disabled = !0;
        h.optDisabled = !g.disabled;
        try {
            delete a.test
        } catch (l) {
            h.deleteExpando = !1
        }!a.addEventListener && a.attachEvent && a.fireEvent && (a.attachEvent("onclick", function() {
            h.noCloneEvent = !1
        }), a.cloneNode(!0).fireEvent("onclick"));
        d = n.createElement("input");
        d.value = "t";
        d.setAttribute("type", "radio");
        h.radioValue = "t" === d.value;
        d.setAttribute("checked", "checked");
        a.appendChild(d);
        e = n.createDocumentFragment();
        e.appendChild(a.firstChild);
        h.checkClone = e.cloneNode(!0).cloneNode(!0).lastChild.checked;
        a.innerHTML = "";
        a.style.width = a.style.paddingLeft = "1px";
        f = n.getElementsByTagName("body")[0];
        e = n.createElement(f ? "div" : "body");
        g = {
            visibility: "hidden",
            width: 0,
            height: 0,
            border: 0,
            margin: 0
        };
        f && c.extend(g, {
            position: "absolute",
            left: -1E3,
            top: -1E3
        });
        for (k in g) e.style[k] = g[k];
        e.appendChild(a);
        b = f || b;
        b.insertBefore(e, b.firstChild);
        h.appendChecked = d.checked;
        h.boxModel = 2 === a.offsetWidth;
        "zoom" in a.style && (a.style.display = "inline", a.style.zoom = 1, h.inlineBlockNeedsLayout =
            2 === a.offsetWidth, a.style.display = "", a.innerHTML = "<div style='width:4px;'></div>", h.shrinkWrapBlocks = 2 !== a.offsetWidth);
        a.innerHTML = "<table><tr><td style='padding:0;border:0;display:none'></td><td>t</td></tr></table>";
        f = a.getElementsByTagName("td");
        d = 0 === f[0].offsetHeight;
        f[0].style.display = "";
        f[1].style.display = "none";
        h.reliableHiddenOffsets = d && 0 === f[0].offsetHeight;
        a.innerHTML = "";
        n.defaultView && n.defaultView.getComputedStyle && (d = n.createElement("div"), d.style.width = "0", d.style.marginRight = "0", a.appendChild(d),
            h.reliableMarginRight = 0 === (parseInt((n.defaultView.getComputedStyle(d, null) || {
                marginRight: 0
            }).marginRight, 10) || 0));
        e.innerHTML = "";
        b.removeChild(e);
        if (a.attachEvent)
            for (k in {
                    submit: 1,
                    change: 1,
                    focusin: 1
                }) b = "on" + k, d = b in a, d || (a.setAttribute(b, "return;"), d = "function" === typeof a[b]), h[k + "Bubbles"] = d;
        e = e = f = g = f = d = a = d = null;
        return h
    }();
    c.boxModel = c.support.boxModel;
    var jb = /^(?:\{.*\}|\[.*\])$/,
        ib = /([a-z])([A-Z])/g;
    c.extend({
        cache: {},
        uuid: 0,
        expando: "jQuery" + (c.fn.jquery + Math.random()).replace(/\D/g, ""),
        noData: {
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: !0
        },
        hasData: function(a) {
            a = a.nodeType ? c.cache[a[c.expando]] : a[c.expando];
            return !!a && !ga(a)
        },
        data: function(a, b, d, e) {
            if (c.acceptData(a)) {
                var f = c.expando,
                    g = "string" === typeof b,
                    h = a.nodeType,
                    k = h ? c.cache : a,
                    l = h ? a[c.expando] : a[c.expando] && c.expando;
                if (l && (!e || !l || k[l][f]) || !g || d !== p) {
                    l || (h ? a[c.expando] = l = ++c.uuid : l = c.expando);
                    k[l] || (k[l] = {}, h || (k[l].toJSON = c.noop));
                    if ("object" === typeof b || "function" === typeof b) e ? k[l][f] = c.extend(k[l][f], b) : k[l] = c.extend(k[l],
                        b);
                    a = k[l];
                    e && (a[f] || (a[f] = {}), a = a[f]);
                    d !== p && (a[c.camelCase(b)] = d);
                    return "events" !== b || a[b] ? g ? a[c.camelCase(b)] || a[b] : a : a[f] && a[f].events
                }
            }
        },
        removeData: function(a, b, d) {
            if (c.acceptData(a)) {
                var e = c.expando,
                    f = a.nodeType,
                    g = f ? c.cache : a,
                    h = f ? a[c.expando] : c.expando;
                if (g[h]) {
                    if (b) {
                        var k = d ? g[h][e] : g[h];
                        if (k && (delete k[b], !ga(k))) return
                    }
                    if (d && (delete g[h][e], !ga(g[h]))) return;
                    b = g[h][e];
                    c.support.deleteExpando || g != r ? delete g[h] : g[h] = null;
                    b ? (g[h] = {}, f || (g[h].toJSON = c.noop), g[h][e] = b) : f && (c.support.deleteExpando ?
                        delete a[c.expando] : a.removeAttribute ? a.removeAttribute(c.expando) : a[c.expando] = null)
                }
            }
        },
        _data: function(a, b, d) {
            return c.data(a, b, d, !0)
        },
        acceptData: function(a) {
            if (a.nodeName) {
                var b = c.noData[a.nodeName.toLowerCase()];
                if (b) return !(!0 === b || a.getAttribute("classid") !== b)
            }
            return !0
        }
    });
    c.fn.extend({
        data: function(a, b) {
            var d = null;
            if ("undefined" === typeof a) {
                if (this.length && (d = c.data(this[0]), 1 === this[0].nodeType))
                    for (var e = this[0].attributes, f, g = 0, h = e.length; g < h; g++) f = e[g].name, 0 === f.indexOf("data-") && (f = c.camelCase(f.substring(5)),
                        va(this[0], f, d[f]));
                return d
            }
            if ("object" === typeof a) return this.each(function() {
                c.data(this, a)
            });
            var k = a.split(".");
            k[1] = k[1] ? "." + k[1] : "";
            return b === p ? (d = this.triggerHandler("getData" + k[1] + "!", [k[0]]), d === p && this.length && (d = c.data(this[0], a), d = va(this[0], a, d)), d === p && k[1] ? this.data(k[0]) : d) : this.each(function() {
                var d = c(this),
                    e = [k[0], b];
                d.triggerHandler("setData" + k[1] + "!", e);
                c.data(this, a, b);
                d.triggerHandler("changeData" + k[1] + "!", e)
            })
        },
        removeData: function(a) {
            return this.each(function() {
                c.removeData(this,
                    a)
            })
        }
    });
    c.extend({
        _mark: function(a, b) {
            a && (b = (b || "fx") + "mark", c.data(a, b, (c.data(a, b, p, !0) || 0) + 1, !0))
        },
        _unmark: function(a, b, d) {
            !0 !== a && (d = b, b = a, a = !1);
            if (b) {
                d = d || "fx";
                var e = d + "mark";
                (a = a ? 0 : (c.data(b, e, p, !0) || 1) - 1) ? c.data(b, e, a, !0): (c.removeData(b, e, !0), wa(b, d, "mark"))
            }
        },
        queue: function(a, b, d) {
            if (a) {
                b = (b || "fx") + "queue";
                var e = c.data(a, b, p, !0);
                d && (!e || c.isArray(d) ? e = c.data(a, b, c.makeArray(d), !0) : e.push(d));
                return e || []
            }
        },
        dequeue: function(a, b) {
            b = b || "fx";
            var d = c.queue(a, b),
                e = d.shift();
            "inprogress" === e && (e =
                d.shift());
            e && ("fx" === b && d.unshift("inprogress"), e.call(a, function() {
                c.dequeue(a, b)
            }));
            d.length || (c.removeData(a, b + "queue", !0), wa(a, b, "queue"))
        }
    });
    c.fn.extend({
        queue: function(a, b) {
            "string" !== typeof a && (b = a, a = "fx");
            return b === p ? c.queue(this[0], a) : this.each(function() {
                var d = c.queue(this, a, b);
                "fx" === a && "inprogress" !== d[0] && c.dequeue(this, a)
            })
        },
        dequeue: function(a) {
            return this.each(function() {
                c.dequeue(this, a)
            })
        },
        delay: function(a, b) {
            a = c.fx ? c.fx.speeds[a] || a : a;
            b = b || "fx";
            return this.queue(b, function() {
                var d =
                    this;
                setTimeout(function() {
                    c.dequeue(d, b)
                }, a)
            })
        },
        clearQueue: function(a) {
            return this.queue(a || "fx", [])
        },
        promise: function(a, b) {
            function d() {
                --h || e.resolveWith(f, [f])
            }
            "string" !== typeof a && (a = p);
            a = a || "fx";
            for (var e = c.Deferred(), f = this, g = f.length, h = 1, k = a + "defer", l = a + "queue", m = a + "mark", q; g--;)
                if (q = c.data(f[g], k, p, !0) || (c.data(f[g], l, p, !0) || c.data(f[g], m, p, !0)) && c.data(f[g], k, c._Deferred(), !0)) h++, q.done(d);
            d();
            return e.promise()
        }
    });
    var Oa = /[\n\t\r]/g,
        pa = /\s+/,
        yb = /\r/g,
        zb = /^(?:button|input)$/i,
        Ab = /^(?:button|input|object|select|textarea)$/i,
        Bb = /^a(?:rea)?$/i,
        Pa = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,
        Cb = /\:|^on/,
        L, Qa;
    c.fn.extend({
        attr: function(a, b) {
            return c.access(this, a, b, !0, c.attr)
        },
        removeAttr: function(a) {
            return this.each(function() {
                c.removeAttr(this, a)
            })
        },
        prop: function(a, b) {
            return c.access(this, a, b, !0, c.prop)
        },
        removeProp: function(a) {
            a = c.propFix[a] || a;
            return this.each(function() {
                try {
                    this[a] = p, delete this[a]
                } catch (b) {}
            })
        },
        addClass: function(a) {
            var b,
                d, e, f, g, h, k;
            if (c.isFunction(a)) return this.each(function(b) {
                c(this).addClass(a.call(this, b, this.className))
            });
            if (a && "string" === typeof a)
                for (b = a.split(pa), d = 0, e = this.length; d < e; d++)
                    if (f = this[d], 1 === f.nodeType)
                        if (f.className || 1 !== b.length) {
                            g = " " + f.className + " ";
                            h = 0;
                            for (k = b.length; h < k; h++) ~g.indexOf(" " + b[h] + " ") || (g += b[h] + " ");
                            f.className = c.trim(g)
                        } else f.className = a;
            return this
        },
        removeClass: function(a) {
            var b, d, e, f, g, h, k;
            if (c.isFunction(a)) return this.each(function(b) {
                c(this).removeClass(a.call(this,
                    b, this.className))
            });
            if (a && "string" === typeof a || a === p)
                for (b = (a || "").split(pa), d = 0, e = this.length; d < e; d++)
                    if (f = this[d], 1 === f.nodeType && f.className)
                        if (a) {
                            g = (" " + f.className + " ").replace(Oa, " ");
                            h = 0;
                            for (k = b.length; h < k; h++) g = g.replace(" " + b[h] + " ", " ");
                            f.className = c.trim(g)
                        } else f.className = "";
            return this
        },
        toggleClass: function(a, b) {
            var d = typeof a,
                e = "boolean" === typeof b;
            return c.isFunction(a) ? this.each(function(d) {
                c(this).toggleClass(a.call(this, d, this.className, b), b)
            }) : this.each(function() {
                if ("string" ===
                    d)
                    for (var f, g = 0, h = c(this), k = b, l = a.split(pa); f = l[g++];) k = e ? k : !h.hasClass(f), h[k ? "addClass" : "removeClass"](f);
                else if ("undefined" === d || "boolean" === d) this.className && c._data(this, "__className__", this.className), this.className = this.className || !1 === a ? "" : c._data(this, "__className__") || ""
            })
        },
        hasClass: function(a) {
            a = " " + a + " ";
            for (var b = 0, c = this.length; b < c; b++)
                if (-1 < (" " + this[b].className + " ").replace(Oa, " ").indexOf(a)) return !0;
            return !1
        },
        val: function(a) {
            var b, d, e = this[0];
            if (!arguments.length) {
                if (e) {
                    if ((b =
                            c.valHooks[e.nodeName.toLowerCase()] || c.valHooks[e.type]) && "get" in b && (d = b.get(e, "value")) !== p) return d;
                    d = e.value;
                    return "string" === typeof d ? d.replace(yb, "") : null == d ? "" : d
                }
                return p
            }
            var f = c.isFunction(a);
            return this.each(function(d) {
                var e = c(this);
                1 === this.nodeType && (d = f ? a.call(this, d, e.val()) : a, null == d ? d = "" : "number" === typeof d ? d += "" : c.isArray(d) && (d = c.map(d, function(a) {
                        return null == a ? "" : a + ""
                    })), b = c.valHooks[this.nodeName.toLowerCase()] || c.valHooks[this.type], b && "set" in b && b.set(this, d, "value") !== p ||
                    (this.value = d))
            })
        }
    });
    c.extend({
        valHooks: {
            option: {
                get: function(a) {
                    var b = a.attributes.value;
                    return !b || b.specified ? a.value : a.text
                }
            },
            select: {
                get: function(a) {
                    var b, d = a.selectedIndex,
                        e = [],
                        f = a.options;
                    a = "select-one" === a.type;
                    if (0 > d) return null;
                    for (var g = a ? d : 0, h = a ? d + 1 : f.length; g < h; g++)
                        if (b = f[g], !(!b.selected || (c.support.optDisabled ? b.disabled : null !== b.getAttribute("disabled")) || b.parentNode.disabled && c.nodeName(b.parentNode, "optgroup"))) {
                            b = c(b).val();
                            if (a) return b;
                            e.push(b)
                        }
                    return a && !e.length && f.length ?
                        c(f[d]).val() : e
                },
                set: function(a, b) {
                    var d = c.makeArray(b);
                    c(a).find("option").each(function() {
                        this.selected = 0 <= c.inArray(c(this).val(), d)
                    });
                    d.length || (a.selectedIndex = -1);
                    return d
                }
            }
        },
        attrFn: {
            val: !0,
            css: !0,
            html: !0,
            text: !0,
            data: !0,
            width: !0,
            height: !0,
            offset: !0
        },
        attrFix: {
            tabindex: "tabIndex"
        },
        attr: function(a, b, d, e) {
            var f = a.nodeType;
            if (!a || 3 === f || 8 === f || 2 === f) return p;
            if (e && b in c.attrFn) return c(a)[b](d);
            if (!("getAttribute" in a)) return c.prop(a, b, d);
            var g, h;
            if (e = 1 !== f || !c.isXMLDoc(a)) b = c.attrFix[b] || b, (h =
                c.attrHooks[b]) || (Pa.test(b) ? h = Qa : L && "className" !== b && (c.nodeName(a, "form") || Cb.test(b)) && (h = L));
            if (d !== p) {
                if (null === d) return c.removeAttr(a, b), p;
                if (h && "set" in h && e && (g = h.set(a, d, b)) !== p) return g;
                a.setAttribute(b, "" + d);
                return d
            }
            if (h && "get" in h && e && null !== (g = h.get(a, b))) return g;
            g = a.getAttribute(b);
            return null === g ? p : g
        },
        removeAttr: function(a, b) {
            var d;
            1 === a.nodeType && (b = c.attrFix[b] || b, c.support.getSetAttribute ? a.removeAttribute(b) : (c.attr(a, b, ""), a.removeAttributeNode(a.getAttributeNode(b))), Pa.test(b) &&
                (d = c.propFix[b] || b) in a && (a[d] = !1))
        },
        attrHooks: {
            type: {
                set: function(a, b) {
                    if (zb.test(a.nodeName) && a.parentNode) c.error("type property can't be changed");
                    else if (!c.support.radioValue && "radio" === b && c.nodeName(a, "input")) {
                        var d = a.value;
                        a.setAttribute("type", b);
                        d && (a.value = d);
                        return b
                    }
                }
            },
            tabIndex: {
                get: function(a) {
                    var b = a.getAttributeNode("tabIndex");
                    return b && b.specified ? parseInt(b.value, 10) : Ab.test(a.nodeName) || Bb.test(a.nodeName) && a.href ? 0 : p
                }
            },
            value: {
                get: function(a, b) {
                    return L && c.nodeName(a, "button") ?
                        L.get(a, b) : b in a ? a.value : null
                },
                set: function(a, b, d) {
                    if (L && c.nodeName(a, "button")) return L.set(a, b, d);
                    a.value = b
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            "for": "htmlFor",
            "class": "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function(a, b, d) {
            var e = a.nodeType;
            if (!a || 3 === e || 8 === e || 2 === e) return p;
            var f, g;
            1 === e && c.isXMLDoc(a) || (b = c.propFix[b] ||
                b, g = c.propHooks[b]);
            return d !== p ? g && "set" in g && (f = g.set(a, d, b)) !== p ? f : a[b] = d : g && "get" in g && (f = g.get(a, b)) !== p ? f : a[b]
        },
        propHooks: {}
    });
    Qa = {
        get: function(a, b) {
            return c.prop(a, b) ? b.toLowerCase() : p
        },
        set: function(a, b, d) {
            !1 === b ? c.removeAttr(a, d) : (b = c.propFix[d] || d, b in a && (a[b] = !0), a.setAttribute(d, d.toLowerCase()));
            return d
        }
    };
    c.support.getSetAttribute || (c.attrFix = c.propFix, L = c.attrHooks.name = c.attrHooks.title = c.valHooks.button = {
        get: function(a, b) {
            var c;
            return (c = a.getAttributeNode(b)) && "" !== c.nodeValue ? c.nodeValue :
                p
        },
        set: function(a, b, c) {
            if (a = a.getAttributeNode(c)) return a.nodeValue = b
        }
    }, c.each(["width", "height"], function(a, b) {
        c.attrHooks[b] = c.extend(c.attrHooks[b], {
            set: function(a, c) {
                if ("" === c) return a.setAttribute(b, "auto"), c
            }
        })
    }));
    c.support.hrefNormalized || c.each(["href", "src", "width", "height"], function(a, b) {
        c.attrHooks[b] = c.extend(c.attrHooks[b], {
            get: function(a) {
                a = a.getAttribute(b, 2);
                return null === a ? p : a
            }
        })
    });
    c.support.style || (c.attrHooks.style = {
        get: function(a) {
            return a.style.cssText.toLowerCase() || p
        },
        set: function(a,
            b) {
            return a.style.cssText = "" + b
        }
    });
    c.support.optSelected || (c.propHooks.selected = c.extend(c.propHooks.selected, {
        get: function(a) {
            if (a = a.parentNode) a.selectedIndex, a.parentNode && a.parentNode.selectedIndex
        }
    }));
    c.support.checkOn || c.each(["radio", "checkbox"], function() {
        c.valHooks[this] = {
            get: function(a) {
                return null === a.getAttribute("value") ? "on" : a.value
            }
        }
    });
    c.each(["radio", "checkbox"], function() {
        c.valHooks[this] = c.extend(c.valHooks[this], {
            set: function(a, b) {
                if (c.isArray(b)) return a.checked = 0 <= c.inArray(c(a).val(),
                    b)
            }
        })
    });
    var ha = /\.(.*)$/,
        qa = /^(?:textarea|input|select)$/i,
        lb = /\./g,
        mb = / /g,
        Db = /[^\w\s.|`]/g,
        Eb = function(a) {
            return a.replace(Db, "\\$&")
        };
    c.event = {
        add: function(a, b, d, e) {
            if (3 !== a.nodeType && 8 !== a.nodeType) {
                if (!1 === d) d = F;
                else if (!d) return;
                var f, g;
                d.handler && (f = d, d = f.handler);
                d.guid || (d.guid = c.guid++);
                if (g = c._data(a)) {
                    var h = g.events,
                        k = g.handle;
                    h || (g.events = h = {});
                    k || (g.handle = k = function(a) {
                        return "undefined" === typeof c || a && c.event.triggered === a.type ? p : c.event.handle.apply(k.elem, arguments)
                    });
                    k.elem = a;
                    b =
                        b.split(" ");
                    for (var l, m = 0, q; l = b[m++];) {
                        g = f ? c.extend({}, f) : {
                            handler: d,
                            data: e
                        }; - 1 < l.indexOf(".") ? (q = l.split("."), l = q.shift(), g.namespace = q.slice(0).sort().join(".")) : (q = [], g.namespace = "");
                        g.type = l;
                        g.guid || (g.guid = d.guid);
                        var n = h[l],
                            r = c.event.special[l] || {};
                        n || (n = h[l] = [], r.setup && !1 !== r.setup.call(a, e, q, k) || (a.addEventListener ? a.addEventListener(l, k, !1) : a.attachEvent && a.attachEvent("on" + l, k)));
                        r.add && (r.add.call(a, g), g.handler.guid || (g.handler.guid = d.guid));
                        n.push(g);
                        c.event.global[l] = !0
                    }
                    a = null
                }
            }
        },
        global: {},
        remove: function(a, b, d, e) {
            if (3 !== a.nodeType && 8 !== a.nodeType) {
                !1 === d && (d = F);
                var f, g, h = 0,
                    k, l, m, q, n, r, u = c.hasData(a) && c._data(a),
                    w = u && u.events;
                if (u && w)
                    if (b && b.type && (d = b.handler, b = b.type), !b || "string" === typeof b && "." === b.charAt(0))
                        for (f in b = b || "", w) c.event.remove(a, f + b);
                    else {
                        for (b = b.split(" "); f = b[h++];)
                            if (q = f, k = 0 > f.indexOf("."), l = [], k || (l = f.split("."), f = l.shift(), m = new RegExp("(^|\\.)" + c.map(l.slice(0).sort(), Eb).join("\\.(?:.*\\.)?") + "(\\.|$)")), n = w[f])
                                if (d) {
                                    q = c.event.special[f] || {};
                                    for (g =
                                        e || 0; g < n.length; g++)
                                        if (r = n[g], d.guid === r.guid) {
                                            if (k || m.test(r.namespace)) null == e && n.splice(g--, 1), q.remove && q.remove.call(a, r);
                                            if (null != e) break
                                        }
                                    if (0 === n.length || null != e && 1 === n.length) q.teardown && !1 !== q.teardown.call(a, l) || c.removeEvent(a, f, u.handle), delete w[f]
                                } else
                                    for (g = 0; g < n.length; g++)
                                        if (r = n[g], k || m.test(r.namespace)) c.event.remove(a, q, r.handler, g), n.splice(g--, 1);
                        if (c.isEmptyObject(w)) {
                            if (b = u.handle) b.elem = null;
                            delete u.events;
                            delete u.handle;
                            c.isEmptyObject(u) && c.removeData(a, p, !0)
                        }
                    }
            }
        },
        customEvent: {
            getData: !0,
            setData: !0,
            changeData: !0
        },
        trigger: function(a, b, d, e) {
            var f = a.type || a,
                g = [],
                h;
            0 <= f.indexOf("!") && (f = f.slice(0, -1), h = !0);
            0 <= f.indexOf(".") && (g = f.split("."), f = g.shift(), g.sort());
            if (d && !c.event.customEvent[f] || c.event.global[f]) {
                a = "object" === typeof a ? a[c.expando] ? a : new c.Event(f, a) : new c.Event(f);
                a.type = f;
                a.exclusive = h;
                a.namespace = g.join(".");
                a.namespace_re = new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.)?") + "(\\.|$)");
                if (e || !d) a.preventDefault(), a.stopPropagation();
                if (!d) c.each(c.cache, function() {
                    var d = this[c.expando];
                    d && d.events && d.events[f] && c.event.trigger(a, b, d.handle.elem)
                });
                else if (3 !== d.nodeType && 8 !== d.nodeType) {
                    a.result = p;
                    a.target = d;
                    b = null != b ? c.makeArray(b) : [];
                    b.unshift(a);
                    g = d;
                    e = 0 > f.indexOf(":") ? "on" + f : "";
                    do h = c._data(g, "handle"), a.currentTarget = g, h && h.apply(g, b), e && c.acceptData(g) && g[e] && !1 === g[e].apply(g, b) && (a.result = !1, a.preventDefault()), g = g.parentNode || g.ownerDocument || g === a.target.ownerDocument && r; while (g && !a.isPropagationStopped());
                    if (!a.isDefaultPrevented()) {
                        var k, g = c.event.special[f] || {};
                        if (!(g._default &&
                                !1 !== g._default.call(d.ownerDocument, a) || "click" === f && c.nodeName(d, "a")) && c.acceptData(d)) {
                            try {
                                e && d[f] && ((k = d[e]) && (d[e] = null), c.event.triggered = f, d[f]())
                            } catch (l) {}
                            k && (d[e] = k);
                            c.event.triggered = p
                        }
                    }
                    return a.result
                }
            }
        },
        handle: function(a) {
            a = c.event.fix(a || r.event);
            var b = ((c._data(this, "events") || {})[a.type] || []).slice(0),
                d = !a.exclusive && !a.namespace,
                e = Array.prototype.slice.call(arguments, 0);
            e[0] = a;
            a.currentTarget = this;
            for (var f = 0, g = b.length; f < g; f++) {
                var h = b[f];
                if (d || a.namespace_re.test(h.namespace))
                    if (a.handler =
                        h.handler, a.data = h.data, a.handleObj = h, h = h.handler.apply(this, e), h !== p && (a.result = h, !1 === h && (a.preventDefault(), a.stopPropagation())), a.isImmediatePropagationStopped()) break
            }
            return a.result
        },
        props: "altKey attrChange attrName bubbles button cancelable charCode clientX clientY ctrlKey currentTarget data detail eventPhase fromElement handler keyCode layerX layerY metaKey newValue offsetX offsetY pageX pageY prevValue relatedNode relatedTarget screenX screenY shiftKey srcElement target toElement view wheelDelta which".split(" "),
        fix: function(a) {
            if (a[c.expando]) return a;
            var b = a;
            a = c.Event(b);
            for (var d = this.props.length, e; d;) e = this.props[--d], a[e] = b[e];
            a.target || (a.target = a.srcElement || n);
            3 === a.target.nodeType && (a.target = a.target.parentNode);
            !a.relatedTarget && a.fromElement && (a.relatedTarget = a.fromElement === a.target ? a.toElement : a.fromElement);
            null == a.pageX && null != a.clientX && (d = a.target.ownerDocument || n, b = d.documentElement, d = d.body, a.pageX = a.clientX + (b && b.scrollLeft || d && d.scrollLeft || 0) - (b && b.clientLeft || d && d.clientLeft || 0), a.pageY =
                a.clientY + (b && b.scrollTop || d && d.scrollTop || 0) - (b && b.clientTop || d && d.clientTop || 0));
            null != a.which || null == a.charCode && null == a.keyCode || (a.which = null != a.charCode ? a.charCode : a.keyCode);
            !a.metaKey && a.ctrlKey && (a.metaKey = a.ctrlKey);
            a.which || a.button === p || (a.which = a.button & 1 ? 1 : a.button & 2 ? 3 : a.button & 4 ? 2 : 0);
            return a
        },
        guid: 1E8,
        proxy: c.proxy,
        special: {
            ready: {
                setup: c.bindReady,
                teardown: c.noop
            },
            live: {
                add: function(a) {
                    c.event.add(this, Z(a.origType, a.selector), c.extend({}, a, {
                        handler: kb,
                        guid: a.handler.guid
                    }))
                },
                remove: function(a) {
                    c.event.remove(this,
                        Z(a.origType, a.selector), a)
                }
            },
            beforeunload: {
                setup: function(a, b, d) {
                    c.isWindow(this) && (this.onbeforeunload = d)
                },
                teardown: function(a, b) {
                    this.onbeforeunload === b && (this.onbeforeunload = null)
                }
            }
        }
    };
    c.removeEvent = n.removeEventListener ? function(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    } : function(a, b, c) {
        a.detachEvent && a.detachEvent("on" + b, c)
    };
    c.Event = function(a, b) {
        if (!this.preventDefault) return new c.Event(a, b);
        a && a.type ? (this.originalEvent = a, this.type = a.type, this.isDefaultPrevented = a.defaultPrevented ||
            !1 === a.returnValue || a.getPreventDefault && a.getPreventDefault() ? Y : F) : this.type = a;
        b && c.extend(this, b);
        this.timeStamp = c.now();
        this[c.expando] = !0
    };
    c.Event.prototype = {
        preventDefault: function() {
            this.isDefaultPrevented = Y;
            var a = this.originalEvent;
            a && (a.preventDefault ? a.preventDefault() : a.returnValue = !1)
        },
        stopPropagation: function() {
            this.isPropagationStopped = Y;
            var a = this.originalEvent;
            a && (a.stopPropagation && a.stopPropagation(), a.cancelBubble = !0)
        },
        stopImmediatePropagation: function() {
            this.isImmediatePropagationStopped =
                Y;
            this.stopPropagation()
        },
        isDefaultPrevented: F,
        isPropagationStopped: F,
        isImmediatePropagationStopped: F
    };
    var Ra = function(a) {
            var b = a.relatedTarget,
                d = !1,
                e = a.type;
            a.type = a.data;
            b !== this && (b && (d = c.contains(this, b)), d || (c.event.handle.apply(this, arguments), a.type = e))
        },
        Sa = function(a) {
            a.type = a.data;
            c.event.handle.apply(this, arguments)
        };
    c.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function(a, b) {
        c.event.special[a] = {
            setup: function(d) {
                c.event.add(this, b, d && d.selector ? Sa : Ra, a)
            },
            teardown: function(a) {
                c.event.remove(this,
                    b, a && a.selector ? Sa : Ra)
            }
        }
    });
    c.support.submitBubbles || (c.event.special.submit = {
        setup: function(a, b) {
            if (c.nodeName(this, "form")) return !1;
            c.event.add(this, "click.specialSubmit", function(a) {
                var b = a.target,
                    f = b.type;
                "submit" !== f && "image" !== f || !c(b).closest("form").length || xa("submit", this, arguments)
            });
            c.event.add(this, "keypress.specialSubmit", function(a) {
                var b = a.target,
                    f = b.type;
                "text" !== f && "password" !== f || !c(b).closest("form").length || 13 !== a.keyCode || xa("submit", this, arguments)
            })
        },
        teardown: function(a) {
            c.event.remove(this,
                ".specialSubmit")
        }
    });
    if (!c.support.changeBubbles) {
        var T, Ta = function(a) {
                var b = a.type,
                    d = a.value;
                "radio" === b || "checkbox" === b ? d = a.checked : "select-multiple" === b ? d = -1 < a.selectedIndex ? c.map(a.options, function(a) {
                    return a.selected
                }).join("-") : "" : c.nodeName(a, "select") && (d = a.selectedIndex);
                return d
            },
            ea = function(a, b) {
                var d = a.target,
                    e, f;
                qa.test(d.nodeName) && !d.readOnly && (e = c._data(d, "_change_data"), f = Ta(d), "focusout" === a.type && "radio" === d.type || c._data(d, "_change_data", f), e === p || f === e || null == e && !f || (a.type =
                    "change", a.liveFired = p, c.event.trigger(a, b, d)))
            };
        c.event.special.change = {
            filters: {
                focusout: ea,
                beforedeactivate: ea,
                click: function(a) {
                    var b = a.target,
                        d = c.nodeName(b, "input") ? b.type : "";
                    ("radio" === d || "checkbox" === d || c.nodeName(b, "select")) && ea.call(this, a)
                },
                keydown: function(a) {
                    var b = a.target,
                        d = c.nodeName(b, "input") ? b.type : "";
                    (13 === a.keyCode && !c.nodeName(b, "textarea") || 32 === a.keyCode && ("checkbox" === d || "radio" === d) || "select-multiple" === d) && ea.call(this, a)
                },
                beforeactivate: function(a) {
                    a = a.target;
                    c._data(a,
                        "_change_data", Ta(a))
                }
            },
            setup: function(a, b) {
                if ("file" === this.type) return !1;
                for (var d in T) c.event.add(this, d + ".specialChange", T[d]);
                return qa.test(this.nodeName)
            },
            teardown: function(a) {
                c.event.remove(this, ".specialChange");
                return qa.test(this.nodeName)
            }
        };
        T = c.event.special.change.filters;
        T.focus = T.beforeactivate
    }
    c.support.focusinBubbles || c.each({
        focus: "focusin",
        blur: "focusout"
    }, function(a, b) {
        function d(a) {
            var d = c.event.fix(a);
            d.type = b;
            d.originalEvent = {};
            c.event.trigger(d, null, d.target);
            d.isDefaultPrevented() &&
                a.preventDefault()
        }
        var e = 0;
        c.event.special[b] = {
            setup: function() {
                0 === e++ && n.addEventListener(a, d, !0)
            },
            teardown: function() {
                0 === --e && n.removeEventListener(a, d, !0)
            }
        }
    });
    c.each(["bind", "one"], function(a, b) {
        c.fn[b] = function(a, e, f) {
            var g;
            if ("object" === typeof a) {
                for (var h in a) this[b](h, e, a[h], f);
                return this
            }
            if (2 === arguments.length || !1 === e) f = e, e = p;
            "one" === b ? (g = function(a) {
                c(this).unbind(a, g);
                return f.apply(this, arguments)
            }, g.guid = f.guid || c.guid++) : g = f;
            if ("unload" === a && "one" !== b) this.one(a, e, f);
            else {
                h = 0;
                for (var k =
                        this.length; h < k; h++) c.event.add(this[h], a, g, e)
            }
            return this
        }
    });
    c.fn.extend({
        unbind: function(a, b) {
            if ("object" !== typeof a || a.preventDefault)
                for (var d = 0, e = this.length; d < e; d++) c.event.remove(this[d], a, b);
            else
                for (d in a) this.unbind(d, a[d]);
            return this
        },
        delegate: function(a, b, c, e) {
            return this.live(b, c, e, a)
        },
        undelegate: function(a, b, c) {
            return 0 === arguments.length ? this.unbind("live") : this.die(b, null, c, a)
        },
        trigger: function(a, b) {
            return this.each(function() {
                c.event.trigger(a, b, this)
            })
        },
        triggerHandler: function(a,
            b) {
            if (this[0]) return c.event.trigger(a, b, this[0], !0)
        },
        toggle: function(a) {
            var b = arguments,
                d = a.guid || c.guid++,
                e = 0,
                f = function(d) {
                    var f = (c.data(this, "lastToggle" + a.guid) || 0) % e;
                    c.data(this, "lastToggle" + a.guid, f + 1);
                    d.preventDefault();
                    return b[f].apply(this, arguments) || !1
                };
            for (f.guid = d; e < b.length;) b[e++].guid = d;
            return this.click(f)
        },
        hover: function(a, b) {
            return this.mouseenter(a).mouseleave(b || a)
        }
    });
    var ra = {
        focus: "focusin",
        blur: "focusout",
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    };
    c.each(["live", "die"],
        function(a, b) {
            c.fn[b] = function(a, e, f, g) {
                var h = 0,
                    k, l, m = g || this.selector,
                    q = g ? this : c(this.context);
                if ("object" === typeof a && !a.preventDefault) {
                    for (k in a) q[b](k, e, a[k], m);
                    return this
                }
                if ("die" === b && !a && g && "." === g.charAt(0)) return q.unbind(g), this;
                if (!1 === e || c.isFunction(e)) f = e || F, e = p;
                for (a = (a || "").split(" "); null != (g = a[h++]);)
                    if (k = ha.exec(g), l = "", k && (l = k[0], g = g.replace(ha, "")), "hover" === g) a.push("mouseenter" + l, "mouseleave" + l);
                    else if (k = g, ra[g] ? (a.push(ra[g] + l), g += l) : g = (ra[g] || g) + l, "live" === b) {
                    l = 0;
                    for (var n =
                            q.length; l < n; l++) c.event.add(q[l], "live." + Z(g, m), {
                        data: e,
                        selector: m,
                        handler: f,
                        origType: g,
                        origHandler: f,
                        preType: k
                    })
                } else q.unbind("live." + Z(g, m), f);
                return this
            }
        });
    c.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error".split(" "), function(a, b) {
        c.fn[b] = function(a, c) {
            null == c && (c = a, a = null);
            return 0 < arguments.length ? this.bind(b, a, c) : this.trigger(b)
        };
        c.attrFn && (c.attrFn[b] = !0)
    });
    (function() {
        function a(a, b, c, d, e, f) {
            e = 0;
            for (var g = d.length; e < g; e++) {
                var h = d[e];
                if (h) {
                    for (var k = !1, h = h[a]; h;) {
                        if (h.sizcache === c) {
                            k = d[h.sizset];
                            break
                        }
                        1 !== h.nodeType || f || (h.sizcache = c, h.sizset = e);
                        if (h.nodeName.toLowerCase() === b) {
                            k = h;
                            break
                        }
                        h = h[a]
                    }
                    d[e] = k
                }
            }
        }

        function b(a, b, c, d, e, f) {
            e = 0;
            for (var g = d.length; e < g; e++) {
                var h = d[e];
                if (h) {
                    for (var k = !1, h = h[a]; h;) {
                        if (h.sizcache === c) {
                            k = d[h.sizset];
                            break
                        }
                        if (1 === h.nodeType)
                            if (f || (h.sizcache = c, h.sizset = e), "string" !== typeof b) {
                                if (h === b) {
                                    k = !0;
                                    break
                                }
                            } else if (0 < m.filter(b, [h]).length) {
                            k = h;
                            break
                        }
                        h = h[a]
                    }
                    d[e] = k
                }
            }
        }
        var d = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
            e = 0,
            f = Object.prototype.toString,
            g = !1,
            h = !0,
            k = /\\/g,
            l = /\W/;
        [0, 0].sort(function() {
            h = !1;
            return 0
        });
        var m = function(a, b, c, e) {
            c = c || [];
            var g = b = b || n;
            if (1 !== b.nodeType && 9 !== b.nodeType) return [];
            if (!a || "string" !== typeof a) return c;
            var h, k, l, p, u, O = !0,
                S = m.isXML(b),
                v = [],
                y = a;
            do
                if (d.exec(""), h = d.exec(y))
                    if (y = h[3], v.push(h[1]), h[2]) {
                        p = h[3];
                        break
                    }
            while (h);
            if (1 < v.length && r.exec(a))
                if (2 === v.length && q.relative[v[0]]) k = z(v[0] + v[1], b);
                else
                    for (k = q.relative[v[0]] ? [b] : m(v.shift(), b); v.length;) a = v.shift(), q.relative[a] && (a += v.shift()), k = z(a, k);
            else if (!e && 1 < v.length && 9 === b.nodeType && !S && q.match.ID.test(v[0]) && !q.match.ID.test(v[v.length - 1]) && (h = m.find(v.shift(), b, S), b = h.expr ? m.filter(h.expr, h.set)[0] : h.set[0]), b)
                for (h = e ? {
                        expr: v.pop(),
                        set: w(e)
                    } : m.find(v.pop(), 1 !== v.length || "~" !== v[0] && "+" !== v[0] || !b.parentNode ? b : b.parentNode, S), k = h.expr ? m.filter(h.expr,
                        h.set) : h.set, 0 < v.length ? l = w(k) : O = !1; v.length;) h = u = v.pop(), q.relative[u] ? h = v.pop() : u = "", null == h && (h = b), q.relative[u](l, h, S);
            else l = [];
            l || (l = k);
            l || m.error(u || a);
            if ("[object Array]" === f.call(l))
                if (O)
                    if (b && 1 === b.nodeType)
                        for (a = 0; null != l[a]; a++) l[a] && (!0 === l[a] || 1 === l[a].nodeType && m.contains(b, l[a])) && c.push(k[a]);
                    else
                        for (a = 0; null != l[a]; a++) l[a] && 1 === l[a].nodeType && c.push(k[a]);
            else c.push.apply(c, l);
            else w(l, c);
            p && (m(p, g, c, e), m.uniqueSort(c));
            return c
        };
        m.uniqueSort = function(a) {
            if (y && (g = h, a.sort(y), g))
                for (var b =
                        1; b < a.length; b++) a[b] === a[b - 1] && a.splice(b--, 1);
            return a
        };
        m.matches = function(a, b) {
            return m(a, null, null, b)
        };
        m.matchesSelector = function(a, b) {
            return 0 < m(b, null, null, [a]).length
        };
        m.find = function(a, b, c) {
            var d;
            if (!a) return [];
            for (var e = 0, f = q.order.length; e < f; e++) {
                var g, h = q.order[e];
                if (g = q.leftMatch[h].exec(a)) {
                    var l = g[1];
                    g.splice(1, 1);
                    if ("\\" !== l.substr(l.length - 1) && (g[1] = (g[1] || "").replace(k, ""), d = q.find[h](g, b, c), null != d)) {
                        a = a.replace(q.match[h], "");
                        break
                    }
                }
            }
            d || (d = "undefined" !== typeof b.getElementsByTagName ?
                b.getElementsByTagName("*") : []);
            return {
                set: d,
                expr: a
            }
        };
        m.filter = function(a, b, c, d) {
            for (var e, f, g = a, h = [], k = b, l = b && b[0] && m.isXML(b[0]); a && b.length;) {
                for (var n in q.filter)
                    if (null != (e = q.leftMatch[n].exec(a)) && e[2]) {
                        var r, v, u = q.filter[n];
                        v = e[1];
                        f = !1;
                        e.splice(1, 1);
                        if ("\\" !== v.substr(v.length - 1)) {
                            k === h && (h = []);
                            if (q.preFilter[n])
                                if (e = q.preFilter[n](e, k, c, h, d, l), !e) f = r = !0;
                                else if (!0 === e) continue;
                            if (e)
                                for (var w = 0; null != (v = k[w]); w++)
                                    if (v) {
                                        r = u(v, e, w, k);
                                        var O = d ^ !!r;
                                        c && null != r ? O ? f = !0 : k[w] = !1 : O && (h.push(v), f = !0)
                                    }
                            if (r !==
                                p) {
                                c || (k = h);
                                a = a.replace(q.match[n], "");
                                if (!f) return [];
                                break
                            }
                        }
                    }
                if (a === g)
                    if (null == f) m.error(a);
                    else break;
                g = a
            }
            return k
        };
        m.error = function(a) {
            throw "Syntax error, unrecognized expression: " + a;
        };
        var q = m.selectors = {
                order: ["ID", "NAME", "TAG"],
                match: {
                    ID: /#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                    CLASS: /\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                    NAME: /\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,
                    ATTR: /\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,
                    TAG: /^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,
                    CHILD: /:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,
                    POS: /:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,
                    PSEUDO: /:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/
                },
                leftMatch: {},
                attrMap: {
                    "class": "className",
                    "for": "htmlFor"
                },
                attrHandle: {
                    href: function(a) {
                        return a.getAttribute("href")
                    },
                    type: function(a) {
                        return a.getAttribute("type")
                    }
                },
                relative: {
                    "+": function(a, b) {
                        var c = "string" === typeof b,
                            d = c && !l.test(b),
                            c = c && !d;
                        d && (b = b.toLowerCase());
                        for (var d = 0, e = a.length, f; d < e; d++)
                            if (f = a[d]) {
                                for (;
                                    (f = f.previousSibling) && 1 !== f.nodeType;);
                                a[d] = c || f && f.nodeName.toLowerCase() === b ? f || !1 : f === b
                            }
                        c && m.filter(b, a, !0)
                    },
                    ">": function(a, b) {
                        var c, d = "string" === typeof b,
                            e = 0,
                            f = a.length;
                        if (d && !l.test(b))
                            for (b = b.toLowerCase(); e < f; e++) {
                                if (c = a[e]) c = c.parentNode, a[e] = c.nodeName.toLowerCase() === b ? c : !1
                            } else {
                                for (; e < f; e++)(c = a[e]) && (a[e] = d ? c.parentNode : c.parentNode === b);
                                d && m.filter(b, a, !0)
                            }
                    },
                    "": function(c, d, f) {
                        var g, h = e++,
                            k = b;
                        "string" !==
                        typeof d || l.test(d) || (g = d = d.toLowerCase(), k = a);
                        k("parentNode", d, h, c, g, f)
                    },
                    "~": function(c, d, f) {
                        var g, h = e++,
                            k = b;
                        "string" !== typeof d || l.test(d) || (g = d = d.toLowerCase(), k = a);
                        k("previousSibling", d, h, c, g, f)
                    }
                },
                find: {
                    ID: function(a, b, c) {
                        if ("undefined" !== typeof b.getElementById && !c) return (a = b.getElementById(a[1])) && a.parentNode ? [a] : []
                    },
                    NAME: function(a, b) {
                        if ("undefined" !== typeof b.getElementsByName) {
                            for (var c = [], d = b.getElementsByName(a[1]), e = 0, f = d.length; e < f; e++) d[e].getAttribute("name") === a[1] && c.push(d[e]);
                            return 0 === c.length ? null : c
                        }
                    },
                    TAG: function(a, b) {
                        if ("undefined" !== typeof b.getElementsByTagName) return b.getElementsByTagName(a[1])
                    }
                },
                preFilter: {
                    CLASS: function(a, b, c, d, e, f) {
                        a = " " + a[1].replace(k, "") + " ";
                        if (f) return a;
                        f = 0;
                        for (var g; null != (g = b[f]); f++) g && (e ^ (g.className && 0 <= (" " + g.className + " ").replace(/[\t\n\r]/g, " ").indexOf(a)) ? c || d.push(g) : c && (b[f] = !1));
                        return !1
                    },
                    ID: function(a) {
                        return a[1].replace(k, "")
                    },
                    TAG: function(a, b) {
                        return a[1].replace(k, "").toLowerCase()
                    },
                    CHILD: function(a) {
                        if ("nth" === a[1]) {
                            a[2] ||
                                m.error(a[0]);
                            a[2] = a[2].replace(/^\+|\s*/g, "");
                            var b = /(-?)(\d*)(?:n([+\-]?\d*))?/.exec("even" === a[2] && "2n" || "odd" === a[2] && "2n+1" || !/\D/.test(a[2]) && "0n+" + a[2] || a[2]);
                            a[2] = b[1] + (b[2] || 1) - 0;
                            a[3] = b[3] - 0
                        } else a[2] && m.error(a[0]);
                        a[0] = e++;
                        return a
                    },
                    ATTR: function(a, b, c, d, e, f) {
                        b = a[1] = a[1].replace(k, "");
                        !f && q.attrMap[b] && (a[1] = q.attrMap[b]);
                        a[4] = (a[4] || a[5] || "").replace(k, "");
                        "~=" === a[2] && (a[4] = " " + a[4] + " ");
                        return a
                    },
                    PSEUDO: function(a, b, c, e, f) {
                        if ("not" === a[1])
                            if (1 < (d.exec(a[3]) || "").length || /^\w/.test(a[3])) a[3] =
                                m(a[3], null, null, b);
                            else return a = m.filter(a[3], b, c, 1 ^ f), c || e.push.apply(e, a), !1;
                        else if (q.match.POS.test(a[0]) || q.match.CHILD.test(a[0])) return !0;
                        return a
                    },
                    POS: function(a) {
                        a.unshift(!0);
                        return a
                    }
                },
                filters: {
                    enabled: function(a) {
                        return !1 === a.disabled && "hidden" !== a.type
                    },
                    disabled: function(a) {
                        return !0 === a.disabled
                    },
                    checked: function(a) {
                        return !0 === a.checked
                    },
                    selected: function(a) {
                        a.parentNode && a.parentNode.selectedIndex;
                        return !0 === a.selected
                    },
                    parent: function(a) {
                        return !!a.firstChild
                    },
                    empty: function(a) {
                        return !a.firstChild
                    },
                    has: function(a, b, c) {
                        return !!m(c[3], a).length
                    },
                    header: function(a) {
                        return /h\d/i.test(a.nodeName)
                    },
                    text: function(a) {
                        var b = a.getAttribute("type"),
                            c = a.type;
                        return "input" === a.nodeName.toLowerCase() && "text" === c && (b === c || null === b)
                    },
                    radio: function(a) {
                        return "input" === a.nodeName.toLowerCase() && "radio" === a.type
                    },
                    checkbox: function(a) {
                        return "input" === a.nodeName.toLowerCase() && "checkbox" === a.type
                    },
                    file: function(a) {
                        return "input" === a.nodeName.toLowerCase() && "file" === a.type
                    },
                    password: function(a) {
                        return "input" === a.nodeName.toLowerCase() &&
                            "password" === a.type
                    },
                    submit: function(a) {
                        var b = a.nodeName.toLowerCase();
                        return ("input" === b || "button" === b) && "submit" === a.type
                    },
                    image: function(a) {
                        return "input" === a.nodeName.toLowerCase() && "image" === a.type
                    },
                    reset: function(a) {
                        var b = a.nodeName.toLowerCase();
                        return ("input" === b || "button" === b) && "reset" === a.type
                    },
                    button: function(a) {
                        var b = a.nodeName.toLowerCase();
                        return "input" === b && "button" === a.type || "button" === b
                    },
                    input: function(a) {
                        return /input|select|textarea|button/i.test(a.nodeName)
                    },
                    focus: function(a) {
                        return a ===
                            a.ownerDocument.activeElement
                    }
                },
                setFilters: {
                    first: function(a, b) {
                        return 0 === b
                    },
                    last: function(a, b, c, d) {
                        return b === d.length - 1
                    },
                    even: function(a, b) {
                        return 0 === b % 2
                    },
                    odd: function(a, b) {
                        return 1 === b % 2
                    },
                    lt: function(a, b, c) {
                        return b < c[3] - 0
                    },
                    gt: function(a, b, c) {
                        return b > c[3] - 0
                    },
                    nth: function(a, b, c) {
                        return c[3] - 0 === b
                    },
                    eq: function(a, b, c) {
                        return c[3] - 0 === b
                    }
                },
                filter: {
                    PSEUDO: function(a, b, c, d) {
                        var e = b[1],
                            f = q.filters[e];
                        if (f) return f(a, c, b, d);
                        if ("contains" === e) return 0 <= (a.textContent || a.innerText || m.getText([a]) || "").indexOf(b[3]);
                        if ("not" === e) {
                            b = b[3];
                            c = 0;
                            for (d = b.length; c < d; c++)
                                if (b[c] === a) return !1;
                            return !0
                        }
                        m.error(e)
                    },
                    CHILD: function(a, b) {
                        var c = b[1],
                            d = a;
                        switch (c) {
                            case "only":
                            case "first":
                                for (; d = d.previousSibling;)
                                    if (1 === d.nodeType) return !1;
                                if ("first" === c) return !0;
                                d = a;
                            case "last":
                                for (; d = d.nextSibling;)
                                    if (1 === d.nodeType) return !1;
                                return !0;
                            case "nth":
                                var c = b[2],
                                    e = b[3];
                                if (1 === c && 0 === e) return !0;
                                var f = b[0],
                                    g = a.parentNode;
                                if (g && (g.sizcache !== f || !a.nodeIndex)) {
                                    for (var h = 0, d = g.firstChild; d; d = d.nextSibling) 1 === d.nodeType && (d.nodeIndex =
                                        ++h);
                                    g.sizcache = f
                                }
                                d = a.nodeIndex - e;
                                return 0 === c ? 0 === d : 0 === d % c && 0 <= d / c
                        }
                    },
                    ID: function(a, b) {
                        return 1 === a.nodeType && a.getAttribute("id") === b
                    },
                    TAG: function(a, b) {
                        return "*" === b && 1 === a.nodeType || a.nodeName.toLowerCase() === b
                    },
                    CLASS: function(a, b) {
                        return -1 < (" " + (a.className || a.getAttribute("class")) + " ").indexOf(b)
                    },
                    ATTR: function(a, b) {
                        var c = b[1],
                            c = q.attrHandle[c] ? q.attrHandle[c](a) : null != a[c] ? a[c] : a.getAttribute(c),
                            d = c + "",
                            e = b[2],
                            f = b[4];
                        return null == c ? "!=" === e : "=" === e ? d === f : "*=" === e ? 0 <= d.indexOf(f) : "~=" === e ? 0 <=
                            (" " + d + " ").indexOf(f) : f ? "!=" === e ? d !== f : "^=" === e ? 0 === d.indexOf(f) : "$=" === e ? d.substr(d.length - f.length) === f : "|=" === e ? d === f || d.substr(0, f.length + 1) === f + "-" : !1 : d && !1 !== c
                    },
                    POS: function(a, b, c, d) {
                        var e = q.setFilters[b[2]];
                        if (e) return e(a, c, b, d)
                    }
                }
            },
            r = q.match.POS,
            O = function(a, b) {
                return "\\" + (b - 0 + 1)
            },
            u;
        for (u in q.match) q.match[u] = new RegExp(q.match[u].source + /(?![^\[]*\])(?![^\(]*\))/.source), q.leftMatch[u] = new RegExp(/(^(?:.|\r|\n)*?)/.source + q.match[u].source.replace(/\\(\d+)/g, O));
        var w = function(a, b) {
            a = Array.prototype.slice.call(a,
                0);
            return b ? (b.push.apply(b, a), b) : a
        };
        try {
            Array.prototype.slice.call(n.documentElement.childNodes, 0)[0].nodeType
        } catch (A) {
            w = function(a, b) {
                var c = 0,
                    d = b || [];
                if ("[object Array]" === f.call(a)) Array.prototype.push.apply(d, a);
                else if ("number" === typeof a.length)
                    for (var e = a.length; c < e; c++) d.push(a[c]);
                else
                    for (; a[c]; c++) d.push(a[c]);
                return d
            }
        }
        var y, C;
        n.documentElement.compareDocumentPosition ? y = function(a, b) {
            return a === b ? (g = !0, 0) : a.compareDocumentPosition && b.compareDocumentPosition ? a.compareDocumentPosition(b) &
                4 ? -1 : 1 : a.compareDocumentPosition ? -1 : 1
        } : (y = function(a, b) {
            if (a === b) return g = !0, 0;
            if (a.sourceIndex && b.sourceIndex) return a.sourceIndex - b.sourceIndex;
            var c, d, e = [],
                f = [];
            c = a.parentNode;
            d = b.parentNode;
            var h = c;
            if (c === d) return C(a, b);
            if (!c) return -1;
            if (!d) return 1;
            for (; h;) e.unshift(h), h = h.parentNode;
            for (h = d; h;) f.unshift(h), h = h.parentNode;
            c = e.length;
            d = f.length;
            for (h = 0; h < c && h < d; h++)
                if (e[h] !== f[h]) return C(e[h], f[h]);
            return h === c ? C(a, f[h], -1) : C(e[h], b, 1)
        }, C = function(a, b, c) {
            if (a === b) return c;
            for (a = a.nextSibling; a;) {
                if (a ===
                    b) return -1;
                a = a.nextSibling
            }
            return 1
        });
        m.getText = function(a) {
            for (var b = "", c, d = 0; a[d]; d++) c = a[d], 3 === c.nodeType || 4 === c.nodeType ? b += c.nodeValue : 8 !== c.nodeType && (b += m.getText(c.childNodes));
            return b
        };
        (function() {
            var a = n.createElement("div"),
                b = "script" + (new Date).getTime(),
                c = n.documentElement;
            a.innerHTML = "<a name='" + b + "'/>";
            c.insertBefore(a, c.firstChild);
            n.getElementById(b) && (q.find.ID = function(a, b, c) {
                if ("undefined" !== typeof b.getElementById && !c) return (b = b.getElementById(a[1])) ? b.id === a[1] || "undefined" !==
                    typeof b.getAttributeNode && b.getAttributeNode("id").nodeValue === a[1] ? [b] : p : []
            }, q.filter.ID = function(a, b) {
                var c = "undefined" !== typeof a.getAttributeNode && a.getAttributeNode("id");
                return 1 === a.nodeType && c && c.nodeValue === b
            });
            c.removeChild(a);
            c = a = null
        })();
        (function() {
            var a = n.createElement("div");
            a.appendChild(n.createComment(""));
            0 < a.getElementsByTagName("*").length && (q.find.TAG = function(a, b) {
                var c = b.getElementsByTagName(a[1]);
                if ("*" === a[1]) {
                    for (var d = [], e = 0; c[e]; e++) 1 === c[e].nodeType && d.push(c[e]);
                    c =
                        d
                }
                return c
            });
            a.innerHTML = "<a href='#'></a>";
            a.firstChild && "undefined" !== typeof a.firstChild.getAttribute && "#" !== a.firstChild.getAttribute("href") && (q.attrHandle.href = function(a) {
                return a.getAttribute("href", 2)
            });
            a = null
        })();
        n.querySelectorAll && function() {
            var a = m,
                b = n.createElement("div");
            b.innerHTML = "<p class='TEST'></p>";
            if (!b.querySelectorAll || 0 !== b.querySelectorAll(".TEST").length) {
                m = function(b, c, d, e) {
                    c = c || n;
                    if (!e && !m.isXML(c)) {
                        var f = /^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(b);
                        if (f && (1 === c.nodeType ||
                                9 === c.nodeType)) {
                            if (f[1]) return w(c.getElementsByTagName(b), d);
                            if (f[2] && q.find.CLASS && c.getElementsByClassName) return w(c.getElementsByClassName(f[2]), d)
                        }
                        if (9 === c.nodeType) {
                            if ("body" === b && c.body) return w([c.body], d);
                            if (f && f[3]) {
                                var g = c.getElementById(f[3]);
                                if (g && g.parentNode) {
                                    if (g.id === f[3]) return w([g], d)
                                } else return w([], d)
                            }
                            try {
                                return w(c.querySelectorAll(b), d)
                            } catch (h) {}
                        } else if (1 === c.nodeType && "object" !== c.nodeName.toLowerCase()) {
                            var f = c,
                                k = (g = c.getAttribute("id")) || "__sizzle__",
                                l = c.parentNode,
                                p = /^\s*[+~]/.test(b);
                            g ? k = k.replace(/'/g, "\\$&") : c.setAttribute("id", k);
                            p && l && (c = c.parentNode);
                            try {
                                if (!p || l) return w(c.querySelectorAll("[id='" + k + "'] " + b), d)
                            } catch (r) {} finally {
                                g || f.removeAttribute("id")
                            }
                        }
                    }
                    return a(b, c, d, e)
                };
                for (var c in a) m[c] = a[c];
                b = null
            }
        }();
        (function() {
            var a = n.documentElement,
                b = a.matchesSelector || a.mozMatchesSelector || a.webkitMatchesSelector || a.msMatchesSelector;
            if (b) {
                var c = !b.call(n.createElement("div"), "div"),
                    d = !1;
                try {
                    b.call(n.documentElement, "[test!='']:sizzle")
                } catch (e) {
                    d = !0
                }
                m.matchesSelector =
                    function(a, e) {
                        e = e.replace(/\=\s*([^'"\]]*)\s*\]/g, "='$1']");
                        if (!m.isXML(a)) try {
                            if (d || !q.match.PSEUDO.test(e) && !/!=/.test(e)) {
                                var f = b.call(a, e);
                                if (f || !c || a.document && 11 !== a.document.nodeType) return f
                            }
                        } catch (g) {}
                        return 0 < m(e, null, null, [a]).length
                    }
            }
        })();
        (function() {
            var a = n.createElement("div");
            a.innerHTML = "<div class='test e'></div><div class='test'></div>";
            a.getElementsByClassName && 0 !== a.getElementsByClassName("e").length && (a.lastChild.className = "e", 1 !== a.getElementsByClassName("e").length && (q.order.splice(1,
                0, "CLASS"), q.find.CLASS = function(a, b, c) {
                if ("undefined" !== typeof b.getElementsByClassName && !c) return b.getElementsByClassName(a[1])
            }, a = null))
        })();
        m.contains = n.documentElement.contains ? function(a, b) {
            return a !== b && (a.contains ? a.contains(b) : !0)
        } : n.documentElement.compareDocumentPosition ? function(a, b) {
            return !!(a.compareDocumentPosition(b) & 16)
        } : function() {
            return !1
        };
        m.isXML = function(a) {
            return (a = (a ? a.ownerDocument || a : 0).documentElement) ? "HTML" !== a.nodeName : !1
        };
        var z = function(a, b) {
            for (var c, d = [], e = "", f = b.nodeType ? [b] : b; c = q.match.PSEUDO.exec(a);) e += c[0], a = a.replace(q.match.PSEUDO, "");
            a = q.relative[a] ? a + "*" : a;
            c = 0;
            for (var g = f.length; c < g; c++) m(a, f[c], d);
            return m.filter(e, d)
        };
        c.find = m;
        c.expr = m.selectors;
        c.expr[":"] = c.expr.filters;
        c.unique = m.uniqueSort;
        c.text = m.getText;
        c.isXMLDoc = m.isXML;
        c.contains = m.contains
    })();
    var Fb = /Until$/,
        Gb = /^(?:parents|prevUntil|prevAll)/,
        Hb = /,/,
        nb = /^.[^:#\[\.,]*$/,
        Ib = Array.prototype.slice,
        Ua = c.expr.match.POS,
        Jb = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    c.fn.extend({
        find: function(a) {
            var b =
                this,
                d, e;
            if ("string" !== typeof a) return c(a).filter(function() {
                d = 0;
                for (e = b.length; d < e; d++)
                    if (c.contains(b[d], this)) return !0
            });
            var f = this.pushStack("", "find", a),
                g, h, k;
            d = 0;
            for (e = this.length; d < e; d++)
                if (g = f.length, c.find(a, this[d], f), 0 < d)
                    for (h = g; h < f.length; h++)
                        for (k = 0; k < g; k++)
                            if (f[k] === f[h]) {
                                f.splice(h--, 1);
                                break
                            }
            return f
        },
        has: function(a) {
            var b = c(a);
            return this.filter(function() {
                for (var a = 0, e = b.length; a < e; a++)
                    if (c.contains(this, b[a])) return !0
            })
        },
        not: function(a) {
            return this.pushStack(za(this, a, !1), "not",
                a)
        },
        filter: function(a) {
            return this.pushStack(za(this, a, !0), "filter", a)
        },
        is: function(a) {
            return !!a && ("string" === typeof a ? 0 < c.filter(a, this).length : 0 < this.filter(a).length)
        },
        closest: function(a, b) {
            var d = [],
                e, f, g = this[0];
            if (c.isArray(a)) {
                var h, k = {},
                    l = 1;
                if (g && a.length) {
                    e = 0;
                    for (f = a.length; e < f; e++) h = a[e], k[h] || (k[h] = Ua.test(h) ? c(h, b || this.context) : h);
                    for (; g && g.ownerDocument && g !== b;) {
                        for (h in k) e = k[h], (e.jquery ? -1 < e.index(g) : c(g).is(e)) && d.push({
                            selector: h,
                            elem: g,
                            level: l
                        });
                        g = g.parentNode;
                        l++
                    }
                }
                return d
            }
            h = Ua.test(a) ||
                "string" !== typeof a ? c(a, b || this.context) : 0;
            e = 0;
            for (f = this.length; e < f; e++)
                for (g = this[e]; g;)
                    if (h ? -1 < h.index(g) : c.find.matchesSelector(g, a)) {
                        d.push(g);
                        break
                    } else if (g = g.parentNode, !g || !g.ownerDocument || g === b || 11 === g.nodeType) break;
            d = 1 < d.length ? c.unique(d) : d;
            return this.pushStack(d, "closest", a)
        },
        index: function(a) {
            return a && "string" !== typeof a ? c.inArray(a.jquery ? a[0] : a, this) : c.inArray(this[0], a ? c(a) : this.parent().children())
        },
        add: function(a, b) {
            var d = "string" === typeof a ? c(a, b) : c.makeArray(a && a.nodeType ? [a] : a),
                e = c.merge(this.get(), d);
            return this.pushStack(ya(d[0]) || ya(e[0]) ? e : c.unique(e))
        },
        andSelf: function() {
            return this.add(this.prevObject)
        }
    });
    c.each({
        parent: function(a) {
            return (a = a.parentNode) && 11 !== a.nodeType ? a : null
        },
        parents: function(a) {
            return c.dir(a, "parentNode")
        },
        parentsUntil: function(a, b, d) {
            return c.dir(a, "parentNode", d)
        },
        next: function(a) {
            return c.nth(a, 2, "nextSibling")
        },
        prev: function(a) {
            return c.nth(a, 2, "previousSibling")
        },
        nextAll: function(a) {
            return c.dir(a, "nextSibling")
        },
        prevAll: function(a) {
            return c.dir(a,
                "previousSibling")
        },
        nextUntil: function(a, b, d) {
            return c.dir(a, "nextSibling", d)
        },
        prevUntil: function(a, b, d) {
            return c.dir(a, "previousSibling", d)
        },
        siblings: function(a) {
            return c.sibling(a.parentNode.firstChild, a)
        },
        children: function(a) {
            return c.sibling(a.firstChild)
        },
        contents: function(a) {
            return c.nodeName(a, "iframe") ? a.contentDocument || a.contentWindow.document : c.makeArray(a.childNodes)
        }
    }, function(a, b) {
        c.fn[a] = function(d, e) {
            var f = c.map(this, b, d),
                g = Ib.call(arguments);
            Fb.test(a) || (e = d);
            e && "string" === typeof e &&
                (f = c.filter(e, f));
            f = 1 < this.length && !Jb[a] ? c.unique(f) : f;
            (1 < this.length || Hb.test(e)) && Gb.test(a) && (f = f.reverse());
            return this.pushStack(f, a, g.join(","))
        }
    });
    c.extend({
        filter: function(a, b, d) {
            d && (a = ":not(" + a + ")");
            return 1 === b.length ? c.find.matchesSelector(b[0], a) ? [b[0]] : [] : c.find.matches(a, b)
        },
        dir: function(a, b, d) {
            var e = [];
            for (a = a[b]; a && 9 !== a.nodeType && (d === p || 1 !== a.nodeType || !c(a).is(d));) 1 === a.nodeType && e.push(a), a = a[b];
            return e
        },
        nth: function(a, b, c, e) {
            b = b || 1;
            for (e = 0; a && (1 !== a.nodeType || ++e !== b); a = a[c]);
            return a
        },
        sibling: function(a, b) {
            for (var c = []; a; a = a.nextSibling) 1 === a.nodeType && a !== b && c.push(a);
            return c
        }
    });
    var Kb = / jQuery\d+="(?:\d+|null)"/g,
        sa = /^\s+/,
        Va = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,
        Wa = /<([\w:]+)/,
        Lb = /<tbody/i,
        Mb = /<|&#?\w+;/,
        Xa = /<(?:script|object|embed|option|style)/i,
        Ya = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Nb = /\/(java|ecma)script/i,
        qb = /^\s*<!(?:\[CDATA\[|\-\-)/,
        A = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            area: [1, "<map>", "</map>"],
            _default: [0, "", ""]
        };
    A.optgroup = A.option;
    A.tbody = A.tfoot = A.colgroup = A.caption = A.thead;
    A.th = A.td;
    c.support.htmlSerialize || (A._default = [1, "div<div>", "</div>"]);
    c.fn.extend({
        text: function(a) {
            return c.isFunction(a) ? this.each(function(b) {
                    var d = c(this);
                    d.text(a.call(this, b, d.text()))
                }) : "object" !==
                typeof a && a !== p ? this.empty().append((this[0] && this[0].ownerDocument || n).createTextNode(a)) : c.text(this)
        },
        wrapAll: function(a) {
            if (c.isFunction(a)) return this.each(function(b) {
                c(this).wrapAll(a.call(this, b))
            });
            if (this[0]) {
                var b = c(a, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && b.insertBefore(this[0]);
                b.map(function() {
                    for (var a = this; a.firstChild && 1 === a.firstChild.nodeType;) a = a.firstChild;
                    return a
                }).append(this)
            }
            return this
        },
        wrapInner: function(a) {
            return c.isFunction(a) ? this.each(function(b) {
                c(this).wrapInner(a.call(this,
                    b))
            }) : this.each(function() {
                var b = c(this),
                    d = b.contents();
                d.length ? d.wrapAll(a) : b.append(a)
            })
        },
        wrap: function(a) {
            return this.each(function() {
                c(this).wrapAll(a)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                c.nodeName(this, "body") || c(this).replaceWith(this.childNodes)
            }).end()
        },
        append: function() {
            return this.domManip(arguments, !0, function(a) {
                1 === this.nodeType && this.appendChild(a)
            })
        },
        prepend: function() {
            return this.domManip(arguments, !0, function(a) {
                1 === this.nodeType && this.insertBefore(a, this.firstChild)
            })
        },
        before: function() {
            if (this[0] && this[0].parentNode) return this.domManip(arguments, !1, function(a) {
                this.parentNode.insertBefore(a, this)
            });
            if (arguments.length) {
                var a = c(arguments[0]);
                a.push.apply(a, this.toArray());
                return this.pushStack(a, "before", arguments)
            }
        },
        after: function() {
            if (this[0] && this[0].parentNode) return this.domManip(arguments, !1, function(a) {
                this.parentNode.insertBefore(a, this.nextSibling)
            });
            if (arguments.length) {
                var a = this.pushStack(this, "after", arguments);
                a.push.apply(a, c(arguments[0]).toArray());
                return a
            }
        },
        remove: function(a, b) {
            for (var d = 0, e; null != (e = this[d]); d++)
                if (!a || c.filter(a, [e]).length) b || 1 !== e.nodeType || (c.cleanData(e.getElementsByTagName("*")), c.cleanData([e])), e.parentNode && e.parentNode.removeChild(e);
            return this
        },
        empty: function() {
            for (var a = 0, b; null != (b = this[a]); a++)
                for (1 === b.nodeType && c.cleanData(b.getElementsByTagName("*")); b.firstChild;) b.removeChild(b.firstChild);
            return this
        },
        clone: function(a, b) {
            a = null == a ? !1 : a;
            b = null == b ? a : b;
            return this.map(function() {
                return c.clone(this, a, b)
            })
        },
        html: function(a) {
            if (a === p) return this[0] && 1 === this[0].nodeType ? this[0].innerHTML.replace(Kb, "") : null;
            if ("string" !== typeof a || Xa.test(a) || !c.support.leadingWhitespace && sa.test(a) || A[(Wa.exec(a) || ["", ""])[1].toLowerCase()]) c.isFunction(a) ? this.each(function(b) {
                var d = c(this);
                d.html(a.call(this, b, d.html()))
            }) : this.empty().append(a);
            else {
                a = a.replace(Va, "<$1></$2>");
                try {
                    for (var b = 0, d = this.length; b < d; b++) 1 === this[b].nodeType && (c.cleanData(this[b].getElementsByTagName("*")), this[b].innerHTML = a)
                } catch (e) {
                    this.empty().append(a)
                }
            }
            return this
        },
        replaceWith: function(a) {
            if (this[0] && this[0].parentNode) {
                if (c.isFunction(a)) return this.each(function(b) {
                    var d = c(this),
                        e = d.html();
                    d.replaceWith(a.call(this, b, e))
                });
                "string" !== typeof a && (a = c(a).detach());
                return this.each(function() {
                    var b = this.nextSibling,
                        d = this.parentNode;
                    c(this).remove();
                    b ? c(b).before(a) : c(d).append(a)
                })
            }
            return this.length ? this.pushStack(c(c.isFunction(a) ? a() : a), "replaceWith", a) : this
        },
        detach: function(a) {
            return this.remove(a, !0)
        },
        domManip: function(a, b, d) {
            var e, f, g, h = a[0],
                k = [];
            if (!c.support.checkClone &&
                3 === arguments.length && "string" === typeof h && Ya.test(h)) return this.each(function() {
                c(this).domManip(a, b, d, !0)
            });
            if (c.isFunction(h)) return this.each(function(e) {
                var f = c(this);
                a[0] = h.call(this, e, b ? f.html() : p);
                f.domManip(a, b, d)
            });
            if (this[0]) {
                e = h && h.parentNode;
                e = c.support.parentNode && e && 11 === e.nodeType && e.childNodes.length === this.length ? {
                    fragment: e
                } : c.buildFragment(a, this, k);
                g = e.fragment;
                if (f = 1 === g.childNodes.length ? g = g.firstChild : g.firstChild) {
                    b = b && c.nodeName(f, "tr");
                    for (var l = 0, m = this.length, q = m - 1; l <
                        m; l++) d.call(b ? ob(this[l], f) : this[l], e.cacheable || 1 < m && l < q ? c.clone(g, !0, !0) : g)
                }
                k.length && c.each(k, pb)
            }
            return this
        }
    });
    c.buildFragment = function(a, b, d) {
        var e, f, g, h;
        b && b[0] && (h = b[0].ownerDocument || b[0]);
        h.createDocumentFragment || (h = n);
        1 === a.length && "string" === typeof a[0] && 512 > a[0].length && h === n && "<" === a[0].charAt(0) && !Xa.test(a[0]) && (c.support.checkClone || !Ya.test(a[0])) && (f = !0, (g = c.fragments[a[0]]) && 1 !== g && (e = g));
        e || (e = h.createDocumentFragment(), c.clean(a, h, e, d));
        f && (c.fragments[a[0]] = g ? e : 1);
        return {
            fragment: e,
            cacheable: f
        }
    };
    c.fragments = {};
    c.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(a, b) {
        c.fn[a] = function(d) {
            var e = [];
            d = c(d);
            var f = 1 === this.length && this[0].parentNode;
            if (f && 11 === f.nodeType && 1 === f.childNodes.length && 1 === d.length) return d[b](this[0]), this;
            for (var f = 0, g = d.length; f < g; f++) {
                var h = (0 < f ? this.clone(!0) : this).get();
                c(d[f])[b](h);
                e = e.concat(h)
            }
            return this.pushStack(e, a, d.selector)
        }
    });
    c.extend({
        clone: function(a, b, d) {
            var e = a.cloneNode(!0),
                f, g, h;
            if (!(c.support.noCloneEvent && c.support.noCloneChecked || 1 !== a.nodeType && 11 !== a.nodeType || c.isXMLDoc(a)))
                for (Ba(a, e), f = aa(a), g = aa(e), h = 0; f[h]; ++h) Ba(f[h], g[h]);
            if (b && (Aa(a, e), d))
                for (f = aa(a), g = aa(e), h = 0; f[h]; ++h) Aa(f[h], g[h]);
            return e
        },
        clean: function(a, b, d, e) {
            b = b || n;
            "undefined" === typeof b.createElement && (b = b.ownerDocument || b[0] && b[0].ownerDocument || n);
            for (var f = [], g, h = 0, k; null != (k = a[h]); h++)
                if ("number" === typeof k && (k += ""), k) {
                    if ("string" === typeof k)
                        if (Mb.test(k)) {
                            k = k.replace(Va, "<$1></$2>");
                            g = (Wa.exec(k) || ["", ""])[1].toLowerCase();
                            var l = A[g] || A._default,
                                m = l[0],
                                q = b.createElement("div");
                            for (q.innerHTML = l[1] + k + l[2]; m--;) q = q.lastChild;
                            if (!c.support.tbody)
                                for (m = Lb.test(k), l = "table" !== g || m ? "<table>" !== l[1] || m ? [] : q.childNodes : q.firstChild && q.firstChild.childNodes, g = l.length - 1; 0 <= g; --g) c.nodeName(l[g], "tbody") && !l[g].childNodes.length && l[g].parentNode.removeChild(l[g]);
                            !c.support.leadingWhitespace && sa.test(k) && q.insertBefore(b.createTextNode(sa.exec(k)[0]), q.firstChild);
                            k = q.childNodes
                        } else k = b.createTextNode(k);
                    var p;
                    if (!c.support.appendChecked)
                        if (k[0] && "number" === typeof(p = k.length))
                            for (g = 0; g < p; g++) Da(k[g]);
                        else Da(k);
                    k.nodeType ? f.push(k) : f = c.merge(f, k)
                }
            if (d)
                for (a = function(a) {
                        return !a.type || Nb.test(a.type)
                    }, h = 0; f[h]; h++) !e || !c.nodeName(f[h], "script") || f[h].type && "text/javascript" !== f[h].type.toLowerCase() ? (1 === f[h].nodeType && (b = c.grep(f[h].getElementsByTagName("script"), a), f.splice.apply(f, [h + 1, 0].concat(b))), d.appendChild(f[h])) : e.push(f[h].parentNode ? f[h].parentNode.removeChild(f[h]) : f[h]);
            return f
        },
        cleanData: function(a) {
            for (var b,
                    d, e = c.cache, f = c.expando, g = c.event.special, h = c.support.deleteExpando, k = 0, l; null != (l = a[k]); k++)
                if (!l.nodeName || !c.noData[l.nodeName.toLowerCase()])
                    if (d = l[c.expando]) {
                        if ((b = e[d] && e[d][f]) && b.events) {
                            for (var m in b.events) g[m] ? c.event.remove(l, m) : c.removeEvent(l, m, b.handle);
                            b.handle && (b.handle.elem = null)
                        }
                        h ? delete l[c.expando] : l.removeAttribute && l.removeAttribute(c.expando);
                        delete e[d]
                    }
        }
    });
    var Za = /alpha\([^)]*\)/i,
        Ob = /opacity=([^)]*)/,
        Pb = /([A-Z]|^ms)/g,
        $a = /^-?\d+(?:px)?$/i,
        Qb = /^-?\d/,
        Rb = /^[+\-]=/,
        Sb = /[^+\-\.\de]+/g,
        Tb = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        rb = ["Left", "Right"],
        sb = ["Top", "Bottom"],
        J, ab, bb;
    c.fn.css = function(a, b) {
        return 2 === arguments.length && b === p ? this : c.access(this, a, b, !0, function(a, b, f) {
            return f !== p ? c.style(a, b, f) : c.css(a, b)
        })
    };
    c.extend({
        cssHooks: {
            opacity: {
                get: function(a, b) {
                    if (b) {
                        var c = J(a, "opacity", "opacity");
                        return "" === c ? "1" : c
                    }
                    return a.style.opacity
                }
            }
        },
        cssNumber: {
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": c.support.cssFloat ?
                "cssFloat" : "styleFloat"
        },
        style: function(a, b, d, e) {
            if (a && 3 !== a.nodeType && 8 !== a.nodeType && a.style) {
                var f, g = c.camelCase(b),
                    h = a.style,
                    k = c.cssHooks[g];
                b = c.cssProps[g] || g;
                if (d !== p) {
                    if (e = typeof d, !("number" === e && isNaN(d) || null == d || ("string" === e && Rb.test(d) && (d = +d.replace(Sb, "") + parseFloat(c.css(a, b)), e = "number"), "number" !== e || c.cssNumber[g] || (d += "px"), k && "set" in k && (d = k.set(a, d)) === p))) try {
                        h[b] = d
                    } catch (l) {}
                } else return k && "get" in k && (f = k.get(a, !1, e)) !== p ? f : h[b]
            }
        },
        css: function(a, b, d) {
            var e, f;
            b = c.camelCase(b);
            f = c.cssHooks[b];
            b = c.cssProps[b] || b;
            "cssFloat" === b && (b = "float");
            if (f && "get" in f && (e = f.get(a, !0, d)) !== p) return e;
            if (J) return J(a, b)
        },
        swap: function(a, b, c) {
            var e = {},
                f;
            for (f in b) e[f] = a.style[f], a.style[f] = b[f];
            c.call(a);
            for (f in b) a.style[f] = e[f]
        }
    });
    c.curCSS = c.css;
    c.each(["height", "width"], function(a, b) {
        c.cssHooks[b] = {
            get: function(a, e, f) {
                var g;
                if (e) {
                    if (0 !== a.offsetWidth) return Ea(a, b, f);
                    c.swap(a, Tb, function() {
                        g = Ea(a, b, f)
                    });
                    return g
                }
            },
            set: function(a, b) {
                if ($a.test(b)) {
                    if (b = parseFloat(b), 0 <= b) return b + "px"
                } else return b
            }
        }
    });
    c.support.opacity || (c.cssHooks.opacity = {
        get: function(a, b) {
            return Ob.test((b && a.currentStyle ? a.currentStyle.filter : a.style.filter) || "") ? parseFloat(RegExp.$1) / 100 + "" : b ? "1" : ""
        },
        set: function(a, b) {
            var d = a.style,
                e = a.currentStyle;
            d.zoom = 1;
            var f = c.isNaN(b) ? "" : "alpha(opacity=" + 100 * b + ")",
                e = e && e.filter || d.filter || "";
            d.filter = Za.test(e) ? e.replace(Za, f) : e + " " + f
        }
    });
    c(function() {
        c.support.reliableMarginRight || (c.cssHooks.marginRight = {
            get: function(a, b) {
                var d;
                c.swap(a, {
                    display: "inline-block"
                }, function() {
                    d = b ? J(a, "margin-right",
                        "marginRight") : a.style.marginRight
                });
                return d
            }
        })
    });
    n.defaultView && n.defaultView.getComputedStyle && (ab = function(a, b) {
        var d, e;
        b = b.replace(Pb, "-$1").toLowerCase();
        if (!(e = a.ownerDocument.defaultView)) return p;
        if (e = e.getComputedStyle(a, null)) d = e.getPropertyValue(b), "" !== d || c.contains(a.ownerDocument.documentElement, a) || (d = c.style(a, b));
        return d
    });
    n.documentElement.currentStyle && (bb = function(a, b) {
        var c, e = a.currentStyle && a.currentStyle[b],
            f = a.runtimeStyle && a.runtimeStyle[b],
            g = a.style;
        !$a.test(e) && Qb.test(e) &&
            (c = g.left, f && (a.runtimeStyle.left = a.currentStyle.left), g.left = "fontSize" === b ? "1em" : e || 0, e = g.pixelLeft + "px", g.left = c, f && (a.runtimeStyle.left = f));
        return "" === e ? "auto" : e
    });
    J = ab || bb;
    c.expr && c.expr.filters && (c.expr.filters.hidden = function(a) {
        var b = a.offsetHeight;
        return 0 === a.offsetWidth && 0 === b || !c.support.reliableHiddenOffsets && "none" === (a.style.display || c.css(a, "display"))
    }, c.expr.filters.visible = function(a) {
        return !c.expr.filters.hidden(a)
    });
    var Ub = /%20/g,
        tb = /\[\]$/,
        cb = /\r?\n/g,
        Vb = /#.*$/,
        Wb = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg,
        Xb = /^(?:color|date|datetime|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
        Yb = /^(?:GET|HEAD)$/,
        Zb = /^\/\//,
        db = /\?/,
        $b = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
        ac = /^(?:select|textarea)/i,
        Ga = /\s+/,
        bc = /([?&])_=[^&]*/,
        eb = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/,
        fb = c.fn.load,
        ia = {},
        gb = {},
        M, G;
    try {
        M = wb.href
    } catch (hc) {
        M = n.createElement("a"), M.href = "", M = M.href
    }
    G = eb.exec(M.toLowerCase()) || [];
    c.fn.extend({
        load: function(a, b, d) {
            if ("string" !== typeof a && fb) return fb.apply(this,
                arguments);
            if (!this.length) return this;
            var e = a.indexOf(" ");
            if (0 <= e) {
                var f = a.slice(e, a.length);
                a = a.slice(0, e)
            }
            e = "GET";
            b && (c.isFunction(b) ? (d = b, b = p) : "object" === typeof b && (b = c.param(b, c.ajaxSettings.traditional), e = "POST"));
            var g = this;
            c.ajax({
                url: a,
                type: e,
                dataType: "html",
                data: b,
                complete: function(a, b, e) {
                    e = a.responseText;
                    a.isResolved() && (a.done(function(a) {
                        e = a
                    }), g.html(f ? c("<div>").append(e.replace($b, "")).find(f) : e));
                    d && g.each(d, [e, b, a])
                }
            });
            return this
        },
        serialize: function() {
            return c.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                return this.elements ? c.makeArray(this.elements) : this
            }).filter(function() {
                return this.name && !this.disabled && (this.checked || ac.test(this.nodeName) || Xb.test(this.type))
            }).map(function(a, b) {
                var d = c(this).val();
                return null == d ? null : c.isArray(d) ? c.map(d, function(a, c) {
                    return {
                        name: b.name,
                        value: a.replace(cb, "\r\n")
                    }
                }) : {
                    name: b.name,
                    value: d.replace(cb, "\r\n")
                }
            }).get()
        }
    });
    c.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function(a,
        b) {
        c.fn[b] = function(a) {
            return this.bind(b, a)
        }
    });
    c.each(["get", "post"], function(a, b) {
        c[b] = function(a, e, f, g) {
            c.isFunction(e) && (g = g || f, f = e, e = p);
            return c.ajax({
                type: b,
                url: a,
                data: e,
                success: f,
                dataType: g
            })
        }
    });
    c.extend({
        getScript: function(a, b) {
            return c.get(a, p, b, "script")
        },
        getJSON: function(a, b, d) {
            return c.get(a, b, d, "json")
        },
        ajaxSetup: function(a, b) {
            b ? c.extend(!0, a, c.ajaxSettings, b) : (b = a, a = c.extend(!0, c.ajaxSettings, b));
            for (var d in {
                    context: 1,
                    url: 1
                }) d in b ? a[d] = b[d] : d in c.ajaxSettings && (a[d] = c.ajaxSettings[d]);
            return a
        },
        ajaxSettings: {
            url: M,
            isLocal: /^(?:about|app|app\-storage|.+\-extension|file|widget):$/.test(G[1]),
            global: !0,
            type: "GET",
            contentType: "application/x-www-form-urlencoded",
            processData: !0,
            async: !0,
            accepts: {
                xml: "application/xml, text/xml",
                html: "text/html",
                text: "text/plain",
                json: "application/json, text/javascript",
                "*": "*/*"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText"
            },
            converters: {
                "* text": r.String,
                "text html": !0,
                "text json": c.parseJSON,
                "text xml": c.parseXML
            }
        },
        ajaxPrefilter: Fa(ia),
        ajaxTransport: Fa(gb),
        ajax: function(a, b) {
            function d(a, b, d, q) {
                if (2 !== C) {
                    C = 2;
                    A && clearTimeout(A);
                    w = p;
                    r = q || "";
                    t.readyState = a ? 4 : 0;
                    var n, u, x;
                    if (d) {
                        q = e;
                        var y = t,
                            v = q.contents,
                            I = q.dataTypes,
                            F = q.responseFields,
                            E, B, D, L;
                        for (B in F) B in d && (y[F[B]] = d[B]);
                        for (;
                            "*" === I[0];) I.shift(), E === p && (E = q.mimeType || y.getResponseHeader("content-type"));
                        if (E)
                            for (B in v)
                                if (v[B] && v[B].test(E)) {
                                    I.unshift(B);
                                    break
                                }
                        if (I[0] in d) D = I[0];
                        else {
                            for (B in d) {
                                if (!I[0] || q.converters[B + " " + I[0]]) {
                                    D = B;
                                    break
                                }
                                L || (L = B)
                            }
                            D = D ||
                                L
                        }
                        D ? (D !== I[0] && I.unshift(D), d = d[D]) : d = void 0
                    } else d = p;
                    if (200 <= a && 300 > a || 304 === a) {
                        if (e.ifModified) {
                            if (E = t.getResponseHeader("Last-Modified")) c.lastModified[m] = E;
                            if (E = t.getResponseHeader("Etag")) c.etag[m] = E
                        }
                        if (304 === a) b = "notmodified", n = !0;
                        else try {
                            E = e;
                            E.dataFilter && (d = E.dataFilter(d, E.dataType));
                            var M = E.dataTypes;
                            B = {};
                            var G, J, P = M.length,
                                K, Q = M[0],
                                H, N, R, U, W;
                            for (G = 1; G < P; G++) {
                                if (1 === G)
                                    for (J in E.converters) "string" === typeof J && (B[J.toLowerCase()] = E.converters[J]);
                                H = Q;
                                Q = M[G];
                                if ("*" === Q) Q = H;
                                else if ("*" !==
                                    H && H !== Q) {
                                    N = H + " " + Q;
                                    R = B[N] || B["* " + Q];
                                    if (!R)
                                        for (U in W = p, B)
                                            if (K = U.split(" "), K[0] === H || "*" === K[0])
                                                if (W = B[K[1] + " " + Q]) {
                                                    U = B[U];
                                                    !0 === U ? R = W : !0 === W && (R = U);
                                                    break
                                                }
                                    R || W || c.error("No conversion from " + N.replace(" ", " to "));
                                    !0 !== R && (d = R ? R(d) : W(U(d)))
                                }
                            }
                            u = d;
                            b = "success";
                            n = !0
                        } catch (T) {
                            b = "parsererror", x = T
                        }
                    } else if (x = b, !b || a) b = "error", 0 > a && (a = 0);
                    t.status = a;
                    t.statusText = b;
                    n ? h.resolveWith(f, [u, b, t]) : h.rejectWith(f, [t, b, x]);
                    t.statusCode(l);
                    l = p;
                    z && g.trigger("ajax" + (n ? "Success" : "Error"), [t, e, n ? u : x]);
                    k.resolveWith(f, [t, b]);
                    z && (g.trigger("ajaxComplete", [t, e]), --c.active || c.event.trigger("ajaxStop"))
                }
            }
            "object" === typeof a && (b = a, a = p);
            b = b || {};
            var e = c.ajaxSetup({}, b),
                f = e.context || e,
                g = f !== e && (f.nodeType || f instanceof c) ? c(f) : c.event,
                h = c.Deferred(),
                k = c._Deferred(),
                l = e.statusCode || {},
                m, q = {},
                n = {},
                r, u, w, A, y, C = 0,
                z, x, t = {
                    readyState: 0,
                    setRequestHeader: function(a, b) {
                        if (!C) {
                            var c = a.toLowerCase();
                            a = n[c] = n[c] || a;
                            q[a] = b
                        }
                        return this
                    },
                    getAllResponseHeaders: function() {
                        return 2 === C ? r : null
                    },
                    getResponseHeader: function(a) {
                        var b;
                        if (2 ===
                            C) {
                            if (!u)
                                for (u = {}; b = Wb.exec(r);) u[b[1].toLowerCase()] = b[2];
                            b = u[a.toLowerCase()]
                        }
                        return b === p ? null : b
                    },
                    overrideMimeType: function(a) {
                        C || (e.mimeType = a);
                        return this
                    },
                    abort: function(a) {
                        a = a || "abort";
                        w && w.abort(a);
                        d(0, a);
                        return this
                    }
                };
            h.promise(t);
            t.success = t.done;
            t.error = t.fail;
            t.complete = k.done;
            t.statusCode = function(a) {
                if (a) {
                    var b;
                    if (2 > C)
                        for (b in a) l[b] = [l[b], a[b]];
                    else b = a[t.status], t.then(b, b)
                }
                return this
            };
            e.url = ((a || e.url) + "").replace(Vb, "").replace(Zb, G[1] + "//");
            e.dataTypes = c.trim(e.dataType || "*").toLowerCase().split(Ga);
            null == e.crossDomain && (y = eb.exec(e.url.toLowerCase()), e.crossDomain = !(!y || y[1] == G[1] && y[2] == G[2] && (y[3] || ("http:" === y[1] ? 80 : 443)) == (G[3] || ("http:" === G[1] ? 80 : 443))));
            e.data && e.processData && "string" !== typeof e.data && (e.data = c.param(e.data, e.traditional));
            ba(ia, e, b, t);
            if (2 === C) return !1;
            z = e.global;
            e.type = e.type.toUpperCase();
            e.hasContent = !Yb.test(e.type);
            z && 0 === c.active++ && c.event.trigger("ajaxStart");
            if (!e.hasContent && (e.data && (e.url += (db.test(e.url) ? "&" : "?") + e.data), m = e.url, !1 === e.cache)) {
                y = c.now();
                var D = e.url.replace(bc, "$1_=" + y);
                e.url = D + (D === e.url ? (db.test(e.url) ? "&" : "?") + "_=" + y : "")
            }(e.data && e.hasContent && !1 !== e.contentType || b.contentType) && t.setRequestHeader("Content-Type", e.contentType);
            e.ifModified && (m = m || e.url, c.lastModified[m] && t.setRequestHeader("If-Modified-Since", c.lastModified[m]), c.etag[m] && t.setRequestHeader("If-None-Match", c.etag[m]));
            t.setRequestHeader("Accept", e.dataTypes[0] && e.accepts[e.dataTypes[0]] ? e.accepts[e.dataTypes[0]] + ("*" !== e.dataTypes[0] ? ", */*; q=0.01" : "") : e.accepts["*"]);
            for (x in e.headers) t.setRequestHeader(x, e.headers[x]);
            if (e.beforeSend && (!1 === e.beforeSend.call(f, t, e) || 2 === C)) return t.abort(), !1;
            for (x in {
                    success: 1,
                    error: 1,
                    complete: 1
                }) t[x](e[x]);
            if (w = ba(gb, e, b, t)) {
                t.readyState = 1;
                z && g.trigger("ajaxSend", [t, e]);
                e.async && 0 < e.timeout && (A = setTimeout(function() {
                    t.abort("timeout")
                }, e.timeout));
                try {
                    C = 1, w.send(q, d)
                } catch (F) {
                    2 > status ? d(-1, F) : c.error(F)
                }
            } else d(-1, "No Transport");
            return t
        },
        param: function(a, b) {
            var d = [],
                e = function(a, b) {
                    b = c.isFunction(b) ? b() : b;
                    d[d.length] = encodeURIComponent(a) +
                        "=" + encodeURIComponent(b)
                };
            b === p && (b = c.ajaxSettings.traditional);
            if (c.isArray(a) || a.jquery && !c.isPlainObject(a)) c.each(a, function() {
                e(this.name, this.value)
            });
            else
                for (var f in a) ja(f, a[f], b, e);
            return d.join("&").replace(Ub, "+")
        }
    });
    c.extend({
        active: 0,
        lastModified: {},
        etag: {}
    });
    var cc = c.now(),
        fa = /(\=)\?(&|$)|\?\?/i;
    c.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            return c.expando + "_" + cc++
        }
    });
    c.ajaxPrefilter("json jsonp", function(a, b, d) {
        b = "application/x-www-form-urlencoded" === a.contentType && "string" ===
            typeof a.data;
        if ("jsonp" === a.dataTypes[0] || !1 !== a.jsonp && (fa.test(a.url) || b && fa.test(a.data))) {
            var e, f = a.jsonpCallback = c.isFunction(a.jsonpCallback) ? a.jsonpCallback() : a.jsonpCallback,
                g = r[f],
                h = a.url,
                k = a.data,
                l = "$1" + f + "$2";
            !1 !== a.jsonp && (h = h.replace(fa, l), a.url === h && (b && (k = k.replace(fa, l)), a.data === k && (h += (/\?/.test(h) ? "&" : "?") + a.jsonp + "=" + f)));
            a.url = h;
            a.data = k;
            r[f] = function(a) {
                e = [a]
            };
            d.always(function() {
                r[f] = g;
                if (e && c.isFunction(g)) r[f](e[0])
            });
            a.converters["script json"] = function() {
                e || c.error(f + " was not called");
                return e[0]
            };
            a.dataTypes[0] = "json";
            return "script"
        }
    });
    c.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /javascript|ecmascript/
        },
        converters: {
            "text script": function(a) {
                c.globalEval(a);
                return a
            }
        }
    });
    c.ajaxPrefilter("script", function(a) {
        a.cache === p && (a.cache = !1);
        a.crossDomain && (a.type = "GET", a.global = !1)
    });
    c.ajaxTransport("script", function(a) {
        if (a.crossDomain) {
            var b, c = n.head || n.getElementsByTagName("head")[0] || n.documentElement;
            return {
                send: function(e, f) {
                    b = n.createElement("script");
                    b.async = "async";
                    a.scriptCharset && (b.charset = a.scriptCharset);
                    b.src = a.url;
                    b.onload = b.onreadystatechange = function(a, e) {
                        if (e || !b.readyState || /loaded|complete/.test(b.readyState)) b.onload = b.onreadystatechange = null, c && b.parentNode && c.removeChild(b), b = p, e || f(200, "success")
                    };
                    c.insertBefore(b, c.firstChild)
                },
                abort: function() {
                    if (b) b.onload(0, 1)
                }
            }
        }
    });
    var ta = r.ActiveXObject ? function() {
            for (var a in H) H[a](0, 1)
        } : !1,
        dc = 0,
        H;
    c.ajaxSettings.xhr = r.ActiveXObject ?
        function() {
            var a;
            if (!(a = !this.isLocal && Ha())) a: {
                try {
                    a = new r.ActiveXObject("Microsoft.XMLHTTP");
                    break a
                } catch (b) {}
                a = void 0
            }
            return a
        } : Ha;
    (function(a) {
        c.extend(c.support, {
            ajax: !!a,
            cors: !!a && "withCredentials" in a
        })
    })(c.ajaxSettings.xhr());
    c.support.ajax && c.ajaxTransport(function(a) {
        if (!a.crossDomain || c.support.cors) {
            var b;
            return {
                send: function(d, e) {
                    var f = a.xhr(),
                        g, h;
                    a.username ? f.open(a.type, a.url, a.async, a.username, a.password) : f.open(a.type, a.url, a.async);
                    if (a.xhrFields)
                        for (h in a.xhrFields) f[h] = a.xhrFields[h];
                    a.mimeType && f.overrideMimeType && f.overrideMimeType(a.mimeType);
                    a.crossDomain || d["X-Requested-With"] || (d["X-Requested-With"] = "XMLHttpRequest");
                    try {
                        for (h in d) f.setRequestHeader(h, d[h])
                    } catch (k) {}
                    f.send(a.hasContent && a.data || null);
                    b = function(d, h) {
                        var k, n, r, u, w;
                        try {
                            if (b && (h || 4 === f.readyState))
                                if (b = p, g && (f.onreadystatechange = c.noop, ta && delete H[g]), h) 4 !== f.readyState && f.abort();
                                else {
                                    k = f.status;
                                    r = f.getAllResponseHeaders();
                                    u = {};
                                    (w = f.responseXML) && w.documentElement && (u.xml = w);
                                    u.text = f.responseText;
                                    try {
                                        n =
                                            f.statusText
                                    } catch (z) {
                                        n = ""
                                    }
                                    k || !a.isLocal || a.crossDomain ? 1223 === k && (k = 204) : k = u.text ? 200 : 404
                                }
                        } catch (y) {
                            h || e(-1, y)
                        }
                        u && e(k, n, u, r)
                    };
                    a.async && 4 !== f.readyState ? (g = ++dc, ta && (H || (H = {}, c(r).unload(ta)), H[g] = b), f.onreadystatechange = b) : b()
                },
                abort: function() {
                    b && b(0, 1)
                }
            }
        }
    });
    var ka = {},
        z, K, ec = /^(?:toggle|show|hide)$/,
        fc = /^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i,
        N, Ja = [
            ["height", "marginTop", "marginBottom", "paddingTop", "paddingBottom"],
            ["width", "marginLeft", "marginRight", "paddingLeft", "paddingRight"],
            ["opacity"]
        ],
        ca, ua = r.webkitRequestAnimationFrame ||
        r.mozRequestAnimationFrame || r.oRequestAnimationFrame;
    c.fn.extend({
        show: function(a, b, d) {
            if (a || 0 === a) return this.animate(P("show", 3), a, b, d);
            d = 0;
            for (var e = this.length; d < e; d++) a = this[d], a.style && (b = a.style.display, c._data(a, "olddisplay") || "none" !== b || (b = a.style.display = ""), "" === b && "none" === c.css(a, "display") && c._data(a, "olddisplay", Ka(a.nodeName)));
            for (d = 0; d < e; d++)
                if (a = this[d], a.style && (b = a.style.display, "" === b || "none" === b)) a.style.display = c._data(a, "olddisplay") || "";
            return this
        },
        hide: function(a, b, d) {
            if (a ||
                0 === a) return this.animate(P("hide", 3), a, b, d);
            a = 0;
            for (b = this.length; a < b; a++) this[a].style && (d = c.css(this[a], "display"), "none" === d || c._data(this[a], "olddisplay") || c._data(this[a], "olddisplay", d));
            for (a = 0; a < b; a++) this[a].style && (this[a].style.display = "none");
            return this
        },
        _toggle: c.fn.toggle,
        toggle: function(a, b, d) {
            var e = "boolean" === typeof a;
            c.isFunction(a) && c.isFunction(b) ? this._toggle.apply(this, arguments) : null == a || e ? this.each(function() {
                var b = e ? a : c(this).is(":hidden");
                c(this)[b ? "show" : "hide"]()
            }) : this.animate(P("toggle",
                3), a, b, d);
            return this
        },
        fadeTo: function(a, b, c, e) {
            return this.filter(":hidden").css("opacity", 0).show().end().animate({
                opacity: b
            }, a, c, e)
        },
        animate: function(a, b, d, e) {
            var f = c.speed(b, d, e);
            if (c.isEmptyObject(a)) return this.each(f.complete, [!1]);
            a = c.extend({}, a);
            return this[!1 === f.queue ? "each" : "queue"](function() {
                !1 === f.queue && c._mark(this);
                var b = c.extend({}, f),
                    d = 1 === this.nodeType,
                    e = d && c(this).is(":hidden"),
                    l, m, n, p, r;
                b.animatedProperties = {};
                for (n in a) {
                    l = c.camelCase(n);
                    n !== l && (a[l] = a[n], delete a[n]);
                    m = a[l];
                    c.isArray(m) ? (b.animatedProperties[l] = m[1], m = a[l] = m[0]) : b.animatedProperties[l] = b.specialEasing && b.specialEasing[l] || b.easing || "swing";
                    if ("hide" === m && e || "show" === m && !e) return b.complete.call(this);
                    !d || "height" !== l && "width" !== l || (b.overflow = [this.style.overflow, this.style.overflowX, this.style.overflowY], "inline" === c.css(this, "display") && "none" === c.css(this, "float") && (c.support.inlineBlockNeedsLayout ? (m = Ka(this.nodeName), "inline" === m ? this.style.display = "inline-block" : (this.style.display = "inline", this.style.zoom =
                        1)) : this.style.display = "inline-block"))
                }
                null != b.overflow && (this.style.overflow = "hidden");
                for (n in a)
                    if (d = new c.fx(this, b, n), m = a[n], ec.test(m)) d["toggle" === m ? e ? "show" : "hide" : m]();
                    else l = fc.exec(m), p = d.cur(), l ? (m = parseFloat(l[2]), r = l[3] || (c.cssNumber[n] ? "" : "px"), "px" !== r && (c.style(this, n, (m || 1) + r), p *= (m || 1) / d.cur(), c.style(this, n, p + r)), l[1] && (m = ("-=" === l[1] ? -1 : 1) * m + p), d.custom(p, m, r)) : d.custom(p, m, "");
                return !0
            })
        },
        stop: function(a, b) {
            a && this.queue([]);
            this.each(function() {
                var a = c.timers,
                    e = a.length;
                for (b ||
                    c._unmark(!0, this); e--;)
                    if (a[e].elem === this) {
                        if (b) a[e](!0);
                        a.splice(e, 1)
                    }
            });
            b || this.dequeue();
            return this
        }
    });
    c.each({
        slideDown: P("show", 1),
        slideUp: P("hide", 1),
        slideToggle: P("toggle", 1),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function(a, b) {
        c.fn[a] = function(a, c, f) {
            return this.animate(b, a, c, f)
        }
    });
    c.extend({
        speed: function(a, b, d) {
            var e = a && "object" === typeof a ? c.extend({}, a) : {
                complete: d || !d && b || c.isFunction(a) && a,
                duration: a,
                easing: d && b || b && !c.isFunction(b) && b
            };
            e.duration =
                c.fx.off ? 0 : "number" === typeof e.duration ? e.duration : e.duration in c.fx.speeds ? c.fx.speeds[e.duration] : c.fx.speeds._default;
            e.old = e.complete;
            e.complete = function(a) {
                c.isFunction(e.old) && e.old.call(this);
                !1 !== e.queue ? c.dequeue(this) : !1 !== a && c._unmark(this)
            };
            return e
        },
        easing: {
            linear: function(a, b, c, e) {
                return c + e * a
            },
            swing: function(a, b, c, e) {
                return (-Math.cos(a * Math.PI) / 2 + .5) * e + c
            }
        },
        timers: [],
        fx: function(a, b, c) {
            this.options = b;
            this.elem = a;
            this.prop = c;
            b.orig = b.orig || {}
        }
    });
    c.fx.prototype = {
        update: function() {
            this.options.step &&
                this.options.step.call(this.elem, this.now, this);
            (c.fx.step[this.prop] || c.fx.step._default)(this)
        },
        cur: function() {
            if (null != this.elem[this.prop] && (!this.elem.style || null == this.elem.style[this.prop])) return this.elem[this.prop];
            var a, b = c.css(this.elem, this.prop);
            return isNaN(a = parseFloat(b)) ? b && "auto" !== b ? b : 0 : a
        },
        custom: function(a, b, d) {
            function e(a) {
                return f.step(a)
            }
            var f = this,
                g = c.fx,
                h;
            this.startTime = ca || Ia();
            this.start = a;
            this.end = b;
            this.unit = d || this.unit || (c.cssNumber[this.prop] ? "" : "px");
            this.now = this.start;
            this.pos = this.state = 0;
            e.elem = this.elem;
            e() && c.timers.push(e) && !N && (ua ? (N = !0, h = function() {
                N && (ua(h), g.tick())
            }, ua(h)) : N = setInterval(g.tick, g.interval))
        },
        show: function() {
            this.options.orig[this.prop] = c.style(this.elem, this.prop);
            this.options.show = !0;
            this.custom("width" === this.prop || "height" === this.prop ? 1 : 0, this.cur());
            c(this.elem).show()
        },
        hide: function() {
            this.options.orig[this.prop] = c.style(this.elem, this.prop);
            this.options.hide = !0;
            this.custom(this.cur(), 0)
        },
        step: function(a) {
            var b = ca || Ia(),
                d = !0,
                e = this.elem,
                f = this.options,
                g;
            if (a || b >= f.duration + this.startTime) {
                this.now = this.end;
                this.pos = this.state = 1;
                this.update();
                f.animatedProperties[this.prop] = !0;
                for (g in f.animatedProperties) !0 !== f.animatedProperties[g] && (d = !1);
                if (d) {
                    null == f.overflow || c.support.shrinkWrapBlocks || c.each(["", "X", "Y"], function(a, b) {
                        e.style["overflow" + b] = f.overflow[a]
                    });
                    f.hide && c(e).hide();
                    if (f.hide || f.show)
                        for (var h in f.animatedProperties) c.style(e, h, f.orig[h]);
                    f.complete.call(e)
                }
                return !1
            }
            Infinity == f.duration ? this.now = b : (a = b - this.startTime,
                this.state = a / f.duration, this.pos = c.easing[f.animatedProperties[this.prop]](this.state, a, 0, 1, f.duration), this.now = this.start + (this.end - this.start) * this.pos);
            this.update();
            return !0
        }
    };
    c.extend(c.fx, {
        tick: function() {
            for (var a = c.timers, b = 0; b < a.length; ++b) a[b]() || a.splice(b--, 1);
            a.length || c.fx.stop()
        },
        interval: 13,
        stop: function() {
            clearInterval(N);
            N = null
        },
        speeds: {
            slow: 600,
            fast: 200,
            _default: 400
        },
        step: {
            opacity: function(a) {
                c.style(a.elem, "opacity", a.now)
            },
            _default: function(a) {
                a.elem.style && null != a.elem.style[a.prop] ?
                    a.elem.style[a.prop] = ("width" === a.prop || "height" === a.prop ? Math.max(0, a.now) : a.now) + a.unit : a.elem[a.prop] = a.now
            }
        }
    });
    c.expr && c.expr.filters && (c.expr.filters.animated = function(a) {
        return c.grep(c.timers, function(b) {
            return a === b.elem
        }).length
    });
    var gc = /^t(?:able|d|h)$/i,
        hb = /^(?:body|html)$/i;
    c.fn.offset = "getBoundingClientRect" in n.documentElement ? function(a) {
        var b = this[0],
            d;
        if (a) return this.each(function(b) {
            c.offset.setOffset(this, a, b)
        });
        if (!b || !b.ownerDocument) return null;
        if (b === b.ownerDocument.body) return c.offset.bodyOffset(b);
        try {
            d = b.getBoundingClientRect()
        } catch (e) {}
        var f = b.ownerDocument,
            g = f.documentElement;
        if (!d || !c.contains(g, b)) return d ? {
            top: d.top,
            left: d.left
        } : {
            top: 0,
            left: 0
        };
        b = f.body;
        f = la(f);
        return {
            top: d.top + (f.pageYOffset || c.support.boxModel && g.scrollTop || b.scrollTop) - (g.clientTop || b.clientTop || 0),
            left: d.left + (f.pageXOffset || c.support.boxModel && g.scrollLeft || b.scrollLeft) - (g.clientLeft || b.clientLeft || 0)
        }
    } : function(a) {
        var b = this[0];
        if (a) return this.each(function(b) {
            c.offset.setOffset(this, a, b)
        });
        if (!b || !b.ownerDocument) return null;
        if (b === b.ownerDocument.body) return c.offset.bodyOffset(b);
        c.offset.initialize();
        var d, e = b.offsetParent,
            f = b.ownerDocument,
            g = f.documentElement,
            h = f.body;
        d = (f = f.defaultView) ? f.getComputedStyle(b, null) : b.currentStyle;
        for (var k = b.offsetTop, l = b.offsetLeft;
            (b = b.parentNode) && b !== h && b !== g && (!c.offset.supportsFixedPosition || "fixed" !== d.position);) d = f ? f.getComputedStyle(b, null) : b.currentStyle, k -= b.scrollTop, l -= b.scrollLeft, b === e && (k += b.offsetTop, l += b.offsetLeft, !c.offset.doesNotAddBorder || c.offset.doesAddBorderForTableAndCells &&
            gc.test(b.nodeName) || (k += parseFloat(d.borderTopWidth) || 0, l += parseFloat(d.borderLeftWidth) || 0), e = b.offsetParent), c.offset.subtractsBorderForOverflowNotVisible && "visible" !== d.overflow && (k += parseFloat(d.borderTopWidth) || 0, l += parseFloat(d.borderLeftWidth) || 0);
        if ("relative" === d.position || "static" === d.position) k += h.offsetTop, l += h.offsetLeft;
        c.offset.supportsFixedPosition && "fixed" === d.position && (k += Math.max(g.scrollTop, h.scrollTop), l += Math.max(g.scrollLeft, h.scrollLeft));
        return {
            top: k,
            left: l
        }
    };
    c.offset = {
        initialize: function() {
            var a =
                n.body,
                b = n.createElement("div"),
                d, e, f, g = parseFloat(c.css(a, "marginTop")) || 0;
            c.extend(b.style, {
                position: "absolute",
                top: 0,
                left: 0,
                margin: 0,
                border: 0,
                width: "1px",
                height: "1px",
                visibility: "hidden"
            });
            b.innerHTML = "<div style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;'><div></div></div><table style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;' cellpadding='0' cellspacing='0'><tr><td></td></tr></table>";
            a.insertBefore(b,
                a.firstChild);
            d = b.firstChild;
            e = d.firstChild;
            f = d.nextSibling.firstChild.firstChild;
            this.doesNotAddBorder = 5 !== e.offsetTop;
            this.doesAddBorderForTableAndCells = 5 === f.offsetTop;
            e.style.position = "fixed";
            e.style.top = "20px";
            this.supportsFixedPosition = 20 === e.offsetTop || 15 === e.offsetTop;
            e.style.position = e.style.top = "";
            d.style.overflow = "hidden";
            d.style.position = "relative";
            this.subtractsBorderForOverflowNotVisible = -5 === e.offsetTop;
            this.doesNotIncludeMarginInBodyOffset = a.offsetTop !== g;
            a.removeChild(b);
            c.offset.initialize =
                c.noop
        },
        bodyOffset: function(a) {
            var b = a.offsetTop,
                d = a.offsetLeft;
            c.offset.initialize();
            c.offset.doesNotIncludeMarginInBodyOffset && (b += parseFloat(c.css(a, "marginTop")) || 0, d += parseFloat(c.css(a, "marginLeft")) || 0);
            return {
                top: b,
                left: d
            }
        },
        setOffset: function(a, b, d) {
            var e = c.css(a, "position");
            "static" === e && (a.style.position = "relative");
            var f = c(a),
                g = f.offset(),
                h = c.css(a, "top"),
                k = c.css(a, "left"),
                l = {},
                m = {};
            ("absolute" === e || "fixed" === e) && -1 < c.inArray("auto", [h, k]) ? (m = f.position(), e = m.top, k = m.left) : (e = parseFloat(h) ||
                0, k = parseFloat(k) || 0);
            c.isFunction(b) && (b = b.call(a, d, g));
            null != b.top && (l.top = b.top - g.top + e);
            null != b.left && (l.left = b.left - g.left + k);
            "using" in b ? b.using.call(a, l) : f.css(l)
        }
    };
    c.fn.extend({
        position: function() {
            if (!this[0]) return null;
            var a = this[0],
                b = this.offsetParent(),
                d = this.offset(),
                e = hb.test(b[0].nodeName) ? {
                    top: 0,
                    left: 0
                } : b.offset();
            d.top -= parseFloat(c.css(a, "marginTop")) || 0;
            d.left -= parseFloat(c.css(a, "marginLeft")) || 0;
            e.top += parseFloat(c.css(b[0], "borderTopWidth")) || 0;
            e.left += parseFloat(c.css(b[0],
                "borderLeftWidth")) || 0;
            return {
                top: d.top - e.top,
                left: d.left - e.left
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var a = this.offsetParent || n.body; a && !hb.test(a.nodeName) && "static" === c.css(a, "position");) a = a.offsetParent;
                return a
            })
        }
    });
    c.each(["Left", "Top"], function(a, b) {
        var d = "scroll" + b;
        c.fn[d] = function(b) {
            var f, g;
            return b === p ? (f = this[0], f ? (g = la(f)) ? "pageXOffset" in g ? g[a ? "pageYOffset" : "pageXOffset"] : c.support.boxModel && g.document.documentElement[d] || g.document.body[d] : f[d] : null) : this.each(function() {
                (g =
                    la(this)) ? g.scrollTo(a ? c(g).scrollLeft() : b, a ? b : c(g).scrollTop()): this[d] = b
            })
        }
    });
    c.each(["Height", "Width"], function(a, b) {
        var d = b.toLowerCase();
        c.fn["inner" + b] = function() {
            var a = this[0];
            return a && a.style ? parseFloat(c.css(a, d, "padding")) : null
        };
        c.fn["outer" + b] = function(a) {
            var b = this[0];
            return b && b.style ? parseFloat(c.css(b, d, a ? "margin" : "border")) : null
        };
        c.fn[d] = function(a) {
            var f = this[0];
            if (!f) return null == a ? null : this;
            if (c.isFunction(a)) return this.each(function(b) {
                var f = c(this);
                f[d](a.call(this, b, f[d]()))
            });
            if (c.isWindow(f)) {
                var g = f.document.documentElement["client" + b];
                return "CSS1Compat" === f.document.compatMode && g || f.document.body["client" + b] || g
            }
            return 9 === f.nodeType ? Math.max(f.documentElement["client" + b], f.body["scroll" + b], f.documentElement["scroll" + b], f.body["offset" + b], f.documentElement["offset" + b]) : a === p ? (f = c.css(f, d), g = parseFloat(f), c.isNaN(g) ? f : g) : this.css(d, "string" === typeof a ? a : a + "px")
        }
    });
    r.jQuery = r.$ = c
})(window);