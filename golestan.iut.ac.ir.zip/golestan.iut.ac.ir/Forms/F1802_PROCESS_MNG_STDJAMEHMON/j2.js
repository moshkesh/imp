var HlpFldList = new Array();
var $ = $ ? $ : top.$;
//-----------------------------
function ShowDiv(DivObj, ParentObj) {
    AbsPos(ParentObj);
    DivObj.style.display = '';
    DivObj.style.left = ParentObj.al - DivObj.offsetWidth / 2.0 + ParentObj.offsetWidth / 2.0;
    DivObj.style.top = ParentObj.at + ParentObj.offsetHeight;

}
//---------------------------
var winid, term;
var Std = new Array();

function npCIndex(TD) {
    if (window.ActiveXObject && !top.SupportOldGolestan) {
        //TD.npCIndex=function(){
        return TD.cellIndex;
        //}
    }
    if (window.ActiveXObject && (top.SupportOldGolestan && !HTMLTableDataCellElement.prototype.cellIndex2)) {
        //HTMLTableDataCellElement.prototype.npCIndex=function(){
        return $(TD).prevAll("td:visible").length;
        // }
    }
    if (!window.ActiveXObject) {
        // TD.npCIndex=function(){
        return $(TD).prevAll("td:visible").length;
        // }
    }

}

function T01_onclick(event) {
    if (!window.ActiveXObject && !T01.eff_TR) {
        T01.eff_TR = function(event) {
            var element = this;
            var srcElement = event.srcElement || event.target;
            if (!srcElement) return null;
            if (srcElement.tagName == "TABLE") return null;
            if (srcElement.tagName == "TBODY") return null;
            o = srcElement;
            while (o.tagName != "TR")
                o = o.parentElement;
            return o;
        }
        T01.eff_TD = function(event) { //Effected Table Row
            var element = this;
            var srcElement = event.srcElement || event.target;
            o = srcElement;
            var t = o.tagName;
            if (t == "TABLE" || t == "TBODY" || t == "TR") return null;
            while (o.tagName != "TD")
                o = o.parentElement;
            return o;
        }
    }
    if (window.ActiveXObject)
        var TR = T01.eff_TR();
    else
        var TR = T01.eff_TR(event);
    if (!TR || TR.rowIndex == 0) return;
    /*		if(winid && !winid.closed){
    			alert('لطفا پنجره قبلي را ببنديد');
    			return;
    		}
    		Std[0] = F41151.value  ;
    		Std[1] = F41201.value  ;
    		Std[2] = F41251.value  ;
    		term   = TR.cells(1).innerText;
    		//parent.parent.Data.DataModi.FidTextBox.value='0;12325';
    		//winid=window.open('NewForm.htm',null,'fullscreen=yes',false);//;toolbar=no;menubar=no;status=no');
    */
    var Act = '';
    if (lvl & 2) Act = '80';
    try {

        if (window.ActiveXObject)
            var TD = T01.eff_TD();
        else
            var TD = T01.eff_TD(event);
        if (npCIndex(TD) == '15' && TD.innerText != '' && lvl & 32)
            Act = '15';
    } catch (e) {}
    if (Act == '') return;
    if (TR.cells[16].innerText == 1 && Act != '15') {
        if (!RegView.disabled) {
            RegView.click();
        }
    } else {
        TrmDetail(TR.cells[1].innerText, Act);
    }
}

function TrmDetail(termno, Act) {
    F43501.value = termno;
    F43501.UpdateSndData();
    window.parent.parent.Commander.act_data_frm(Act)
}

function SetDataLocation(URL, QueryStr) {
    try {
        if (!winid.frames[5] && winid.frames[5].document.readyState != "complete") {
            setTimeout("SetDataLocation('" + URL + "','" + QueryStr + "')", 100);
            return;
        }
        winid.frames[2].location = "../.." + URL + "&" + QueryStr;
    } catch (e) {
        setTimeout("SetDataLocation('" + URL + "','" + QueryStr + "')", 100);
    }
}

function SetLocToErrorPage() {
    try {
        if (!winid.frames[5] && winid.frames[5].document.readyState != "complete") {
            setTimeout("SetLocToErrorPage()", 100);
            return;
        }
        winid.frames[0].Form1.ExitTextBox.value = 'nx';
        winid.frames[0].location = "Error.htm";
        winid.frames[3].location = "Error.htm";
    } catch (e) {
        setTimeout("SetLocToErrorPage()", 100);
    }
    winid.close();
}
if (window.ActiveXObject) {
    var XmlSnd = new ActiveXObject("Microsoft.XMLDOM");
    XmlSnd.loadXML("<r/>");
} else {
    var XmlSnd = new DOMParser().parseFromString("<r/>", "text/xml");
    var s_MB = new XMLSerializer();
    var d_MB = XmlSnd.documentElement;
    XmlSnd.xml = s_MB.serializeToString(d_MB);
}
var CommImage = new Array(1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
var FrmFields = new Array(F41251);
var Fathers = new Array(); //'F41251','F01851','F01901','F01951');
var Sons = new Array(); //'F51851','F01901','F01951','F02001');

var ACT08 = new Array(F41251);
var ACT21 = new Array();
//var ACT22=new Array('F41151');
var ACT23 = new Array();
var ACT26 = new Array(F01851);
var ACT65 = new Array(F01851, F01901, F01951);

function window_onload() {
    if (window.parent.parent.Commander.document.readyState != "complete") {
        window.setTimeout("window_onload();", 10);
        return;
    }
    window.parent.parent.Commander.Form_BodyLoad();
    rows = parent.parent.document.body.rows;
    CostView.disable_Butt();
    SpcView.disable_Butt();
    OneCrsView.disable_Butt();
    RegView.disable_Butt();
    PreRegView.disable_Butt();
    Notes.disable_Butt();
    Personally.disable_Butt();
    //-----------------------------
    for (var i = 0; i < tblToolbar.rows[0].cells.length; i++) {
        var c = tblToolbar.rows[0].cells[i]
        c.width = parseInt(c.children[0].width) + 2;
        c.onmouseover = parent.parent.Commander.Hi;
        c.onmouseout = parent.parent.Commander.Lo;
        c.style.border = '1px solid white';
    }
    //-----------------------------
    window.setTimeout("OnFullScreen();", 200);
    //document.oncontextmenu=mycontext;
}

function mycontext() {
    return false;
}
if (window.ActiveXObject) {
    var TXML = new ActiveXObject("Microsoft.XMLDOM");
} else {
    var TXML;
}
if (!window.ActiveXObject) {
    function SimpleGridInit(params) {

        var element = params.element;
        var XMLText = params.XMLText,
            Tip = params.Tip,
            RowClassName = params.RowClassName,
            RowID = params.RowID;
        var Index = null;
        var nn, nod = null;
        if (!RowID || RowID == '') {
            if (TXML.parseFromString)
                TXML = TXML.parseFromString(XMLText, "text/xml");
            else {
                TXML = new DOMParser();
                TXML = TXML.parseFromString(XMLText, "text/xml");
            }
            _GTXML = TXML;
            fill(Tip, RowClassName, element);
        } else {

            var X = new DOMParser();
            X = X.parseFromString(XMLText, "text/xml")
            var r1 = TXML.documentElement,
                f1, r2 = X.documentElement;
            for (var i = 0; i < r1.childNodes.length; i++) {
                f1 = r1.childNodes[i].attributes.getNamedItem('F9990').value;
                for (var j = 0; j < r2.childNodes.length; j++) {
                    if (f1 == r2.childNodes[j].attributes.getNamedItem('F9990').value) {
                        if (window.ActiveXObject)
                            r2.childNodes[j].setAttribute('_iid') = i + 1;
                        else
                            r2.childNodes[j].setAttribute('_iid', i + 1);
                        try {
                            r2.childNodes[j].attributes.getNamedItem('id').value = i + 1;
                        } catch (e) {}
                    }
                }
            }
            _GTXML = X;
            fill(Tip, RowClassName, element);
        }
    };
    var l, _GTO = new Array();

    function fill(Tip, RowClassName, element) {
        l = _GTXML.childNodes[0].childNodes.length;
        _GI = 0;
        T01.CancelFill = CancelFill();
        CancelFill();
        _GCANCONTINUE = true;
        element.finish = false;
        _GTO[_GTO.length] = setTimeout(function() {
            ContinueFill(Tip, RowClassName, element);
        }, 1);
    }

    function ContinueFill(Tip, RowClassName, element) {
        if (_GI >= l || !_GCANCONTINUE) {
            element.finish = true;
            return;
        }
        var n = _GTXML.childNodes[0].childNodes[_GI],
            i;
        try {
            i = parseInt(n.attributes.getNamedItem('_iid').value);
        } catch (e) {
            i = _GI + 1
        }
        FillARow(n, i, Tip, RowClassName, element);
        _GI++;
        if (_GI > 25) {
            _GTO[_GTO.length] = setTimeout(function() {
                ContinueFill(Tip, RowClassName, element)
            }, 1);
        } else {
            ContinueFill(Tip, RowClassName, element);
        }
    }

    function CancelFill() {
        _GCANCONTINUE = false;
        for (var i = 0; i < _GTO.length; i++) {
            clearTimeout(_GTO[i]);
        }
        _GTO.length = 0;
    }

    function FillARow(XmlNode, RowNo, Tip, RowClassName, element) {
        var TD, ZCell, TR;
        var Tlen = element.rows.length - 1;
        var NewRow = false;
        if (Tlen < RowNo) {
            TR = element.insertRow();
            NewRow = true;
        } else
            TR = element.rows[RowNo];
        if (!RowClassName)
            TR.className = "TableDataRow";
        else
            TR.className = RowClassName;
        TR.style.display = '';
        var i = 0,
            xa = XmlNode.attributes;
        for (var j = 0; j < xa.length; j++) {
            if (xa[j].name == '_iid') continue;
            if (NewRow) TD = TR.insertCell();
            else TD = TR.cells[i];
            ZCell = element.rows[0].cells[i]; //Zero Row Cell Number i
            TD.className = ZCell.className;
            if (!window.ActiveXObject) {
                TD.style.borderLeftColor = "#fff";
                if (/^(\d+-)+\d+$/.test(xa[j].value))
                    xa[j].value = FixNumber(xa[j].value);

            }
            //TD.innerHTML='<NOBR>'+XmlNode.attributes(j).value+'</NOBR>';
            if (!top.SupportOldGolestan)
                TD.innerHTML = '<NOBR>' + xa[j].value.replace(/  /g, '&nbsp;&nbsp;') + '</NOBR>';
            else {
                var w = $(TD).width() - 2;
                TD.innerHTML = '<p style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:' + w + 'px;">' + xa[j].value.replace(/  /g, '&nbsp;&nbsp;') + '</p>';
            }

            if (TD.innerText != xa[j].value) {
                TD.innerHTML = xa[j].value;
            }
            if (Tip) {
                j++;
                if (j < xa.length)
                    TD.title = TD.innerText;
            } else
                TD.title = TD.innerText;

            TD.align = "right";
            i++;
            if (TD.innerHTML.indexOf("TEXT-ALIGN: left") != -1)
                TD.style.fontFamily = "tahoma";
        }
        try {
            AfterFillARow(TR)
        } catch (e) {}

    }

}
var ColList = new Array("id", "F4350", "F4455", "F4365", "CumGet", "F4370", "F4180", "CumPas", "F4390", "F4395", "F4375", "F4385", "F4360", "CumGPA", "F4415", "F6557", "F9076");
var Labels = new Array('F51851', 'F34501', 'F43301', 'F42401', 'F42451', 'F42371', 'F61151', 'F16451',
    'F17551', 'F41301', 'F41351', 'F41701',
    'F42191', 'F35431', 'F35461', 'F41801',
    /*تاريخ دفاع*/
    'F54421',
    'F51852', 'F42251', 'F61152', 'F38101', 'F38151', 'F38201', 'F38221', 'F65351', 'F35321', 'F35331',
    /*امتحان جامع*/
    'F51801', 'F38351', 'F38301', 'F38401', 'F38251',
    /*تسهيلات*/
    'F67301', 'F35601', 'F35651', 'F35411',
    /*رشته دوم*/
    'F21701', 'F21751', 'F21801', 'F21851', 'F21901', 'F21951', 'F21971', 'F22001', 'F41702', 'F41703',
    /*شعبه*/
    'F89831', 'E57991', 'G17541',
    /*واکسیناسیون*/
    'I3997', 'I3997_2');

function Get_Data() {
    var d = parent.parent.Data.document;
    switch (parent.parent.Data.DataModi.Fm_Action.value) {
        case "00":
            {
                if (F41251.value != '') {
                    F41251.Disable();
                    window.parent.parent.Commander.act_data_frm('08');
                }
                if (!window.ActiveXObject) {
                    $.each($("input", DivCrs), function(i, v) {
                        $(v).MBPrepare();
                        window.parent.parent.Commander.KeyEvents(v);
                    })
                }
                break;
            }
        case "08":
            {
                //CostView.disable_Butt();
                ent.style.display = '';
                SpcView.disable_Butt();
                OneCrsView.disable_Butt();
                RegView.disable_Butt();
                PreRegView.disable_Butt();
                Notes.disable_Butt();
                Personally.disable_Butt();
                CostView.disable_Butt();
                pic.style.display = "none";
                pic.style.left = T01Tit.offsetLeft;

                if (parent.Form_Title.stat.toUpperCase() == 'OK') {
                    lvl = parent.parent.Data.lvl;
                    T01.onclick = null;
                    T01.style.cursor = '';
                    if (lvl & 2) {
                        T01.onclick = T01_onclick;
                        T01.style.cursor = 'pointer';
                        SpcView.enable_Butt();
                        OneCrsView.enable_Butt();
                    }
                    if (lvl & 4) Personally.enable_Butt();
                    if (lvl & 8) Notes.enable_Butt();
                    if (lvl & 16) {
                        RegView.enable_Butt();
                        PreRegView.enable_Butt();
                    }
                    if (lvl & 32) {
                        T01.onclick = T01_onclick;
                        T01.style.cursor = 'pointer';
                        CostView.enable_Butt();
                    }
                    pic.src = PhotoInprog.src;
                    pic.style.display = "";
                    StdPhoto.src = "/_Templates/ShowStdPic/ShowStdPic.aspx" + "?" + Math.random();
                    showStdPhoto();
                }
                parent.parent.Commander.NextAct = '08';
                parent.parent.Commander.InitFrm();
                try {
                    /*F51851.value=parent.parent.Data.F51851;
                    if(F51851.value=='undefined')F51851.value='';*/
                    for (var i = 0; i < Labels.length; i++) {
                        var ss = (eval(Labels[i] + '.tagName') == 'INPUT') ? '.value' : '.innerHTML',
                            ti = eval(Labels[i] + '.ti'),
                            tidat = eval('parent.parent.Data.' + ti);
                        eval(Labels[i] + ss + "=parent.parent.Data." + Labels[i]);
                        if (Labels[i] == 'F51852') {
                            if (typeof(ti) != 'undefined' && tidat != '') {
                                eval(Labels[i] + ".title=parent.parent.Data." + ti);
                                eval(Labels[i] + '.style.textDecoration="underline";');
                            } else {
                                eval(Labels[i] + '.style.textDecoration="none";');
                            }
                        }
                        if (eval(Labels[i] + ss) == 'undefined')
                            eval(Labels[i] + ss + "=''");
                    }
                    if ($("#I3997_2", document).text() == '0') {
                        $("#__vac", document).removeClass('DisQual');
                    } else {
                        $("#__vac", document).addClass('DisQual');
                    }
                    F41352.innerText = parent.parent.Data.F41351;
                    //F61152.innerText=parent.parent.Data.F61151;
                } catch (e) {}
                if (F42251.innerText == 'ندارد') {
                    F42251.style.fontWeight = 'bold';
                    F42251.style.color = 'blue';
                    F42251.style.textDecoration = "underline";
                } else {
                    F42251.style.fontWeight = 'normal';
                    F42251.style.color = 'black';
                    F42251.style.textDecoration = "none";
                }

                if (!parent.parent.Data.T01XML) {
                    parent.parent.Data.T01XML = '<Root></Root>';
                }
                //alert(parent.parent.Data.T01XML);
                if (window.ActiveXObject) {
                    TXML.loadXML(parent.parent.Data.T01XML);
                } else {
                    TXML = new DOMParser().parseFromString(parent.parent.Data.T01XML, "text/xml");
                }
                var l = TXML.childNodes[0].childNodes.length;

                var TLength = T01.rows.length,
                    TR;
                for (i = 1; i < TLength; i++)
                    T01.deleteRow(TLength - i);
                for (i = 0; i < l; i++) {
                    XmlNode = TXML.childNodes[0].childNodes[i];
                    TR = T01.insertRow();
                    TR.className = "TableDataRow";
                    for (var j = 0; j < ColList.length; j++) {
                        TD = TR.insertCell();
                        TD.innerText = XmlNode.attributes.getNamedItem(ColList[j]).value;
                        TD.title = TD.innerText;
                        if ((j == 0 && lvl & 2) || (j == 15 && lvl & 32)) {
                            TD.style.textDecoration = "underline";
                            TD.style.color = 'red';
                            //TD.style.background="#CCC9EA";
                        }
                        if (j == 4 || j == 7 || j == 13) {
                            TD.className = 'Hi';
                            //TD.style.background="#CCC9EA";
                            //TD.style.color="#01DFF9";
                        }
                        if (!window.ActiveXObject)
                            TD.style.borderLeftColor = "#fff";
                    }
                    F41251.SetFocus();
                    setTimeout('F41251.scrollIntoView();', 200);

                    //TD=TR.insertCell();

                }
                try {
                    T01.rows[l - 1].scrollIntoView();
                } catch (e) {}
                //جدول دلايل منع ثبت نام
                var T02XML = parent.parent.Data.T02XML;
                if (!T02XML) T02XML = '<Root></Root>';

                var TLength = T02.rows.length,
                    TR;
                for (i = 1; i < TLength; i++) T02.rows[i].style.display = 'none';
                if (window.ActiveXObject)
                    T02.init(T02XML);
                else
                    SimpleGridInit({
                        XMLText: T02XML,
                        Tip: null,
                        RowClassName: null,
                        RowID: null,
                        element: T02
                    });

                //نظام فارغ التحصيلي
                if (F38101.innerText != '') {
                    TblFeraghat.style.display = '';
                } else {
                    TblFeraghat.style.display = 'none';
                }

                //if(F65351.innerText!=''){
                F43301.style.color = 'blue';
                F43301.style.fontWeight = 'bold';
                //F43301.style.border='1px dotted blue';
                F43301.style.textDecoration = "underline";
                F43301.style.cursor = 'pointer';
                F43301.onmouseover = function() {
                    ShowDiv(DivFeraghat, this);
                    /*var left=0,a=this;
                    while(a.tagName!='BODY'){left+=a.offsetLeft;a=a.offsetParent};
                    DivFeraghat.style.display = '';
                    DivFeraghat.style.left    = left - DivFeraghat.clientWidth/2;*/
                };
                F43301.onmouseout = function() {
                    DivFeraghat.style.display = 'none';
                };
                /*}
                else{
                	F43301.style.color='';
                	F43301.style.fontWeight='';
                	//F43301.style.border='';
                	F43301.style.textDecorationUnderline=false;
                	F43301.style.cursor='';
                	DivFeraghat.style.display = 'none';
                	F43301.onmouseover = null;
                	F43301.onmouseout = null;
                }*/

                //تغيير رشته
                if (parent.parent.Data.TaghResht == '0')
                    lblTaghResht.style.display = 'none';
                if (parent.parent.Data.TaghResht == '1')
                    lblTaghResht.style.display = '';

                // رشته دوم
                switch (parent.parent.Data.F35451) {
                    case '0':
                        {
                            multdep.style.visibility = 'hidden';
                            break;
                        }
                    case '1':
                        {
                            multdep.style.visibility = 'visible';
                            multdep.innerText = 'دو رشته اي داخل';
                            tblmultidep1.style.display = '';
                            tblmultidep1_2.style.display = '';
                            tblmultidep2.style.display = 'none';
                            break;
                        }
                    case '2':
                    case '3':
                        {
                            multdep.style.visibility = 'visible';
                            multdep.innerText = 'دو رشته اي خارج';
                            F21702.innerText = F21701.innerText;
                            F21752.innerText = F21751.innerText;
                            tblmultidep1.style.display = 'none';
                            tblmultidep1_2.style.display = 'none';
                            tblmultidep2.style.display = '';
                            break;
                        }
                    case '4':
                        {
                            multdep.style.visibility = 'visible';
                            multdep.innerText = 'دو وجهی';
                            tblmultidep1.style.display = '';
                            tblmultidep1_2.style.display = 'none';
                            tblmultidep2.style.display = 'none';
                            break;
                        }
                }
                F17551.title = F17551.innerText;
                Education_Help.style.display = "";
                break;
            }
        case "53":
            { //اطلاعات پرسنلي
                document.all.DIVFrameHelp.style.visibility = 'hidden';
                parent.parent.document.body.rows = '0,0,*,0,30';
                //alert();
                //DataFrame=5;//parent.parent.Data;
                //showHelp("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm");
                //window.open("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm",null,"menubar=no,status=no,toolbar=no,width=790,height=520,left=0,top=5,scrollbars=0");
                //a();
                document.all.FrameNewForm.style.width = document.body.clientWidth; //-14;
                document.all.FrameNewForm.style.height = document.body.clientHeight; //-14;
                document.all.FrameNewForm.style.left = 0; //5;
                document.all.FrameNewForm.style.top = 0; //2;
                if (window.ActiveXObject)
                    FrameNewForm.navigate("F1802_58_PROCESS_MNG_PERSONALLYMON_Bod.htm");
                else
                    FrameNewForm.src = "F1802_58_PROCESS_MNG_PERSONALLYMON_Bod.htm";

                break;
            }
        case "79":
        case "80":
        case "81":
            {
                document.all.DIVFrameHelp.style.visibility = 'hidden';
                parent.parent.document.body.rows = '0,0,*,0,30';
                //alert();
                //DataFrame=5;//parent.parent.Data;
                //showHelp("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm");
                //window.open("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm",null,"menubar=no,status=no,toolbar=no,width=790,height=520,left=0,top=5,scrollbars=0");
                //a();
                document.all.FrameNewForm.style.width = document.body.clientWidth; //-14;
                document.all.FrameNewForm.style.height = document.body.clientHeight; //-14;
                document.all.FrameNewForm.style.left = 0; //5;
                document.all.FrameNewForm.style.top = 0; //2;
                if (window.ActiveXObject)
                    FrameNewForm.navigate("F1802_56_PROCESS_MNG_STDTRMMON_Bod.htm");
                else
                    FrameNewForm.src = "F1802_56_PROCESS_MNG_STDTRMMON_Bod.htm";


                break;
            }
        case "14":
        case "15":
        case "16":
            {
                document.all.DIVFrameHelp.style.visibility = 'hidden';
                parent.parent.document.body.rows = '0,0,*,0,30';
                document.all.FrameNewForm.style.width = document.body.clientWidth; //-14;
                document.all.FrameNewForm.style.height = document.body.clientHeight; //-14;
                document.all.FrameNewForm.style.left = 0; //5;
                document.all.FrameNewForm.style.top = 0; //2;
                if (window.ActiveXObject)
                    FrameNewForm.navigate("F1802_57_PROCESS_MNG_STDTRMTUTMON_Bod.htm");
                else
                    FrameNewForm.src = "F1802_57_PROCESS_MNG_STDTRMTUTMON_Bod.htm";

                break;
            }
        case "70":
            {
                document.all.DIVFrameHelp.style.visibility = 'hidden';
                parent.parent.document.body.rows = '0,0,*,0,30';
                //alert();
                //DataFrame=5;//parent.parent.Data;
                //showHelp("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm");
                //window.open("F1803_54_PROCESS_MNG_STDTRMMON_Bod.htm",null,"menubar=no,status=no,toolbar=no,width=790,height=520,left=0,top=5,scrollbars=0");
                //a();
                document.all.FrameNewForm.style.width = document.body.clientWidth; //-14;
                document.all.FrameNewForm.style.height = document.body.clientHeight; //-14;
                document.all.FrameNewForm.style.left = 0; //5;
                document.all.FrameNewForm.style.top = 0; //2;
                if (window.ActiveXObject)
                    FrameNewForm.navigate("F1802_55_GrdCrsTypeMode.htm");
                else
                    FrameNewForm.src = "F1802_55_GrdCrsTypeMode.htm";
                break;
            }
        case "90":
            {
                if (parent.parent.Data.ErrorDSC.length == 0) {
                    var QueryStr = "fa=" + Std[0] + "&fl=" + Std[1] + "&td=" + Std[2] + "&trm=" + term;
                    SetDataLocation(parent.parent.Data.NewFrmURL, QueryStr);
                } else {
                    SetLocToErrorPage();
                }
                break;
            }
    }
}

function OnFullScreen(FullScreen) {
    var r = parent.parent.document.body.rows.split(',');
    if (r[r.length - 2] == 0) return;
    var o, top = T01Div.offsetTop;
    o = T01Div.offsetParent;
    while (o.tagName != 'BODY') {
        top += o.offsetTop;
        o = o.offsetParent;
    }
    var h = document.body.clientHeight - top - tblOverall.offsetHeight;
    h = (h > 0) ? h : 5;
    T01Div.style.height = h;
    //    T01Div.style.height =  tblOverall.offsetTop - top;
    rows = parent.parent.document.body.rows;
}

function ClearContent() {
    for (var i = 0; i < Labels.length; i++) {
        eval(Labels[i] + ".innerText=''");
    }
    var l = T01.rows.length;

    for (i = 1; i < l; i++) {
        T01.deleteRow(1);
    }
    pic.src = PhotoInprog.src;
    pic.style.display = "none";
    lblFeraghat.style.display = 'none';
    lblTaghResht.style.display = 'none';
    Education_Help.style.display = 'none';

    CostView.disable_Butt();
    SpcView.disable_Butt();
    OneCrsView.disable_Butt();
    RegView.disable_Butt();
    PreRegView.disable_Butt();
    Notes.disable_Butt();
    Personally.disable_Butt();
    ent.style.display = 'none';
    multdep.style.visibility = 'hidden';
}

function AfterClickedHelp(FieldLists) {
    var f = FieldLists.substring(0, 6);
    if (f == 'F41251') {
        var t = F41251.value;
        ClearContent();
        F41251.value = t;
        F41251.UpdateSndData();
        F41251.FocusNext();
        HlpFldList = new Array();
    }
}

//مربوط به تصاوير
var NoPhoto = new Image();
NoPhoto.src = "/_Images/nophoto.gif";
var PhotoInprog = new Image();
PhotoInprog.src = "/_Images/PhotoInprogress.gif";
var StdPhoto = new Image();

function showStdPhoto() {
    if ((window.ActiveXObject && StdPhoto.readyState != 'complete') || (!window.ActiveXObject && !StdPhoto.complete)) {
        setTimeout("showStdPhoto();", 50);
        return;
    }
    pic.src = StdPhoto.src;
}
//----------
function a() {
    if (w.document.readyState != 'complete') {
        setTimeout("a()", 10);
        return;
    }
    w.Get_Data();
}
var ver = 3;

function AbsPos(o, r) {
    if (!r) r = document.body;
    var left = 0,
        top = 0,
        a = o;
    while (a && a != r) {
        left += a.offsetLeft + a.clientLeft;
        top += a.offsetTop + a.clientTop;
        a = a.offsetParent;
    }
    o.al = left;
    o.at = top;
}

function Put_Data() {
    parent.parent.Data.document.cookie = 'stdno=' + F41251.value + "; path=/";
    parent.parent.Data.document.cookie = 'sno=' + F41251.value + "; path=/";
}